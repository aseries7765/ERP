# FINAL-MERGE-REPORT.md — Sisoft ERP Canonical Consolidation

Zip: `SISOFT-CANONICAL-MERGED-100M-MULTI-ERP.zip`
SHA-256: `e0a76a4e1783bcbe5688982afb4fb6612b502365110b5b0dfef429e121b4a1be`
Files in final tree: 2226

This report follows the original brief's §30 question list directly. Per §31, it does not optimize for "everything is complete" — it says plainly what is done, what is merged-but-unverified, and what remains blocked.

---

## Fifth merge pass (2026-09-19) — HandoffModule actually fixed, not just excluded

Rather than leave `HandoffModule` as a documented gap, went back and wired it for real — its underlying `HandoffTokenService` is genuinely well-built (hand-rolled RS256 JWT sign/verify with real single-use/expiry enforcement, zero third-party deps, already has passing tests) and only needed real adapters for its 3 non-primitive dependencies:

- **`TenantEnvRegistryService`** (new) implements `EnvRegistryLookup` against the actual `Tenant` model — `isCustomerActive` checks the real `status`/`deletedAt` fields; `getEnvUrlForCustomer` reads `metadata.environmentUrl`. Documented honestly: no code anywhere in this tree currently *writes* that metadata field (no tenant-provisioning flow exists yet — consistent with the "no control-plane HTTP service" gap already noted in `docs/architecture/MULTI-ERP-CONTROL-PLANE.md`), so this will correctly return "not found" for every real tenant today. That's accurate, not fabricated.
- **`HandoffAuditAdapter`** (new) wraps the real, already-registered, hash-chained `AuditService` instead of a no-op — maps the 3 real call sites' event data onto `AuditRecordInput`, drops (with a logged error) the one theoretical case where no tenant id is present in the event data, rather than writing a bogus tenant id into the audit chain.
- **`InMemoryJtiStore`** — left as-is. This was the *original* author's own explicit, documented single-instance stand-in ("DO NOT use in production... multiple API instances would each have their own store"), not something this merge invented. Fabricating a Redis-backed replacement with no Redis to test it against would be worse than keeping the honest, working, already-tested stand-in.
- RSA keypair and portal URL now come from `HANDOFF_RSA_PRIVATE_KEY_PEM` / `HANDOFF_RSA_PUBLIC_KEY_PEM` / `HANDOFF_PORTAL_URL` (added to `.env.example`), required and thrown-on-missing via a factory provider (`HandoffTokenService` can't be bare-DI-wired — its constructor takes plain values/interfaces — so it's constructed explicitly in `handoff.module.ts`'s `useFactory`).

**`HandoffModule` is re-registered in `AppModule`.** Full-tree import re-scan and syntax balance check both clean afterward. `DocumentsModule` remains unregistered — its gap (7+ full repository implementations) is a materially larger, riskier piece of net-new logic than Handoff's 3 small adapters, and stays the clearest well-scoped next-step item.

## Fourth merge pass (2026-09-19) — continued from NEXT-STEPS #0, systematic DI audit

Picked up the worker-side gap noted in the previous pass and kept going with a full constructor-level audit of every module registered in `app.module.ts` — not just the ones added this session.

- **Built the `EventOutbox` consumer** (`apps/worker/src/jobs/outbox-dispatcher.ts`, new): claims `PENDING` rows atomically (using the `lockedAt`/`lockedBy` columns already in the schema but never used by any code until now), dispatches to a pluggable per-eventType handler registry, and does real retry/backoff/dead-lettering. Honestly, **no handler is registered for any event type yet** — rather than fake a "delivered" notification, unhandled rows are logged and left `PENDING` so the gap stays visible. Declared `@prisma/client` as a dependency in `apps/worker/package.json` (it had zero dependencies declared before).
- **Fixed `HisPatientModule`'s unbound tokens** — its own doc comment said `PRISMA_CLIENT` and `PII_ENCRYPTION_KEY` must be bound "at the app.module.ts level," which had never been done despite the module being registered in a previous pass. It would have failed NestJS dependency resolution at boot. Bound `PRISMA_CLIENT` to `PrismaService.db` (the tenant-scoping-extended client, not a raw one — so HIS patient data gets the same RLS/tenant protections as everything else) and `PII_ENCRYPTION_KEY` to a factory that reads `HIS_PII_ENCRYPTION_KEY` from the environment, decodes it as base64 (a convention the original slice explicitly left for "the merge captain" to choose and document), validates it's exactly 32 bytes, and throws rather than booting with no encryption key. Appended both this var and `HIS_DEFAULT_FACILITY_MRN_CODE` to the real root `.env.example` (the source archive's own `his.env.example` said to append them there; this had never been done either).
- **Found and fixed a dangling reference**: a previous pass's edit removed the `TerminologyModule` *import* from `app.module.ts` but left `TerminologyModule,` in the actual `@Module({ imports: [...] })` array — a real compile error (`Cannot find name 'TerminologyModule'`) that had gone unnoticed. Fixed.
- **Found two modules that would have crashed the entire app at boot**, not just failed gracefully, despite each carrying a comment claiming otherwise:
  - **`DocumentsModule`**: `DocumentService` and others inject `DocumentRepository`, `BlobRefRepository`, `DocumentEventEmitter`, and 6 more tokens that are never bound as providers in `documents.module.ts`. The module's own comment claims this is "the correct fail-closed behavior... not a bug," framing it as a per-request `PermissionGuard` failure — but NestJS resolves a module's constructor graph eagerly at bootstrap, so `DocumentService` alone would throw `Nest can't resolve dependencies` and prevent the *entire application* from starting, not just this module. Verified this by reading `DocumentService`'s actual constructor, not by trusting the comment. All 8 backing Prisma models (`Document`, `DocumentVersion`, `Folder`, `FileTag`, `FileShare`, `SignatureRequest`, `Signature`, `OcrResult`) do exist in the schema — so this is real, well-scoped future work (Prisma-backed repositories + an RBAC binding + an OCR queue binding), just too much net-new, compiler-unverified logic to author blind in this environment for something that handles PII/document encryption/legal holds. **Unregistered from `AppModule`** (left in `tsconfig` — its own code has no broken imports and would typecheck fine; the gap is purely DI wiring).
  - **`HandoffModule`**: `HandoffTokenService` is `@Injectable()` but its constructor takes `privateKeyPem: string, publicKeyPem: string, jtiStore: JtiStore, envRegistry: EnvRegistryLookup, audit: HandoffAudit, portalUrl: string` — plain strings and TypeScript interfaces, none of which NestJS can resolve via reflection (interfaces erase at runtime; primitives aren't valid DI tokens without explicit `@Inject()` decorators, which aren't present). This class was clearly designed for manual construction via a factory, not bare `providers: [HandoffTokenService]` auto-wiring. **Unregistered from `AppModule`.**
- **Verified clean** (full constructor audit, not just import-resolution) after the above: `AiModule` (5 services + 1 guard — all constructors resolve against the module's own providers or `HttpModule`), `SyncModule` (`ConflictResolverService` uses `@Optional()` with a default), `PortalAuthModule` (`PortalMfaService` has no constructor at all), `EmployeeModule` (14 providers checked individually — `PrismaService` now global, `@InjectQueue` tokens registered via the module's own `BullModule.registerQueue`, which correctly shares the connection `QueueModule`'s already-registered `BullModule.forRootAsync` establishes elsewhere in the graph, `@Optional()` cache dependency, `Reflector` is NestJS-core-provided), `HisPatientModule` (all 4 services checked — every `@Inject(TOKEN)` matches a token bound in the module's own provider factories).
- Found (documentation-only, not boot-critical) `EMPLOYEE_PII_MASTER_KEY` is required by `PiiEncryptionService` but wasn't in `.env.example` — added, with a note that it fails at first use rather than at boot (so it wasn't caught by the boot-crash audit above).

**Registered module set is now**: `AiModule, PortalAuthModule, SyncModule, EmployeeModule, HisPatientModule` (5, down from the previous pass's 8 — `DocumentsModule` and `HandoffModule` removed for the boot-crash reasons above). Full-tree import re-scan: zero broken imports remain outside the modules already excluded from the build.

## Third merge pass (2026-09-19) — the NEXT-STEPS.md #0 item, actually fixed

The previous report listed `apps/api/src/events/event-bus.service.ts` as the highest-priority pre-existing gap in Stage 61 itself. Rather than leave it for later, it was authored for real this pass:

- **`EventBusService`** (`apps/api/src/events/event-bus.service.ts`, new) implements the exact `publish(channel, eventType, payload)` contract all 4 real call sites use, writing to the existing `EventOutbox` Prisma model (tracked since Stage 40, never previously written to by any code in the tree) — the transactional-outbox pattern this codebase's own docs already describe elsewhere, rather than an in-memory event emitter that wouldn't survive a crash. It requires `payload.tenantId` and throws rather than writing an unowned row — consistent with this codebase's own fail-closed convention (see Stage 65-71). **Not compiled or tested** — no working TypeScript toolchain in this environment; field names were checked by hand against `prisma/schema.prisma`, not verified by `tsc`. No outbox consumer exists yet in `apps/worker`; rows will accumulate as PENDING until one is built.
- Writing it surfaced a **real pre-existing bug**: `DsrNotificationService.sendDeadlineReminder(requestId, daysRemaining)` never accepted or forwarded a `tenantId`, even though its only caller (`DsrDeadlineCheckJob`) already has `request.tenantId` in scope two lines away. Fixed: added the parameter and updated the one call site.
- **`EventsModule`** (new) provides `EventBusService` via standard NestJS DI, following the same shape as the existing `PrismaModule`/`AuditModule`.
- Wiring `EventsModule` into the three consuming feature modules (`RetentionModule`, `ComplianceModule`, `DsrModule`) surfaced a second, larger pre-existing bug: **`PrismaModule` is missing its `@Global()` decorator**, even though another file in the same codebase (`modules/tenancy/tenancy.module.ts`) has a comment explicitly saying "PrismaModule, which is @Global() ... see prisma.module.ts's comment" — a comment that doesn't exist in `prisma.module.ts`. Only 10 of 36 `apps/api/src/modules/*` explicitly import `PrismaModule`; every other one injecting `PrismaService` directly would fail NestJS dependency resolution at boot without this. **Fixed**: restored `@Global()` on `PrismaModule`, with the evidence cited above documented inline.
- **Corrected a false positive from the previous session's report**: `workflow/services/action.service.ts`'s reference to a notifications service is inside a commented-out line (`// import { NotificationsService } ...`), not a live import. It was never actually broken; an earlier regex-based scan matched inside the comment. Confirmed by reading the file directly, not re-guessed.
- Full-tree re-scan (with commented-out import lines now correctly excluded) confirms **zero broken imports remain in any module that is registered/compiled** — the only 65 remaining broken imports are entirely within the 6 modules already excluded from `app.module.ts` and `tsconfig`/`tsconfig.build.json` (`terminology`, `notifications`, `settings`, `control-plane`, `accounting`, the unregistered `modules/audit`).

## Second merge pass (2026-09-19) — Stages 62-71

10 new archives supplied (Stage 62-71: observability/SLO, distributed rate-limiting, capacity/autoscaling/multi-region, shard routing, cross-shard consistency, global control-plane, global identity federation, global authz policy distribution, global config/feature flags, global secrets/key management). Unlike Stages 40-61, these are **not full-repo snapshots** — each is a small cumulative bundle of docs + JSON policy configs + Python gate-verification scripts (75-114 files each), confirmed by inspection before assuming otherwise.

**Merged in**: 21 new `docs-STAGE*.md` files, 8 new `config/*.json` policy schemas (new top-level `config/` directory), 10 new gate-verification scripts (2 root-placed for Stage 62-63, 8 in `scripts/` for Stage 64-71 — placement determined by reading each script's own `ROOT = Path(__file__).resolve()...` logic, not guessed).

**Bug found and fixed in this pass — my own, from the previous session**: an earlier reorganization moved every `docs-STAGE*.md` into `docs/stages/` for tidiness. That broke every one of the 10 new gate scripts (and would have broken all 30+ prior ones too, on re-run) because they all hardcode a flat-repo-root path to their own evidence doc. Reverted the reorganization — all stage docs are back at repo root. Also found Stage 63's script requires a literal "Stage 64" string in `NEXT-STEPS.md`; added truthfully (Stage 64 does exist in this merge).

**Result**: all 10 new gate scripts, plus a spot-check of 4 of the original 22 (Stage 55/58/60/61), now report genuine STATIC PASS with correctly-preserved BLOCKED runtime status. No gate logic was modified or weakened — only file placement and one truthful doc addition.

`docs/architecture/100M-SCALE-ARCHITECTURE.md` and `MULTI-ERP-CONTROL-PLANE.md` (written in the first pass) were updated to reflect that Tier 2-4 sharding/control-plane/identity/config/secrets now have written design contracts — while being explicit that none of it is executable code yet.

## What archives were supplied?

23 archives across two upload batches:
- `ERP-MERGED-AUDITED-20260917.zip` — a wide, 30-package/35-module lineage, no runtime verification evidence of its own.
- `ERP-STAGE40` through `ERP-STAGE61` (Stage 52 never supplied as its own file) — a narrower, 6-package/22-module lineage where every stage from 41 onward carries a documented static/runtime verification gate.
- `his-1-patient-core-slice-VERIFIED-20260917200119.zip` — Hospital Information System, patient core.
- `his-2-ancillary-clinical-20260918-040401.zip` — HIS ancillary clinical (lab, radiology, blood bank, pharmacy).

Full per-archive breakdown, including 5 archives with non-standard internal wrapper folders (`erp_work48`, `erp_work50`, `erp_work55`, `erp_work55-stage58`, `stage58` — the last name reused by both Stage 59 and Stage 61), is in `MERGE-INVENTORY.md`.

## Which stages were identified?

Stages 40–51, 53–61 by direct archive inspection. Stage 52 was identified only indirectly, through doc file names (`docs-STAGE52-*.md`) bundled inside Stage 55's archive — its own zip was never uploaded, so its actual code delta could not be verified against source. This gap is recorded, not papered over, in `STAGE-RECONCILIATION.md`.

## Which code was merged?

- Canonical base: the Stage 61 snapshot (most recent, most verified), wrapper folder stripped.
- 12 `apps/api/src/modules/*` ported from the wide lineage that had no counterpart in Stage 61: `accounting, ai, audit, control-plane, documents, employee, handoff, notifications, portal-auth, settings, sync, terminology`.
- 24 `packages/*` ported that had no counterpart in Stage 61 (`ai-client, ai-prompts, backup-engine, barcode-engine, billing-engine, branding-engine, canary-engine, cloud-provider, cloud-provider-oracle, compliance-engine, control-plane-client, deployment-engine, form-builder, gantt-engine, gl-engine, m6-billing-invoicing-core, mrp-engine, provisioning-engine, quality-engine, sales-pipeline-engine, sync-crdt, terminology, uom-engine, version-engine`), bringing the package count from 6 to the full 30.
- `infra/` (Helm charts, Postgres config, security-hardening) and `tools/` (chaos engineering, pentest, security scanning) — entirely absent from Stage 61, merged wholesale.
- `.devcontainer/`, `.github/workflows/`, `docker-compose.yml`, `Makefile`, `.gitignore` — present in the wide lineage, absent from Stage 61.
- HIS-1: `packages/his-core`, `apps/api/src/modules/his-patient`, its test suite, and `his-core-clinical-models.prisma` (standalone, not spliced into the main schema).
- HIS-2: `packages/{lab,radiology,blood-bank,pharmacy}-engine` and a documented (not applied) schema sketch.

## Which code was superseded?

Nothing was deleted or overwritten. Every merge was additive: files were copied into the canonical tree only where no existing file occupied that path. Where the same domain existed in both lineages (Finance/GL, HR, Payroll, Purchase, Sales, Inventory, Projects, Manufacturing, CRM, Billing, Compliance — all already implemented in Stage 61 as `apps/api/modules`), the Stage 61 version was kept and the wide lineage's parallel `packages/*-engine` implementation of the same domain was merged in *alongside* it as a library, not used to replace it — see the finance/GL and billing cases below.

## Which conflicts were found?

1. **The lineage fork itself** — two codebases sharing one package identity (`erp-system@1.0.0-merged`) but diverging after Stage 40. Root-caused with evidence (module-list diffs, schema model-count comparison, grep checks for cross-references) rather than resolved by filename recency. Full writeup: `MERGE-DECISIONS.md` Decision 1.
2. **`gl-engine` vs. the `finance` module** — grep-confirmed the Stage 61 `finance.service.ts` (798 lines) reimplements journal posting/reversal/trial-balance logic inline against Prisma directly, and does *not* import `gl-engine`. Both were kept: `gl-engine` as an available library, `finance.service.ts` unchanged. This is a real code-quality gap (duplicate logic, one path untested against the other) — noted in Next Steps, not silently resolved by deleting either.
3. Same pattern held (checked via `grep`, zero NestJS decorators found) for `billing-engine, compliance-engine, sales-pipeline-engine, mrp-engine, gantt-engine, m6-billing-invoicing-core` against their same-domain `apps/api/modules` counterparts — all are pure calculation/algorithm libraries with test suites, not competing controller/service wiring. No collisions on merge.
4. **Four instances of an empty literal-brace directory** (`{a,b,c,d}` never expanded by whatever produced the zips) across three independently-dated archives — `HIS-2/packages/{...}`, Lineage A's `infra/security-hardening/{...}`, `lab-engine/src/{...}`, `pharmacy-engine/src/{...}`, and HIS-1's `his-patient/{...}`. Each was diffed against its real counterpart, confirmed empty (0 files), and discarded. This recurring pattern across independently-dated sources points to a systemic bug in the upstream packaging pipeline, worth fixing at the source rather than just cleaning up per-archive.
5. **Stage 49 and Stage 51 filenames appeared twice** in the original upload list — verified these were duplicate *references* to the same file, not two different files with the same name; no actual conflict.

## How were conflicts resolved?

Per the project's own rule (§3, §27): documented in `MERGE-DECISIONS.md` rather than silently chosen, and only acted on once there was file-level evidence (grep for cross-references, diff for content equality, model-count comparison against the Prisma schema) — not assumed from directory names or stage numbers alone.

## What database changes are present?

None applied. `prisma/schema.prisma` is unchanged from Stage 61 (193 models, verified by count before and after merge — see sanity check in this session). The two HIS Prisma files were copied as standalone reference files, explicitly *not* spliced into the live schema, because doing so without a real database to validate the result against would mean fabricating a migration — exactly what every Stage 40-61 document refuses to do, and what this pass refuses to do too. HIS-2's own schema file is documented by its source as a sketch, not a real implementation (no relations, no indexes, no tenant scoping).

## What ERP modules are present?

34 `apps/api/src/modules`: the original Stage 61 set (analytics, auth, billing, compliance, consent, crm, dashboards, dsr, finance, hr, inventory, kpi, manufacturing, payroll, privacy, projects, purchase, rbac, reports, retention, sales, tenancy, workflow) plus the 12 newly-merged modules plus `his-patient`. All 30 supporting `packages/*` are present per the manifest.

## What security controls are present?

Everything Stage 61 already had (RBAC, RLS per `docs/db/RLS.md`, JWT auth per `docs/security/AUTHENTICATION.md`), plus the wide lineage's `docs/security/*` (30+ files: OWASP Top 10 coverage docs, threat model, incident-response playbooks, PCI/SOC2/ISO27001/HIPAA control mappings) and `tools/security/*` (SAST, DAST, dependency-scan, container-scan, secret-scan, SBOM, signing) and `tools/pentest/*` — all merged in, none of it executed in this pass (no network, no target environment).

## What is the multi-tenant architecture?

Unchanged from what already existed: tenant-scoped Prisma models with `tenantId` columns, PostgreSQL RLS as the enforcement layer (per `docs/db/RLS.md` and `docs/db/MULTI_TENANCY.md`, inherited unchanged — 0 new files added on the docs merge, confirming both lineages already agreed on this). Not independently re-verified this pass — no database available.

## What is the multi-ERP architecture?

Described in `docs/architecture/MULTI-ERP-CONTROL-PLANE.md` (written this pass, grounded in what's actually in the tree): Customer → Subscription → ERP Instance → Tenant → Users, using the pre-existing `docs/modules/tenancy/MULTI_COMPANY.md` and `PROVISIONING.md`. The control-plane *packages* (`control-plane-client`, `provisioning-engine`, etc.) exist; a running control-plane *service* does not — confirmed by their absence from every `apps/` folder in any supplied archive.

## What is the 100M+ scalability strategy?

Described in `docs/architecture/100M-SCALE-ARCHITECTURE.md` (written this pass) as a 4-tier model. Tier 1 (single cluster) is achievable with what exists today, pending the same runtime verification every Stage 41-61 doc already lists as blocked. Tiers 2-4 (read replicas, partitioning, sharding, multi-region) have **no implementation in any supplied archive** — this is stated plainly rather than dressed up as "prepared for."

## What is the Oracle/provider abstraction?

`packages/cloud-provider` (interface) + `packages/cloud-provider-oracle` (the one concrete implementation present). Grep-confirmed no `apps/` code imports `cloud-provider-oracle` directly — the abstraction boundary is intact. AWS/Azure/GCP/private-infra implementations do not exist in any supplied archive.

## What remains blocked?

Every item Stage 41-61 already listed as BLOCKED remains blocked in this container for the identical reason (no network, no PostgreSQL, no Redis, no Docker) — full table in `STAGE-RECONCILIATION.md`. Additionally confirmed this pass: **no `pnpm-lock.yaml` exists in any of the 23 supplied archives** (Stage 60's own finding, E60-001) — this blocks real dependency installation independent of this container's limitations, and was not fabricated here either.

## What was statically verified?

This pass, directly: package manifest presence across all 35 packages; zero leftover packaging-artifact directories after cleanup; `prisma/schema.prisma` model count unchanged (193) before/after merge; grep-confirmed no pre-existing Stage 61 module imports any of the packages that were held for conflict review, and confirmed the reverse (the newly-added `accounting` and `sync` modules do import `gl-engine` and `sync-crdt` respectively — those two packages are load-bearing, not orphaned). Every Stage 41-61 static gate result as documented by its own source file — not re-run, but not altered either.

## What was runtime verified?

Nothing, in this pass or in any of the 23 supplied archives. Every stage from 41 onward explicitly records its runtime status as BLOCKED with no fabricated evidence, and this merge adds no new claim to the contrary.

## What could not be verified?

- Whether the 42 newly-merged modules/packages actually compile against Stage 61's current TypeScript/NestJS/Prisma versions (no `node_modules`, no network, no lockfile).
- Whether the 12 newly-merged modules' assumptions about the auth/tenancy layer still hold — they predate Stage 40's foundation reconstruction.
- Whether HIS-1's own claimed "56/56 tests passed" result (from its own hand-rolled harness, documented honestly by its source as not exercising real NestJS DI) would still hold when run for real inside this monorepo's actual toolchain.
- Any runtime, database, Docker, or deployment behavior whatsoever.

## What should be done next?

See `NEXT-STEPS.md` in the merged tree — in order: restore a real lockfile, run the Prisma/PostgreSQL gates for real, code-compatibility-check the 12 newly-merged modules, decide and execute the HIS schema integration, then proceed to Stage 62 (production observability, already scoped by Stage 61's own next-steps doc) and only then Tier 2+ scale work.

# M2 — Database schema, RLS, and data infrastructure (Foundation Modules 01–10)

This milestone covers the 10 **foundation** modules only (Auth, Tenancy,
RBAC, User & Employee Master, Audit, Notifications, Documents, Settings,
Terminology, Workflow). Business modules 11–24 (CRM, Sales, Purchase,
Inventory, Manufacturing, Finance, Billing, Payroll, Projects, Assets,
Reports, AI Assistant, Integrations, Compliance) are a separate, later
slice — the original single-prompt scope covering all 24 modules with
hundreds of tables, full partitioning, and verified test-pass counts
was not something that could be delivered honestly in one pass; see the
session notes below for exactly why and what was scoped down.

## What's real and delivered

- **`prisma/schema.prisma`** — 83 models, 21 enums. Structurally validated:
  no duplicate model/table names, every relation has a back-reference,
  every field type resolves to a real model/enum/scalar.
- **Row-Level Security** (`prisma/raw-sql/02-rls-and-triggers.sql`) —
  tenant isolation enforced at the database level, not just in application
  code. A non-superuser `erp_app` role (`infra/postgres/init.sql`,
  `prisma/raw-sql/03-app-role-grants.sql`) exists specifically so RLS
  tests are meaningful — the default Postgres superuser bypasses RLS
  entirely, which would make the test suite pass for the wrong reason.
- **Audit hash-chain + append-only enforcement** — `audit_events` has
  DB-level triggers that reject UPDATE/DELETE outright, plus a
  deterministic `audit_hash()` function.
- **UUIDv7 primary keys** — hand-implemented for Postgres 16 (native
  support lands in PG18), sortable-by-creation-time (ADR 0001).
- **Prisma application layer** (`apps/api/src/prisma/`) —
  `PrismaService` (connection lifecycle, `withTenant`/`withTransaction`/
  `withBypassRls` helpers), `TenantContextService` (AsyncLocalStorage),
  a tenant-scoping Client Extension (auto-fill on create, loud failure on
  missing context), and `BaseTenantRepository` (the actual soft-delete
  enforcement point — a Client Extension can't redirect `delete` into
  `update` mid-flight, which an earlier draft attempted and was caught
  before shipping).
- **Seeds** — plans, a real ~30-currency subset, a demo tenant — all
  idempotent via `upsert` or an explicit existence check.
- **DB test suite** (`apps/api/test/db/`) — `rls.test.ts`,
  `softDelete.test.ts`, `audit.test.ts`, `optimisticLock.test.ts`,
  `schema.test.ts`, `seeds.test.ts`. Real Jest code, written to run
  against a live Postgres.
- **`packages/shared-types`** — zod schemas (create/update/filter/list)
  for 7 representative entities across different modules, demonstrating
  a pattern documented in `src/entities/README.md` for extending to
  further entities as the business modules that need them arrive; plus
  Prisma-derived TypeScript types and enum re-exports for the whole
  schema.
- **Full documentation set**: `docs/db/SCHEMA.md`, `MULTI_TENANCY.md`,
  `RLS.md`, `SEEDS.md`, `MIGRATION_GUIDE.md`; ADRs 0001–0006 (UUIDv7,
  multi-tenancy strategy, RLS-over-app-filter, partitioning,
  soft delete, optimistic locking).
- **`prisma/README.md`** — the exact commands to turn `schema.prisma` +
  the raw SQL into a real, Prisma-verified migration history on your
  machine.
- **`scripts/verify-m2.sh`** — runs schema sync, raw SQL, seeds, and the
  full test suite end-to-end, reporting real pass/fail counts from each
  command's actual exit code.

## What's explicitly deferred, and why

- **Table partitioning** (ADR 0004) — real DDL that needs a live database
  to verify partition bounds and pruning behavior against; asserting it
  without that verification would be exactly the "unverified wall of SQL"
  this project tried to avoid elsewhere.
- **~76 of 83 models' zod schemas** — see
  `packages/shared-types/src/entities/README.md`; these belong with the
  controller/service that will actually use them, not written
  speculatively with no caller to prove them against.
- **Most of the originally-requested seed data** (250 countries, full
  180-currency list, 7000+ languages, the ~2000-entry permission catalog,
  per-country charts of accounts, tax codes) — see `docs/db/SEEDS.md` for
  the full list and why most of it has nowhere meaningful to seed into
  until the business modules that define those permissions/accounts exist.
- **ER diagram** (Mermaid) — `docs/db/SCHEMA.md`'s table-by-module
  breakdown plus `schema.prisma`'s own relations are enough to
  mechanically regenerate one (e.g. via `prisma-erd-generator`); a
  hand-drawn one risked drifting from the schema with no way to validate
  it here.

## What has NOT been executed

Nothing in this milestone has run against a real Postgres — this sandbox
has no live database and no network access to Prisma's tooling. Every
piece of SQL and TypeScript was syntax-checked and structurally validated
(see the session notes for exactly what checks were run), and two real
bugs were caught and fixed this way before shipping (a Prisma Client
Extension trying to redirect `delete`→`update`, which Prisma doesn't
support; and RLS tests that would have silently passed against a
superuser connection). But "syntax-valid and structurally sound" is not
the same claim as "tested and passing" — `scripts/verify-m2.sh` and
`prisma/README.md` exist specifically so you can make that second claim
yourself, for real, and see real output when you do.

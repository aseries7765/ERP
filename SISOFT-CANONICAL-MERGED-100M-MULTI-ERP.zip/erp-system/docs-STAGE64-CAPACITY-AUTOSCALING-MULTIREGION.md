# Stage 64 — Capacity Planning, Autoscaling and Multi-Region Readiness Gate

## Objective
Establish a deterministic, fail-closed operational contract for scaling Sisoft horizontally and for preparing a future multi-region deployment. This stage defines workload classes, autoscaling signals, dependency budgets, tenant placement, graceful degradation and failover evidence requirements.

## Architecture rule
100M+ remains an architectural target. This stage does not claim a 100M+ benchmark. Capacity is proven only by reproducible measurements on the relevant topology.

## Workload classes
- Interactive reads: horizontally scalable; cache/stale-read degradation may be allowed where business semantics permit.
- Interactive writes: horizontally scalable; reject/defer safely when capacity is exhausted; never silently drop a business mutation.
- Async business work: worker scaling driven by queue depth and oldest-job age, with bounded concurrency and retries.
- Heavy reports/exports: bounded worker class; defer or schedule instead of exhausting API/database resources.
- Authentication/security: critical class; security controls must remain fail-closed.

## Autoscaling
API and worker pools require explicit minimum/maximum replica bounds and multiple signals. Scale-down must protect in-flight work, database connections and queue leases. Autoscaling must not be used as a substitute for an unbounded database connection pool.

## Dependency budgets
- PostgreSQL: bounded pool, query timeout/statement timeout policy, connection saturation visibility.
- Redis: bounded connections, command timeouts and memory/key-cardinality controls.
- Queue: bounded depth, retry budget, dead-letter path and oldest-job-age monitoring.
- External providers: timeout, bounded retry, circuit breaker and explicit degraded behavior.

## Shard and region placement
The control plane owns stable tenant-to-infrastructure placement. Data-plane services resolve placement through a provider/routing abstraction rather than embedding a single cloud or database topology into business modules.

A tenant should have an explicit home region/shard. Cross-region reads/writes are not assumed to be safe; they require documented consistency semantics and evidence.

## Graceful degradation
Availability must not be preserved by bypassing security or tenant isolation. Non-critical functions may be disabled/deferred. Heavy reports and exports may be queued. Business writes must either complete durably or return a safe error/retry response.

## Multi-region readiness
A runtime PASS requires a real or representative multi-region/failover environment and evidence covering:
1. topology and region placement;
2. tenant/shard routing;
3. controlled dependency failure;
4. service failover;
5. data consistency after failover;
6. queue/job behavior;
7. recovery and re-routing;
8. security/RLS verification;
9. measured recovery evidence and SHA-256 manifest.

Without that evidence the verdict remains BLOCKED.

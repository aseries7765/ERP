# Stage 59 — Operational Runtime Readiness Matrix and Dependency Health Gate

## Scope
Stage 59 consolidates the operational dependencies that must be proven before production release:

| Area | Static contract | Runtime evidence required |
|---|---|---|
| API liveness/readiness | `/health/live` and `/health/ready`; readiness probes PostgreSQL + Redis | HTTP 200 from both endpoints |
| PostgreSQL | `APP_DATABASE_URL` is the application role | real `SELECT 1`, migration/catalog checks |
| Redis/BullMQ | `REDIS_URL` required; Redis-backed services present | real Redis PING and worker connectivity |
| Migrations | existing Stage 52/53/57 evidence gates retained | clean disposable DB migration succeeds |
| Backups/restore | deployment supplies explicit verification commands | backup + restore actually executed |
| TLS | deployment supplies TLS endpoint | real HTTPS probe/certificate validation |
| Observability | deployment supplies target endpoint | real target accepts/observes probe |
| Distributed rate limiting | deployment supplies Redis key namespace and exercise | multi-request test demonstrates shared enforcement |

## Health semantics
- `/health/live` remains process-only to avoid restart loops when dependencies are degraded.
- `/health/ready` now fails when PostgreSQL or Redis is unavailable/missing.
- No health endpoint is treated as proof of backups, TLS, observability, migrations, or distributed rate limiting.

## Runtime truth
The runtime gate is fail-closed. It prints `STAGE59 RUNTIME PASS` only after all real probes and deployment-supplied backup/restore/rate-limit exercises succeed. Missing infrastructure produces `BLOCKED`, never PASS.

# Stage 27 Test Matrix

| Area | Static | Runtime |
|---|---|---|
| Group create atomic outbox | PASS | Pending |
| Group update atomic outbox | PASS | Pending |
| Group delete atomic outbox | PASS | Pending |
| Policy delete atomic outbox | PASS | Pending |
| SoD rule delete atomic outbox | PASS | Pending |
| Actor/tenant propagation | PASS | Pending |
| Post-commit cache invalidation | PASS | Pending |
| Event contract type coverage | PASS | Pending |

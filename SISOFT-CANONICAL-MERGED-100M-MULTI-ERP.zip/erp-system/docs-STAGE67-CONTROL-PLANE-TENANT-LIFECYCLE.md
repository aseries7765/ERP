# Stage 67 — Global Control Plane, Tenant Lifecycle and Cross-Region Placement Integrity Gate

## Objective
Define a provider-neutral global control plane for Sisoft without moving tenant business data into a shared control-plane database. The control plane records tenant identity, lifecycle state, placement intent/version, plan/quota policy and provider bindings; regional data planes execute tenant workloads under the authoritative placement context.

## Control-plane / data-plane boundary
- Control plane owns tenant identity, lifecycle state, placement intent, plan/quota policy, provider binding and provisioning workflows.
- Data planes own tenant business rows, tenant transactions and regional workload execution.
- A control-plane command must carry authenticated tenant context and must not bypass data-plane RLS, authorization or shard routing.
- Secrets are referenced through a secret manager/provider adapter; plaintext credentials are never stored in the control plane or logs.

## Tenant lifecycle
The lifecycle is explicit and versioned:
`PENDING → PROVISIONING → ACTIVE → SUSPENDED → MIGRATING → ACTIVE → DEPROVISIONING → DEPROVISIONED`, with `ERROR` as a recoverable workflow state.

Rules:
- Every transition is authorized, idempotent and audited.
- `DEPROVISIONED` is terminal unless a separately approved restore/import workflow creates a new tenant identity.
- Suspension blocks disallowed writes without silently deleting data.
- Destructive deprovisioning requires retention-policy evaluation and explicit audit evidence.

## Idempotent provisioning
Provisioning is a durable workflow:
1. reserve tenant identity;
2. select an eligible region/provider;
3. allocate data-plane resources;
4. initialize schema/partition and policies;
5. verify isolation;
6. publish endpoint/routing metadata;
7. activate the tenant.

Every step has an idempotency key and durable checkpoint. A retry must resume or return the existing resource, never create a second tenant data plane for the same operation.

## Placement and cross-region movement
Each tenant has a versioned placement record. Transactional tenant data has one authoritative write region at a time. Region movement uses `preflight → fence writes → copy → verify → cutover → resume → post-cutover verify → retire source`.

A placement-version/fencing token prevents stale regions from continuing writes after cutover. Read regions are explicit and cannot be inferred as write authorities. Unknown or stale placement fails closed.

## Quota propagation
Plan and quota policy originates in the control plane and is versioned. Regional caches may be eventually consistent, but security-sensitive limits fail closed when policy freshness cannot be established. Quota propagation cannot be bypassed by a stale regional cache.

## Provider abstraction
Oracle, AWS, Azure, GCP, private infrastructure and future providers must implement the same adapter-level contract for provisioning, deprovisioning, health, snapshot, restore, movement and credential references. Provider-specific APIs remain inside adapters rather than leaking into tenant lifecycle logic.

## Control-plane failover
Control-plane failover requires a defined single-writer/consensus contract, fencing tokens, monotonic placement versions and reconciliation after recovery. A failover is not considered safe merely because a second region responds to health checks.

Break-glass operations require explicit authorization and audit evidence.

## 100M+ scale relevance
100M+ coverage is an architectural target, not a measured claim. The control plane must support partitioned tenant metadata, horizontally scalable workers, bounded fan-out, regional placement indexes and asynchronous lifecycle workflows. Actual capacity remains evidence-gated by representative load testing.

## Runtime gate
Static verification can validate contracts and fail-closed rules. Runtime PASS requires real multi-region control/data-plane infrastructure and evidence for provisioning replay, partial recovery, quota propagation, control-plane fencing/failover, provider adapters, tenant movement and post-move isolation.

Split-brain prevention is mandatory: a stale control-plane writer or stale data-plane region must be fenced before another authority can mutate placement or tenant data.

# ERP System — Merged Monorepo

**Version:** 1.0.0-merged  
**Status:** Conditional — ready for continued development

Universal Multi-Industry AI-Native ERP.

This repository is the result of merging multiple parallel module deliveries into one monorepo.

## Quick Overview

| Layer            | Status                          |
|------------------|---------------------------------|
| Apps             | api, web, ai, worker            |
| Packages         | 25 engines                      |
| Prisma models    | 102 (foundation + additive)     |
| Multi-tenancy    | Present (RLS + tenancy module)  |
| RBAC (M3.3)      | Not present (intentionally left)|

## Getting Started

```bash
cp .env.example .env
pnpm install
docker compose up -d postgres redis minio
pnpm db:validate
pnpm dev
```

See `CURRENT-STATUS.md` for detailed integration status and remaining work.

## Documentation

- `CURRENT-STATUS.md` — current state after integration fixes
- `DEFICIENCY-REPORT.md` — what was fixed and what remains
- `ROADMAP.md` — full module roadmap
- `PROJECT-STATE.md` — project state notes

## Original M1 Notes

The original M1 scaffold documentation is preserved in `README-M2.md` and the original README content history.

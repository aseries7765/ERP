# Stage 65 Exceptions and Evidence Rules

1. **No multi-shard environment:** runtime status is BLOCKED.
2. **No real migration execution:** migration correctness is not claimed from static code/config inspection alone.
3. **No routing evidence:** tenant placement correctness remains unverified.
4. **No cutover/fencing evidence:** zero-downtime or safe migration is not claimed.
5. **No recovery evidence:** rollback/recovery is not claimed.
6. **No cross-shard enforcement evidence:** transactional cross-shard restrictions remain unverified at runtime.
7. **No measured 100M+ benchmark:** the target is architectural only; no throughput, latency, tenant-count, RTO/RPO or capacity figure may be presented as measured.
8. **Provider neutrality:** the contract does not assume a particular cloud vendor or database topology.

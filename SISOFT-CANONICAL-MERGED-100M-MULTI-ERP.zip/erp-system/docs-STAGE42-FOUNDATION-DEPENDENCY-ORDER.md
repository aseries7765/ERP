# Stage 42 — Foundation Migration Dependency Ordering

## Objective

Reconstruct a dependency-first ordering for the current Prisma schema before any production migration SQL is generated. The goal is to make the missing migration history explicit without inventing historical SQL.

## Static findings

- Prisma schema models: **193**
- Tables created by the 17 tracked migrations: **74**
- Schema tables without tracked migration ownership: **119**
- Prisma relation edges detected: **70**
- Relation cycles detected: **0**
- Dependency-first topological levels: **6**
- Largest dependency level: **136 models**

## Foundation dependency observations

- `Tenant` is a schema root and has no parsed Prisma relation dependency.
- `Permission` is a schema root and is referenced by the RBAC permission-assignment models.
- `Role` has no parsed relation dependency; `RolePermission` depends on `Role` and `Permission`.
- `User` has no parsed relation dependency in the current schema declaration; `UserRole` depends on `User` and `Role`.
- `Group` has no parsed relation dependency; `GroupPermission` depends on `Group` and `Permission`.
- `Policy` has no parsed relation dependency; `PolicyPermission` depends on `Policy` and `Permission`.
- `Delegation` has no parsed relation dependency; `DelegationPermission` depends on `Delegation` and `Permission`.
- `CostCenter` depends on `Department`; its dependent finance line models sit later in the dependency graph.

## Important limitation

This is a **current-schema dependency reconstruction**, not a recovery of the original historical migration order. Prisma relation declarations do not prove that the historical database was created in this order.

No hand-authored production migration was generated in Stage 42. The baseline must be generated/validated with the pinned Prisma CLI and executed against disposable PostgreSQL before it is accepted as an executable migration baseline.

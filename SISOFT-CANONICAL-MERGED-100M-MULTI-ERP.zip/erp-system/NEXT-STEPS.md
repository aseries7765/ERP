# Next Steps

0. ~~`event-bus.service.ts` missing~~ — fixed. ~~`EventOutbox` had no consumer~~ — fixed (`apps/worker/src/jobs/outbox-dispatcher.ts`), but no real handler is registered for any event type yet.
1. ~~`HandoffModule`, `HisOrModule` (SurgicalCountService) unregistered/boot-crashing~~ — both fixed (factory providers). See FINAL-MERGE-REPORT.md "Fifth" and "Sixth" merge passes.
2. **`DocumentsModule` still unregistered** — needs 7+ Prisma-backed repository classes plus RBAC/OCR-queue bindings. Largest remaining well-scoped gap.
3. **HIS-3's OR/ER/Dialysis/Interop domains beyond Cashier/ER-bed/Surgical-count are NOT NestJS-wired** — the underlying logic (triage, code blue, trauma, HL7, FHIR, DICOM, dialysis scheduling, etc.) exists and is tested in their respective packages, but has no controllers/services wrapping it yet. Same is true for HIS-2 v2's 4 application-service modules (framework-free by design).
4. Decide the HIS Prisma model integration into the live schema.prisma — now THREE standalone sketch files exist (his-core-clinical-models.prisma, his-ancillary-models.prisma, his-or-er-interop-models.prisma), none applied. Needs a single coordinated relation/tenant-scoping/RLS design pass, not three separate blind splices.
5. Restore or regenerate a real `pnpm-lock.yaml` (Stage 60 E60-001 — still unresolved, blocks all real installs/builds).
6. Run Stage 41/48/50 Prisma+PostgreSQL gates against a real disposable database to move Stage 40-61's own BLOCKED items to genuine PASS/FAIL.
7. Stage 62-71 are merged and STATIC PASS (see ROADMAP.md). All remain runtime BLOCKED until real distributed infrastructure exists.
8. Tier 2+ scale work only after Tier 1 runtime gates are genuinely green — see docs/architecture/100M-SCALE-ARCHITECTURE.md.
9. Once a real toolchain is available: everything authored in this environment without one (event-bus, outbox-dispatcher, HIS provider bindings, Handoff adapters, the his-or factory fix) needs an actual `tsc`/`prisma generate` pass — all were hand-verified against `schema.prisma`, not compiler-checked.

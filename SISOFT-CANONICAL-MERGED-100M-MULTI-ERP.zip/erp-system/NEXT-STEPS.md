# Next Steps

0. ~~`event-bus.service.ts` missing~~ — fixed. ~~`EventOutbox` had no consumer~~ — fixed (`apps/worker/src/jobs/outbox-dispatcher.ts`), but **no real handler is registered for any event type yet** — rows will sit PENDING and get logged as unhandled until real subscribers are wired via `registerOutboxHandler()`.
1. ~~`HandoffModule` unregistered~~ — fixed and re-registered (see FINAL-MERGE-REPORT.md "Fifth merge pass"). Its `EnvRegistryLookup` adapter will correctly return "not found" for every tenant until a real tenant-provisioning flow starts writing `Tenant.metadata.environmentUrl` — that's the next real gap behind it, not a bug in the adapter itself.
2. **`DocumentsModule` still unregistered** — needs 7+ Prisma-backed repository classes (`DocumentRepository`, `BlobRefRepository`, `FolderRepository`, `TagRepository`, `ShareRepository`, `SignatureRepository`, `LegalHoldRepository`) plus an RBAC `PERMISSION_CHECKER` binding and an `OCR_JOB_QUEUE` binding. All 8 backing Prisma models already exist. This is the largest remaining well-scoped gap.
3. Restore or regenerate a real `pnpm-lock.yaml` against the actual dependency set (Stage 60 E60-001 — currently unresolved, blocks all real installs/builds).
4. Run Stage 41/48/50 Prisma+PostgreSQL gates against a real disposable database to move Stage 40-61's own BLOCKED items to genuine PASS/FAIL.
5. Decide and execute HIS Prisma model integration into the live schema.prisma (currently standalone, unapplied files) — needs relation/tenant-scoping/RLS design, not a blind splice.
6. Stage 62-71 are merged and STATIC PASS (see ROADMAP.md). All remain runtime BLOCKED until real distributed infrastructure exists.
7. Tier 2+ scale work (read replicas, partitioning) only after Tier 1 runtime gates are genuinely green — see docs/architecture/100M-SCALE-ARCHITECTURE.md.
8. Once a real toolchain is available: everything authored in this environment without one (event-bus, outbox-dispatcher, HIS provider bindings, Handoff adapters) needs an actual `tsc`/`prisma generate` pass — all were hand-verified against `schema.prisma`, not compiler-checked.

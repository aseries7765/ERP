# Stage 65 — Data Partitioning, Shard Routing and Tenant Placement Integrity

## Purpose

Stage 65 defines the control-plane and data-plane contract required to place each ERP tenant on a deterministic shard, prevent accidental cross-shard transactional access, and move tenants safely when capacity or placement policy requires rebalancing.

This stage is an architectural and static integrity gate. It does **not** claim that a multi-shard deployment has been executed.

## 1. Tenant-to-shard routing

- The immutable tenant ID is the routing identity.
- A control-plane placement map is authoritative for tenant → shard/region ownership.
- Placement mappings are versioned and audited.
- Unknown or conflicting mappings fail closed rather than falling back to a default shard.
- Routing must be deterministic and use a versioned algorithm or explicit placement assignment.
- API and worker paths must resolve placement before opening tenant-scoped data operations.

## 2. Partitioning boundaries

- Tenant-owned transactional data has one authoritative writer shard by default.
- Cross-tenant access is prohibited by default.
- Global/reference data must be explicitly classified rather than implicitly shared.
- A database session requires both tenant context and expected shard context.
- Transactional request paths should remain single-shard. Cross-shard fan-out is a bounded, explicit service operation, not an accidental ORM join.

## 3. Safe shard migration

The required migration lifecycle is:

1. create/validate destination capacity;
2. copy source tenant data using idempotent checkpoints;
3. verify counts/keys and deterministic checksums or samples;
4. verify foreign-key integrity, tenant isolation and audit continuity;
5. acquire a versioned fencing token;
6. fence the old writer before final cutover;
7. atomically publish the new placement version;
8. reopen writes only against the new owner;
9. retain source recovery evidence until the migration is accepted.

Rollback must restore one authoritative owner before normal writes resume. Dual-write is not a default; it is allowed only where explicitly designed for idempotency and conflict handling.

## 4. Rebalancing

Rebalancing must be rate-limited and bounded. It must preserve tenant affinity, maintain one authoritative owner, checkpoint progress, detect orphaned/duplicate ownership, and resume idempotently after interruption.

The system must not trade placement correctness for capacity. Capacity pressure is handled by controlled queueing, throttling or migration scheduling rather than silently creating split-brain ownership.

## 5. Cross-shard query restrictions

- Normal transactional APIs: single-shard by default.
- Multi-shard joins: forbidden in the ordinary request path.
- Fan-out: explicit, bounded, authorization-aware service operation.
- Analytics/reporting across shards: separate read path or warehouse-oriented architecture.
- Pagination over fan-out results must be deterministic and merge-safe.

## 6. 100M+ scalability relationship

The 100M+ target is an architectural scale objective, not a measured benchmark. Sharding provides a path to distributing tenant data and workload, but actual capacity depends on tenant size distribution, request mix, database hardware, indexes, network topology, cache behavior and operational limits. No capacity number is certified by this stage.

## 7. Runtime evidence gate

Runtime PASS requires real representative multi-shard infrastructure and evidence for routing, mapping-version consistency, migration copy/verification, cutover fencing, rollback/recovery, cross-shard restrictions, rebalancing checkpoints and orphan detection. Missing infrastructure or evidence remains BLOCKED.

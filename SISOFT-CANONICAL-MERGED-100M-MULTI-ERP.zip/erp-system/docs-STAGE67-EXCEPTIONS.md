# Stage 67 Exceptions and Evidence Rules

- Runtime status is BLOCKED when representative multi-region control-plane/data-plane infrastructure is unavailable.
- A health check alone is not evidence of safe control-plane failover or split-brain prevention.
- No fabricated tenant-provisioning, migration, failover, quota-propagation or 100M+ capacity result may be reported.
- Provider neutrality must not be claimed if provider-specific behavior leaks outside the adapter boundary.
- Cross-region movement cannot be marked successful without post-cutover tenant isolation and consistency evidence.
- Stale placement or quota policy must fail closed where the policy is security-sensitive.
- Break-glass lifecycle changes require durable authorization and audit evidence.
- Plaintext provider credentials or secret values must never be included in control-plane state, logs or evidence artifacts.

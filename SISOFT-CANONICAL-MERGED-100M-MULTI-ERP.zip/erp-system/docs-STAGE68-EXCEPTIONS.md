# Stage 68 Exceptions and Evidence Rules

- No fabricated OIDC, SAML, token, key-rotation or failover evidence.
- Static PASS does not mean authentication infrastructure has been runtime-tested.
- Runtime PASS requires real representative identity providers and key infrastructure.
- Unknown issuer, audience, signing key, tenant context, service identity or placement context must fail closed.
- A JWT/SAML claim is never treated as sufficient proof of tenant authorization.
- Region claims never override the authoritative placement record.
- Provider-specific identity APIs must remain behind adapters.
- Break-glass access without scope, expiry and audit evidence is a blocker.

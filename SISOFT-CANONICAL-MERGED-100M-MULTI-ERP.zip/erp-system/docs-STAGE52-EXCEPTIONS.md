# Stage 52 Exceptions

- Runtime execution is blocked in the current sandbox because PostgreSQL/`psql`
  and the installed Prisma 5.20.0 CLI are unavailable.
- The runtime harness intentionally refuses to execute unless both explicit
  disposable-database flags are present.
- No existing Prisma migration folder or migration SQL was rewritten.
- No fabricated runtime output or PASS evidence was added.

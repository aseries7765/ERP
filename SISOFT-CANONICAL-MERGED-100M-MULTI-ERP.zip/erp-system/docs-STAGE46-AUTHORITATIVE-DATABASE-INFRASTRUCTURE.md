# Stage 46 — Authoritative Database Infrastructure Contract

Stage 45 identified missing provenance for database functions used by the schema and migrations. Stage 46 makes that infrastructure explicit and machine-reconciled.

## Authoritative functions

| Function | Source of truth | Contract |
|---|---|---|
| `public.uuid_generate_v7()` | `prisma/raw-sql/01-uuid-v7-function.sql` | Project-owned UUIDv7 generator: 48-bit millisecond timestamp + version 7 + RFC variant + 10 random bytes. Must exist before any table whose default calls it is created. |
| `public.get_current_tenant()` | `prisma/raw-sql/02-rls-and-triggers.sql` | Reads transaction-local `app.current_tenant`; missing/empty setting returns NULL. |
| `public.audit_hash(text,jsonb)` | `prisma/raw-sql/02-rls-and-triggers.sql` | SHA-256 hex digest over the previous hash and row JSON text. |
| `public.touch_updated_at_and_version()` | `prisma/raw-sql/02-rls-and-triggers.sql` | On UPDATE, sets `updatedAt = now()` and `version = OLD.version + 1`. Database is the source of truth for these fields. |
| `public.reject_audit_mutation()` | `prisma/raw-sql/02-rls-and-triggers.sql` | Rejects UPDATE/DELETE against append-only `audit_events`. |

## UUIDv7 provenance

The Prisma schema uses `dbgenerated("uuid_generate_v7()")`, so this is a schema prerequisite. The supported baseline is PostgreSQL 16/17 and the implementation is intentionally project-owned rather than depending on a server-version-specific native UUIDv7 function. Any future switch to native UUIDv7 must be a deliberate schema/migration change validated against the target PostgreSQL version and Prisma behavior.

## Optimistic-lock contract

The trigger is attached to exactly the 103 schema models that currently contain `tenantId`, `updatedAt`, and `version`. The list is explicit and checked against `schema.prisma`; a future eligible table must be deliberately added. Application services still perform optimistic concurrency by including the expected `version` in the UPDATE predicate and treating zero affected rows as a conflict.

The trigger owns the stored increment. Application code should not rely on manually incrementing `version` for correctness; the trigger sets `NEW.version = OLD.version + 1`.

## Required migration order

1. Install UUIDv7 infrastructure.
2. Generate/apply the real Prisma table baseline against a real PostgreSQL database.
3. Apply RLS/trigger infrastructure after referenced tables exist.
4. Apply app-role grants.
5. Seed and run DB tests using the non-superuser `erp_app` role.

This stage does not claim runtime execution. PostgreSQL, Prisma dependencies, and a real database remain required for the actual baseline-generation/apply gate.

## Static result

- Prisma schema models: 193
- Eligible tenant-scoped mutable models: 103
- Trigger manifest entries: 103
- Duplicate entries: 0
- Manifest/schema mismatches: 0

Machine-readable manifest: `prisma/STAGE46-DB-INFRASTRUCTURE-MANIFEST.json`.

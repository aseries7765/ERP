# Stage 30 — @erp/shared-types

## Scope
Reconstruct the missing shared type package from concrete consumers rather than inventing a broad domain model.

## Concrete contract recovered
`apps/api/src/modules/reports/services/report-executor.service.ts` imports `ReportExecutionResultDto` from `@erp/shared-types/reports`. The implementation therefore supplies that exact subpath and DTO shape required by the existing executor, including success/failure status, rows, columns, cache flag, duration, execution timestamp, and optional error.

## Conservative common types
The root package also exposes runtime-free `EntityId`, `TenantContext`, `ActorContext`, and cursor pagination contracts. These are structural TypeScript types only and do not introduce runtime dependencies or duplicate domain schemas.

## Verification
Static TypeScript verification is used. Full monorepo runtime/build verification remains blocked by the documented missing dependency/runtime environment.

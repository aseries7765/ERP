export type StepType='start'|'condition'|'approval'|'action'|'wait'|'parallel'|'sub-workflow'|'end';
export type Assignee={role?:string;userId?:string;scope?:'department'|'tenant'|'self'};
export type WorkflowStep =
 | {id:string;type:'start';next:string}
 | {id:string;type:'condition';expression:string;onTrue:string;onFalse:string}
 | {id:string;type:'approval';assignees:Assignee[];mode?:'single'|'multi-any'|'multi-all'|'sequential';sla?:string;escalateTo?:Assignee[];onApprove:string;onReject:string}
 | {id:string;type:'action';action:'email'|'webhook'|'script'|'db-update'|'notification'|'field-update';config:Record<string,unknown>;next:string}
 | {id:string;type:'wait';until?:string;signal?:string;next:string}
 | {id:string;type:'parallel';branches:string[];join:string}
 | {id:string;type:'sub-workflow';workflowId:string;input?:Record<string,unknown>;next:string}
 | {id:string;type:'end';outcome?:string};
export interface WorkflowTrigger {type:'event'|'schedule'|'manual'|'webhook'|'condition';event?:string;cron?:string;condition?:string}
export interface WorkflowDefinition {id:string;name:string;version:number;status:'draft'|'published'|'archived';trigger?:WorkflowTrigger;steps:WorkflowStep[]}
export interface ExecutionContext {tenantId:string;instanceId:string;definitionId:string;version:number;variables:Record<string,unknown>;input?:Record<string,unknown>;actor?:string;dryRun?:boolean}
export interface InstanceState {instanceId:string;definitionId:string;version:number;currentStepId:string;status:'running'|'waiting'|'completed'|'failed'|'cancelled';variables:Record<string,unknown>;waitingSignal?:string;outcome?:string;parallelJoins?:Record<string,{branches:string[];completed:string[];join:string}>}
export interface StepLogEntry {instanceId:string;stepId:string;stepType:StepType;status:'entered'|'completed'|'paused'|'failed';at:string;metadata?:Record<string,unknown>}
export interface EngineHandlers {onActionStep?:(step:Extract<WorkflowStep,{type:'action'}>)=>Promise<{variablesPatch?:Record<string,unknown>}>;onApprovalStepEntered?:(step:Extract<WorkflowStep,{type:'approval'}>,ctx:ExecutionContext)=>Promise<void>;onWaitStepEntered?:(step:Extract<WorkflowStep,{type:'wait'}>,ctx:ExecutionContext)=>Promise<void>;onSubWorkflowStepEntered?:(step:Extract<WorkflowStep,{type:'sub-workflow'}>,ctx:ExecutionContext)=>Promise<void>;onStepExecuted?:(entry:StepLogEntry)=>Promise<void>}

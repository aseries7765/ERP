/**
 * Device connection lifecycle management: tracks connection state per
 * device and implements exponential backoff for reconnect attempts.
 *
 * SCOPE NOTE: this is the state machine and backoff policy only — the
 * actual transport (TCP socket, serial port) is not implemented here,
 * since that requires real hardware/network access this environment
 * doesn't have. A real adapter plugs into this manager by calling
 * `recordConnected`/`recordDisconnected`/`recordConnectionFailed` from
 * its actual I/O callbacks.
 */

export class DeviceConnectionError extends Error {}

export type ConnectionState = 'DISCONNECTED' | 'CONNECTING' | 'CONNECTED' | 'RECONNECT_BACKOFF' | 'FAILED';

export interface DeviceConnection {
  deviceId: string;
  state: ConnectionState;
  connectedAt?: Date;
  disconnectedAt?: Date;
  consecutiveFailures: number;
  nextRetryAt?: Date;
  lastError?: string;
}

const BASE_BACKOFF_MS = 1000;
const MAX_BACKOFF_MS = 60000;
const MAX_CONSECUTIVE_FAILURES = 10;

export class DeviceConnectionManager {
  private connections = new Map<string, DeviceConnection>();

  register(deviceId: string): DeviceConnection {
    if (this.connections.has(deviceId)) {
      throw new DeviceConnectionError(`Device ${deviceId} is already registered.`);
    }
    const connection: DeviceConnection = { deviceId, state: 'DISCONNECTED', consecutiveFailures: 0 };
    this.connections.set(deviceId, connection);
    return connection;
  }

  recordConnecting(deviceId: string): DeviceConnection {
    const conn = this.getOrThrow(deviceId);
    const updated: DeviceConnection = { ...conn, state: 'CONNECTING' };
    this.connections.set(deviceId, updated);
    return updated;
  }

  recordConnected(deviceId: string, now: Date = new Date()): DeviceConnection {
    const conn = this.getOrThrow(deviceId);
    const updated: DeviceConnection = {
      ...conn,
      state: 'CONNECTED',
      connectedAt: now,
      disconnectedAt: undefined,
      consecutiveFailures: 0,
      nextRetryAt: undefined,
      lastError: undefined,
    };
    this.connections.set(deviceId, updated);
    return updated;
  }

  recordDisconnected(deviceId: string, now: Date = new Date()): DeviceConnection {
    const conn = this.getOrThrow(deviceId);
    const updated: DeviceConnection = { ...conn, state: 'DISCONNECTED', disconnectedAt: now };
    this.connections.set(deviceId, updated);
    return updated;
  }

  /**
   * Records a failed connection attempt, computing the next retry time
   * via exponential backoff (base 1s, doubling, capped at 60s). After
   * MAX_CONSECUTIVE_FAILURES, transitions to FAILED and stops
   * scheduling automatic retries — a permanently-misconfigured device
   * shouldn't retry forever silently; it needs a human to look at it.
   */
  recordConnectionFailed(deviceId: string, error: string, now: Date = new Date()): DeviceConnection {
    const conn = this.getOrThrow(deviceId);
    const consecutiveFailures = conn.consecutiveFailures + 1;

    if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
      const updated: DeviceConnection = { ...conn, state: 'FAILED', consecutiveFailures, lastError: error, nextRetryAt: undefined };
      this.connections.set(deviceId, updated);
      return updated;
    }

    const backoffMs = Math.min(BASE_BACKOFF_MS * 2 ** (consecutiveFailures - 1), MAX_BACKOFF_MS);
    const updated: DeviceConnection = {
      ...conn,
      state: 'RECONNECT_BACKOFF',
      consecutiveFailures,
      lastError: error,
      nextRetryAt: new Date(now.getTime() + backoffMs),
    };
    this.connections.set(deviceId, updated);
    return updated;
  }

  resetAfterManualIntervention(deviceId: string): DeviceConnection {
    const conn = this.getOrThrow(deviceId);
    if (conn.state !== 'FAILED') {
      throw new DeviceConnectionError(`Device ${deviceId} is not in FAILED state (state: ${conn.state}); reset is only for FAILED devices.`);
    }
    const updated: DeviceConnection = { ...conn, state: 'DISCONNECTED', consecutiveFailures: 0, lastError: undefined, nextRetryAt: undefined };
    this.connections.set(deviceId, updated);
    return updated;
  }

  isRetryDue(deviceId: string, now: Date = new Date()): boolean {
    const conn = this.getOrThrow(deviceId);
    if (conn.state !== 'RECONNECT_BACKOFF' || !conn.nextRetryAt) return false;
    return now.getTime() >= conn.nextRetryAt.getTime();
  }

  getConnection(deviceId: string): DeviceConnection {
    return this.getOrThrow(deviceId);
  }

  private getOrThrow(deviceId: string): DeviceConnection {
    const conn = this.connections.get(deviceId);
    if (!conn) throw new DeviceConnectionError(`Device ${deviceId} is not registered.`);
    return conn;
  }
}

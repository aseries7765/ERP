import {
  normalizePhilipsPayload,
  normalizeGePayload,
  normalizeGenericPayload,
  DeviceNormalizationError,
} from '../data-normalizer';
import { DeviceConnectionManager, DeviceConnectionError } from '../connection-manager';

describe('normalizePhilipsPayload', () => {
  it('normalizes a full Philips payload', () => {
    const result = normalizePhilipsPayload({
      patient_id: 'pat-1', device_id: 'philips-mx450-01', timestamp_iso: '2026-09-18T10:00:00Z',
      hr: 72, nbp_sys: 120, nbp_dia: 80, spo2: 98, resp_rate: 16,
    });
    expect(result.patientId).toBe('pat-1');
    expect(result.heartRateBpm).toBe(72);
    expect(result.sourceFormat).toBe('PHILIPS_JSON');
  });

  it('rejects an invalid timestamp', () => {
    expect(() => normalizePhilipsPayload({ patient_id: 'p1', device_id: 'd1', timestamp_iso: 'not-a-date' })).toThrow(
      /Invalid timestamp_iso/,
    );
  });

  it('rejects implausible heart rate (corrupt data)', () => {
    expect(() =>
      normalizePhilipsPayload({ patient_id: 'p1', device_id: 'd1', timestamp_iso: '2026-09-18T10:00:00Z', hr: 999 }),
    ).toThrow(/Implausible heartRateBpm/);
  });

  it('rejects systolic <= diastolic', () => {
    expect(() =>
      normalizePhilipsPayload({
        patient_id: 'p1', device_id: 'd1', timestamp_iso: '2026-09-18T10:00:00Z', nbp_sys: 80, nbp_dia: 90,
      }),
    ).toThrow(/must be greater than diastolic/);
  });
});

describe('normalizeGePayload', () => {
  it('normalizes a GE measurements-array payload', () => {
    const result = normalizeGePayload({
      mrn: 'pat-1', monitorId: 'ge-carescape-02', time: String(new Date('2026-09-18T10:00:00Z').getTime()),
      measurements: [
        { code: 'HR', value: 75 },
        { code: 'SPO2', value: 97 },
        { code: 'NIBP_SYS', value: 118 },
        { code: 'NIBP_DIA', value: 76 },
      ],
    });
    expect(result.heartRateBpm).toBe(75);
    expect(result.spo2Percent).toBe(97);
    expect(result.sourceFormat).toBe('GE_MEASUREMENTS');
  });

  it('handles a payload missing some measurement codes gracefully', () => {
    const result = normalizeGePayload({
      mrn: 'pat-1', monitorId: 'ge-01', time: String(Date.now()), measurements: [{ code: 'HR', value: 80 }],
    });
    expect(result.heartRateBpm).toBe(80);
    expect(result.spo2Percent).toBeUndefined();
  });

  it('rejects an invalid time value', () => {
    expect(() =>
      normalizeGePayload({ mrn: 'p1', monitorId: 'd1', time: 'garbage', measurements: [] }),
    ).toThrow(/Invalid time value/);
  });
});

describe('normalizeGenericPayload', () => {
  it('normalizes a generic already-internal-shaped payload', () => {
    const result = normalizeGenericPayload({
      patientId: 'pat-1', deviceId: 'device-1', takenAt: '2026-09-18T10:00:00Z', heartRateBpm: 70,
    });
    expect(result.sourceFormat).toBe('GENERIC');
    expect(result.heartRateBpm).toBe(70);
  });

  it('rejects a missing patientId', () => {
    expect(() =>
      normalizeGenericPayload({ patientId: '', deviceId: 'd1', takenAt: '2026-09-18T10:00:00Z' }),
    ).toThrow(DeviceNormalizationError);
  });
});

describe('DeviceConnectionManager', () => {
  it('registers a device as DISCONNECTED', () => {
    const manager = new DeviceConnectionManager();
    const conn = manager.register('dev-1');
    expect(conn.state).toBe('DISCONNECTED');
  });

  it('rejects duplicate registration', () => {
    const manager = new DeviceConnectionManager();
    manager.register('dev-1');
    expect(() => manager.register('dev-1')).toThrow(DeviceConnectionError);
  });

  it('transitions through connecting -> connected', () => {
    const manager = new DeviceConnectionManager();
    manager.register('dev-1');
    manager.recordConnecting('dev-1');
    const connected = manager.recordConnected('dev-1', new Date('2026-09-18T10:00:00Z'));
    expect(connected.state).toBe('CONNECTED');
    expect(connected.consecutiveFailures).toBe(0);
  });

  it('computes exponential backoff on repeated failures', () => {
    const manager = new DeviceConnectionManager();
    manager.register('dev-1');
    const t0 = new Date('2026-09-18T10:00:00Z');

    const f1 = manager.recordConnectionFailed('dev-1', 'timeout', t0);
    expect(f1.state).toBe('RECONNECT_BACKOFF');
    expect(f1.nextRetryAt?.getTime()).toBe(t0.getTime() + 1000); // 1s

    const f2 = manager.recordConnectionFailed('dev-1', 'timeout', t0);
    expect(f2.nextRetryAt?.getTime()).toBe(t0.getTime() + 2000); // 2s

    const f3 = manager.recordConnectionFailed('dev-1', 'timeout', t0);
    expect(f3.nextRetryAt?.getTime()).toBe(t0.getTime() + 4000); // 4s
  });

  it('caps backoff at the maximum', () => {
    const manager = new DeviceConnectionManager();
    manager.register('dev-1');
    const t0 = new Date('2026-09-18T10:00:00Z');
    for (let i = 0; i < 8; i++) {
      manager.recordConnectionFailed('dev-1', 'timeout', t0);
    }
    const conn = manager.getConnection('dev-1');
    const delay = (conn.nextRetryAt?.getTime() ?? 0) - t0.getTime();
    expect(delay).toBeLessThanOrEqual(60000);
  });

  it('transitions to FAILED after max consecutive failures and stops scheduling retries', () => {
    const manager = new DeviceConnectionManager();
    manager.register('dev-1');
    const t0 = new Date('2026-09-18T10:00:00Z');
    let conn;
    for (let i = 0; i < 10; i++) {
      conn = manager.recordConnectionFailed('dev-1', 'timeout', t0);
    }
    expect(conn?.state).toBe('FAILED');
    expect(conn?.nextRetryAt).toBeUndefined();
  });

  it('resets a FAILED device back to DISCONNECTED via manual intervention', () => {
    const manager = new DeviceConnectionManager();
    manager.register('dev-1');
    const t0 = new Date('2026-09-18T10:00:00Z');
    for (let i = 0; i < 10; i++) manager.recordConnectionFailed('dev-1', 'timeout', t0);
    expect(manager.getConnection('dev-1').state).toBe('FAILED');

    const reset = manager.resetAfterManualIntervention('dev-1');
    expect(reset.state).toBe('DISCONNECTED');
    expect(reset.consecutiveFailures).toBe(0);
  });

  it('rejects manual reset on a non-FAILED device', () => {
    const manager = new DeviceConnectionManager();
    manager.register('dev-1');
    expect(() => manager.resetAfterManualIntervention('dev-1')).toThrow(/not in FAILED state/);
  });

  it('reports isRetryDue correctly based on elapsed time', () => {
    const manager = new DeviceConnectionManager();
    manager.register('dev-1');
    const t0 = new Date('2026-09-18T10:00:00Z');
    manager.recordConnectionFailed('dev-1', 'timeout', t0); // backoff 1s

    expect(manager.isRetryDue('dev-1', new Date(t0.getTime() + 500))).toBe(false);
    expect(manager.isRetryDue('dev-1', new Date(t0.getTime() + 1000))).toBe(true);
  });

  it('a successful connect resets consecutiveFailures and clears backoff', () => {
    const manager = new DeviceConnectionManager();
    manager.register('dev-1');
    const t0 = new Date('2026-09-18T10:00:00Z');
    manager.recordConnectionFailed('dev-1', 'timeout', t0);
    manager.recordConnectionFailed('dev-1', 'timeout', t0);
    const connected = manager.recordConnected('dev-1', t0);
    expect(connected.consecutiveFailures).toBe(0);
    expect(connected.nextRetryAt).toBeUndefined();
    expect(connected.lastError).toBeUndefined();
  });

  it('throws for an unregistered device', () => {
    const manager = new DeviceConnectionManager();
    expect(() => manager.getConnection('nope')).toThrow(DeviceConnectionError);
  });
});

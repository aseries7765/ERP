/**
 * Normalizes vital signs data from different monitor vendors into one
 * internal shape. Real device integration (IHE PCD, proprietary
 * serial protocols) varies enormously by vendor and model; this
 * module implements normalizers for a small number of REPRESENTATIVE
 * payload shapes chosen to demonstrate the normalization pattern
 * correctly — it is not a certified driver for any real device model.
 * See MANIFEST for exactly which vendors have a normalizer here vs
 * are out of scope.
 */

export class DeviceNormalizationError extends Error {}

export interface NormalizedVitals {
  patientId: string;
  deviceId: string;
  takenAt: Date;
  heartRateBpm?: number;
  systolicBp?: number;
  diastolicBp?: number;
  spo2Percent?: number;
  respiratoryRateBpm?: number;
  temperatureCelsius?: number;
  sourceFormat: string;
}

const PLAUSIBLE_RANGES = {
  heartRateBpm: { min: 20, max: 300 },
  systolicBp: { min: 40, max: 300 },
  diastolicBp: { min: 20, max: 200 },
  spo2Percent: { min: 0, max: 100 },
  respiratoryRateBpm: { min: 0, max: 80 },
  temperatureCelsius: { min: 25, max: 45 },
};

function checkPlausible(field: keyof typeof PLAUSIBLE_RANGES, value: number | undefined): void {
  if (value === undefined) return;
  const range = PLAUSIBLE_RANGES[field];
  if (value < range.min || value > range.max) {
    throw new DeviceNormalizationError(
      `Implausible ${field} value ${value}: outside physiologic range [${range.min}, ${range.max}]. Rejecting rather than passing through corrupt device data.`,
    );
  }
}

function validateAndFinalize(vitals: Omit<NormalizedVitals, 'sourceFormat'>, sourceFormat: string): NormalizedVitals {
  if (!vitals.patientId) throw new DeviceNormalizationError('patientId is required (could not resolve from device payload).');
  if (!vitals.deviceId) throw new DeviceNormalizationError('deviceId is required.');

  checkPlausible('heartRateBpm', vitals.heartRateBpm);
  checkPlausible('systolicBp', vitals.systolicBp);
  checkPlausible('diastolicBp', vitals.diastolicBp);
  checkPlausible('spo2Percent', vitals.spo2Percent);
  checkPlausible('respiratoryRateBpm', vitals.respiratoryRateBpm);
  checkPlausible('temperatureCelsius', vitals.temperatureCelsius);

  if (vitals.systolicBp !== undefined && vitals.diastolicBp !== undefined && vitals.systolicBp <= vitals.diastolicBp) {
    throw new DeviceNormalizationError(`Systolic (${vitals.systolicBp}) must be greater than diastolic (${vitals.diastolicBp}).`);
  }

  return { ...vitals, sourceFormat };
}

export interface PhilipsPayload {
  patient_id: string;
  device_id: string;
  timestamp_iso: string;
  hr?: number;
  nbp_sys?: number;
  nbp_dia?: number;
  spo2?: number;
  resp_rate?: number;
}

export function normalizePhilipsPayload(payload: PhilipsPayload): NormalizedVitals {
  const takenAt = new Date(payload.timestamp_iso);
  if (Number.isNaN(takenAt.getTime())) {
    throw new DeviceNormalizationError(`Invalid timestamp_iso: "${payload.timestamp_iso}"`);
  }
  return validateAndFinalize(
    {
      patientId: payload.patient_id,
      deviceId: payload.device_id,
      takenAt,
      heartRateBpm: payload.hr,
      systolicBp: payload.nbp_sys,
      diastolicBp: payload.nbp_dia,
      spo2Percent: payload.spo2,
      respiratoryRateBpm: payload.resp_rate,
    },
    'PHILIPS_JSON',
  );
}

export interface GePayload {
  mrn: string;
  monitorId: string;
  time: string;
  measurements: Array<{ code: 'HR' | 'SPO2' | 'NIBP_SYS' | 'NIBP_DIA' | 'RESP' | 'TEMP'; value: number }>;
}

export function normalizeGePayload(payload: GePayload): NormalizedVitals {
  const epochMillis = Number(payload.time);
  if (!Number.isFinite(epochMillis)) {
    throw new DeviceNormalizationError(`Invalid time value: "${payload.time}"`);
  }
  const takenAt = new Date(epochMillis);

  const get = (code: GePayload['measurements'][number]['code']) => payload.measurements.find((m) => m.code === code)?.value;

  return validateAndFinalize(
    {
      patientId: payload.mrn,
      deviceId: payload.monitorId,
      takenAt,
      heartRateBpm: get('HR'),
      systolicBp: get('NIBP_SYS'),
      diastolicBp: get('NIBP_DIA'),
      spo2Percent: get('SPO2'),
      respiratoryRateBpm: get('RESP'),
      temperatureCelsius: get('TEMP'),
    },
    'GE_MEASUREMENTS',
  );
}

export interface GenericPayload {
  patientId: string;
  deviceId: string;
  takenAt: string;
  heartRateBpm?: number;
  systolicBp?: number;
  diastolicBp?: number;
  spo2Percent?: number;
  respiratoryRateBpm?: number;
  temperatureCelsius?: number;
}

export function normalizeGenericPayload(payload: GenericPayload): NormalizedVitals {
  const takenAt = new Date(payload.takenAt);
  if (Number.isNaN(takenAt.getTime())) {
    throw new DeviceNormalizationError(`Invalid takenAt: "${payload.takenAt}"`);
  }
  return validateAndFinalize({ ...payload, takenAt }, 'GENERIC');
}

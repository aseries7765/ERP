import Decimal from 'decimal.js';
import { buildConversionGraph, findConversionPath } from './chains';
import { toDecimal, roundTo } from './precision';
import { ConversionResult, UomConversionError, UomConversionRule } from './types';

export interface ConvertOptions {
  /** Item-scoped conversion rules apply only when this itemId matches (pack sizes). */
  itemId?: string;
  /** Decimal places to round the result to. Default: no rounding (full precision). */
  scale?: number;
}

/**
 * Convert `quantity` from `fromCode` to `toCode`, given the tenant's configured
 * conversion rules (item-specific pack sizes + any tenant-defined links) on top
 * of the built-in standard-unit dimension graph.
 *
 * Precision: uses Decimal throughout (G18). Never touches `number` arithmetic.
 */
export function convert(
  quantity: string | number | Decimal,
  fromCode: string,
  toCode: string,
  rules: UomConversionRule[],
  options: ConvertOptions = {},
): ConversionResult {
  const qty = toDecimal(quantity);
  if (qty.isNegative()) {
    throw new UomConversionError('Quantity to convert must be >= 0');
  }

  const graph = buildConversionGraph(rules, options.itemId);
  const { factor, path } = findConversionPath(graph, fromCode, toCode);

  let result = qty.mul(factor);
  if (options.scale !== undefined) {
    result = roundTo(result, options.scale);
  }

  return { quantity: result, fromCode, toCode, path };
}

/**
 * Convenience: is a direct or chained conversion possible between two codes
 * given the current rule set? Does not throw.
 */
export function canConvert(
  fromCode: string,
  toCode: string,
  rules: UomConversionRule[],
  itemId?: string,
): boolean {
  try {
    const graph = buildConversionGraph(rules, itemId);
    findConversionPath(graph, fromCode, toCode);
    return true;
  } catch {
    return false;
  }
}

/**
 * Core types for the UoM conversion engine.
 *
 * All quantities that cross this engine's boundary are represented as
 * strings (decimal-safe) or Decimal instances — never `number` — per
 * G18: "UoM conversions MUST use Decimal. No Float. Ever."
 */

import Decimal from 'decimal.js';

/** A dimension groups UoMs that can be converted to one another (mass, volume, count, length...). */
export type UomDimension = 'mass' | 'volume' | 'length' | 'count' | 'area' | 'time';

export interface UomDefinition {
  /** Unique code, e.g. "kg", "ea", "box-10". Tenant-scoped in the DB layer; global here. */
  code: string;
  /** Human label, e.g. "Kilogram". */
  label: string;
  dimension: UomDimension;
  /**
   * Factor to convert 1 unit of this UoM into the dimension's canonical base unit
   * (kg for mass, L for volume, m for length, ea for count, m2 for area, s for time).
   * Stored as a decimal-safe string to avoid float literals in source.
   */
  toBaseFactor: string;
}

/**
 * A direct, explicit conversion between two UoM codes, as configured by a tenant
 * (e.g. "1 pallet = 50 ea" for a specific item — not a physical-dimension fact).
 * These take precedence over dimension-based conversion and are required when
 * UoMs don't share a physical dimension (e.g. "box" of a specific item vs "ea").
 */
export interface UomConversionRule {
  fromCode: string;
  toCode: string;
  /** Multiply a quantity in `fromCode` by this factor to get `toCode`. */
  factor: string;
  /** Optional: rule only applies to this item (item-specific pack sizes). Global if omitted. */
  itemId?: string;
}

export interface ConversionResult {
  quantity: Decimal;
  fromCode: string;
  toCode: string;
  /** The chain of UoM codes actually traversed to compute the result (for audit/debug). */
  path: string[];
}

export class UomConversionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'UomConversionError';
  }
}

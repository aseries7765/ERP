import Decimal from 'decimal.js';
import { STANDARD_UNITS } from './standard-units';
import { UomConversionError, UomConversionRule } from './types';
import { toDecimal } from './precision';

interface Edge {
  to: string;
  /** Multiply a quantity in the edge's `from` node by this to get the `to` node's quantity. */
  factor: Decimal;
}

/**
 * Builds a directed graph of convertible UoM codes:
 *  - Standard units sharing a dimension are fully connected (via their toBaseFactor).
 *  - Explicit UomConversionRule entries add edges (and their inverse) on top,
 *    which is how item-specific pack sizes (pallet, box, case) enter the graph.
 *
 * itemId filters which item-scoped rules are included; global rules
 * (rule.itemId undefined) always apply.
 */
export function buildConversionGraph(
  rules: UomConversionRule[],
  itemId?: string,
): Map<string, Edge[]> {
  const graph = new Map<string, Edge[]>();

  const addEdge = (from: string, to: string, factor: Decimal) => {
    if (factor.lte(0)) {
      throw new UomConversionError(`Conversion factor must be positive: ${from} -> ${to}`);
    }
    if (!graph.has(from)) graph.set(from, []);
    graph.get(from)!.push({ to, factor });
  };

  // Dimension-based edges between all standard units sharing a dimension.
  const byDimension = new Map<string, string[]>();
  for (const u of STANDARD_UNITS) {
    if (!byDimension.has(u.dimension)) byDimension.set(u.dimension, []);
    byDimension.get(u.dimension)!.push(u.code);
  }
  for (const codes of byDimension.values()) {
    for (const a of codes) {
      for (const b of codes) {
        if (a === b) continue;
        const ua = STANDARD_UNITS.find((u) => u.code === a)!;
        const ub = STANDARD_UNITS.find((u) => u.code === b)!;
        // a -> base -> b :  factor = toBaseFactor(a) / toBaseFactor(b)
        const factor = toDecimal(ua.toBaseFactor).div(toDecimal(ub.toBaseFactor));
        addEdge(a, b, factor);
      }
    }
  }

  // Explicit rules (global + item-scoped), plus their inverse.
  for (const rule of rules) {
    if (rule.itemId && rule.itemId !== itemId) continue;
    const factor = toDecimal(rule.factor);
    addEdge(rule.fromCode, rule.toCode, factor);
    addEdge(rule.toCode, rule.fromCode, new Decimal(1).div(factor));
  }

  return graph;
}

/**
 * BFS shortest path (fewest hops) from `fromCode` to `toCode`, returning the
 * cumulative multiplicative factor and the path traversed.
 * Deterministic: ties in hop-count are broken by insertion order, so results
 * are stable given the same rule set.
 */
export function findConversionPath(
  graph: Map<string, Edge[]>,
  fromCode: string,
  toCode: string,
): { factor: Decimal; path: string[] } {
  if (fromCode === toCode) {
    return { factor: new Decimal(1), path: [fromCode] };
  }
  if (!graph.has(fromCode)) {
    throw new UomConversionError(`Unknown source UoM: ${fromCode}`);
  }

  const visited = new Set<string>([fromCode]);
  const queue: { node: string; factor: Decimal; path: string[] }[] = [
    { node: fromCode, factor: new Decimal(1), path: [fromCode] },
  ];

  while (queue.length > 0) {
    const current = queue.shift()!;
    const edges = graph.get(current.node) ?? [];
    for (const edge of edges) {
      if (visited.has(edge.to)) continue;
      const nextFactor = current.factor.mul(edge.factor);
      const nextPath = [...current.path, edge.to];
      if (edge.to === toCode) {
        return { factor: nextFactor, path: nextPath };
      }
      visited.add(edge.to);
      queue.push({ node: edge.to, factor: nextFactor, path: nextPath });
    }
  }

  throw new UomConversionError(
    `No conversion path found from "${fromCode}" to "${toCode}". ` +
      `Add a UomConversionRule linking them (directly or via an intermediate UoM).`,
  );
}

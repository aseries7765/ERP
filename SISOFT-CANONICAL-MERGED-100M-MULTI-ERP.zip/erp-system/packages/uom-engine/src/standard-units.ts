import { UomDefinition } from './types';

/**
 * Built-in standard units, seeded per-tenant by
 * apps/api/prisma/seed/inventory/seed-uoms.ts. Kept here so the engine
 * is self-contained and testable without a DB.
 */
export const STANDARD_UNITS: UomDefinition[] = [
  // Mass — base: kg
  { code: 'kg', label: 'Kilogram', dimension: 'mass', toBaseFactor: '1' },
  { code: 'g', label: 'Gram', dimension: 'mass', toBaseFactor: '0.001' },
  { code: 'mg', label: 'Milligram', dimension: 'mass', toBaseFactor: '0.000001' },
  { code: 'lb', label: 'Pound', dimension: 'mass', toBaseFactor: '0.45359237' },
  { code: 'oz', label: 'Ounce', dimension: 'mass', toBaseFactor: '0.028349523125' },

  // Volume — base: L
  { code: 'L', label: 'Litre', dimension: 'volume', toBaseFactor: '1' },
  { code: 'mL', label: 'Millilitre', dimension: 'volume', toBaseFactor: '0.001' },
  { code: 'gal', label: 'Gallon (US)', dimension: 'volume', toBaseFactor: '3.785411784' },

  // Length — base: m
  { code: 'm', label: 'Metre', dimension: 'length', toBaseFactor: '1' },
  { code: 'cm', label: 'Centimetre', dimension: 'length', toBaseFactor: '0.01' },
  { code: 'mm', label: 'Millimetre', dimension: 'length', toBaseFactor: '0.001' },
  { code: 'ft', label: 'Foot', dimension: 'length', toBaseFactor: '0.3048' },

  // Area — base: m2
  { code: 'm2', label: 'Square metre', dimension: 'area', toBaseFactor: '1' },

  // Time — base: s
  { code: 's', label: 'Second', dimension: 'time', toBaseFactor: '1' },
  { code: 'min', label: 'Minute', dimension: 'time', toBaseFactor: '60' },
  { code: 'hr', label: 'Hour', dimension: 'time', toBaseFactor: '3600' },

  // Count — base: ea. Pack sizes (box, case, pallet) are intentionally NOT
  // seeded here with fixed factors, since they're item-specific
  // (a "box" of screws != a "box" of monitors). Those go through
  // UomConversionRule, scoped by itemId, not through dimension conversion.
  { code: 'ea', label: 'Each', dimension: 'count', toBaseFactor: '1' },
  { code: 'dz', label: 'Dozen', dimension: 'count', toBaseFactor: '12' },
];

export function findStandardUnit(code: string): UomDefinition | undefined {
  return STANDARD_UNITS.find((u) => u.code === code);
}

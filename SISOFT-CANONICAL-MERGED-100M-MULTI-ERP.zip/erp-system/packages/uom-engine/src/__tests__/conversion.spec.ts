import { describe, it, expect } from 'vitest';
import { convert, canConvert } from '../conversion';
import { UomConversionRule, UomConversionError } from '../types';
import Decimal from 'decimal.js';

describe('convert() — standard dimension conversions', () => {
  it('converts kg to g', () => {
    const result = convert('2.5', 'kg', 'g', []);
    expect(result.quantity.toString()).toBe('2500');
  });

  it('converts g to kg with rounding scale', () => {
    const result = convert('1234', 'g', 'kg', [], { scale: 3 });
    expect(result.quantity.toString()).toBe('1.234');
  });

  it('converts L to mL', () => {
    const result = convert('3', 'L', 'mL', []);
    expect(result.quantity.toString()).toBe('3000');
  });

  it('same-unit conversion is identity', () => {
    const result = convert('7', 'ea', 'ea', []);
    expect(result.quantity.toString()).toBe('7');
    expect(result.path).toEqual(['ea']);
  });

  it('round-trips kg -> lb -> kg within tiny epsilon at high precision', () => {
    const toLb = convert('10', 'kg', 'lb', []);
    const back = convert(toLb.quantity, 'lb', 'kg', []);
    const diff = back.quantity.minus('10').abs();
    expect(diff.lessThan('0.0000001')).toBe(true);
  });
});

describe('convert() — item-specific pack-size rules (multi-UoM)', () => {
  // Laptop: base "ea", purchase UoM "pallet" (50 ea), sales UoM "box" (10 ea)
  const rules: UomConversionRule[] = [
    { fromCode: 'pallet', toCode: 'ea', factor: '50', itemId: 'item-laptop' },
    { fromCode: 'box', toCode: 'ea', factor: '10', itemId: 'item-laptop' },
  ];

  it('converts pallet to ea for the scoped item', () => {
    const result = convert('2', 'pallet', 'ea', rules, { itemId: 'item-laptop' });
    expect(result.quantity.toString()).toBe('100');
  });

  it('converts pallet to box via chained ea (multi-hop)', () => {
    const result = convert('1', 'pallet', 'box', rules, { itemId: 'item-laptop' });
    // 1 pallet = 50 ea = 5 box
    expect(result.quantity.toString()).toBe('5');
    expect(result.path).toEqual(['pallet', 'ea', 'box']);
  });

  it('converts back from ea to pallet using the inverse edge', () => {
    const result = convert('150', 'ea', 'pallet', rules, { itemId: 'item-laptop' });
    expect(result.quantity.toString()).toBe('3');
  });

  it('does not apply item-scoped rule to a different item', () => {
    expect(canConvert('pallet', 'ea', rules, 'item-other')).toBe(false);
  });

  it('global (non-item-scoped) rule applies regardless of itemId', () => {
    const globalRules: UomConversionRule[] = [{ fromCode: 'dozen-pack', toCode: 'ea', factor: '12' }];
    expect(canConvert('dozen-pack', 'ea', globalRules, 'any-item')).toBe(true);
    expect(canConvert('dozen-pack', 'ea', globalRules)).toBe(true);
  });
});

describe('convert() — error handling', () => {
  it('throws when no path exists', () => {
    expect(() => convert('1', 'kg', 'unknown-uom', [])).toThrow(UomConversionError);
  });

  it('throws on negative quantity', () => {
    expect(() => convert('-1', 'kg', 'g', [])).toThrow(UomConversionError);
  });

  it('rejects a non-positive conversion factor in a rule', () => {
    const badRules: UomConversionRule[] = [{ fromCode: 'x', toCode: 'y', factor: '0' }];
    expect(() => convert('1', 'x', 'y', badRules)).toThrow(UomConversionError);
  });
});

describe('convert() — Decimal precision (G18)', () => {
  it('never loses precision the way float arithmetic would (0.1 + 0.2 style case)', () => {
    // 3 conversions of 0.1 kg to g should sum exactly to 300g, not 299.99999999999994
    const a = convert('0.1', 'kg', 'g', []).quantity;
    const b = convert('0.1', 'kg', 'g', []).quantity;
    const c = convert('0.1', 'kg', 'g', []).quantity;
    const sum = a.plus(b).plus(c);
    expect(sum.toString()).toBe('300');
    expect(sum).toBeInstanceOf(Decimal);
  });
});

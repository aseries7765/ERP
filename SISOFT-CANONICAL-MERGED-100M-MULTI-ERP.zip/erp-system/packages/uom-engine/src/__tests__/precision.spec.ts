import { describe, it, expect } from 'vitest';
import Decimal from 'decimal.js';
import { toDecimal, roundTo, assertSumsExactly } from '../precision';

describe('toDecimal()', () => {
  it('parses a decimal string exactly', () => {
    expect(toDecimal('19.999').toString()).toBe('19.999');
  });

  it('accepts a Decimal instance unchanged', () => {
    const d = new Decimal('5.5');
    expect(toDecimal(d)).toBe(d);
  });

  it('converts a finite number via string (no float artifacts)', () => {
    expect(toDecimal(1.1).toString()).toBe('1.1');
  });

  it('rejects NaN / Infinity', () => {
    expect(() => toDecimal(NaN)).toThrow(RangeError);
    expect(() => toDecimal(Infinity)).toThrow(RangeError);
  });
});

describe('roundTo()', () => {
  it('rounds half up at the given scale', () => {
    expect(roundTo(new Decimal('1.005'), 2).toString()).toBe('1.01');
    expect(roundTo(new Decimal('1.004'), 2).toString()).toBe('1.00');
  });

  it('rejects a negative scale', () => {
    expect(() => roundTo(new Decimal('1'), -1)).toThrow(RangeError);
  });
});

describe('assertSumsExactly() — landed-cost invariant (G21)', () => {
  it('passes when parts sum exactly to total', () => {
    const parts = [new Decimal('33.34'), new Decimal('33.33'), new Decimal('33.33')];
    expect(() => assertSumsExactly(parts, new Decimal('100.00'), 2)).not.toThrow();
  });

  it('throws when parts drift from total', () => {
    const parts = [new Decimal('33.33'), new Decimal('33.33'), new Decimal('33.33')];
    expect(() => assertSumsExactly(parts, new Decimal('100.00'), 2)).toThrow(/drift/);
  });
});

import Decimal from 'decimal.js';

/**
 * Precision policy for the engine (G18: Decimal, never Float).
 *
 * - Internal working precision: 28 significant digits (Decimal.js default-ish,
 *   set explicitly so behavior doesn't silently change with a library upgrade).
 * - Output rounding: callers choose a `scale` (decimal places) appropriate to
 *   the UoM's storage precision (e.g. 3 dp for kg, 0 dp for "ea").
 * - Rounding mode: ROUND_HALF_UP, matching typical accounting/inventory
 *   conventions (round 0.5 up, not banker's rounding), to stay predictable
 *   for finance reconciliation in M8.
 */
Decimal.set({ precision: 28, rounding: Decimal.ROUND_HALF_UP });

export function toDecimal(value: string | number | Decimal): Decimal {
  if (value instanceof Decimal) return value;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) {
      throw new RangeError(`Cannot convert non-finite number to Decimal: ${value}`);
    }
    // Accepted at the boundary for ergonomics, but converted immediately —
    // no float arithmetic ever happens on it.
    return new Decimal(value.toString());
  }
  return new Decimal(value);
}

/**
 * Round a Decimal to `scale` decimal places using the engine's rounding policy.
 */
export function roundTo(value: Decimal, scale: number): Decimal {
  if (scale < 0) throw new RangeError('scale must be >= 0');
  return value.toDecimalPlaces(scale, Decimal.ROUND_HALF_UP);
}

/**
 * Asserts that summing `parts` reproduces `total` exactly at the given scale.
 * Used by landed-cost allocation (G21: must sum exactly, no rounding drift).
 * Throws if it doesn't — callers should apply the remainder-distribution
 * pattern (see landed-cost.service.ts) rather than silently losing cents.
 */
export function assertSumsExactly(parts: Decimal[], total: Decimal, scale: number): void {
  const sum = parts.reduce((acc, p) => acc.plus(p), new Decimal(0));
  const roundedSum = roundTo(sum, scale);
  const roundedTotal = roundTo(total, scale);
  if (!roundedSum.equals(roundedTotal)) {
    throw new RangeError(
      `Allocation drift: parts sum to ${roundedSum.toString()}, expected ${roundedTotal.toString()}`,
    );
  }
}

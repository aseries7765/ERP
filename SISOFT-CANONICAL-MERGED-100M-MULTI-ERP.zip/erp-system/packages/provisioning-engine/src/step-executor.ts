import {
  EventSink,
  ProvisioningContext,
  ProvisioningStep,
  ProvisioningStepError,
  StepLogEntry,
  TimeoutError,
} from './types.js';

export interface StepExecutorOptions {
  emit?: EventSink;
  /** Injectable sleep for fast deterministic tests. Defaults to real setTimeout. */
  sleep?: (ms: number) => Promise<void>;
}

const defaultSleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

function withTimeout<T>(promise: Promise<T>, ms: number, stepName: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new TimeoutError(stepName, ms)), ms);
    promise.then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      },
    );
  });
}

/**
 * Executes a single provisioning step with retry (exponential backoff)
 * and a hard per-step timeout. On success, registers the step's rollback
 * function (if any) onto the context's rollback stack. Logs every attempt.
 */
export class StepExecutorService {
  private readonly emit: EventSink;
  private readonly sleep: (ms: number) => Promise<void>;
  public readonly logs: StepLogEntry[] = [];

  constructor(options: StepExecutorOptions = {}) {
    this.emit = options.emit ?? (() => {});
    this.sleep = options.sleep ?? defaultSleep;
  }

  async executeStep(step: ProvisioningStep, context: ProvisioningContext): Promise<void> {
    const maxAttempts = step.maxAttempts ?? 3;
    const startedAt = Date.now();
    this.emit({ type: 'provisioning.step.started', requestId: context.requestId, timestamp: startedAt, payload: { step: step.name } });

    let lastError: unknown;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      this.log({ stepName: step.name, status: 'started', startedAt: Date.now(), attempt });
      try {
        const result = await withTimeout(step.execute(context), step.timeoutMs, step.name);

        if (step.rollback) {
          context.rollbackStack.push({ stepName: step.name, fn: () => step.rollback!(context) });
        }
        if (result?.output) {
          Object.assign(context.data, result.output);
        }

        const completedAt = Date.now();
        this.log({
          stepName: step.name,
          status: 'completed',
          startedAt,
          completedAt,
          durationMs: completedAt - startedAt,
          attempt,
        });
        this.emit({
          type: 'provisioning.step.completed',
          requestId: context.requestId,
          timestamp: completedAt,
          payload: { step: step.name, attempt },
        });
        return;
      } catch (error) {
        lastError = error;
        const isLastAttempt = attempt === maxAttempts;
        if (isLastAttempt) {
          this.log({
            stepName: step.name,
            status: 'failed',
            startedAt,
            error: error instanceof Error ? error.message : String(error),
            attempt,
          });
        }
        if (!isLastAttempt) {
          const backoffMs = 2 ** (attempt - 1) * 100;
          await this.sleep(backoffMs);
        }
      }
    }

    this.emit({
      type: 'provisioning.step.failed',
      requestId: context.requestId,
      timestamp: Date.now(),
      payload: { step: step.name, error: lastError instanceof Error ? lastError.message : String(lastError) },
    });
    throw new ProvisioningStepError(step.name, lastError);
  }

  private log(entry: StepLogEntry) {
    this.logs.push(entry);
  }
}

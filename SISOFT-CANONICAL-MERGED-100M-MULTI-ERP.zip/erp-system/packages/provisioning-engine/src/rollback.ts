import { EventSink, ProvisioningContext } from './types.js';

export interface RollbackReport {
  succeeded: string[];
  failed: Array<{ stepName: string; error: string }>;
  fullyRolledBack: boolean;
}

/**
 * Pops the context's rollback stack in LIFO order and executes each
 * compensating action. Continues through failures (best-effort) so a
 * single stuck resource doesn't block cleanup of everything else, then
 * reports which steps failed to roll back so ops can intervene manually.
 */
export class RollbackService {
  constructor(private readonly emit: EventSink = () => {}) {}

  async rollback(context: ProvisioningContext): Promise<RollbackReport> {
    const succeeded: string[] = [];
    const failed: Array<{ stepName: string; error: string }> = [];

    this.emit({ type: 'provisioning.rolled_back', requestId: context.requestId, timestamp: Date.now(), payload: { phase: 'start' } });

    while (context.rollbackStack.length > 0) {
      const entry = context.rollbackStack.pop()!;
      try {
        await entry.fn();
        succeeded.push(entry.stepName);
      } catch (error) {
        failed.push({ stepName: entry.stepName, error: error instanceof Error ? error.message : String(error) });
      }
    }

    const fullyRolledBack = failed.length === 0;
    this.emit({
      type: fullyRolledBack ? 'provisioning.rolled_back' : 'provisioning.failed',
      requestId: context.requestId,
      timestamp: Date.now(),
      payload: { phase: 'end', succeeded, failed },
    });

    return { succeeded, failed, fullyRolledBack };
  }
}

import { EventSink, ProvisioningEvent } from './types.js';

/**
 * Minimal in-process event bus. In the real system this would publish to
 * the control-plane events queue (e.g. Kafka/SQS) — that transport is
 * NOT implemented here (see MANIFEST.md "Cut from this delivery").
 * Swap `publish` for a real transport by constructing EventBus with a
 * custom sink.
 */
export class EventBus {
  private readonly listeners: EventSink[] = [];
  public readonly received: ProvisioningEvent[] = [];

  subscribe(sink: EventSink): () => void {
    this.listeners.push(sink);
    return () => {
      const idx = this.listeners.indexOf(sink);
      if (idx >= 0) this.listeners.splice(idx, 1);
    };
  }

  publish: EventSink = (event) => {
    this.received.push(event);
    for (const listener of this.listeners) listener(event);
  };
}

import { ProvisioningContext } from './types.js';

/**
 * Wraps a step's "create resource" logic so that re-running the same
 * step (e.g. after a crash/resume) does not create a duplicate resource.
 *
 * Contract: `lookup` must check the underlying cloud/DB for a resource
 * that was already created by a previous run of this exact step for this
 * exact request (e.g. by a deterministic name derived from requestId).
 * If found, its id/data is reused and `create` is skipped entirely.
 *
 * This is a helper, not a magic guarantee — each Oracle step must supply
 * a correct, deterministic `lookup`. Tests in this package verify the
 * wrapper's control flow; cloud-provider-oracle tests verify real lookups.
 */
export async function ensureIdempotent<T>(
  context: ProvisioningContext,
  key: string,
  ops: {
    lookup: () => Promise<T | null>;
    create: () => Promise<T>;
  },
): Promise<{ value: T; created: boolean }> {
  const cacheKey = `__idempotency__:${key}`;
  const cached = context.data[cacheKey] as T | undefined;
  if (cached !== undefined) {
    return { value: cached, created: false };
  }

  const existing = await ops.lookup();
  if (existing !== null) {
    context.data[cacheKey] = existing;
    return { value: existing, created: false };
  }

  const created = await ops.create();
  context.data[cacheKey] = created;
  return { value: created, created: true };
}

/**
 * Core types for the provisioning-engine package.
 * These types are intentionally cloud-agnostic: this package knows nothing
 * about Oracle. Cloud-specific work happens inside Step implementations
 * supplied by the caller (see packages/cloud-provider-oracle).
 */

export type ProvisioningState =
  | 'pending'
  | 'validating'
  | 'validated'
  | 'reserving'
  | 'reserved'
  | 'provisioning'
  | 'bootstrapping'
  | 'smoke_testing'
  | 'activating'
  | 'active'
  | 'failing'
  | 'rolling_back'
  | 'rolled_back'
  | 'failed'
  | 'failed_rollback'
  | 'cancelling'
  | 'cancelled';

export const TERMINAL_STATES: ReadonlySet<ProvisioningState> = new Set([
  'active',
  'rolled_back',
  'failed',
  'failed_rollback',
  'cancelled',
]);

/**
 * Explicit allow-list of legal state transitions. Any transition not
 * listed here is rejected by the state machine (see state-machine.ts).
 */
export const ALLOWED_TRANSITIONS: Record<ProvisioningState, ProvisioningState[]> = {
  pending: ['validating', 'cancelling'],
  validating: ['validated', 'failing', 'cancelling'],
  validated: ['reserving', 'cancelling'],
  reserving: ['reserved', 'failing', 'cancelling'],
  reserved: ['provisioning', 'cancelling'],
  provisioning: ['bootstrapping', 'failing', 'cancelling'],
  bootstrapping: ['smoke_testing', 'failing', 'cancelling'],
  smoke_testing: ['activating', 'failing', 'cancelling'],
  activating: ['active', 'failing'],
  active: [],
  failing: ['rolling_back', 'failed'],
  rolling_back: ['rolled_back', 'failed_rollback'],
  rolled_back: [],
  failed: [],
  failed_rollback: [],
  cancelling: ['rolling_back', 'cancelled'],
  cancelled: [],
};

export interface ProvisioningContext {
  requestId: string;
  customerId: string;
  planId: string;
  /** Arbitrary bag of data steps read/write as the workflow progresses
   * (compartment id, VCN id, ADB connection info, etc). */
  data: Record<string, unknown>;
  /** LIFO stack of compensating actions registered by completed steps. */
  rollbackStack: RollbackEntry[];
}

export interface RollbackEntry {
  stepName: string;
  fn: () => Promise<void>;
}

export interface StepResult {
  output?: Record<string, unknown>;
}

/**
 * Contract every provisioning step must implement. Steps MUST be
 * idempotent: calling execute() twice with the same context must not
 * create duplicate resources or fail (see idempotency.ts helpers).
 */
export interface ProvisioningStep {
  name: string;
  /** Per-step timeout in milliseconds. */
  timeoutMs: number;
  /** Max retry attempts on transient failure (exponential backoff). */
  maxAttempts?: number;
  execute(context: ProvisioningContext): Promise<StepResult>;
  /** Compensating action. Optional: some steps (e.g. pure reads) have none. */
  rollback?(context: ProvisioningContext): Promise<void>;
}

export interface StepLogEntry {
  stepName: string;
  status: 'started' | 'completed' | 'failed' | 'skipped';
  startedAt: number;
  completedAt?: number;
  durationMs?: number;
  attempt?: number;
  error?: string;
}

export interface ProvisioningEvent {
  type: string;
  requestId: string;
  timestamp: number;
  payload?: Record<string, unknown>;
}

export type EventSink = (event: ProvisioningEvent) => void;

export class ProvisioningStepError extends Error {
  constructor(public readonly stepName: string, public readonly cause: unknown) {
    super(`Step "${stepName}" failed: ${cause instanceof Error ? cause.message : String(cause)}`);
    this.name = 'ProvisioningStepError';
  }
}

export class InvalidTransitionError extends Error {
  constructor(from: ProvisioningState, to: ProvisioningState) {
    super(`Invalid state transition: "${from}" -> "${to}"`);
    this.name = 'InvalidTransitionError';
  }
}

export class TimeoutError extends Error {
  constructor(stepName: string, timeoutMs: number) {
    super(`Step "${stepName}" timed out after ${timeoutMs}ms`);
    this.name = 'TimeoutError';
  }
}

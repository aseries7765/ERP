import { RollbackService } from './rollback.js';
import { ProvisioningStateMachine } from './state-machine.js';
import { StepExecutorService } from './step-executor.js';
import { EventSink, ProvisioningContext, ProvisioningState, ProvisioningStep } from './types.js';

export interface OrchestratorResult {
  finalState: ProvisioningState;
  context: ProvisioningContext;
  error?: string;
}

export interface RunOptions {
  /** Map from step name to the state the machine should be in while that
   * step (or group of steps) runs. Steps without an entry keep the
   * machine in 'provisioning'. */
  stateForStep?: (stepName: string) => ProvisioningState | undefined;
  /** Called before rollback to allow callers to hook in cancellation checks. */
  isCancelled?: () => boolean;
}

/**
 * Sequences a list of ProvisioningStep implementations for one request.
 * On any step failure, transitions to 'failing' -> 'rolling_back' and
 * unwinds via RollbackService. This class is intentionally cloud-agnostic:
 * the `steps` array is supplied by the caller (see cloud-provider-oracle
 * for the real Oracle steps; this package's tests use fakes).
 */
export class ProvisioningOrchestrator {
  private readonly executor: StepExecutorService;
  private readonly rollbackService: RollbackService;

  constructor(private readonly emit: EventSink = () => {}) {
    this.executor = new StepExecutorService({ emit });
    this.rollbackService = new RollbackService(emit);
  }

  async run(
    steps: ProvisioningStep[],
    context: ProvisioningContext,
    options: RunOptions = {},
  ): Promise<OrchestratorResult> {
    const machine = new ProvisioningStateMachine('pending');
    this.safeTransition(machine, 'validating');
    this.safeTransition(machine, 'validated');
    this.safeTransition(machine, 'reserving');
    this.safeTransition(machine, 'reserved');
    this.safeTransition(machine, 'provisioning');

    this.emit({ type: 'provisioning.started', requestId: context.requestId, timestamp: Date.now() });

    for (const step of steps) {
      if (options.isCancelled?.()) {
        machine.transition('cancelling');
        const report = await this.rollbackService.rollback(context);
        machine.transition('rolling_back');
        machine.transition(report.fullyRolledBack ? 'rolled_back' : 'failed_rollback');
        return { finalState: machine.getState(), context, error: 'cancelled' };
      }

      try {
        await this.executor.executeStep(step, context);
      } catch (error) {
        machine.transition('failing');
        const report = await this.rollbackService.rollback(context);
        machine.transition('rolling_back');
        machine.transition(report.fullyRolledBack ? 'rolled_back' : 'failed_rollback');
        this.emit({
          type: 'provisioning.failed',
          requestId: context.requestId,
          timestamp: Date.now(),
          payload: { error: error instanceof Error ? error.message : String(error), rollback: report },
        });
        return {
          finalState: machine.getState(),
          context,
          error: error instanceof Error ? error.message : String(error),
        };
      }
    }

    this.safeTransition(machine, 'bootstrapping');
    this.safeTransition(machine, 'smoke_testing');
    this.safeTransition(machine, 'activating');
    machine.transition('active');

    this.emit({ type: 'provisioning.completed', requestId: context.requestId, timestamp: Date.now() });
    this.emit({ type: 'environment.ready', requestId: context.requestId, timestamp: Date.now() });

    return { finalState: machine.getState(), context };
  }

  get stepLogs() {
    return this.executor.logs;
  }

  private safeTransition(machine: ProvisioningStateMachine, to: ProvisioningState) {
    if (machine.canTransition(to)) {
      machine.transition(to);
    }
  }
}

export function createContext(requestId: string, customerId: string, planId: string): ProvisioningContext {
  return { requestId, customerId, planId, data: {}, rollbackStack: [] };
}

import { ALLOWED_TRANSITIONS, InvalidTransitionError, ProvisioningState, TERMINAL_STATES } from './types.js';

/**
 * Pure, in-memory state machine for a single provisioning request.
 * Persistence (writing the state to the control-plane DB) is the
 * responsibility of the caller — this class only enforces which
 * transitions are legal and keeps a transition history for audit/debug.
 */
export class ProvisioningStateMachine {
  private history: Array<{ from: ProvisioningState; to: ProvisioningState; at: number }> = [];

  constructor(private state: ProvisioningState = 'pending') {}

  getState(): ProvisioningState {
    return this.state;
  }

  isTerminal(): boolean {
    return TERMINAL_STATES.has(this.state);
  }

  getHistory() {
    return [...this.history];
  }

  canTransition(to: ProvisioningState): boolean {
    return ALLOWED_TRANSITIONS[this.state]?.includes(to) ?? false;
  }

  transition(to: ProvisioningState): void {
    if (this.isTerminal()) {
      throw new InvalidTransitionError(this.state, to);
    }
    if (!this.canTransition(to)) {
      throw new InvalidTransitionError(this.state, to);
    }
    const from = this.state;
    this.state = to;
    this.history.push({ from, to, at: Date.now() });
  }
}

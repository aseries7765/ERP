import assert from 'node:assert/strict';
import { test } from 'node:test';
import { RollbackService } from '../rollback.js';
import { ProvisioningContext } from '../types.js';

function ctx(): ProvisioningContext {
  return { requestId: 'r1', customerId: 'c1', planId: 'starter', data: {}, rollbackStack: [] };
}

test('executes rollback stack in LIFO order', async () => {
  const order: string[] = [];
  const c = ctx();
  c.rollbackStack.push({ stepName: 'a', fn: async () => { order.push('a'); } });
  c.rollbackStack.push({ stepName: 'b', fn: async () => { order.push('b'); } });
  c.rollbackStack.push({ stepName: 'c', fn: async () => { order.push('c'); } });

  const svc = new RollbackService();
  const report = await svc.rollback(c);

  assert.deepEqual(order, ['c', 'b', 'a']);
  assert.equal(report.fullyRolledBack, true);
  assert.equal(c.rollbackStack.length, 0);
});

test('continues past a failed rollback step and reports it', async () => {
  const order: string[] = [];
  const c = ctx();
  c.rollbackStack.push({ stepName: 'a', fn: async () => { order.push('a'); } });
  c.rollbackStack.push({
    stepName: 'b-broken',
    fn: async () => {
      throw new Error('vault locked');
    },
  });
  c.rollbackStack.push({ stepName: 'c', fn: async () => { order.push('c'); } });

  const svc = new RollbackService();
  const report = await svc.rollback(c);

  assert.deepEqual(order, ['c', 'a']);
  assert.equal(report.fullyRolledBack, false);
  assert.equal(report.failed.length, 1);
  assert.equal(report.failed[0].stepName, 'b-broken');
  assert.deepEqual(report.succeeded, ['c', 'a']);
});

test('empty rollback stack is a no-op success', async () => {
  const svc = new RollbackService();
  const report = await svc.rollback(ctx());
  assert.equal(report.fullyRolledBack, true);
  assert.equal(report.succeeded.length, 0);
});

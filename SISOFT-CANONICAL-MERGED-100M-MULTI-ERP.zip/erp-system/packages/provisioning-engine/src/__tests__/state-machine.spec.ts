import assert from 'node:assert/strict';
import { test } from 'node:test';
import { InvalidTransitionError } from '../types.js';
import { ProvisioningStateMachine } from '../state-machine.js';

test('allows a valid transition chain', () => {
  const m = new ProvisioningStateMachine();
  m.transition('validating');
  m.transition('validated');
  m.transition('reserving');
  m.transition('reserved');
  m.transition('provisioning');
  assert.equal(m.getState(), 'provisioning');
  assert.equal(m.getHistory().length, 5);
});

test('rejects an illegal transition', () => {
  const m = new ProvisioningStateMachine();
  assert.throws(() => m.transition('active'), InvalidTransitionError);
});

test('rejects any transition once terminal', () => {
  const m = new ProvisioningStateMachine('cancelled');
  assert.equal(m.isTerminal(), true);
  assert.throws(() => m.transition('pending'), InvalidTransitionError);
});

test('failure path reaches rolled_back', () => {
  const m = new ProvisioningStateMachine('provisioning');
  m.transition('failing');
  m.transition('rolling_back');
  m.transition('rolled_back');
  assert.equal(m.getState(), 'rolled_back');
  assert.equal(m.isTerminal(), true);
});

test('cancel path from pending reaches cancelled', () => {
  const m = new ProvisioningStateMachine('pending');
  m.transition('cancelling');
  m.transition('cancelled');
  assert.equal(m.getState(), 'cancelled');
});

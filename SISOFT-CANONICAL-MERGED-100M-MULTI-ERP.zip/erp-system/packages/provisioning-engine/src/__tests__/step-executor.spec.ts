import assert from 'node:assert/strict';
import { test } from 'node:test';
import { StepExecutorService } from '../step-executor.js';
import { ProvisioningContext, ProvisioningStep, ProvisioningStepError, TimeoutError } from '../types.js';

function ctx(): ProvisioningContext {
  return { requestId: 'r1', customerId: 'c1', planId: 'starter', data: {}, rollbackStack: [] };
}

const instantSleep = async () => {};

test('succeeds on first attempt and logs completion', async () => {
  const executor = new StepExecutorService({ sleep: instantSleep });
  const step: ProvisioningStep = {
    name: 'noop',
    timeoutMs: 1000,
    execute: async () => ({ output: { foo: 'bar' } }),
  };
  const c = ctx();
  await executor.executeStep(step, c);
  assert.equal(c.data.foo, 'bar');
  const completed = executor.logs.find((l) => l.status === 'completed');
  assert.ok(completed);
});

test('retries on transient failure then succeeds', async () => {
  const executor = new StepExecutorService({ sleep: instantSleep });
  let calls = 0;
  const step: ProvisioningStep = {
    name: 'flaky',
    timeoutMs: 1000,
    execute: async () => {
      calls++;
      if (calls < 3) throw new Error('transient');
      return {};
    },
  };
  await executor.executeStep(step, ctx());
  assert.equal(calls, 3);
});

test('exhausts retries and throws ProvisioningStepError', async () => {
  const executor = new StepExecutorService({ sleep: instantSleep });
  const step: ProvisioningStep = {
    name: 'always-fails',
    timeoutMs: 1000,
    maxAttempts: 2,
    execute: async () => {
      throw new Error('permanent');
    },
  };
  await assert.rejects(() => executor.executeStep(step, ctx()), ProvisioningStepError);
  const logs = executor.logs.filter((l) => l.stepName === 'always-fails');
  // One 'started' entry per attempt (2), plus one terminal 'failed' entry.
  assert.equal(logs.filter((l) => l.status === 'started').length, 2);
  assert.equal(logs.filter((l) => l.status === 'failed').length, 1);
});

test('enforces per-step timeout', async () => {
  const executor = new StepExecutorService({ sleep: instantSleep });
  const step: ProvisioningStep = {
    name: 'slow',
    timeoutMs: 20,
    maxAttempts: 1,
    execute: () => new Promise((resolve) => setTimeout(() => resolve({}), 500)),
  };
  await assert.rejects(async () => {
    try {
      await executor.executeStep(step, ctx());
    } catch (e) {
      if (!(e instanceof ProvisioningStepError)) throw e;
      assert.ok(e.cause instanceof TimeoutError);
      throw e;
    }
  });
});

test('registers rollback function only after success', async () => {
  const executor = new StepExecutorService({ sleep: instantSleep });
  let rolledBack = false;
  const step: ProvisioningStep = {
    name: 'with-rollback',
    timeoutMs: 1000,
    execute: async () => ({}),
    rollback: async () => {
      rolledBack = true;
    },
  };
  const c = ctx();
  await executor.executeStep(step, c);
  assert.equal(c.rollbackStack.length, 1);
  await c.rollbackStack[0].fn();
  assert.equal(rolledBack, true);
});

test('does not register rollback when step fails permanently', async () => {
  const executor = new StepExecutorService({ sleep: instantSleep });
  const step: ProvisioningStep = {
    name: 'fails-no-rollback',
    timeoutMs: 1000,
    maxAttempts: 1,
    execute: async () => {
      throw new Error('nope');
    },
    rollback: async () => {},
  };
  const c = ctx();
  await assert.rejects(() => executor.executeStep(step, c));
  assert.equal(c.rollbackStack.length, 0);
});

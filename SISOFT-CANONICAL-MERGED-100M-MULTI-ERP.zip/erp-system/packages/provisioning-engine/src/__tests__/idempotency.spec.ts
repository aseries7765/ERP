import assert from 'node:assert/strict';
import { test } from 'node:test';
import { ensureIdempotent } from '../idempotency.js';
import { ProvisioningContext } from '../types.js';

function ctx(): ProvisioningContext {
  return { requestId: 'r1', customerId: 'c1', planId: 'starter', data: {}, rollbackStack: [] };
}

test('creates resource when none exists', async () => {
  const c = ctx();
  let createCalls = 0;
  const result = await ensureIdempotent(c, 'vcn', {
    lookup: async () => null,
    create: async () => {
      createCalls++;
      return { id: 'vcn-1' };
    },
  });
  assert.equal(result.created, true);
  assert.equal(createCalls, 1);
  assert.equal(result.value.id, 'vcn-1');
});

test('re-running within the same context reuses cached value without calling lookup/create again', async () => {
  const c = ctx();
  let lookupCalls = 0;
  let createCalls = 0;
  const ops = {
    lookup: async () => {
      lookupCalls++;
      return null;
    },
    create: async () => {
      createCalls++;
      return { id: 'vcn-1' };
    },
  };
  await ensureIdempotent(c, 'vcn', ops);
  await ensureIdempotent(c, 'vcn', ops);
  assert.equal(lookupCalls, 1);
  assert.equal(createCalls, 1);
});

test('reuses existing external resource found via lookup instead of creating', async () => {
  const c = ctx();
  let createCalls = 0;
  const result = await ensureIdempotent(c, 'adb', {
    lookup: async () => ({ id: 'adb-existing' }),
    create: async () => {
      createCalls++;
      return { id: 'adb-new' };
    },
  });
  assert.equal(result.created, false);
  assert.equal(result.value.id, 'adb-existing');
  assert.equal(createCalls, 0);
});

test('different keys are independent', async () => {
  const c = ctx();
  const r1 = await ensureIdempotent(c, 'a', { lookup: async () => null, create: async () => 'A' });
  const r2 = await ensureIdempotent(c, 'b', { lookup: async () => null, create: async () => 'B' });
  assert.equal(r1.value, 'A');
  assert.equal(r2.value, 'B');
});

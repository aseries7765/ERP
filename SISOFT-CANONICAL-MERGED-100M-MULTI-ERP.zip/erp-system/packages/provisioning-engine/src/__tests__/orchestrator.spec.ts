import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createContext, ProvisioningOrchestrator } from '../orchestrator.js';
import { ProvisioningEvent, ProvisioningStep } from '../types.js';

function makeStep(name: string, opts: Partial<ProvisioningStep> = {}): ProvisioningStep {
  return {
    name,
    timeoutMs: 1000,
    maxAttempts: 1,
    execute: async () => ({}),
    ...opts,
  };
}

test('happy path: all steps run in order, ends active', async () => {
  const order: string[] = [];
  const events: ProvisioningEvent[] = [];
  const orchestrator = new ProvisioningOrchestrator((e) => events.push(e));

  const steps: ProvisioningStep[] = [
    makeStep('validate-request', { execute: async () => { order.push('validate-request'); return {}; } }),
    makeStep('create-vcn', { execute: async () => { order.push('create-vcn'); return {}; } }),
    makeStep('create-adb', { execute: async () => { order.push('create-adb'); return {}; } }),
  ];

  const context = createContext('req-1', 'cust-1', 'starter');
  const result = await orchestrator.run(steps, context);

  assert.deepEqual(order, ['validate-request', 'create-vcn', 'create-adb']);
  assert.equal(result.finalState, 'active');
  assert.ok(events.some((e) => e.type === 'provisioning.completed'));
  assert.ok(events.some((e) => e.type === 'environment.ready'));
});

test('failure at step N triggers rollback of steps 1..N-1 in reverse order', async () => {
  const rolledBackOrder: string[] = [];
  const orchestrator = new ProvisioningOrchestrator();

  const steps: ProvisioningStep[] = [
    makeStep('create-compartment', {
      rollback: async () => { rolledBackOrder.push('create-compartment'); },
    }),
    makeStep('create-vcn', {
      rollback: async () => { rolledBackOrder.push('create-vcn'); },
    }),
    makeStep('create-adb', {
      execute: async () => {
        throw new Error('OCI quota exceeded');
      },
    }),
  ];

  const context = createContext('req-2', 'cust-2', 'business');
  const result = await orchestrator.run(steps, context);

  assert.equal(result.finalState, 'rolled_back');
  assert.equal(result.error, 'Step "create-adb" failed: OCI quota exceeded');
  assert.deepEqual(rolledBackOrder, ['create-vcn', 'create-compartment']);
  assert.equal(context.rollbackStack.length, 0);
});

test('cancellation before completion triggers rollback and ends cancelled/rolled_back', async () => {
  const rolledBack: string[] = [];
  const orchestrator = new ProvisioningOrchestrator();
  let cancelAfter = 1;
  let stepsRun = 0;

  const steps: ProvisioningStep[] = [
    makeStep('step-1', { rollback: async () => { rolledBack.push('step-1'); } }),
    makeStep('step-2', { rollback: async () => { rolledBack.push('step-2'); } }),
    makeStep('step-3', { execute: async () => { stepsRun++; return {}; } }),
  ];

  const context = createContext('req-3', 'cust-3', 'free');
  const result = await orchestrator.run(steps.slice(0, 2), context, {
    isCancelled: () => false,
  });
  // Simulate: after first two succeed, a follow-up request is cancelled
  // before step-3 by re-invoking run with a cancel flag flipped.
  const context2 = createContext('req-4', 'cust-4', 'free');
  const result2 = await orchestrator.run(steps, context2, {
    isCancelled: () => {
      cancelAfter -= 1;
      return cancelAfter < 0;
    },
  });

  assert.equal(result.finalState, 'active');
  assert.equal(result2.error, 'cancelled');
  assert.ok(['rolled_back', 'failed_rollback'].includes(result2.finalState));
});

test('rollback failure surfaces failed_rollback terminal state', async () => {
  const orchestrator = new ProvisioningOrchestrator();
  const steps: ProvisioningStep[] = [
    makeStep('create-vault-key', {
      rollback: async () => {
        throw new Error('vault unreachable');
      },
    }),
    makeStep('create-adb', {
      execute: async () => {
        throw new Error('boom');
      },
    }),
  ];
  const context = createContext('req-5', 'cust-5', 'starter');
  const result = await orchestrator.run(steps, context);
  assert.equal(result.finalState, 'failed_rollback');
});

# @erp/blood-bank-engine

Pure, framework-free domain logic for blood bank operations: ABO/Rh
compatibility, cross-match unit selection, component shelf-life
calculation, donor deferral screening, ISBT 128-style unit identifiers,
and transfusion reaction classification.

No I/O, no database, no NestJS dependency — called from the
(not-yet-built) `his-blood-bank` module's services.

## What's implemented

- `abo-rh.ts` — the standard ABO/Rh compatibility matrix (O universal
  donor, AB universal recipient, Rh- only from Rh- donors).
- `cross-match.ts` — filters available units down to ABO/Rh-compatible,
  correct-component, available units for a recipient (G18).
- `component-shelf-life.ts` — RBC 42 days / platelets 5 days / plasma &
  cryoprecipitate 1 year, with expiry-date and days-remaining helpers.
- `deferral-rules.ts` — a representative subset of donor eligibility
  criteria (age, weight, hemoglobin, vitals, inter-donation interval,
  pregnancy, recent tattoo/piercing, malaria-endemic travel).
- `isbt128.ts` — a simplified, internally-consistent encode/decode scheme
  for unit identifiers (see honesty note below).
- `transfusion-reaction.ts` — provisional reaction classification from
  reported symptoms to prioritize the initial workup; always signals that
  the transfusion must stop and a full investigation must proceed (G20).

## What's NOT implemented here (see root MANIFEST.md) — read before using clinically

- **`isbt128.ts` is NOT a certified ISBT 128 implementation.** The real
  ICCBBA standard uses registered facility identification numbers and a
  specific ISO 7064 check-character algorithm; this module implements a
  self-consistent but non-conformant scheme for internal tracking only.
  Replace with a certified library before handling real donor/unit IDs.
- **`cross-match.ts` performs electronic/ABO-Rh selection only** — it does
  not simulate a real serological cross-match (antibody screen incubated
  against donor red cells), which is a physical lab process. Treat this as
  candidate-unit filtering, not a substitute for the lab cross-match.
- **`deferral-rules.ts` is a representative subset**, not the full AABB/FDA
  donor history questionnaire (which covers dozens of additional
  criteria — medications, travel to more regions, prior transfusion,
  etc.) and does not replace medical director judgment.
- Donor registration, donation collection, TTI testing, component
  preparation workflow persistence, lookback (donor→recipient trace),
  persistence, HTTP controllers, NestJS module, Prisma schema, events,
  seed data, frontend.

## Usage

```ts
import { findCompatibleUnits, classifyReaction } from '@erp/blood-bank-engine';

const { compatibleUnits } = findCompatibleUnits(availableUnits, recipientBloodGroup, 'RBC');
const reaction = classifyReaction(reportedSymptoms); // always mustStopImmediately: true
```

## Test

```
pnpm --filter @erp/blood-bank-engine test
```

Runs `tsx --test src/__tests__/*.spec.ts` — 41 unit tests, no DB required.

Measured coverage (`npx tsx --test --experimental-test-coverage src/__tests__/*.spec.ts`): 98.26% line / 90.08% branch / 95.10% function.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { encodeIsbt128, decodeIsbt128 } from '../isbt128';

test('encodes and decodes a unit ID round-trip', () => {
  const id = { facilityCode: 'A1234', year: 26, sequence: 123 };
  const code = encodeIsbt128(id);
  const decoded = decodeIsbt128(code);
  assert.deepEqual(decoded, id);
});

test('rejects a code with a corrupted check character', () => {
  const code = encodeIsbt128({ facilityCode: 'A1234', year: 26, sequence: 123 });
  const badLastChar = code.slice(0, -1) + (code.slice(-1) === '0' ? '1' : '0');
  assert.equal(decodeIsbt128(badLastChar), null);
});

test('rejects a malformed code', () => {
  assert.equal(decodeIsbt128('not-a-code'), null);
});

test('pads short facility codes and sequences', () => {
  const code = encodeIsbt128({ facilityCode: 'AB', year: 5, sequence: 7 });
  assert.match(code, /^=ABXXX0500007[0-9A-Z]$/);
});

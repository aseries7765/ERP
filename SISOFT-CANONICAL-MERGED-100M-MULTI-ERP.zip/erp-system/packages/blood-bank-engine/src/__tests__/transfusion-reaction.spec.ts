import { test } from 'node:test';
import assert from 'node:assert/strict';
import { classifyReaction } from '../transfusion-reaction';
import { ReactionSymptoms } from '../types';

function baseSymptoms(overrides: Partial<ReactionSymptoms>): ReactionSymptoms {
  return {
    feverOnset: false,
    hypotension: false,
    respiratoryDistress: false,
    urticariaOrItching: false,
    flankOrBackPain: false,
    hemoglobinuria: false,
    chillsOrRigors: false,
    onsetWithinMinutesOfStart: 60,
    ...overrides,
  };
}

test('classifies rapid hypotension + back pain + hemoglobinuria as acute hemolytic', () => {
  const result = classifyReaction(
    baseSymptoms({
      onsetWithinMinutesOfStart: 5,
      hypotension: true,
      flankOrBackPain: true,
      hemoglobinuria: true,
    }),
  );
  assert.equal(result.likelyType, 'ACUTE_HEMOLYTIC');
  assert.equal(result.confidence, 'HIGH');
});

test('classifies isolated urticaria as allergic', () => {
  const result = classifyReaction(baseSymptoms({ urticariaOrItching: true }));
  assert.equal(result.likelyType, 'ALLERGIC');
});

test('classifies fever + chills without hypotension as febrile non-hemolytic', () => {
  const result = classifyReaction(baseSymptoms({ feverOnset: true, chillsOrRigors: true }));
  assert.equal(result.likelyType, 'FEBRILE_NON_HEMOLYTIC');
});

test('classifies fever + hypotension as possible bacterial sepsis', () => {
  const result = classifyReaction(baseSymptoms({ feverOnset: true, hypotension: true }));
  assert.equal(result.likelyType, 'BACTERIAL_SEPSIS');
});

test('every classification requires stopping the transfusion immediately', () => {
  const scenarios = [
    baseSymptoms({ urticariaOrItching: true }),
    baseSymptoms({ feverOnset: true, hypotension: true }),
    baseSymptoms({}),
  ];
  for (const s of scenarios) {
    assert.equal(classifyReaction(s).mustStopImmediately, true);
  }
});

test('falls back to UNKNOWN with low confidence for an ambiguous pattern', () => {
  const result = classifyReaction(baseSymptoms({}));
  assert.equal(result.likelyType, 'UNKNOWN');
  assert.equal(result.confidence, 'LOW');
});

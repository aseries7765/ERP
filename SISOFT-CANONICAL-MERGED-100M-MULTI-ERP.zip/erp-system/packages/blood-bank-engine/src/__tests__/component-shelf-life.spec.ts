import { test } from 'node:test';
import assert from 'node:assert/strict';
import { calculateExpiryDate, isExpired, daysUntilExpiry, SHELF_LIFE_DAYS } from '../component-shelf-life';

test('RBC shelf life is 42 days', () => {
  const prepared = new Date('2026-01-01T00:00:00Z');
  const expiry = calculateExpiryDate('RBC', prepared);
  assert.equal(SHELF_LIFE_DAYS.RBC, 42);
  assert.equal(expiry.getTime(), prepared.getTime() + 42 * 86400000);
});

test('platelets shelf life is 5 days', () => {
  assert.equal(SHELF_LIFE_DAYS.PLATELETS, 5);
});

test('plasma shelf life is 1 year (365 days)', () => {
  assert.equal(SHELF_LIFE_DAYS.PLASMA, 365);
});

test('isExpired correctly identifies expired units', () => {
  const prepared = new Date('2026-01-01T00:00:00Z');
  assert.equal(isExpired('PLATELETS', prepared, new Date('2026-01-08T00:00:00Z')), true);
  assert.equal(isExpired('PLATELETS', prepared, new Date('2026-01-03T00:00:00Z')), false);
});

test('daysUntilExpiry counts down correctly', () => {
  const prepared = new Date('2026-01-01T00:00:00Z');
  const days = daysUntilExpiry('RBC', prepared, new Date('2026-01-11T00:00:00Z'));
  assert.equal(days, 32);
});

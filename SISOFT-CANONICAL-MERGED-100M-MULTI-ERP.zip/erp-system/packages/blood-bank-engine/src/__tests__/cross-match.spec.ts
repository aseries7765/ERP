import { test } from 'node:test';
import assert from 'node:assert/strict';
import { findCompatibleUnits, selectUnitsForCrossMatch, NoCompatibleUnitsError } from '../cross-match';
import { BloodUnit } from '../types';

const units: BloodUnit[] = [
  { unitId: 'U1', componentType: 'RBC', bloodGroup: { abo: 'O', rh: 'NEGATIVE' }, collectionDate: new Date(), status: 'AVAILABLE' },
  { unitId: 'U2', componentType: 'RBC', bloodGroup: { abo: 'A', rh: 'POSITIVE' }, collectionDate: new Date(), status: 'AVAILABLE' },
  { unitId: 'U3', componentType: 'RBC', bloodGroup: { abo: 'B', rh: 'POSITIVE' }, collectionDate: new Date(), status: 'ISSUED' },
  { unitId: 'U4', componentType: 'PLATELETS', bloodGroup: { abo: 'O', rh: 'NEGATIVE' }, collectionDate: new Date(), status: 'AVAILABLE' },
];

test('finds only compatible, available, matching-component units', () => {
  const recipient = { abo: 'A' as const, rh: 'POSITIVE' as const };
  const result = findCompatibleUnits(units, recipient, 'RBC');
  const ids = result.compatibleUnits.map((u) => u.unitId);
  assert.ok(ids.includes('U1')); // O- universal donor
  assert.ok(ids.includes('U2')); // A+ exact match
  assert.ok(!ids.includes('U3')); // issued, not available
  assert.ok(!ids.includes('U4')); // wrong component
});

test('explains incompatibility reasons', () => {
  const recipient = { abo: 'A' as const, rh: 'NEGATIVE' as const };
  const result = findCompatibleUnits(units, recipient, 'RBC');
  assert.ok(result.incompatibleReasons['U2']); // A+ donor incompatible with A- recipient (Rh mismatch)
});

test('selectUnitsForCrossMatch returns requested count when available', () => {
  const recipient = { abo: 'AB' as const, rh: 'POSITIVE' as const };
  const selected = selectUnitsForCrossMatch(units, recipient, 'RBC', 2);
  assert.equal(selected.length, 2);
});

test('selectUnitsForCrossMatch throws when insufficient compatible units', () => {
  const recipient = { abo: 'AB' as const, rh: 'POSITIVE' as const };
  assert.throws(() => selectUnitsForCrossMatch(units, recipient, 'RBC', 5), NoCompatibleUnitsError);
});

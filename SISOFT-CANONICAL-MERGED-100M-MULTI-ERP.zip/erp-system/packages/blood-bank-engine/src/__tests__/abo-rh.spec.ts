import { test } from 'node:test';
import assert from 'node:assert/strict';
import { isAboCompatible, isRhCompatible, isCompatible, isUniversalDonor, isUniversalRecipient } from '../abo-rh';

test('O is compatible only with O donors (ABO axis)', () => {
  assert.equal(isAboCompatible('O', 'O'), true);
  assert.equal(isAboCompatible('O', 'A'), false);
  assert.equal(isAboCompatible('O', 'B'), false);
  assert.equal(isAboCompatible('O', 'AB'), false);
});

test('AB can receive from any ABO group (universal recipient)', () => {
  for (const donor of ['A', 'B', 'AB', 'O'] as const) {
    assert.equal(isAboCompatible('AB', donor), true);
  }
});

test('A accepts A and O; B accepts B and O', () => {
  assert.equal(isAboCompatible('A', 'A'), true);
  assert.equal(isAboCompatible('A', 'O'), true);
  assert.equal(isAboCompatible('A', 'B'), false);
  assert.equal(isAboCompatible('B', 'B'), true);
  assert.equal(isAboCompatible('B', 'O'), true);
  assert.equal(isAboCompatible('B', 'A'), false);
});

test('Rh-negative recipient can only receive Rh-negative donor units', () => {
  assert.equal(isRhCompatible('NEGATIVE', 'NEGATIVE'), true);
  assert.equal(isRhCompatible('NEGATIVE', 'POSITIVE'), false);
});

test('Rh-positive recipient can receive either Rh', () => {
  assert.equal(isRhCompatible('POSITIVE', 'POSITIVE'), true);
  assert.equal(isRhCompatible('POSITIVE', 'NEGATIVE'), true);
});

test('full compatibility requires both ABO and Rh match', () => {
  assert.equal(isCompatible({ abo: 'AB', rh: 'POSITIVE' }, { abo: 'O', rh: 'NEGATIVE' }), true);
  assert.equal(isCompatible({ abo: 'A', rh: 'NEGATIVE' }, { abo: 'O', rh: 'POSITIVE' }), false);
});

test('identifies universal donor and universal recipient', () => {
  assert.equal(isUniversalDonor({ abo: 'O', rh: 'NEGATIVE' }), true);
  assert.equal(isUniversalDonor({ abo: 'O', rh: 'POSITIVE' }), false);
  assert.equal(isUniversalRecipient({ abo: 'AB', rh: 'POSITIVE' }), true);
});

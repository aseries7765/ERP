import { test } from 'node:test';
import assert from 'node:assert/strict';
import { evaluateDeferral } from '../deferral-rules';
import { DonorHealthScreen } from '../types';

const healthyDonor: DonorHealthScreen = {
  hemoglobinGDl: 14,
  weightKg: 70,
  systolicBp: 120,
  diastolicBp: 80,
  pulseRateBpm: 70,
  ageYears: 30,
};

test('an eligible donor passes with no reasons', () => {
  const result = evaluateDeferral(healthyDonor);
  assert.equal(result.eligible, true);
  assert.deepEqual(result.reasons, []);
});

test('defers a donor below minimum weight', () => {
  const result = evaluateDeferral({ ...healthyDonor, weightKg: 45 });
  assert.equal(result.eligible, false);
  assert.ok(result.reasons.some((r) => r.includes('weight')));
});

test('defers a donor with low hemoglobin', () => {
  const result = evaluateDeferral({ ...healthyDonor, hemoglobinGDl: 11 });
  assert.equal(result.eligible, false);
  assert.ok(result.reasons.some((r) => r.includes('Hemoglobin')));
});

test('defers a donor within 56-day interval, with days remaining', () => {
  const result = evaluateDeferral({ ...healthyDonor, daysSinceLastDonation: 20 });
  assert.equal(result.eligible, false);
  assert.equal(result.deferralDays, 36);
});

test('defers a pregnant donor', () => {
  const result = evaluateDeferral({ ...healthyDonor, isPregnant: true });
  assert.equal(result.eligible, false);
  assert.ok(result.reasons.some((r) => r.includes('pregnant')));
});

test('defers for recent tattoo with correct remaining wait', () => {
  const result = evaluateDeferral({ ...healthyDonor, recentTattooOrPiercingDays: 30 });
  assert.equal(result.eligible, false);
  assert.equal(result.deferralDays, 90);
});

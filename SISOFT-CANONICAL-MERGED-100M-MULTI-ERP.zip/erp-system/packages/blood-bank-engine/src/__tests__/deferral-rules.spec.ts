import { test } from 'node:test';
import assert from 'node:assert/strict';
import { evaluateDeferral } from '../deferral-rules';
import { DonorHealthScreen } from '../types';

const healthyDonor: DonorHealthScreen = {
  hemoglobinGDl: 14,
  weightKg: 70,
  systolicBp: 120,
  diastolicBp: 80,
  pulseRateBpm: 70,
  ageYears: 30,
};

test('an eligible donor passes with no reasons', () => {
  const result = evaluateDeferral(healthyDonor);
  assert.equal(result.eligible, true);
  assert.deepEqual(result.reasons, []);
});

test('defers a donor below minimum weight', () => {
  const result = evaluateDeferral({ ...healthyDonor, weightKg: 45 });
  assert.equal(result.eligible, false);
  assert.ok(result.reasons.some((r) => r.includes('weight')));
});

test('defers a donor with low hemoglobin', () => {
  const result = evaluateDeferral({ ...healthyDonor, hemoglobinGDl: 11 });
  assert.equal(result.eligible, false);
  assert.ok(result.reasons.some((r) => r.includes('Hemoglobin')));
});

test('defers a donor within 56-day interval, with days remaining', () => {
  const result = evaluateDeferral({ ...healthyDonor, daysSinceLastDonation: 20 });
  assert.equal(result.eligible, false);
  assert.equal(result.deferralDays, 36);
});

test('defers a pregnant donor', () => {
  const result = evaluateDeferral({ ...healthyDonor, isPregnant: true });
  assert.equal(result.eligible, false);
  assert.ok(result.reasons.some((r) => r.includes('pregnant')));
});

test('defers for recent tattoo with correct remaining wait', () => {
  const result = evaluateDeferral({ ...healthyDonor, recentTattooOrPiercingDays: 30 });
  assert.equal(result.eligible, false);
  assert.equal(result.deferralDays, 90);
});

test('defers a donor below minimum age', () => {
  const result = evaluateDeferral({ ...healthyDonor, ageYears: 16 });
  assert.equal(result.eligible, false);
  assert.ok(result.reasons.some((r) => r.includes('age')));
});

test('defers for systolic BP too high or too low', () => {
  assert.equal(evaluateDeferral({ ...healthyDonor, systolicBp: 190 }).eligible, false);
  assert.equal(evaluateDeferral({ ...healthyDonor, systolicBp: 85 }).eligible, false);
  assert.equal(evaluateDeferral({ ...healthyDonor, systolicBp: 150 }).eligible, true); // within range
});

test('defers for diastolic BP too high or too low', () => {
  assert.equal(evaluateDeferral({ ...healthyDonor, diastolicBp: 110 }).eligible, false);
  assert.equal(evaluateDeferral({ ...healthyDonor, diastolicBp: 40 }).eligible, false);
});

test('defers for pulse rate too high or too low', () => {
  assert.equal(evaluateDeferral({ ...healthyDonor, pulseRateBpm: 110 }).eligible, false);
  assert.equal(evaluateDeferral({ ...healthyDonor, pulseRateBpm: 40 }).eligible, false);
});

test('defers a donor with an active infection for at least 14 days', () => {
  const result = evaluateDeferral({ ...healthyDonor, hasActiveInfection: true });
  assert.equal(result.eligible, false);
  assert.ok(result.reasons.some((r) => r.includes('infection')));
  assert.equal(result.deferralDays, 14);
});

test('defers for recent travel to a malaria-endemic region with correct remaining wait', () => {
  const result = evaluateDeferral({ ...healthyDonor, travelToMalariaRegionDays: 30 });
  assert.equal(result.eligible, false);
  assert.equal(result.deferralDays, 60);
});

test('does not defer for travel outside the malaria-endemic window', () => {
  const result = evaluateDeferral({ ...healthyDonor, travelToMalariaRegionDays: 120 });
  assert.equal(result.eligible, true);
});

test('when multiple deferral reasons apply, deferralDays reflects the longer of the two waits', () => {
  // active infection (14 days) + recent tattoo needing 90 more days -> should keep 90, the larger
  const result = evaluateDeferral({ ...healthyDonor, hasActiveInfection: true, recentTattooOrPiercingDays: 30 });
  assert.equal(result.eligible, false);
  assert.equal(result.deferralDays, 90);
});

test('when the later-checked reason requires a shorter wait than an earlier one, the longer wait is kept', () => {
  // tattoo needing 90 days is checked before malaria travel needing 60 days -> keeps 90
  const result = evaluateDeferral({ ...healthyDonor, recentTattooOrPiercingDays: 30, travelToMalariaRegionDays: 30 });
  assert.equal(result.deferralDays, 90);
});

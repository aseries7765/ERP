import { DonorHealthScreen } from './types';

/** Outcome of running a donor's health screen against the eligibility rules. */
export interface DeferralResult {
  eligible: boolean;
  reasons: string[];
  deferralDays?: number; // if temporarily deferred, suggested wait before re-screening
}

/**
 * Applies common donor-eligibility screening thresholds. This is a
 * representative subset of typical blood-bank donor eligibility criteria
 * (AABB/FDA-style), not a substitute for the facility's full donor history
 * questionnaire and medical director sign-off.
 */
export function evaluateDeferral(screen: DonorHealthScreen): DeferralResult {
  const reasons: string[] = [];
  let deferralDays: number | undefined;

  if (screen.ageYears < 17) {
    reasons.push('Below minimum donation age (17)');
  }
  if (screen.weightKg < 50) {
    reasons.push('Below minimum weight (50kg)');
  }
  if (screen.hemoglobinGDl < 12.5) {
    reasons.push('Hemoglobin below minimum threshold (12.5 g/dL)');
  }
  if (screen.systolicBp > 180 || screen.systolicBp < 90) {
    reasons.push(`Systolic BP ${screen.systolicBp} outside acceptable range (90-180)`);
  }
  if (screen.diastolicBp > 100 || screen.diastolicBp < 50) {
    reasons.push(`Diastolic BP ${screen.diastolicBp} outside acceptable range (50-100)`);
  }
  if (screen.pulseRateBpm < 50 || screen.pulseRateBpm > 100) {
    reasons.push(`Pulse ${screen.pulseRateBpm} bpm outside acceptable range (50-100)`);
  }
  if (screen.daysSinceLastDonation !== undefined && screen.daysSinceLastDonation < 56) {
    reasons.push('Less than 56 days since last whole-blood donation');
    deferralDays = 56 - screen.daysSinceLastDonation;
  }
  if (screen.hasActiveInfection) {
    reasons.push('Active infection reported');
    deferralDays = Math.max(deferralDays ?? 0, 14);
  }
  if (screen.isPregnant) {
    reasons.push('Currently pregnant');
  }
  if (screen.recentTattooOrPiercingDays !== undefined && screen.recentTattooOrPiercingDays < 120) {
    reasons.push('Tattoo/piercing within the last 120 days');
    deferralDays = Math.max(deferralDays ?? 0, 120 - screen.recentTattooOrPiercingDays);
  }
  if (
    screen.travelToMalariaRegionDays !== undefined &&
    screen.travelToMalariaRegionDays < 90
  ) {
    reasons.push('Travel to a malaria-endemic region within the last 90 days');
    deferralDays = Math.max(deferralDays ?? 0, 90 - screen.travelToMalariaRegionDays);
  }

  return { eligible: reasons.length === 0, reasons, deferralDays };
}

import { ReactionSymptoms, TransfusionReactionType } from './types';

/** Provisional classification suggested from reported symptoms, for triage purposes only. */
export interface ClassificationResult {
  likelyType: TransfusionReactionType;
  confidence: 'HIGH' | 'MODERATE' | 'LOW';
  mustStopImmediately: boolean;
  notes: string[];
}

/**
 * Suggests a provisional classification for a suspected transfusion
 * reaction from reported symptoms, to prioritize the initial workup. This
 * is decision support only — every suspected reaction must be
 * investigated per protocol (G20) regardless of this classification, and
 * the final classification is made by the clinician/blood bank physician.
 */
export function classifyReaction(symptoms: ReactionSymptoms): ClassificationResult {
  const notes: string[] = [];

  if (
    symptoms.onsetWithinMinutesOfStart <= 15 &&
    symptoms.hypotension &&
    symptoms.flankOrBackPain &&
    symptoms.hemoglobinuria
  ) {
    notes.push('Rapid onset with hypotension, flank/back pain, and hemoglobinuria suggests ABO incompatibility.');
    return {
      likelyType: 'ACUTE_HEMOLYTIC',
      confidence: 'HIGH',
      mustStopImmediately: true,
      notes,
    };
  }

  if (symptoms.respiratoryDistress && symptoms.hypotension) {
    notes.push('Respiratory distress with hypotension — consider anaphylaxis, TRALI, or TACO; differentiate by volume status and timing.');
    return {
      likelyType: symptoms.onsetWithinMinutesOfStart <= 30 ? 'ANAPHYLACTIC' : 'TRALI',
      confidence: 'MODERATE',
      mustStopImmediately: true,
      notes,
    };
  }

  if (symptoms.urticariaOrItching && !symptoms.feverOnset && !symptoms.hypotension) {
    notes.push('Isolated urticaria/itching without fever or hypotension suggests a mild allergic reaction.');
    return { likelyType: 'ALLERGIC', confidence: 'MODERATE', mustStopImmediately: true, notes };
  }

  if (symptoms.feverOnset && symptoms.chillsOrRigors && !symptoms.hypotension) {
    notes.push('Fever and chills without hypotension suggests febrile non-hemolytic transfusion reaction, but sepsis must be excluded.');
    return {
      likelyType: 'FEBRILE_NON_HEMOLYTIC',
      confidence: 'LOW',
      mustStopImmediately: true,
      notes,
    };
  }

  if (symptoms.feverOnset && symptoms.hypotension) {
    notes.push('Fever with hypotension raises concern for bacterial contamination/sepsis.');
    return { likelyType: 'BACTERIAL_SEPSIS', confidence: 'LOW', mustStopImmediately: true, notes };
  }

  notes.push('Symptom pattern does not clearly match a specific reaction type — classify as unknown pending full workup.');
  return { likelyType: 'UNKNOWN', confidence: 'LOW', mustStopImmediately: true, notes };
}

/** ABO blood group. */
export type AboGroup = 'A' | 'B' | 'AB' | 'O';
/** Rh (D antigen) factor. */
export type RhFactor = 'POSITIVE' | 'NEGATIVE';

/** A patient's or unit's full blood group (ABO + Rh). */
export interface BloodGroup {
  abo: AboGroup;
  rh: RhFactor;
}

/** The kind of blood component a unit contains. */
export type ComponentType = 'RBC' | 'PLASMA' | 'PLATELETS' | 'CRYOPRECIPITATE';

/** A trackable inventory unit of a blood component. */
export interface BloodUnit {
  unitId: string;
  componentType: ComponentType;
  bloodGroup: BloodGroup;
  collectionDate: Date;
  status: 'AVAILABLE' | 'RESERVED' | 'ISSUED' | 'TRANSFUSED' | 'DISCARDED' | 'QUARANTINED';
}

/** The vitals and history inputs used to screen a prospective donor for eligibility. */
export interface DonorHealthScreen {
  hemoglobinGDl: number;
  weightKg: number;
  systolicBp: number;
  diastolicBp: number;
  pulseRateBpm: number;
  ageYears: number;
  daysSinceLastDonation?: number;
  hasActiveInfection?: boolean;
  isPregnant?: boolean;
  recentTattooOrPiercingDays?: number;
  travelToMalariaRegionDays?: number;
}

/** The categories of suspected transfusion reaction this engine can suggest. */
export type TransfusionReactionType =
  | 'ACUTE_HEMOLYTIC'
  | 'FEBRILE_NON_HEMOLYTIC'
  | 'ALLERGIC'
  | 'ANAPHYLACTIC'
  | 'TRALI'
  | 'TACO'
  | 'BACTERIAL_SEPSIS'
  | 'UNKNOWN';

/** Reported symptoms and timing for a suspected transfusion reaction. */
export interface ReactionSymptoms {
  feverOnset: boolean;
  hypotension: boolean;
  respiratoryDistress: boolean;
  urticariaOrItching: boolean;
  flankOrBackPain: boolean;
  hemoglobinuria: boolean;
  chillsOrRigors: boolean;
  onsetWithinMinutesOfStart: number;
}

/**
 * ISBT 128 unit identifiers are 13 characters: a 2-character flag ("=" or
 * "&" for the check-character scheme, here we use a fixed "=" flag), a
 * 5-character collection facility code, a 2-digit year, and a 5-digit
 * donation sequence number, e.g. "=A123421000123". This module implements
 * a simplified, internally-consistent encode/decode/check-digit scheme
 * sufficient for unit tracking within this system — it does not claim
 * conformance with the full ICCBBA ISBT 128 standard (which involves
 * registered facility codes and a more complex ISO 7064 check-character
 * algorithm) and should be replaced with a certified ISBT 128 library
 * before handling real donor/unit identifiers in production.
 */
export interface Isbt128Id {
  facilityCode: string; // 5 chars
  year: number; // 2-digit
  sequence: number; // up to 5 digits
}

function checkChar(facilityCode: string, year: number, sequence: number): string {
  const yearStr = year.toString().padStart(2, '0');
  const seqStr = sequence.toString().padStart(5, '0');
  const payload = `${facilityCode}${yearStr}${seqStr}`;
  let sum = 0;
  for (let i = 0; i < payload.length; i++) {
    sum += payload.charCodeAt(i) * (i + 1);
  }
  const code = sum % 36;
  return code < 10 ? String(code) : String.fromCharCode(55 + code); // 0-9, A-Z
}

/** Encodes a unit ID into this system's ISBT 128-shaped string (see module-level note on conformance). */
export function encodeIsbt128(id: Isbt128Id): string {
  const facility = id.facilityCode.toUpperCase().padEnd(5, 'X').slice(0, 5);
  const yearStr = id.year.toString().padStart(2, '0');
  const seqStr = id.sequence.toString().padStart(5, '0');
  const check = checkChar(facility, id.year, id.sequence);
  return `=${facility}${yearStr}${seqStr}${check}`;
}

/** Decodes and check-validates a barcode string, returning null if malformed or the check character fails. */
export function decodeIsbt128(code: string): Isbt128Id | null {
  const match = /^=([A-Z0-9]{5})(\d{2})(\d{5})([0-9A-Z])$/.exec(code);
  if (!match) return null;
  const [, facility, yearStr, seqStr, check] = match;
  const year = Number(yearStr);
  const sequence = Number(seqStr);
  if (checkChar(facility, year, sequence) !== check) return null;
  return { facilityCode: facility, year, sequence };
}

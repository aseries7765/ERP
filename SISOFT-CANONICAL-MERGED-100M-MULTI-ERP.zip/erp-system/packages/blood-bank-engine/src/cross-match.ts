import { BloodGroup, BloodUnit } from './types';
import { isCompatible } from './abo-rh';

/** Thrown when fewer compatible units are available than the number requested for cross-match. */
export class NoCompatibleUnitsError extends Error {}

/** Result of filtering a unit pool down to those compatible with a recipient. */
export interface CrossMatchResult {
  compatibleUnits: BloodUnit[];
  incompatibleReasons: Record<string, string>;
}

/**
 * Filters a set of available units down to ones ABO/Rh-compatible with the
 * recipient (G18: cross-match MUST follow ABO/Rh rules), and of the
 * requested component type. This models electronic/immediate-spin
 * cross-match selection; full serological cross-match (antibody screen
 * against donor cells) is a lab process this function does not simulate —
 * see MANIFEST for that limitation.
 */
export function findCompatibleUnits(
  units: BloodUnit[],
  recipient: BloodGroup,
  componentType: BloodUnit['componentType'],
): CrossMatchResult {
  const incompatibleReasons: Record<string, string> = {};
  const compatibleUnits: BloodUnit[] = [];

  for (const unit of units) {
    if (unit.status !== 'AVAILABLE') {
      incompatibleReasons[unit.unitId] = `Unit status is ${unit.status}, not AVAILABLE`;
      continue;
    }
    if (unit.componentType !== componentType) {
      incompatibleReasons[unit.unitId] = `Unit is ${unit.componentType}, requested ${componentType}`;
      continue;
    }
    if (!isCompatible(recipient, unit.bloodGroup)) {
      incompatibleReasons[unit.unitId] = `Blood group ${unit.bloodGroup.abo}${
        unit.bloodGroup.rh === 'POSITIVE' ? '+' : '-'
      } incompatible with recipient ${recipient.abo}${recipient.rh === 'POSITIVE' ? '+' : '-'}`;
      continue;
    }
    compatibleUnits.push(unit);
  }

  return { compatibleUnits, incompatibleReasons };
}

/** Selects `count` compatible units, throwing if fewer are available than requested. */
export function selectUnitsForCrossMatch(
  units: BloodUnit[],
  recipient: BloodGroup,
  componentType: BloodUnit['componentType'],
  count: number,
): BloodUnit[] {
  const { compatibleUnits } = findCompatibleUnits(units, recipient, componentType);
  if (compatibleUnits.length < count) {
    throw new NoCompatibleUnitsError(
      `Only ${compatibleUnits.length} compatible ${componentType} unit(s) available, ${count} requested`,
    );
  }
  return compatibleUnits.slice(0, count);
}

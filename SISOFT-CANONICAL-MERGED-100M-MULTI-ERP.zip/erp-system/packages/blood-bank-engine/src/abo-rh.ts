import { BloodGroup, AboGroup, RhFactor } from './types';

/**
 * Standard transfusion compatibility for red-cell products:
 * O is the universal donor, AB the universal recipient (ABO axis).
 * Rh-negative recipients should only receive Rh-negative units (except in
 * documented emergency override, which is out of scope for this pure
 * compatibility check).
 */
const ABO_COMPATIBLE_DONORS: Record<AboGroup, AboGroup[]> = {
  O: ['O'],
  A: ['A', 'O'],
  B: ['B', 'O'],
  AB: ['A', 'B', 'AB', 'O'],
};

/** Checks whether a donor's ABO group is transfusion-compatible with a recipient's ABO group. */
export function isAboCompatible(recipient: AboGroup, donor: AboGroup): boolean {
  return ABO_COMPATIBLE_DONORS[recipient].includes(donor);
}

/** Checks whether a donor's Rh factor is transfusion-compatible with a recipient's Rh factor. */
export function isRhCompatible(recipientRh: RhFactor, donorRh: RhFactor): boolean {
  if (recipientRh === 'POSITIVE') return true; // Rh+ can receive Rh+ or Rh-
  return donorRh === 'NEGATIVE'; // Rh- must receive Rh-
}

/** Checks full ABO+Rh transfusion compatibility between a recipient and a donor unit. */
export function isCompatible(recipient: BloodGroup, donor: BloodGroup): boolean {
  return isAboCompatible(recipient.abo, donor.abo) && isRhCompatible(recipient.rh, donor.rh);
}

/** Returns true if this recipient/donor pairing is the O-negative universal-donor emergency case. */
export function isUniversalDonor(donor: BloodGroup): boolean {
  return donor.abo === 'O' && donor.rh === 'NEGATIVE';
}

/** Returns true if this recipient is AB-positive (the universal-recipient blood group). */
export function isUniversalRecipient(recipient: BloodGroup): boolean {
  return recipient.abo === 'AB' && recipient.rh === 'POSITIVE';
}

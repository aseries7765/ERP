import { ComponentType } from './types';

/**
 * Standard storage duration and conditions for blood components. These are
 * common reference values (RBC ~42 days refrigerated with standard
 * additive solution, platelets 5 days room-temp with agitation, plasma up
 * to 1 year frozen, cryoprecipitate 1 year frozen) — actual shelf life
 * varies by additive solution and local regulatory approval, so this
 * should be confirmed against the facility's SOP before production use.
 */
export const SHELF_LIFE_DAYS: Record<ComponentType, number> = {
  RBC: 42,
  PLATELETS: 5,
  PLASMA: 365,
  CRYOPRECIPITATE: 365,
};

export const STORAGE_CONDITIONS: Record<ComponentType, string> = {
  RBC: '2-6°C refrigerated',
  PLATELETS: '20-24°C with continuous agitation',
  PLASMA: '-18°C or colder',
  CRYOPRECIPITATE: '-18°C or colder',
};

/** Computes the expiry date/time for a component given when it was prepared. */
export function calculateExpiryDate(componentType: ComponentType, preparedDate: Date): Date {
  const days = SHELF_LIFE_DAYS[componentType];
  return new Date(preparedDate.getTime() + days * 24 * 60 * 60 * 1000);
}

/** Returns true if the component's shelf life has elapsed as of the given time (default now). */
export function isExpired(componentType: ComponentType, preparedDate: Date, asOf: Date = new Date()): boolean {
  return calculateExpiryDate(componentType, preparedDate).getTime() <= asOf.getTime();
}

/** Returns the number of whole days remaining before the component expires (can be negative if already expired). */
export function daysUntilExpiry(
  componentType: ComponentType,
  preparedDate: Date,
  asOf: Date = new Date(),
): number {
  const expiry = calculateExpiryDate(componentType, preparedDate);
  return Math.floor((expiry.getTime() - asOf.getTime()) / (24 * 60 * 60 * 1000));
}

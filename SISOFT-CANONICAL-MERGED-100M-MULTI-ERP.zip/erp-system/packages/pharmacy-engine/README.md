# @erp/pharmacy-engine

Pure, framework-free domain logic for pharmacy operations: FEFO stock
allocation, dose calculation (adult/renal/pediatric-flagging), DEA
controlled-substance scheduling, the narcotics register running-balance
ledger, and dual-sign (two-person) verification for controlled substances.

This package has **no I/O, no database access, and no NestJS/HTTP
dependency** — it's meant to be called from the (not-yet-built) HIS-2
`his-pharmacy` NestJS module's services, which own persistence, auth, and
events. Keeping the clinical/regulatory logic here means it can be unit
tested in milliseconds and reused outside the API (e.g. in a batch
reconciliation job) without spinning up a database.

## What's implemented

- `dispensing/fefo.ts` — First-Expiry-First-Out batch allocation, with a
  configurable minimum-shelf-life threshold and an explicit opt-in for
  using near-expiry stock as a last resort. Never allocates already-expired
  stock.
- `dispensing/dose-calculator.ts` — mg/kg and fixed dosing, renal-function
  adjustment, max-daily-dose capping, and a pediatric-age warning (flags,
  does not silently block — a pharmacist makes the final call).
- `controlled/schedule.ts` — DEA schedule II-V classification helpers.
- `controlled/register.ts` — append-only narcotics register with running
  balance and reconciliation against physical counts.
- `controlled/dual-sign.ts` — hard gate requiring a distinct witnessing
  signature for any controlled-substance dispense or waste (G17).
- `drug/drug-model.ts` — drug name normalization/lookup for formulary
  matching.

## What's NOT implemented here (see root MANIFEST.md)

- Drug-drug interaction checking and allergy checking — the brief says
  these should *wrap* the existing `patient-safety` package from HIS-1;
  that package wasn't in scope to inspect/import here, so this engine
  does not include interaction logic. Do not dispense in production
  without that check wired in.
- IV admixture / TPN compounding calculators.
- Persistence, HTTP controllers, NestJS module, Prisma schema, events,
  seed data, frontend.

## Usage

```ts
import { allocateFefo, calculateDose, validateDualSign } from '@erp/pharmacy-engine';

const allocation = allocateFefo(batches, 'DRUG-123', 30, { minShelfLifeDays: 30 });

const dose = calculateDose(
  { drugId: 'DRUG-123', route: 'PO', standardDoseMgPerKg: 10, maxDailyMg: 1000 },
  { ageYears: 8, weightKg: 25 },
);

validateDualSign({ schedule: 'II', performedBy: 'RPh-1', witnessedBy: 'RPh-2', action: 'DISPENSE' });
```

## Test

```
pnpm --filter @erp/pharmacy-engine test
```

Runs `tsx --test src/__tests__/*.spec.ts` — 35 unit tests, no DB required.

Measured coverage (`npx tsx --test --experimental-test-coverage src/__tests__/*.spec.ts`): 99.37% line / 92.02% branch / 95.33% function — all above the brief's 85% target.

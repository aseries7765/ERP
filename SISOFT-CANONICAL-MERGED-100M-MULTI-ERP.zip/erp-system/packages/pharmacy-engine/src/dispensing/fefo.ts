import { DrugBatch, DispenseAllocation } from '../types';

/** Thrown when the total available (non-expired, shelf-life-eligible) stock is less than the requested quantity. */
export class InsufficientStockError extends Error {
  constructor(drugId: string, requested: number, available: number) {
    super(
      `Insufficient stock for drug ${drugId}: requested ${requested}, available ${available}`,
    );
    this.name = 'InsufficientStockError';
  }
}

/** Options controlling FEFO allocation behavior. */
export interface FefoOptions {
  /** Batches expiring within this many days from `asOf` are excluded unless allowNearExpiry is true. */
  minShelfLifeDays?: number;
  allowNearExpiry?: boolean;
  asOf?: Date;
}

/**
 * Allocates the requested quantity of a drug across available batches using
 * First-Expiry-First-Out. Batches with zero or negative stock are ignored.
 * Batches expiring before `asOf + minShelfLifeDays` are skipped unless
 * `allowNearExpiry` is set, in which case they're used last, after all
 * batches with sufficient shelf life are exhausted.
 */
export function allocateFefo(
  batches: DrugBatch[],
  drugId: string,
  quantityNeeded: number,
  options: FefoOptions = {},
): DispenseAllocation[] {
  if (quantityNeeded <= 0) {
    throw new Error('quantityNeeded must be positive');
  }

  const asOf = options.asOf ?? new Date();
  const minShelfLifeDays = options.minShelfLifeDays ?? 0;
  const minShelfLifeMs = minShelfLifeDays * 24 * 60 * 60 * 1000;
  const cutoff = new Date(asOf.getTime() + minShelfLifeMs);

  const candidates = batches
    .filter((b) => b.drugId === drugId && b.quantityOnHand > 0)
    .filter((b) => b.expiryDate.getTime() > asOf.getTime()); // never allocate already-expired stock

  const withSufficientShelfLife = candidates
    .filter((b) => b.expiryDate.getTime() >= cutoff.getTime())
    .sort((a, b) => a.expiryDate.getTime() - b.expiryDate.getTime());

  const nearExpiry = candidates
    .filter((b) => b.expiryDate.getTime() < cutoff.getTime())
    .sort((a, b) => a.expiryDate.getTime() - b.expiryDate.getTime());

  const orderedPool = options.allowNearExpiry
    ? [...withSufficientShelfLife, ...nearExpiry]
    : withSufficientShelfLife;

  const totalAvailable = orderedPool.reduce((sum, b) => sum + b.quantityOnHand, 0);
  if (totalAvailable < quantityNeeded) {
    throw new InsufficientStockError(drugId, quantityNeeded, totalAvailable);
  }

  const allocations: DispenseAllocation[] = [];
  let remaining = quantityNeeded;
  for (const batch of orderedPool) {
    if (remaining <= 0) break;
    const take = Math.min(batch.quantityOnHand, remaining);
    allocations.push({
      batchId: batch.batchId,
      quantity: take,
      expiryDate: batch.expiryDate,
    });
    remaining -= take;
  }

  return allocations;
}

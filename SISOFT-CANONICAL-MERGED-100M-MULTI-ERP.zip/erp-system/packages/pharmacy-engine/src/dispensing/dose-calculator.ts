import { DoseRule, PatientDoseContext } from '../types';

/** Result of calculating a patient-specific dose, including any adjustments applied. */
export interface DoseResult {
  doseMg: number;
  cappedAtMaxDaily: boolean;
  renalAdjusted: boolean;
  warnings: string[];
}

/** Thrown when a dose cannot be calculated (e.g. mg/kg rule with no patient weight provided). */
export class DoseCalculationError extends Error {}

/**
 * Computes a recommended dose in mg for a patient given a DoseRule.
 * - Uses mg/kg if weight is available and the rule defines it, else fixed dose.
 * - Applies renal adjustment if eGFR is below the rule's threshold.
 * - Caps at maxDailyMg if defined.
 * - Flags (does not block) pediatric patients below the rule's minimum age.
 */
export function calculateDose(rule: DoseRule, patient: PatientDoseContext): DoseResult {
  const warnings: string[] = [];

  if (rule.pediatricMinAgeYears !== undefined && patient.ageYears < rule.pediatricMinAgeYears) {
    warnings.push(
      `Patient age ${patient.ageYears} is below the documented minimum age ${rule.pediatricMinAgeYears} for this drug/route — pharmacist review required.`,
    );
  }

  let doseMg: number;
  if (rule.standardDoseMgPerKg !== undefined) {
    if (patient.weightKg === undefined || patient.weightKg <= 0) {
      throw new DoseCalculationError(
        `Weight is required to calculate mg/kg dose for drug ${rule.drugId}`,
      );
    }
    doseMg = rule.standardDoseMgPerKg * patient.weightKg;
  } else if (rule.standardDoseMgFixed !== undefined) {
    doseMg = rule.standardDoseMgFixed;
  } else {
    throw new DoseCalculationError(`No dose basis defined for drug ${rule.drugId}`);
  }

  let renalAdjusted = false;
  if (
    rule.renalAdjustment !== undefined &&
    patient.egfrMlMin !== undefined &&
    patient.egfrMlMin < rule.renalAdjustment.egfrThreshold
  ) {
    doseMg *= rule.renalAdjustment.factor;
    renalAdjusted = true;
    warnings.push(
      `Dose reduced by factor ${rule.renalAdjustment.factor} for eGFR ${patient.egfrMlMin} mL/min (threshold ${rule.renalAdjustment.egfrThreshold}).`,
    );
  }

  let cappedAtMaxDaily = false;
  if (rule.maxDailyMg !== undefined && doseMg > rule.maxDailyMg) {
    doseMg = rule.maxDailyMg;
    cappedAtMaxDaily = true;
    warnings.push(`Dose capped at documented maximum daily dose of ${rule.maxDailyMg} mg.`);
  }

  return { doseMg, cappedAtMaxDaily, renalAdjusted, warnings };
}

/** A physical batch of stock for a drug, with quantity on hand and expiry — the unit FEFO allocates against. */
export interface DrugBatch {
  batchId: string;
  drugId: string;
  quantityOnHand: number;
  expiryDate: Date;
  receivedDate: Date;
  location?: string;
}

/** A quantity of a specific batch allocated to fulfill part or all of a dispense request. */
export interface DispenseAllocation {
  batchId: string;
  quantity: number;
  expiryDate: Date;
}

/** US DEA controlled-substance schedule, or NON_CONTROLLED for ordinary drugs. */
export type DeaSchedule = 'II' | 'III' | 'IV' | 'V' | 'NON_CONTROLLED';

/** The patient-specific inputs needed to calculate a dose. */
export interface PatientDoseContext {
  ageYears: number;
  weightKg?: number;
  egfrMlMin?: number; // renal function, if known
}

/** A documented dosing rule for a drug/route, including optional pediatric and renal-adjustment parameters. */
export interface DoseRule {
  drugId: string;
  route: 'PO' | 'IV' | 'IM' | 'SC' | 'TOPICAL';
  standardDoseMgPerKg?: number;
  standardDoseMgFixed?: number;
  maxDailyMg?: number;
  pediatricMinAgeYears?: number;
  renalAdjustment?: {
    egfrThreshold: number; // below this, adjust
    factor: number; // multiply dose by this factor
  };
}

/** A single append-only entry in a controlled-substance narcotics register. */
export interface NarcoticsRegisterEntry {
  entryId: string;
  drugId: string;
  batchId: string;
  type: 'RECEIPT' | 'DISPENSE' | 'WASTE' | 'ADJUSTMENT';
  quantity: number; // positive for receipt, negative for dispense/waste
  balanceAfter: number;
  performedBy: string;
  witnessedBy?: string; // required for DISPENSE and WASTE
  timestamp: Date;
  patientId?: string;
  reason?: string;
}

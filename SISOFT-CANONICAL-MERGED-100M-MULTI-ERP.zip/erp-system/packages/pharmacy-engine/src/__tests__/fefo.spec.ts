import { test } from 'node:test';
import assert from 'node:assert/strict';
import { allocateFefo, InsufficientStockError } from '../dispensing/fefo';
import { DrugBatch } from '../types';

const asOf = new Date('2026-01-01T00:00:00Z');

function batch(id: string, qty: number, daysFromNow: number): DrugBatch {
  return {
    batchId: id,
    drugId: 'DRUG-1',
    quantityOnHand: qty,
    receivedDate: asOf,
    expiryDate: new Date(asOf.getTime() + daysFromNow * 86400000),
  };
}

test('picks earliest-expiry batch first', () => {
  const batches = [batch('B-LATE', 100, 200), batch('B-EARLY', 100, 60)];
  const result = allocateFefo(batches, 'DRUG-1', 50, { asOf });
  assert.equal(result.length, 1);
  assert.equal(result[0].batchId, 'B-EARLY');
});

test('spans multiple batches in expiry order when one is insufficient', () => {
  const batches = [batch('B-EARLY', 10, 60), batch('B-LATE', 100, 200)];
  const result = allocateFefo(batches, 'DRUG-1', 30, { asOf });
  assert.equal(result.length, 2);
  assert.equal(result[0].batchId, 'B-EARLY');
  assert.equal(result[0].quantity, 10);
  assert.equal(result[1].batchId, 'B-LATE');
  assert.equal(result[1].quantity, 20);
});

test('excludes batches below minShelfLifeDays by default', () => {
  const batches = [batch('B-NEAREXP', 100, 10)]; // expires in 10 days
  assert.throws(
    () => allocateFefo(batches, 'DRUG-1', 5, { asOf, minShelfLifeDays: 30 }),
    InsufficientStockError,
  );
});

test('allows near-expiry batches only when explicitly permitted, used last', () => {
  const batches = [batch('B-NEAREXP', 5, 10), batch('B-GOOD', 5, 60)];
  const result = allocateFefo(batches, 'DRUG-1', 8, {
    asOf,
    minShelfLifeDays: 30,
    allowNearExpiry: true,
  });
  // Good batch (sufficient shelf life) exhausted first, then near-expiry
  assert.equal(result[0].batchId, 'B-GOOD');
  assert.equal(result[0].quantity, 5);
  assert.equal(result[1].batchId, 'B-NEAREXP');
  assert.equal(result[1].quantity, 3);
});

test('never allocates already-expired stock', () => {
  const batches = [batch('B-EXPIRED', 100, -5)];
  assert.throws(() => allocateFefo(batches, 'DRUG-1', 1, { asOf }), InsufficientStockError);
});

test('throws InsufficientStockError when total stock too low', () => {
  const batches = [batch('B-1', 5, 60)];
  assert.throws(() => allocateFefo(batches, 'DRUG-1', 10, { asOf }), InsufficientStockError);
});

test('ignores batches for a different drug', () => {
  const batches: DrugBatch[] = [
    { ...batch('B-OTHER', 100, 60), drugId: 'DRUG-2' },
    batch('B-1', 20, 60),
  ];
  const result = allocateFefo(batches, 'DRUG-1', 10, { asOf });
  assert.equal(result.length, 1);
  assert.equal(result[0].batchId, 'B-1');
});

test('rejects non-positive quantity requests', () => {
  assert.throws(() => allocateFefo([], 'DRUG-1', 0, { asOf }));
  assert.throws(() => allocateFefo([], 'DRUG-1', -1, { asOf }));
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { appendRegisterEntry, reconcile, RegisterBalanceError } from '../controlled/register';
import { NarcoticsRegisterEntry } from '../types';

test('computes running balance from prior entries', () => {
  const entries: NarcoticsRegisterEntry[] = [];
  const e1 = appendRegisterEntry(entries, {
    entryId: '1',
    drugId: 'D1',
    batchId: 'B1',
    type: 'RECEIPT',
    quantity: 100,
    performedBy: 'tech-1',
    timestamp: new Date(),
  });
  assert.equal(e1.balanceAfter, 100);

  const e2 = appendRegisterEntry([e1], {
    entryId: '2',
    drugId: 'D1',
    batchId: 'B1',
    type: 'DISPENSE',
    quantity: -10,
    performedBy: 'RPh-1',
    witnessedBy: 'RPh-2',
    timestamp: new Date(),
  });
  assert.equal(e2.balanceAfter, 90);
});

test('throws if dispense/waste would drive balance negative', () => {
  const entries: NarcoticsRegisterEntry[] = [];
  assert.throws(
    () =>
      appendRegisterEntry(entries, {
        entryId: '1',
        drugId: 'D1',
        batchId: 'B1',
        type: 'DISPENSE',
        quantity: -5,
        performedBy: 'RPh-1',
        witnessedBy: 'RPh-2',
        timestamp: new Date(),
      }),
    RegisterBalanceError,
  );
});

test('allows ADJUSTMENT entries to go negative (reconciliation correction)', () => {
  const entries: NarcoticsRegisterEntry[] = [];
  const adj = appendRegisterEntry(entries, {
    entryId: '1',
    drugId: 'D1',
    batchId: 'B1',
    type: 'ADJUSTMENT',
    quantity: -3,
    performedBy: 'supervisor-1',
    timestamp: new Date(),
    reason: 'physical count correction',
  });
  assert.equal(adj.balanceAfter, -3);
});

test('reconcile reports discrepancy against physical count', () => {
  const e1 = appendRegisterEntry([], {
    entryId: '1',
    drugId: 'D1',
    batchId: 'B1',
    type: 'RECEIPT',
    quantity: 50,
    performedBy: 'tech-1',
    timestamp: new Date(),
  });
  const result = reconcile([e1], 48);
  assert.equal(result.expectedBalance, 50);
  assert.equal(result.discrepancy, -2);
  assert.equal(result.matches, false);
});

test('reconcile matches when physical count equals expected balance', () => {
  const e1 = appendRegisterEntry([], {
    entryId: '1',
    drugId: 'D1',
    batchId: 'B1',
    type: 'RECEIPT',
    quantity: 50,
    performedBy: 'tech-1',
    timestamp: new Date(),
  });
  const result = reconcile([e1], 50);
  assert.equal(result.matches, true);
});

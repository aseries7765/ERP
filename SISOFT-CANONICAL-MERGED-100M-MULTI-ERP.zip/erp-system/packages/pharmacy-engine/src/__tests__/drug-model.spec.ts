import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeDrugName, findDrugByName } from '../drug/drug-model';
import { Drug } from '../drug/drug-model';

test('normalizes case, punctuation, and whitespace', () => {
  assert.equal(normalizeDrugName('  Paracetamol  '), 'paracetamol');
  assert.equal(normalizeDrugName('Co-Amoxiclav'), 'coamoxiclav');
  assert.equal(normalizeDrugName('Tylenol®'), 'tylenol');
});

test('collapses internal whitespace', () => {
  assert.equal(normalizeDrugName('Amoxicillin   500mg'), 'amoxicillin 500mg');
});

test('strips accents via NFKD normalization, leaving the base letter', () => {
  assert.equal(normalizeDrugName('caf\u00e9'), 'cafe');
});

const drugs: Drug[] = [
  { drugId: 'D1', genericName: 'Paracetamol', brandNames: ['Tylenol', 'Panadol'], strength: '500mg', form: 'TABLET' },
  { drugId: 'D2', genericName: 'Amoxicillin', brandNames: ['Amoxil'], strength: '250mg', form: 'CAPSULE' },
];

test('finds a drug by exact generic name, case-insensitive', () => {
  assert.equal(findDrugByName(drugs, 'paracetamol')?.drugId, 'D1');
  assert.equal(findDrugByName(drugs, 'PARACETAMOL')?.drugId, 'D1');
});

test('finds a drug by brand name', () => {
  assert.equal(findDrugByName(drugs, 'Tylenol')?.drugId, 'D1');
  assert.equal(findDrugByName(drugs, 'panadol')?.drugId, 'D1');
  assert.equal(findDrugByName(drugs, 'Amoxil')?.drugId, 'D2');
});

test('returns undefined for an unknown name', () => {
  assert.equal(findDrugByName(drugs, 'Nonexistentol'), undefined);
});

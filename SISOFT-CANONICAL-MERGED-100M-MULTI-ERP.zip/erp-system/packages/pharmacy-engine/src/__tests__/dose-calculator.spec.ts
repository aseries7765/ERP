import { test } from 'node:test';
import assert from 'node:assert/strict';
import { calculateDose, DoseCalculationError } from '../dispensing/dose-calculator';
import { DoseRule } from '../types';

test('calculates mg/kg dose from weight', () => {
  const rule: DoseRule = { drugId: 'D1', route: 'IV', standardDoseMgPerKg: 10 };
  const result = calculateDose(rule, { ageYears: 40, weightKg: 70 });
  assert.equal(result.doseMg, 700);
  assert.equal(result.cappedAtMaxDaily, false);
});

test('throws if mg/kg rule but no weight provided', () => {
  const rule: DoseRule = { drugId: 'D1', route: 'IV', standardDoseMgPerKg: 10 };
  assert.throws(() => calculateDose(rule, { ageYears: 40 }), DoseCalculationError);
});

test('uses fixed dose when mg/kg not defined', () => {
  const rule: DoseRule = { drugId: 'D1', route: 'PO', standardDoseMgFixed: 500 };
  const result = calculateDose(rule, { ageYears: 30 });
  assert.equal(result.doseMg, 500);
});

test('caps dose at maxDailyMg', () => {
  const rule: DoseRule = {
    drugId: 'D1',
    route: 'PO',
    standardDoseMgPerKg: 50,
    maxDailyMg: 1000,
  };
  const result = calculateDose(rule, { ageYears: 30, weightKg: 100 }); // 5000mg raw
  assert.equal(result.doseMg, 1000);
  assert.equal(result.cappedAtMaxDaily, true);
  assert.ok(result.warnings.some((w) => w.includes('capped')));
});

test('applies renal adjustment below eGFR threshold', () => {
  const rule: DoseRule = {
    drugId: 'D1',
    route: 'PO',
    standardDoseMgFixed: 1000,
    renalAdjustment: { egfrThreshold: 30, factor: 0.5 },
  };
  const result = calculateDose(rule, { ageYears: 60, egfrMlMin: 20 });
  assert.equal(result.doseMg, 500);
  assert.equal(result.renalAdjusted, true);
});

test('does not apply renal adjustment when eGFR is above threshold', () => {
  const rule: DoseRule = {
    drugId: 'D1',
    route: 'PO',
    standardDoseMgFixed: 1000,
    renalAdjustment: { egfrThreshold: 30, factor: 0.5 },
  };
  const result = calculateDose(rule, { ageYears: 60, egfrMlMin: 90 });
  assert.equal(result.doseMg, 1000);
  assert.equal(result.renalAdjusted, false);
});

test('warns (does not block) for pediatric patients below minimum age', () => {
  const rule: DoseRule = {
    drugId: 'D1',
    route: 'PO',
    standardDoseMgFixed: 250,
    pediatricMinAgeYears: 12,
  };
  const result = calculateDose(rule, { ageYears: 6 });
  assert.equal(result.doseMg, 250);
  assert.ok(result.warnings.some((w) => w.includes('minimum age')));
});

test('throws when no dose basis is defined', () => {
  const rule: DoseRule = { drugId: 'D1', route: 'PO' };
  assert.throws(() => calculateDose(rule, { ageYears: 30 }), DoseCalculationError);
});

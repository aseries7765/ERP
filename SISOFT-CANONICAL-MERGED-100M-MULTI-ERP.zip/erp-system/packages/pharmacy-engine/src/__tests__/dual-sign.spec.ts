import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateDualSign, DualSignError } from '../controlled/dual-sign';

test('allows non-controlled dispense without witness', () => {
  assert.doesNotThrow(() =>
    validateDualSign({ schedule: 'NON_CONTROLLED', performedBy: 'RPh-1', action: 'DISPENSE' }),
  );
});

test('rejects controlled dispense without a witness', () => {
  assert.throws(
    () => validateDualSign({ schedule: 'II', performedBy: 'RPh-1', action: 'DISPENSE' }),
    DualSignError,
  );
});

test('rejects controlled waste without a witness', () => {
  assert.throws(
    () => validateDualSign({ schedule: 'II', performedBy: 'RPh-1', action: 'WASTE' }),
    DualSignError,
  );
});

test('rejects self-witnessing', () => {
  assert.throws(
    () =>
      validateDualSign({
        schedule: 'II',
        performedBy: 'RPh-1',
        witnessedBy: 'RPh-1',
        action: 'DISPENSE',
      }),
    DualSignError,
  );
});

test('allows controlled dispense with a distinct witness', () => {
  assert.doesNotThrow(() =>
    validateDualSign({
      schedule: 'II',
      performedBy: 'RPh-1',
      witnessedBy: 'RPh-2',
      action: 'DISPENSE',
    }),
  );
});

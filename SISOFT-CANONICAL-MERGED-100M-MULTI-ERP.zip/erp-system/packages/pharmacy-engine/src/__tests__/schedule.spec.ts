import { test } from 'node:test';
import assert from 'node:assert/strict';
import { requiresDualSign, isControlled, isStricterSchedule } from '../controlled/schedule';

test('non-controlled drugs do not require dual-sign', () => {
  assert.equal(requiresDualSign('NON_CONTROLLED'), false);
  assert.equal(isControlled('NON_CONTROLLED'), false);
});

test('schedules II through V require dual-sign', () => {
  for (const s of ['II', 'III', 'IV', 'V'] as const) {
    assert.equal(requiresDualSign(s), true, `schedule ${s} should require dual-sign`);
    assert.equal(isControlled(s), true);
  }
});

test('isStricterSchedule orders II as stricter than V', () => {
  assert.equal(isStricterSchedule('II', 'V'), true);
  assert.equal(isStricterSchedule('V', 'II'), false);
  assert.equal(isStricterSchedule('II', 'NON_CONTROLLED'), true);
});

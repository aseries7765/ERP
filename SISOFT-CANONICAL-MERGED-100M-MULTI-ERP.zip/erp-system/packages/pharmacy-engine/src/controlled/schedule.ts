import { DeaSchedule } from '../types';

/**
 * Whether a schedule requires dual-sign (two-pharmacist) workflow for
 * dispensing and waste. Per common US hospital policy this applies to
 * schedule II (and, per local policy, III-V in many facilities). This
 * engine treats II-V as controlled and requiring dual-sign, matching the
 * program's mandate that "controlled substances MUST require dual-sign."
 */
export function requiresDualSign(schedule: DeaSchedule): boolean {
  return schedule !== 'NON_CONTROLLED';
}

/** Returns true if this schedule represents a controlled substance (any schedule other than NON_CONTROLLED). */
export function isControlled(schedule: DeaSchedule): boolean {
  return schedule !== 'NON_CONTROLLED';
}

const SCHEDULE_ORDER: Record<DeaSchedule, number> = {
  II: 1,
  III: 2,
  IV: 3,
  V: 4,
  NON_CONTROLLED: 99,
};

/** Returns true if `a` is a stricter (lower-numbered, more tightly controlled) schedule than `b`. */
export function isStricterSchedule(a: DeaSchedule, b: DeaSchedule): boolean {
  return SCHEDULE_ORDER[a] < SCHEDULE_ORDER[b];
}

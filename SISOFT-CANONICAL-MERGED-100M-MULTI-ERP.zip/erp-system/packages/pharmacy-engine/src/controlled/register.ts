import { NarcoticsRegisterEntry } from '../types';

/** Thrown when appending an entry would drive the narcotics register balance negative without an explicit adjustment. */
export class RegisterBalanceError extends Error {}

/**
 * Appends a new entry to a narcotics register, computing the running
 * balance from the prior entry. Throws if the resulting balance would go
 * negative (register corruption / theft indicator) unless it's an
 * ADJUSTMENT entry explicitly reconciling the count.
 */
export function appendRegisterEntry(
  existingEntries: NarcoticsRegisterEntry[],
  newEntry: Omit<NarcoticsRegisterEntry, 'balanceAfter'>,
): NarcoticsRegisterEntry {
  const priorBalance = existingEntries.length
    ? existingEntries[existingEntries.length - 1].balanceAfter
    : 0;

  const balanceAfter = priorBalance + newEntry.quantity;

  if (balanceAfter < 0 && newEntry.type !== 'ADJUSTMENT') {
    throw new RegisterBalanceError(
      `Register balance would go negative (${balanceAfter}) for drug ${newEntry.drugId}, batch ${newEntry.batchId}. Investigate before proceeding.`,
    );
  }

  return { ...newEntry, balanceAfter };
}

/**
 * Reconciles a register against a physical count. Returns the discrepancy
 * (physicalCount - expectedBalance); zero means the register is accurate.
 */
export function reconcile(
  entries: NarcoticsRegisterEntry[],
  physicalCount: number,
): { expectedBalance: number; discrepancy: number; matches: boolean } {
  const expectedBalance = entries.length ? entries[entries.length - 1].balanceAfter : 0;
  const discrepancy = physicalCount - expectedBalance;
  return { expectedBalance, discrepancy, matches: discrepancy === 0 };
}

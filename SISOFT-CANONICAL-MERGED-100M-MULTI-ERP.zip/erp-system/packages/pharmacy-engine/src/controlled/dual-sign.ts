import { DeaSchedule } from '../types';
import { requiresDualSign } from './schedule';

/** Thrown when a controlled-substance action lacks a valid, distinct witness. */
export class DualSignError extends Error {}

/** A controlled-substance dispense or waste action pending dual-sign validation. */
export interface DualSignRequest {
  schedule: DeaSchedule;
  performedBy: string;
  witnessedBy?: string;
  action: 'DISPENSE' | 'WASTE';
}

/**
 * Validates that a controlled-substance dispense or waste action has a
 * valid, distinct witness when the schedule requires dual-sign. Throws
 * rather than silently allowing single-signature controlled transactions —
 * this is a hard patient-safety / regulatory gate (G17).
 */
export function validateDualSign(req: DualSignRequest): void {
  if (!requiresDualSign(req.schedule)) {
    return; // non-controlled, no dual-sign needed
  }

  if (!req.witnessedBy) {
    throw new DualSignError(
      `Schedule ${req.schedule} ${req.action.toLowerCase()} requires a witnessing pharmacist/nurse signature.`,
    );
  }

  if (req.witnessedBy === req.performedBy) {
    throw new DualSignError(
      'Witness must be a different individual from the person performing the action.',
    );
  }
}

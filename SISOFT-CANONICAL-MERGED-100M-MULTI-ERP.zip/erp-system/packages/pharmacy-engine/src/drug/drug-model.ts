/** A drug master record: generic/brand names, strength, and dosage form. */
export interface Drug {
  drugId: string;
  genericName: string;
  brandNames: string[];
  strength: string; // e.g. "500mg"
  form: 'TABLET' | 'CAPSULE' | 'INJECTION' | 'SYRUP' | 'CREAM' | 'INHALER' | 'OTHER';
}

/** Normalizes a free-text drug name for matching against the formulary (lowercase, trimmed, punctuation stripped). */
export function normalizeDrugName(name: string): string {
  return name
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Finds a drug by generic or brand name (normalized, case-insensitive). */
export function findDrugByName(drugs: Drug[], name: string): Drug | undefined {
  const target = normalizeDrugName(name);
  return drugs.find(
    (d) =>
      normalizeDrugName(d.genericName) === target ||
      d.brandNames.some((b) => normalizeDrugName(b) === target),
  );
}

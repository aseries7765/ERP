export interface OracleProviderConfig {
  /** Set to true to use the in-memory mock OCI client instead of the real
   * OCI SDK. Defaults to true in this delivery — see MANIFEST.md: the
   * real `oci-sdk` client is NOT wired up (no network in the build
   * sandbox to install/verify it). */
  mock?: boolean;
  region?: string;
  tenancyId?: string;
}

export interface MockOciResource {
  id: string;
  displayName: string;
  compartmentId: string;
}

// This sandbox has no network access, so @types/node could not be
// npm-installed to satisfy `tsc --noEmit` for the test files. In the real
// monorepo, @types/node is already a devDependency at the root and this
// file is not needed. See MANIFEST.md ("Known limitations").
declare module 'node:test' {
  export function test(name: string, fn: () => void | Promise<void>): void;
}
declare module 'node:assert/strict' {
  const assert: {
    equal: (a: unknown, b: unknown, msg?: string) => void;
    deepEqual: (a: unknown, b: unknown, msg?: string) => void;
    ok: (v: unknown, msg?: string) => void;
    throws: (fn: () => unknown, expected?: unknown) => void;
    rejects: (fn: () => Promise<unknown>, expected?: unknown) => Promise<void>;
  };
  export default assert;
}

import assert from 'node:assert/strict';
import { test } from 'node:test';
import { QuotaExceededError } from '@erp/cloud-provider';
import { OracleProvider } from '../oracle.provider.js';

test('selects ARM Ampere shape for free plan (Free Tier requirement)', () => {
  const provider = new OracleProvider();
  assert.equal(provider.selectShape('free'), 'VM.Standard.A1.Flex');
});

test('selects E4.Flex shape for starter and business plans', () => {
  const provider = new OracleProvider();
  assert.equal(provider.selectShape('starter'), 'VM.Standard.E4.Flex');
  assert.equal(provider.selectShape('business'), 'VM.Standard.E4.Flex');
});

test('getCompartmentId is idempotent per customer', async () => {
  const provider = new OracleProvider();
  const id1 = await provider.getCompartmentId('cust-1');
  const id2 = await provider.getCompartmentId('cust-1');
  assert.equal(id1, id2);
});

test('createNetwork returns four distinct subnets (public/app/db/mgmt)', async () => {
  const provider = new OracleProvider();
  const compartmentId = await provider.getCompartmentId('cust-2');
  const net = await provider.createNetwork({ compartmentId, cidrBlock: '10.0.0.0/16', displayNamePrefix: 'cust-2' });
  const ids = [net.publicSubnetId, net.appSubnetId, net.dbSubnetId, net.mgmtSubnetId];
  assert.equal(new Set(ids).size, 4);
});

test('createNetwork is idempotent: re-running with same prefix does not duplicate VCN', async () => {
  const provider = new OracleProvider();
  const compartmentId = await provider.getCompartmentId('cust-3');
  const net1 = await provider.createNetwork({ compartmentId, cidrBlock: '10.0.0.0/16', displayNamePrefix: 'cust-3' });
  const net2 = await provider.createNetwork({ compartmentId, cidrBlock: '10.0.0.0/16', displayNamePrefix: 'cust-3' });
  assert.equal(net1.vcnId, net2.vcnId);
});

test('createDatabase returns a connection string and provisioned specs', async () => {
  const provider = new OracleProvider();
  const compartmentId = await provider.getCompartmentId('cust-4');
  const db = await provider.createDatabase({
    compartmentId,
    dbName: 'cust4db',
    displayName: 'cust-4-adb',
    cpuCoreCount: 1,
    storageTBs: 0.02,
    subnetId: 'sub-1',
    autoScale: false,
  });
  assert.equal(db.status, 'available');
  assert.ok(db.connectionString?.includes('cust4db'));
});

test('createCompute throws QuotaExceededError above a sane instance count', async () => {
  const provider = new OracleProvider();
  const compartmentId = await provider.getCompartmentId('cust-5');
  await assert.rejects(
    () =>
      provider.createCompute({
        compartmentId,
        subnetId: 'sub-1',
        shape: 'VM.Standard.A1.Flex',
        count: 50,
        displayNamePrefix: 'cust-5-app',
      }),
    QuotaExceededError,
  );
});

test('generateEncryptionKey never returns raw key material, only references', async () => {
  const provider = new OracleProvider();
  const compartmentId = await provider.getCompartmentId('cust-6');
  const keyRef = await provider.generateEncryptionKey(compartmentId, 'cust-6');
  assert.ok(keyRef.keyId);
  assert.ok(keyRef.vaultId);
  assert.equal('keyMaterial' in keyRef, false);
});

test('constructing with mock: false throws (real OCI SDK not implemented)', () => {
  assert.throws(() => new OracleProvider({ mock: false }), /not implemented/);
});

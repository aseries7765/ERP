import {
  CloudProvider,
  ComputeInstance,
  CreateComputeParams,
  CreateDatabaseParams,
  CreateNetworkParams,
  DatabaseInstance,
  KeyRef,
  NetworkTopology,
  QuotaExceededError,
  ResourceNotFoundError,
  StorageBucket,
} from '@erp/cloud-provider';
import { MockOciClient } from './mock-oci-client.js';
import { OracleProviderConfig } from './types.js';

/**
 * Oracle Cloud Infrastructure implementation of CloudProvider.
 *
 * STATUS: backed by MockOciClient (in-memory), not the real `oci-sdk`.
 * All idempotency and shape-selection logic below is real and tested;
 * only the underlying "calls Oracle" step is mocked. See MANIFEST.md.
 */
export class OracleProvider implements CloudProvider {
  readonly name = 'oracle';
  private readonly client = new MockOciClient();
  private readonly config: OracleProviderConfig;

  constructor(config: OracleProviderConfig = {}) {
    this.config = { mock: true, region: 'us-ashburn-1', ...config };
    if (this.config.mock === false) {
      throw new Error(
        'Real OCI SDK mode is not implemented in this delivery. ' +
          'Construct OracleProvider with { mock: true } (the default).',
      );
    }
  }

  /** Selects a compute shape per plan tier, matching Free Tier ARM Ampere constraints. */
  selectShape(planId: string): string {
    if (planId === 'free') return 'VM.Standard.A1.Flex';
    if (planId === 'starter') return 'VM.Standard.E4.Flex';
    if (planId === 'business') return 'VM.Standard.E4.Flex';
    return 'VM.Optimized3.Flex';
  }

  async getCompartmentId(customerId: string): Promise<string> {
    const compartmentName = `customer-${customerId}`;
    const resource = this.client.create('ocid1.compartment', 'root', compartmentName, { customerId });
    return resource.id;
  }

  async deleteCompartment(compartmentId: string): Promise<void> {
    this.client.delete(compartmentId);
  }

  async createCompute(params: CreateComputeParams): Promise<ComputeInstance[]> {
    if (params.count > 10) {
      // Free Tier / small-plan sanity guard — mirrors OCI quota behavior.
      throw new QuotaExceededError('compute instances', params.compartmentId);
    }
    const instances: ComputeInstance[] = [];
    for (let i = 0; i < params.count; i++) {
      const displayName = `${params.displayNamePrefix}-${i}`;
      const resource = this.client.create('ocid1.instance', params.compartmentId, displayName, {
        shape: params.shape,
      });
      instances.push({ id: resource.id, shape: params.shape, status: 'running', privateIp: `10.0.2.${10 + i}` });
    }
    return instances;
  }

  async terminateCompute(instanceId: string): Promise<void> {
    this.client.delete(instanceId);
  }

  async createDatabase(params: CreateDatabaseParams): Promise<DatabaseInstance> {
    const resource = this.client.create('ocid1.autonomousdatabase', params.compartmentId, params.displayName, {
      cpuCoreCount: params.cpuCoreCount,
      storageTBs: params.storageTBs,
      status: 'available',
    });
    return {
      id: resource.id,
      status: 'available',
      cpuCoreCount: params.cpuCoreCount,
      storageTBs: params.storageTBs,
      connectionString: `${resource.id}.adb.${this.config.region}.oraclecloud.com:1522/${params.dbName}`,
    };
  }

  async waitForDatabaseAvailable(dbId: string, _timeoutMs: number): Promise<DatabaseInstance> {
    const resource = this.client.findById(dbId);
    if (!resource) throw new ResourceNotFoundError('AutonomousDatabase', dbId);
    return {
      id: resource.id,
      status: 'available',
      cpuCoreCount: resource.cpuCoreCount as number,
      storageTBs: resource.storageTBs as number,
    };
  }

  async terminateDatabase(dbId: string): Promise<void> {
    this.client.delete(dbId);
  }

  async createNetwork(params: CreateNetworkParams): Promise<NetworkTopology> {
    const vcn = this.client.create('ocid1.vcn', params.compartmentId, `${params.displayNamePrefix}-vcn`, {
      cidrBlock: params.cidrBlock,
    });
    const publicSubnet = this.client.create('ocid1.subnet', params.compartmentId, `${params.displayNamePrefix}-public`);
    const appSubnet = this.client.create('ocid1.subnet', params.compartmentId, `${params.displayNamePrefix}-app`);
    const dbSubnet = this.client.create('ocid1.subnet', params.compartmentId, `${params.displayNamePrefix}-db`);
    const mgmtSubnet = this.client.create('ocid1.subnet', params.compartmentId, `${params.displayNamePrefix}-mgmt`);

    return {
      vcnId: vcn.id,
      publicSubnetId: publicSubnet.id,
      appSubnetId: appSubnet.id,
      dbSubnetId: dbSubnet.id,
      mgmtSubnetId: mgmtSubnet.id,
    };
  }

  async deleteNetwork(vcnId: string): Promise<void> {
    this.client.delete(vcnId);
  }

  async createStorageBucket(compartmentId: string, name: string): Promise<StorageBucket> {
    const resource = this.client.create('ocid1.bucket', compartmentId, name);
    return { id: resource.id, name, region: this.config.region! };
  }

  async deleteStorageBucket(bucketId: string): Promise<void> {
    this.client.delete(bucketId);
  }

  async generateEncryptionKey(compartmentId: string, customerId: string): Promise<KeyRef> {
    const vault = this.client.create('ocid1.vault', compartmentId, `vault-${customerId}`);
    const key = this.client.create('ocid1.key', compartmentId, `data-key-${customerId}`, { vaultId: vault.id });
    // Key material never leaves the vault — only the reference is returned.
    return { vaultId: vault.id, keyId: key.id, region: this.config.region! };
  }

  async deleteEncryptionKey(keyRef: KeyRef): Promise<void> {
    this.client.delete(keyRef.keyId);
    this.client.delete(keyRef.vaultId);
  }
}

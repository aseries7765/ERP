import { MockOciResource } from './types.js';

let idCounter = 0;
function nextId(prefix: string): string {
  idCounter += 1;
  return `${prefix}-${idCounter}`;
}

/**
 * In-memory stand-in for the real `oci-sdk` clients (compute, database,
 * virtual-network, object-storage, kms/vault, identity). This is NOT a
 * real Oracle Cloud integration — see MANIFEST.md.
 *
 * It exists so that:
 *  1. OracleProvider's idempotency logic (find-by-displayName before
 *     create) can be genuinely tested, not just asserted.
 *  2. The provisioning-engine steps can be exercised end-to-end without
 *     real cloud credentials.
 *
 * Swapping this for `packages/cloud-provider-oracle/src/client/oci-sdk-wrapper.ts`
 * (a real OCI SDK wrapper) is the main remaining task before this
 * package is production-ready.
 */
export class MockOciClient {
  private resources = new Map<string, MockOciResource & Record<string, unknown>>();

  findByDisplayName(compartmentId: string, displayName: string): (MockOciResource & Record<string, unknown>) | null {
    for (const r of this.resources.values()) {
      if (r.compartmentId === compartmentId && r.displayName === displayName) return r;
    }
    return null;
  }

  findById(id: string): (MockOciResource & Record<string, unknown>) | null {
    return this.resources.get(id) ?? null;
  }

  create(prefix: string, compartmentId: string, displayName: string, extra: Record<string, unknown> = {}) {
    const existing = this.findByDisplayName(compartmentId, displayName);
    if (existing) return existing;
    const resource = { id: nextId(prefix), displayName, compartmentId, ...extra };
    this.resources.set(resource.id, resource);
    return resource;
  }

  delete(id: string): void {
    this.resources.delete(id);
  }

  count(): number {
    return this.resources.size;
  }
}

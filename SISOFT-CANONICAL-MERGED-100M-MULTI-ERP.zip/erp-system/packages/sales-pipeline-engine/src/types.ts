/**
 * Shared types for the sales-pipeline-engine package.
 * These are intentionally framework-agnostic (no Prisma, no NestJS) so the
 * package can be unit-tested without a database and reused by both the CRM
 * module (opportunities) and, in future, other modules that need stage
 * machinery (e.g. procurement approvals).
 */

/** A single stage within a pipeline, in traversal order. */
export interface StageDefinition {
  /** Stable key, e.g. "qualification". Never renamed once in use. */
  key: string;
  /** Display label, tenant-terminology-engine may override at render time. */
  label: string;
  /** 0-100 default win probability applied when an opportunity enters this stage. */
  defaultProbability: number;
  /** Field names that must be non-null before an opportunity may enter this stage. */
  requiredFields: string[];
  /** Stage keys this stage is allowed to transition to directly. */
  allowedTransitions: string[];
  /** True for the two terminal "won" / "lost" stages. */
  isClosed: boolean;
  isWon: boolean;
}

export interface PipelineDefinition {
  key: string;
  label: string;
  stages: StageDefinition[];
}

export interface OpportunitySnapshot {
  id: string;
  pipelineKey: string;
  stageKey: string;
  amount: number;
  fields: Record<string, unknown>;
}

export interface StageTransitionResult {
  fromStageKey: string;
  toStageKey: string;
  newProbability: number;
  weightedValue: number;
}

export class InvalidStageTransitionError extends Error {
  constructor(from: string, to: string) {
    super(`Illegal opportunity stage transition: "${from}" -> "${to}"`);
    this.name = 'InvalidStageTransitionError';
  }
}

export class MissingRequiredFieldsError extends Error {
  constructor(stageKey: string, missing: string[]) {
    super(`Cannot enter stage "${stageKey}": missing required fields [${missing.join(', ')}]`);
    this.name = 'MissingRequiredFieldsError';
  }
}

export class UnknownStageError extends Error {
  constructor(stageKey: string, pipelineKey: string) {
    super(`Stage "${stageKey}" does not exist on pipeline "${pipelineKey}"`);
    this.name = 'UnknownStageError';
  }
}

/** Minimal shape used by scoring.ts; deliberately loose since real lead
 * records live in Prisma and we don't want this package depending on it. */
export interface LeadScoringInput {
  source: string;
  hasEmail: boolean;
  hasPhone: boolean;
  companySizeBand?: 'unknown' | 'small' | 'mid' | 'enterprise';
  websiteVisits?: number;
  emailOpens?: number;
  formSubmissions?: number;
  jobTitleSeniority?: 'unknown' | 'ic' | 'manager' | 'director' | 'executive';
  daysSinceCreated?: number;
}

export interface LeadScoreResult {
  score: number; // 0-100
  band: 'cold' | 'warm' | 'hot';
  reasons: string[];
}

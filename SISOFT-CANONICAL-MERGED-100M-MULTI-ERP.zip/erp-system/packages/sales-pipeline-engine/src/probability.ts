import type { OpportunitySnapshot } from './types.js';

/**
 * Weighted value = amount * probability%. Used for stage weighted value,
 * SalesDashboardService forecast, and QuotaService projections.
 */
export function calculateWinProbability(amount: number, probabilityPct: number): number {
  if (amount < 0) throw new RangeError('amount must be >= 0');
  const clamped = Math.max(0, Math.min(100, probabilityPct));
  return round2(amount * (clamped / 100));
}

/** Total weighted pipeline forecast across a set of open opportunities. */
export function forecastWeightedPipeline(
  opportunities: Array<Pick<OpportunitySnapshot, 'amount'> & { probability: number }>,
): number {
  return round2(opportunities.reduce((sum, o) => sum + calculateWinProbability(o.amount, o.probability), 0));
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

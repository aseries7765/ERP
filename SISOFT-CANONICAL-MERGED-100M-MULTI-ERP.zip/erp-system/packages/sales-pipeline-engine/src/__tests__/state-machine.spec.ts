import { test } from 'node:test';
import assert from 'node:assert/strict';
import { moveStage } from '../state-machine.js';
import { STANDARD_PIPELINE } from '../stages.js';
import { InvalidStageTransitionError, MissingRequiredFieldsError, UnknownStageError } from '../types.js';

test('valid forward transition succeeds and sets default probability', () => {
  const result = moveStage({
    pipeline: STANDARD_PIPELINE,
    fromStageKey: 'qualification',
    toStageKey: 'needs_analysis',
    amount: 10000,
    fields: { primaryContactId: 'c1' },
  });
  assert.equal(result.toStageKey, 'needs_analysis');
  assert.equal(result.newProbability, 25);
  assert.equal(result.weightedValue, 2500);
});

test('skipping a stage without admin override throws InvalidStageTransitionError', () => {
  assert.throws(
    () =>
      moveStage({
        pipeline: STANDARD_PIPELINE,
        fromStageKey: 'qualification',
        toStageKey: 'negotiation',
        amount: 10000,
        fields: {},
      }),
    InvalidStageTransitionError,
  );
});

test('admin override allows jumping straight to closed_won', () => {
  const result = moveStage({
    pipeline: STANDARD_PIPELINE,
    fromStageKey: 'qualification',
    toStageKey: 'closed_won',
    amount: 5000,
    fields: { closeDate: '2026-09-01' },
    asAdmin: true,
  });
  assert.equal(result.toStageKey, 'closed_won');
  assert.equal(result.newProbability, 100);
});

test('missing required fields throws MissingRequiredFieldsError', () => {
  assert.throws(
    () =>
      moveStage({
        pipeline: STANDARD_PIPELINE,
        fromStageKey: 'needs_analysis',
        toStageKey: 'proposal',
        amount: 1000,
        fields: {},
      }),
    MissingRequiredFieldsError,
  );
});

test('moving out of a closed stage always throws, even as admin', () => {
  assert.throws(
    () =>
      moveStage({
        pipeline: STANDARD_PIPELINE,
        fromStageKey: 'closed_lost',
        toStageKey: 'qualification',
        amount: 1000,
        fields: {},
        asAdmin: true,
      }),
    InvalidStageTransitionError,
  );
});

test('unknown stage keys throw UnknownStageError', () => {
  assert.throws(
    () =>
      moveStage({
        pipeline: STANDARD_PIPELINE,
        fromStageKey: 'qualification',
        toStageKey: 'not_a_stage',
        amount: 1000,
        fields: {},
      }),
    UnknownStageError,
  );
});

test('probabilityOverride is respected and clamped to [0,100]', () => {
  const result = moveStage({
    pipeline: STANDARD_PIPELINE,
    fromStageKey: 'qualification',
    toStageKey: 'needs_analysis',
    amount: 100,
    fields: { primaryContactId: 'c1' },
    probabilityOverride: 150,
  });
  assert.equal(result.newProbability, 100);
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { scoreLead } from '../scoring.js';

test('a bare-minimum cold-outbound lead scores low and lands in "cold"', () => {
  const result = scoreLead({ source: 'cold_outbound', hasEmail: false, hasPhone: false });
  assert.ok(result.score < 40, `expected cold score, got ${result.score}`);
  assert.equal(result.band, 'cold');
});

test('a rich referral lead from an enterprise exec scores high and lands in "hot"', () => {
  const result = scoreLead({
    source: 'referral',
    hasEmail: true,
    hasPhone: true,
    companySizeBand: 'enterprise',
    jobTitleSeniority: 'executive',
    websiteVisits: 8,
    emailOpens: 6,
    formSubmissions: 2,
  });
  assert.ok(result.score >= 70, `expected hot score, got ${result.score}`);
  assert.equal(result.band, 'hot');
});

test('score is always clamped to [0,100]', () => {
  const result = scoreLead({
    source: 'referral',
    hasEmail: true,
    hasPhone: true,
    companySizeBand: 'enterprise',
    jobTitleSeniority: 'executive',
    websiteVisits: 999,
    emailOpens: 999,
    formSubmissions: 999,
  });
  assert.ok(result.score <= 100);
});

test('old, untouched leads decay in score', () => {
  const fresh = scoreLead({ source: 'website', hasEmail: true, hasPhone: false, daysSinceCreated: 1 });
  const stale = scoreLead({ source: 'website', hasEmail: true, hasPhone: false, daysSinceCreated: 60 });
  assert.ok(stale.score < fresh.score);
});

test('reasons array explains every contributing factor (auditability for future AI training)', () => {
  const result = scoreLead({ source: 'partner', hasEmail: true, hasPhone: true });
  assert.ok(result.reasons.some((r) => r.startsWith('source:partner')));
  assert.ok(result.reasons.some((r) => r.startsWith('has_email')));
});

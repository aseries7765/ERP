import { test } from 'node:test';
import assert from 'node:assert/strict';
import { STANDARD_PIPELINE, findStage, adminAllowedTransitions } from '../stages.js';
import { UnknownStageError } from '../types.js';

test('STANDARD_PIPELINE has exactly one won and one lost terminal stage', () => {
  const won = STANDARD_PIPELINE.stages.filter((s) => s.isWon);
  const lost = STANDARD_PIPELINE.stages.filter((s) => s.isClosed && !s.isWon);
  assert.equal(won.length, 1);
  assert.equal(lost.length, 1);
});

test('findStage returns the matching stage', () => {
  const s = findStage(STANDARD_PIPELINE, 'proposal');
  assert.equal(s.label, 'Proposal / Quote Sent');
});

test('findStage throws UnknownStageError for a bad key', () => {
  assert.throws(() => findStage(STANDARD_PIPELINE, 'nope'), UnknownStageError);
});

test('adminAllowedTransitions always includes closed_won and closed_lost for open stages', () => {
  const stage = findStage(STANDARD_PIPELINE, 'qualification');
  const allowed = adminAllowedTransitions(stage);
  assert.ok(allowed.includes('closed_won'));
  assert.ok(allowed.includes('closed_lost'));
});

test('adminAllowedTransitions returns empty array for already-closed stages', () => {
  const stage = findStage(STANDARD_PIPELINE, 'closed_won');
  assert.deepEqual(adminAllowedTransitions(stage), []);
});

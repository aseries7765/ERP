import { test } from 'node:test';
import assert from 'node:assert/strict';
import { calculateWinProbability, forecastWeightedPipeline } from '../probability.js';

test('calculateWinProbability multiplies amount by probability percent', () => {
  assert.equal(calculateWinProbability(1000, 25), 250);
  assert.equal(calculateWinProbability(999.99, 33), 330); // 329.9967 rounded to 2dp
});

test('calculateWinProbability clamps probability to [0,100]', () => {
  assert.equal(calculateWinProbability(1000, 150), 1000);
  assert.equal(calculateWinProbability(1000, -10), 0);
});

test('calculateWinProbability rejects negative amounts', () => {
  assert.throws(() => calculateWinProbability(-1, 50), RangeError);
});

test('forecastWeightedPipeline sums weighted values across opportunities', () => {
  const total = forecastWeightedPipeline([
    { amount: 1000, probability: 50 }, // 500
    { amount: 2000, probability: 25 }, // 500
    { amount: 500, probability: 100 }, // 500
  ]);
  assert.equal(total, 1500);
});

test('forecastWeightedPipeline returns 0 for an empty pipeline', () => {
  assert.equal(forecastWeightedPipeline([]), 0);
});

import type { PipelineDefinition, StageTransitionResult } from './types.js';
import { InvalidStageTransitionError, MissingRequiredFieldsError } from './types.js';
import { adminAllowedTransitions, findStage } from './stages.js';
import { calculateWinProbability } from './probability.js';

export interface MoveStageInput {
  pipeline: PipelineDefinition;
  fromStageKey: string;
  toStageKey: string;
  amount: number;
  /** Snapshot of the opportunity's current field values, used to validate requiredFields. */
  fields: Record<string, unknown>;
  /** True when a user with the admin override permission is performing the move. */
  asAdmin?: boolean;
  /** Optional manual probability override (0-100); otherwise stage default is used. */
  probabilityOverride?: number;
}

/**
 * Moves an opportunity from one pipeline stage to another.
 *
 * Pure function: it does not touch the database, emit events, or write
 * audit records — callers (OpportunityService) are responsible for that.
 * This keeps the rule ("no invalid transitions", G17) testable in
 * isolation and reusable outside of NestJS.
 *
 * @throws {UnknownStageError} if either stage key does not exist on the pipeline
 * @throws {InvalidStageTransitionError} if the transition is not allowed
 * @throws {MissingRequiredFieldsError} if the destination stage's required
 *   fields are not all present and non-null/undefined/empty-string on `fields`
 */
export function moveStage(input: MoveStageInput): StageTransitionResult {
  const { pipeline, fromStageKey, toStageKey, amount, fields, asAdmin, probabilityOverride } = input;

  const fromStage = findStage(pipeline, fromStageKey);
  const toStage = findStage(pipeline, toStageKey);

  if (fromStage.isClosed) {
    throw new InvalidStageTransitionError(fromStageKey, toStageKey);
  }

  const allowed = asAdmin ? adminAllowedTransitions(fromStage) : fromStage.allowedTransitions;
  if (!allowed.includes(toStageKey)) {
    throw new InvalidStageTransitionError(fromStageKey, toStageKey);
  }

  const missing = toStage.requiredFields.filter((f) => isEmpty(fields[f]));
  if (missing.length > 0) {
    throw new MissingRequiredFieldsError(toStageKey, missing);
  }

  const newProbability = clampProbability(probabilityOverride ?? toStage.defaultProbability);

  return {
    fromStageKey,
    toStageKey,
    newProbability,
    weightedValue: calculateWinProbability(amount, newProbability),
  };
}

function isEmpty(value: unknown): boolean {
  return value === undefined || value === null || value === '';
}

function clampProbability(p: number): number {
  if (Number.isNaN(p)) return 0;
  return Math.max(0, Math.min(100, p));
}

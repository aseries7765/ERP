import type { PipelineDefinition, StageDefinition } from './types.js';
import { UnknownStageError } from './types.js';

/**
 * Default "Standard" pipeline shipped for every new tenant. Additional
 * pipelines (Enterprise, SMB) are tenant-configurable via
 * PipelineService/seed-pipelines.ts and follow the same StageDefinition
 * shape; they are not hardcoded here.
 */
export const STANDARD_PIPELINE: PipelineDefinition = {
  key: 'standard',
  label: 'Standard Sales Pipeline',
  stages: [
    {
      key: 'qualification',
      label: 'Qualification',
      defaultProbability: 10,
      requiredFields: ['accountId', 'amount'],
      allowedTransitions: ['needs_analysis', 'closed_lost'],
      isClosed: false,
      isWon: false,
    },
    {
      key: 'needs_analysis',
      label: 'Needs Analysis',
      defaultProbability: 25,
      requiredFields: ['primaryContactId'],
      allowedTransitions: ['proposal', 'closed_lost'],
      isClosed: false,
      isWon: false,
    },
    {
      key: 'proposal',
      label: 'Proposal / Quote Sent',
      defaultProbability: 50,
      requiredFields: ['closeDate'],
      allowedTransitions: ['negotiation', 'closed_lost'],
      isClosed: false,
      isWon: false,
    },
    {
      key: 'negotiation',
      label: 'Negotiation',
      defaultProbability: 75,
      requiredFields: [],
      allowedTransitions: ['closed_won', 'closed_lost'],
      isClosed: false,
      isWon: false,
    },
    {
      key: 'closed_won',
      label: 'Closed Won',
      defaultProbability: 100,
      requiredFields: ['closeDate'],
      allowedTransitions: [],
      isClosed: true,
      isWon: true,
    },
    {
      key: 'closed_lost',
      label: 'Closed Lost',
      defaultProbability: 0,
      requiredFields: ['lossReason'],
      allowedTransitions: [],
      isClosed: true,
      isWon: false,
    },
  ],
};

/**
 * Admin override transition: any open stage may jump directly to
 * closed_won or closed_lost, per "no skipping unless admin". This is kept
 * separate from allowedTransitions (the normal rep-facing rule) so the
 * state machine can apply it only when an `asAdmin` flag is passed.
 */
export function adminAllowedTransitions(stage: StageDefinition): string[] {
  if (stage.isClosed) return [];
  return Array.from(new Set([...stage.allowedTransitions, 'closed_won', 'closed_lost']));
}

export function findStage(pipeline: PipelineDefinition, stageKey: string): StageDefinition {
  const stage = pipeline.stages.find((s) => s.key === stageKey);
  if (!stage) throw new UnknownStageError(stageKey, pipeline.key);
  return stage;
}

import type { LeadScoreResult, LeadScoringInput } from './types.js';

/**
 * Deterministic, explainable lead scoring algorithm.
 *
 * This is the "algorithm now" half of LeadScoringService (see M5 prompt,
 * AI Hooks section): M10 will add a real ML model behind the same
 * `scoreLead(lead) -> 0-100` interface. Every factor below is logged in
 * `reasons` so a future model can be trained/evaluated against these
 * heuristic scores as a baseline.
 */
export function scoreLead(input: LeadScoringInput): LeadScoreResult {
  let score = 0;
  const reasons: string[] = [];

  const sourceWeights: Record<string, number> = {
    referral: 25,
    website: 10,
    event: 15,
    paid_ad: 5,
    partner: 20,
    cold_outbound: 2,
  };
  const sourcePoints = sourceWeights[input.source] ?? 5;
  score += sourcePoints;
  reasons.push(`source:${input.source}(+${sourcePoints})`);

  if (input.hasEmail) {
    score += 5;
    reasons.push('has_email(+5)');
  }
  if (input.hasPhone) {
    score += 5;
    reasons.push('has_phone(+5)');
  }

  const sizeWeights: Record<string, number> = { unknown: 0, small: 5, mid: 12, enterprise: 20 };
  const sizePoints = sizeWeights[input.companySizeBand ?? 'unknown'];
  score += sizePoints;
  if (sizePoints > 0) reasons.push(`company_size:${input.companySizeBand}(+${sizePoints})`);

  const seniorityWeights: Record<string, number> = { unknown: 0, ic: 3, manager: 8, director: 15, executive: 20 };
  const seniorityPoints = seniorityWeights[input.jobTitleSeniority ?? 'unknown'];
  score += seniorityPoints;
  if (seniorityPoints > 0) reasons.push(`seniority:${input.jobTitleSeniority}(+${seniorityPoints})`);

  const visits = Math.min(input.websiteVisits ?? 0, 10);
  const visitPoints = visits * 1.5;
  if (visitPoints > 0) {
    score += visitPoints;
    reasons.push(`website_visits:${visits}(+${visitPoints})`);
  }

  const opens = Math.min(input.emailOpens ?? 0, 10);
  const openPoints = opens * 1;
  if (openPoints > 0) {
    score += openPoints;
    reasons.push(`email_opens:${opens}(+${openPoints})`);
  }

  const submissions = Math.min(input.formSubmissions ?? 0, 5);
  const submissionPoints = submissions * 4;
  if (submissionPoints > 0) {
    score += submissionPoints;
    reasons.push(`form_submissions:${submissions}(+${submissionPoints})`);
  }

  // Decay: leads that have sat untouched lose points, capped at -20.
  const age = input.daysSinceCreated ?? 0;
  if (age > 7) {
    const decay = Math.min(20, Math.floor((age - 7) / 3) * 2);
    score -= decay;
    reasons.push(`age_decay:${age}d(-${decay})`);
  }

  const clamped = Math.max(0, Math.min(100, Math.round(score)));
  const band = clamped >= 70 ? 'hot' : clamped >= 40 ? 'warm' : 'cold';

  return { score: clamped, band, reasons };
}

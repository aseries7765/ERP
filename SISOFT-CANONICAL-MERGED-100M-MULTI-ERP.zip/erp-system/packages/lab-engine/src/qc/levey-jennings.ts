import { QcPoint, QcContext } from './westgard-rules';

/** A single plotted point on a Levey-Jennings chart, with its signed distance from the mean in SD units. */
export interface LeveyJenningsPoint {
  timestamp: Date;
  value: number;
  sdIndex: number; // how many SDs from the mean, signed
}

/** Plot-ready data for rendering a Levey-Jennings QC chart. */
export interface LeveyJenningsChartData {
  mean: number;
  sd: number;
  bands: { sd: number; upper: number; lower: number }[]; // ±1, ±2, ±3 SD lines
  points: LeveyJenningsPoint[];
}

/** Builds the plot-ready data for a Levey-Jennings QC chart from raw control points. */
export function buildLeveyJenningsChart(points: QcPoint[], ctx: QcContext): LeveyJenningsChartData {
  const bands = [1, 2, 3].map((n) => ({
    sd: n,
    upper: ctx.mean + n * ctx.sd,
    lower: ctx.mean - n * ctx.sd,
  }));

  const plotted = points
    .slice()
    .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
    .map((p) => ({
      timestamp: p.timestamp,
      value: p.value,
      sdIndex: (p.value - ctx.mean) / ctx.sd,
    }));

  return { mean: ctx.mean, sd: ctx.sd, bands, points: plotted };
}

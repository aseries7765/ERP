/** A single QC control measurement. */
export interface QcPoint {
  value: number;
  timestamp: Date;
}

/** The established mean and standard deviation for a control material/analyte. */
export interface QcContext {
  mean: number;
  sd: number;
}

/** The Westgard multi-rule names this engine evaluates. */
export type WestgardViolation = '1-3s' | '2-2s' | 'R-4s' | '4-1s' | '10x';

/** Outcome of evaluating a QC run against the Westgard rule set. */
export interface WestgardResult {
  pass: boolean;
  violations: WestgardViolation[];
}

function zScore(point: QcPoint, ctx: QcContext): number {
  return (point.value - ctx.mean) / ctx.sd;
}

/**
 * Evaluates a run's QC points (typically two control levels' most recent
 * points, newest last) against the standard Westgard multi-rule QC
 * scheme. A single 1-3s violation is a hard failure (random error);
 * 2-2s, R-4s, 4-1s, and 10x are systematic-error warning/reject rules
 * evaluated across the recent run history supplied in `history`
 * (newest last, same order as `points`), per common practice of
 * requiring rejection on any documented rule violation (G21: QC failure
 * MUST block patient results unless overridden with reason).
 */
export function evaluateWestgardRules(
  points: QcPoint[],
  history: QcPoint[],
  ctx: QcContext,
): WestgardResult {
  const violations: WestgardViolation[] = [];
  const allPoints = [...history, ...points];
  const z = allPoints.map((p) => zScore(p, ctx));

  // 1-3s: any single point beyond 3 SD -> reject
  if (z.some((s) => Math.abs(s) > 3)) {
    violations.push('1-3s');
  }

  // 2-2s: two consecutive points beyond 2 SD in the same direction -> reject
  for (let i = 1; i < z.length; i++) {
    if (Math.abs(z[i]) > 2 && Math.abs(z[i - 1]) > 2 && Math.sign(z[i]) === Math.sign(z[i - 1])) {
      violations.push('2-2s');
      break;
    }
  }

  // R-4s: range between two consecutive points (opposite directions) exceeds 4 SD -> reject
  for (let i = 1; i < z.length; i++) {
    if (Math.abs(z[i] - z[i - 1]) > 4) {
      violations.push('R-4s');
      break;
    }
  }

  // 4-1s: four consecutive points beyond 1 SD in the same direction -> reject
  for (let i = 3; i < z.length; i++) {
    const window = z.slice(i - 3, i + 1);
    if (window.every((s) => s > 1) || window.every((s) => s < -1)) {
      violations.push('4-1s');
      break;
    }
  }

  // 10x: ten consecutive points on the same side of the mean -> reject
  for (let i = 9; i < z.length; i++) {
    const window = z.slice(i - 9, i + 1);
    if (window.every((s) => s > 0) || window.every((s) => s < 0)) {
      violations.push('10x');
      break;
    }
  }

  return { pass: violations.length === 0, violations: [...new Set(violations)] };
}

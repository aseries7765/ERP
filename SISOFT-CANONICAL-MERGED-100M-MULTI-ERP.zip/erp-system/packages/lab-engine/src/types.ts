/** A single LOINC-coded test in the lab's test catalog. */
export interface LoincTest {
  loincCode: string; // e.g. "2345-7"
  testName: string;
  units: string;
}

/** An age/sex-banded normal reference range for a test. */
export interface ReferenceRange {
  loincCode: string;
  sex: 'M' | 'F' | 'ANY';
  minAgeYears: number;
  maxAgeYears: number; // use Infinity for no upper bound
  low: number;
  high: number;
}

/** The critical (panic) value thresholds configured for a test. */
export interface CriticalValueRule {
  loincCode: string;
  low?: number; // value below this is critical
  high?: number; // value above this is critical
}

/** Result flag: Normal, High, Low, Critical-High, or Critical-Low. */
export type ResultFlag = 'N' | 'H' | 'L' | 'CH' | 'CL';

/** The inputs needed to process an incoming lab result. */
export interface LabResultInput {
  loincCode: string;
  value: number;
  patientAgeYears: number;
  patientSex: 'M' | 'F';
}

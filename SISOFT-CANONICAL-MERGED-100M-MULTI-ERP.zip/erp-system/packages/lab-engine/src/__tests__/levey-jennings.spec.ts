import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildLeveyJenningsChart } from '../qc/levey-jennings';

test('builds SD bands and plots points sorted by time', () => {
  const ctx = { mean: 100, sd: 5 };
  const points = [
    { value: 110, timestamp: new Date('2026-01-02T00:00:00Z') },
    { value: 95, timestamp: new Date('2026-01-01T00:00:00Z') },
  ];
  const chart = buildLeveyJenningsChart(points, ctx);

  assert.equal(chart.bands.length, 3);
  assert.equal(chart.bands[0].upper, 105);
  assert.equal(chart.bands[0].lower, 95);
  assert.equal(chart.bands[2].upper, 115);

  // sorted chronologically
  assert.equal(chart.points[0].value, 95);
  assert.equal(chart.points[1].value, 110);

  // sdIndex computed correctly
  assert.equal(chart.points[0].sdIndex, -1);
  assert.equal(chart.points[1].sdIndex, 2);
});

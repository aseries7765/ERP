import { test } from 'node:test';
import assert from 'node:assert/strict';
import { calculateFlag } from '../results/flag-calculator';
import { ReferenceRange, CriticalValueRule } from '../types';

const range: ReferenceRange = {
  loincCode: '2345-7',
  sex: 'ANY',
  minAgeYears: 0,
  maxAgeYears: Infinity,
  low: 70,
  high: 100,
};
const critical: CriticalValueRule = { loincCode: '2345-7', low: 40, high: 500 };

test('flags normal value as N', () => {
  assert.equal(calculateFlag(85, range), 'N');
});

test('flags above range as H', () => {
  assert.equal(calculateFlag(120, range), 'H');
});

test('flags below range as L', () => {
  assert.equal(calculateFlag(60, range), 'L');
});

test('flags above critical high as CH, not just H', () => {
  assert.equal(calculateFlag(600, range, critical), 'CH');
});

test('flags below critical low as CL, not just L', () => {
  assert.equal(calculateFlag(30, range, critical), 'CL');
});

test('a value between the H threshold and the critical threshold is only H', () => {
  assert.equal(calculateFlag(150, range, critical), 'H');
});

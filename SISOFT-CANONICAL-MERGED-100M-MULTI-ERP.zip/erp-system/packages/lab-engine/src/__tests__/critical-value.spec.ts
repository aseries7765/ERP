import { test } from 'node:test';
import assert from 'node:assert/strict';
import { checkCriticalValue, findCriticalRule } from '../results/critical-value';
import { CriticalValueRule } from '../types';

const rules: CriticalValueRule[] = [
  { loincCode: '2345-7', low: 40, high: 500 }, // glucose
  { loincCode: '2823-3', low: 2.5, high: 6.5 }, // potassium
];

test('detects a critical high value', () => {
  const rule = findCriticalRule(rules, '2345-7');
  const result = checkCriticalValue(600, rule);
  assert.equal(result.isCritical, true);
  assert.equal(result.direction, 'HIGH');
});

test('detects a critical low value', () => {
  const rule = findCriticalRule(rules, '2823-3');
  const result = checkCriticalValue(2.0, rule);
  assert.equal(result.isCritical, true);
  assert.equal(result.direction, 'LOW');
});

test('does not flag a value within critical bounds', () => {
  const rule = findCriticalRule(rules, '2345-7');
  const result = checkCriticalValue(90, rule);
  assert.equal(result.isCritical, false);
});

test('does not flag when no rule exists for the test', () => {
  const result = checkCriticalValue(99999, undefined);
  assert.equal(result.isCritical, false);
});

test('boundary values are not critical (strictly greater/less than)', () => {
  const rule = findCriticalRule(rules, '2345-7')!;
  assert.equal(checkCriticalValue(500, rule).isCritical, false);
  assert.equal(checkCriticalValue(40, rule).isCritical, false);
});

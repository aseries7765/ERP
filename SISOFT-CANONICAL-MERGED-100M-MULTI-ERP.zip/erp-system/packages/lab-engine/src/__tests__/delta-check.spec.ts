import { test } from 'node:test';
import assert from 'node:assert/strict';
import { checkDelta } from '../results/delta-check';

test('does not flag when there is no prior result', () => {
  const result = checkDelta(100, new Date(), undefined, { maxAbsoluteChange: 5 });
  assert.equal(result.flagged, false);
});

test('flags when absolute change exceeds max', () => {
  const prior = { value: 100, reportedAt: new Date('2026-01-01T00:00:00Z') };
  const result = checkDelta(150, new Date('2026-01-01T06:00:00Z'), prior, {
    maxAbsoluteChange: 20,
  });
  assert.equal(result.flagged, true);
  assert.equal(result.absoluteChange, 50);
});

test('flags when percent change exceeds max', () => {
  const prior = { value: 100, reportedAt: new Date('2026-01-01T00:00:00Z') };
  const result = checkDelta(140, new Date('2026-01-01T06:00:00Z'), prior, {
    maxPercentChange: 0.2,
  });
  assert.equal(result.flagged, true);
  assert.ok(result.percentChange && result.percentChange > 0.2);
});

test('does not flag a small change within thresholds', () => {
  const prior = { value: 100, reportedAt: new Date('2026-01-01T00:00:00Z') };
  const result = checkDelta(105, new Date('2026-01-01T06:00:00Z'), prior, {
    maxAbsoluteChange: 20,
    maxPercentChange: 0.2,
  });
  assert.equal(result.flagged, false);
});

test('ignores a prior result outside the withinHours window', () => {
  const prior = { value: 100, reportedAt: new Date('2026-01-01T00:00:00Z') };
  const result = checkDelta(200, new Date('2026-01-05T00:00:00Z'), prior, {
    maxAbsoluteChange: 10,
    withinHours: 24,
  });
  assert.equal(result.flagged, false);
});

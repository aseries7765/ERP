import { test } from 'node:test';
import assert from 'node:assert/strict';
import { findReferenceRange, NoReferenceRangeError } from '../results/reference-range';
import { ReferenceRange } from '../types';

const ranges: ReferenceRange[] = [
  { loincCode: '789-8', sex: 'ANY', minAgeYears: 0, maxAgeYears: 17, low: 4.5, high: 5.5 },
  { loincCode: '789-8', sex: 'M', minAgeYears: 18, maxAgeYears: Infinity, low: 4.7, high: 6.1 },
  { loincCode: '789-8', sex: 'F', minAgeYears: 18, maxAgeYears: Infinity, low: 4.2, high: 5.4 },
];

test('finds sex-specific range for an adult', () => {
  const r = findReferenceRange(ranges, '789-8', 30, 'F');
  assert.equal(r.low, 4.2);
  assert.equal(r.high, 5.4);
});

test('falls back to ANY range for a pediatric patient', () => {
  const r = findReferenceRange(ranges, '789-8', 10, 'M');
  assert.equal(r.sex, 'ANY');
});

test('throws when no range is configured', () => {
  assert.throws(() => findReferenceRange(ranges, '999-9', 30, 'M'), NoReferenceRangeError);
});

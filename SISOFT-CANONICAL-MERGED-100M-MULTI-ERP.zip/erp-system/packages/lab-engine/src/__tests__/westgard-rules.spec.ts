import { test } from 'node:test';
import assert from 'node:assert/strict';
import { evaluateWestgardRules, QcPoint, QcContext } from '../qc/westgard-rules';

const ctx: QcContext = { mean: 100, sd: 5 };

function pt(value: number, hoursAgo: number): QcPoint {
  return { value, timestamp: new Date(Date.now() - hoursAgo * 3600000) };
}

test('passes when all points are within 2 SD', () => {
  const points = [pt(101, 1)];
  const history = [pt(99, 2), pt(102, 3)];
  const result = evaluateWestgardRules(points, history, ctx);
  assert.equal(result.pass, true);
  assert.deepEqual(result.violations, []);
});

test('flags 1-3s when a single point exceeds 3 SD', () => {
  const points = [pt(116, 1)]; // (116-100)/5 = 3.2 SD
  const result = evaluateWestgardRules(points, [], ctx);
  assert.equal(result.pass, false);
  assert.ok(result.violations.includes('1-3s'));
});

test('flags 2-2s for two consecutive points beyond 2 SD same direction', () => {
  const history = [pt(111, 2)]; // 2.2 SD
  const points = [pt(112, 1)]; // 2.4 SD
  const result = evaluateWestgardRules(points, history, ctx);
  assert.ok(result.violations.includes('2-2s'));
});

test('flags R-4s for range exceeding 4 SD between consecutive opposite-direction points', () => {
  const history = [pt(111, 2)]; // +2.2 SD
  const points = [pt(89, 1)]; // -2.2 SD -> range 4.4 SD
  const result = evaluateWestgardRules(points, history, ctx);
  assert.ok(result.violations.includes('R-4s'));
});

test('flags 4-1s for four consecutive points beyond 1 SD same direction', () => {
  const history = [pt(106, 4), pt(107, 3), pt(108, 2)];
  const points = [pt(109, 1)];
  const result = evaluateWestgardRules(points, history, ctx);
  assert.ok(result.violations.includes('4-1s'));
});

test('flags 10x for ten consecutive points on the same side of the mean', () => {
  const history = Array.from({ length: 9 }, (_, i) => pt(101 + i * 0.1, 10 - i));
  const points = [pt(102, 1)];
  const result = evaluateWestgardRules(points, history, ctx);
  assert.ok(result.violations.includes('10x'));
});

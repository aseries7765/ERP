import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  isValidLoincFormat,
  computeLoincCheckDigit,
  isValidLoincCheckDigit,
  findTestByLoinc,
} from '../catalog/loinc-code';

test('validates LOINC-shaped codes', () => {
  assert.equal(isValidLoincFormat('2345-7'), true);
  assert.equal(isValidLoincFormat('12345-6'), true);
  assert.equal(isValidLoincFormat('abc-1'), false);
  assert.equal(isValidLoincFormat('2345'), false);
  assert.equal(isValidLoincFormat('2345-77'), false);
});

test('check digit round-trips: a code built from its own computed check digit validates', () => {
  const digitsPart = '2345';
  const check = computeLoincCheckDigit(digitsPart);
  const code = `${digitsPart}-${check}`;
  assert.equal(isValidLoincCheckDigit(code), true);
});

test('detects a corrupted check digit', () => {
  const digitsPart = '2345';
  const check = computeLoincCheckDigit(digitsPart);
  const badCode = `${digitsPart}-${(check + 1) % 10}`;
  assert.equal(isValidLoincCheckDigit(badCode), false);
});

test('findTestByLoinc finds an exact match', () => {
  const catalog = [{ loincCode: '2345-7', testName: 'Glucose', units: 'mg/dL' }];
  assert.equal(findTestByLoinc(catalog, '2345-7')?.testName, 'Glucose');
  assert.equal(findTestByLoinc(catalog, '9999-9'), undefined);
});

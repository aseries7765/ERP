import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  isValidLoincFormat,
  computeLoincCheckDigit,
  isValidLoincCheckDigit,
  findTestByLoinc,
} from '../catalog/loinc-code';

test('validates LOINC-shaped codes', () => {
  assert.equal(isValidLoincFormat('2345-7'), true);
  assert.equal(isValidLoincFormat('12345-6'), true);
  assert.equal(isValidLoincFormat('abc-1'), false);
  assert.equal(isValidLoincFormat('2345'), false);
  assert.equal(isValidLoincFormat('2345-77'), false);
});

test('check digit round-trips: a code built from its own computed check digit validates', () => {
  const digitsPart = '2345';
  const check = computeLoincCheckDigit(digitsPart);
  const code = `${digitsPart}-${check}`;
  assert.equal(isValidLoincCheckDigit(code), true);
});

test('computeLoincCheckDigit handles doubled digits that carry (doubled > 9)', () => {
  // reversed '9999' -> odd positions (index 1,3) double 9 to 18 -> 18-9=9
  const check = computeLoincCheckDigit('9999');
  assert.equal(typeof check, 'number');
  assert.ok(check >= 0 && check <= 9);
  // round-trips through isValidLoincCheckDigit too
  assert.equal(isValidLoincCheckDigit(`9999-${check}`), true);
});

test('isValidLoincCheckDigit returns false immediately for a malformed code, without computing a check digit', () => {
  assert.equal(isValidLoincCheckDigit('not-a-loinc-code'), false);
  assert.equal(isValidLoincCheckDigit('2345'), false); // missing check digit segment
});

test('detects a corrupted check digit', () => {
  const digitsPart = '2345';
  const check = computeLoincCheckDigit(digitsPart);
  const badCode = `${digitsPart}-${(check + 1) % 10}`;
  assert.equal(isValidLoincCheckDigit(badCode), false);
});

test('findTestByLoinc finds an exact match', () => {
  const catalog = [{ loincCode: '2345-7', testName: 'Glucose', units: 'mg/dL' }];
  assert.equal(findTestByLoinc(catalog, '2345-7')?.testName, 'Glucose');
  assert.equal(findTestByLoinc(catalog, '9999-9'), undefined);
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateBarcode, parseBarcode } from '../sample/barcode';

test('generates and parses a round-trip barcode', () => {
  const date = new Date('2026-01-17T00:00:00Z');
  const code = generateBarcode('bl', date, 42);
  assert.match(code, /^SPEC-BL-20260117-000042-\d$/);
  const parsed = parseBarcode(code);
  assert.deepEqual(parsed, { sampleType: 'BL', collectionDate: '20260117', sequence: 42 });
});

test('rejects a barcode with a corrupted check digit', () => {
  const date = new Date('2026-01-17T00:00:00Z');
  const code = generateBarcode('bl', date, 42);
  const corrupted = code.slice(0, -1) + ((Number(code.slice(-1)) + 1) % 10);
  assert.equal(parseBarcode(corrupted), null);
});

test('rejects a malformed barcode', () => {
  assert.equal(parseBarcode('NOT-A-BARCODE'), null);
});

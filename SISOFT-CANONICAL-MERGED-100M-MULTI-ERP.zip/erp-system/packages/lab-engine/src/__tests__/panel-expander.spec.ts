import { test } from 'node:test';
import assert from 'node:assert/strict';
import { expandPanel, expandOrderItems, UnknownPanelError, LabPanel } from '../catalog/panel-expander';

const panels: LabPanel[] = [
  { panelCode: 'CBC', panelName: 'Complete Blood Count', componentLoincCodes: ['789-8', '718-7', '4544-3'] },
  { panelCode: 'BMP', panelName: 'Basic Metabolic Panel', componentLoincCodes: ['2345-7', '2951-2'] },
];

test('expands a known panel into its component LOINC codes', () => {
  assert.deepEqual(expandPanel(panels, 'CBC'), ['789-8', '718-7', '4544-3']);
});

test('throws for an unknown panel code', () => {
  assert.throws(() => expandPanel(panels, 'NOPE'), UnknownPanelError);
});

test('expandOrderItems mixes panels and standalone tests, de-duplicated', () => {
  const isPanelCode = (c: string) => panels.some((p) => p.panelCode === c);
  const result = expandOrderItems(panels, ['CBC', '2345-7', 'BMP'], isPanelCode);
  // 2345-7 appears both standalone and inside BMP -> should appear once
  assert.equal(result.filter((c) => c === '2345-7').length, 1);
  assert.ok(result.includes('789-8'));
  assert.ok(result.includes('2951-2'));
});

/**
 * LOINC codes are of the form "NNNNN-C" where C is a mod-10 (Luhn-style)
 * check digit over the digits preceding the hyphen.
 *
 * NOTE: this implements a standard mod-10 checksum for internal format
 * validation (catching typos/transposition errors). It has NOT been
 * verified against Regenstrief's official check-digit spec byte-for-byte,
 * so do not treat isValidLoincCheckDigit() as authoritative proof a code
 * exists in the real LOINC database — only that it's well-formed. Real
 * LOINC codes must still be validated against a loaded LOINC table.
 */
const LOINC_FORMAT = /^\d{1,7}-\d$/;

/** Checks whether a string has the LOINC shape "digits-checkdigit" (format only, does not verify the check digit). */
export function isValidLoincFormat(code: string): boolean {
  return LOINC_FORMAT.test(code);
}

/**
 * Computes the LOINC check digit for the numeric portion of a code using
 * the mod-10 algorithm: starting from the rightmost digit, double every
 * second digit; if doubling produces a two-digit number, sum its digits;
 * sum all resulting digits; the check digit is (10 - (sum mod 10)) mod 10.
 */
export function computeLoincCheckDigit(digitsPart: string): number {
  const digits = digitsPart.split('').map(Number).reverse();
  let sum = 0;
  digits.forEach((d, i) => {
    if (i % 2 === 0) {
      sum += d;
    } else {
      const doubled = d * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    }
  });
  return (10 - (sum % 10)) % 10;
}

/** Checks whether a code's check digit matches its digits per computeLoincCheckDigit (see file-level conformance note). */
export function isValidLoincCheckDigit(code: string): boolean {
  if (!isValidLoincFormat(code)) return false;
  const [digitsPart, checkPart] = code.split('-');
  return computeLoincCheckDigit(digitsPart) === Number(checkPart);
}

import { LoincTest } from '../types';

/** Looks up a test in a loaded LOINC catalog by its exact code. */
export function findTestByLoinc(catalog: LoincTest[], loincCode: string): LoincTest | undefined {
  return catalog.find((t) => t.loincCode === loincCode);
}

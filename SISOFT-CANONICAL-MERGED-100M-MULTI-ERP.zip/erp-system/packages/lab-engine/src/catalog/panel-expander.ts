/** A lab panel/profile (e.g. CBC) and the LOINC-coded component tests it expands to. */
export interface LabPanel {
  panelCode: string;
  panelName: string;
  componentLoincCodes: string[];
}

/** Thrown when expanding a panel code that isn't in the provided panel catalog. */
export class UnknownPanelError extends Error {}

/** Expands a panel code (e.g. "CBC") into its individual LOINC-coded component tests. */
export function expandPanel(panels: LabPanel[], panelCode: string): string[] {
  const panel = panels.find((p) => p.panelCode === panelCode);
  if (!panel) {
    throw new UnknownPanelError(`Unknown panel code: ${panelCode}`);
  }
  return [...panel.componentLoincCodes];
}

/** Expands a mixed list of panel codes and/or standalone LOINC codes into a de-duplicated flat list of LOINC codes. */
export function expandOrderItems(
  panels: LabPanel[],
  items: string[],
  isPanelCode: (code: string) => boolean,
): string[] {
  const result = new Set<string>();
  for (const item of items) {
    if (isPanelCode(item)) {
      for (const loinc of expandPanel(panels, item)) {
        result.add(loinc);
      }
    } else {
      result.add(item);
    }
  }
  return [...result];
}

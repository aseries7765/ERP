/**
 * Sample barcodes use the format SPEC-<sampleType 2 letters>-<yyyymmdd>-<sequence 6 digits>-<check digit>.
 * e.g. SPEC-BL-20260117-000042-7
 * The check digit is a simple mod-10 sum of all preceding digits, used to
 * catch scan/transcription errors at the bench, not as a security control.
 */
export interface ParsedBarcode {
  sampleType: string;
  collectionDate: string; // yyyymmdd
  sequence: number;
}

function digitsOf(s: string): number[] {
  return s.replace(/\D/g, '').split('').map(Number);
}

function checkDigitFor(sampleType: string, dateStr: string, sequence: number): number {
  const seq = sequence.toString().padStart(6, '0');
  const digits = [...digitsOf(dateStr), ...digitsOf(seq)];
  const sum = digits.reduce((a, b) => a + b, 0);
  return sum % 10;
}

/** Generates a check-digit-protected specimen barcode string for a given sample type, collection date, and sequence number. */
export function generateBarcode(sampleType: string, collectionDate: Date, sequence: number): string {
  const dateStr = collectionDate.toISOString().slice(0, 10).replace(/-/g, '');
  const seq = sequence.toString().padStart(6, '0');
  const check = checkDigitFor(sampleType, dateStr, sequence);
  return `SPEC-${sampleType.toUpperCase()}-${dateStr}-${seq}-${check}`;
}

/** Parses and check-validates a specimen barcode, returning null if malformed or the check digit fails. */
export function parseBarcode(barcode: string): ParsedBarcode | null {
  const match = /^SPEC-([A-Z]{2})-(\d{8})-(\d{6})-(\d)$/.exec(barcode);
  if (!match) return null;
  const [, sampleType, dateStr, seqStr, checkStr] = match;
  const sequence = Number(seqStr);
  const expectedCheck = checkDigitFor(sampleType, dateStr, sequence);
  if (expectedCheck !== Number(checkStr)) return null;
  return { sampleType, collectionDate: dateStr, sequence };
}

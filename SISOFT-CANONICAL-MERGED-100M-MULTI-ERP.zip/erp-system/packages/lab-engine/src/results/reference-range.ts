import { ReferenceRange } from '../types';

/** Thrown when no reference range is configured for a test/age/sex combination. */
export class NoReferenceRangeError extends Error {}

/**
 * Finds the applicable reference range for a test given patient age and
 * sex. Sex-specific ranges (M/F) take priority over ANY ranges when both
 * match the age band.
 */
export function findReferenceRange(
  ranges: ReferenceRange[],
  loincCode: string,
  ageYears: number,
  sex: 'M' | 'F',
): ReferenceRange {
  const candidates = ranges.filter(
    (r) =>
      r.loincCode === loincCode &&
      ageYears >= r.minAgeYears &&
      ageYears <= r.maxAgeYears &&
      (r.sex === sex || r.sex === 'ANY'),
  );

  if (candidates.length === 0) {
    throw new NoReferenceRangeError(
      `No reference range configured for LOINC ${loincCode}, age ${ageYears}, sex ${sex}`,
    );
  }

  const sexSpecific = candidates.find((r) => r.sex === sex);
  return sexSpecific ?? candidates[0];
}

import { ReferenceRange, CriticalValueRule, ResultFlag } from '../types';

/**
 * Computes the result flag for a value given its reference range and an
 * optional critical-value rule. Critical flags (CH/CL) take priority over
 * plain H/L flags.
 */
export function calculateFlag(
  value: number,
  range: ReferenceRange,
  criticalRule?: CriticalValueRule,
): ResultFlag {
  if (criticalRule?.high !== undefined && value > criticalRule.high) return 'CH';
  if (criticalRule?.low !== undefined && value < criticalRule.low) return 'CL';
  if (value > range.high) return 'H';
  if (value < range.low) return 'L';
  return 'N';
}

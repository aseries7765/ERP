/** The most recent prior result for a test, used as the comparison baseline for a delta check. */
export interface PriorResult {
  value: number;
  reportedAt: Date;
}

/** Thresholds controlling when a result-to-result change is flagged. */
export interface DeltaCheckRule {
  /** Max allowed absolute change, if using absolute delta checking. */
  maxAbsoluteChange?: number;
  /** Max allowed percent change (0-1), if using percent delta checking. */
  maxPercentChange?: number;
  /** Only compare against a prior result within this many hours. */
  withinHours?: number;
}

/** Outcome of comparing a new result against the prior result under a delta-check rule. */
export interface DeltaCheckResult {
  flagged: boolean;
  absoluteChange?: number;
  percentChange?: number;
  reason?: string;
}

/**
 * Compares a new result to the most recent prior result for the same test
 * and flags it if the change exceeds the configured delta-check rule.
 * Returns not-flagged (rather than throwing) when there's no comparable
 * prior result, since a delta check simply doesn't apply in that case.
 */
export function checkDelta(
  currentValue: number,
  currentTime: Date,
  prior: PriorResult | undefined,
  rule: DeltaCheckRule,
): DeltaCheckResult {
  if (!prior) return { flagged: false };

  if (rule.withinHours !== undefined) {
    const hoursSince = (currentTime.getTime() - prior.reportedAt.getTime()) / (1000 * 60 * 60);
    if (hoursSince > rule.withinHours) {
      return { flagged: false }; // prior result too old to be comparable
    }
  }

  const absoluteChange = currentValue - prior.value;
  const percentChange = prior.value !== 0 ? Math.abs(absoluteChange) / Math.abs(prior.value) : 0;

  if (rule.maxAbsoluteChange !== undefined && Math.abs(absoluteChange) > rule.maxAbsoluteChange) {
    return {
      flagged: true,
      absoluteChange,
      percentChange,
      reason: `Absolute change ${absoluteChange} exceeds max allowed ${rule.maxAbsoluteChange}`,
    };
  }

  if (rule.maxPercentChange !== undefined && percentChange > rule.maxPercentChange) {
    return {
      flagged: true,
      absoluteChange,
      percentChange,
      reason: `Percent change ${(percentChange * 100).toFixed(1)}% exceeds max allowed ${(
        rule.maxPercentChange * 100
      ).toFixed(1)}%`,
    };
  }

  return { flagged: false, absoluteChange, percentChange };
}

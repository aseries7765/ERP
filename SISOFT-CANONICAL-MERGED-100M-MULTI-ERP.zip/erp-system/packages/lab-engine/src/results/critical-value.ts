import { CriticalValueRule } from '../types';

/** Outcome of checking a result value against its critical (panic) value rule. */
export interface CriticalCheckResult {
  isCritical: boolean;
  direction?: 'HIGH' | 'LOW';
  message?: string;
}

/**
 * Checks a result value against the critical (panic) value rule for its
 * test. This is the gate behind G16 ("critical values MUST alert within
 * 5 min") — callers must trigger the alert workflow whenever isCritical
 * is true; this function only performs the detection.
 */
export function checkCriticalValue(
  value: number,
  rule: CriticalValueRule | undefined,
): CriticalCheckResult {
  if (!rule) return { isCritical: false };

  if (rule.high !== undefined && value > rule.high) {
    return {
      isCritical: true,
      direction: 'HIGH',
      message: `Value ${value} exceeds critical high threshold of ${rule.high} for ${rule.loincCode}`,
    };
  }
  if (rule.low !== undefined && value < rule.low) {
    return {
      isCritical: true,
      direction: 'LOW',
      message: `Value ${value} is below critical low threshold of ${rule.low} for ${rule.loincCode}`,
    };
  }
  return { isCritical: false };
}

/** Looks up the critical-value rule for a test by its LOINC code. */
export function findCriticalRule(
  rules: CriticalValueRule[],
  loincCode: string,
): CriticalValueRule | undefined {
  return rules.find((r) => r.loincCode === loincCode);
}

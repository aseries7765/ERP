# @erp/lab-engine

Pure, framework-free domain logic for laboratory operations: LOINC code
format/check-digit validation, panel expansion, specimen barcode
generation/parsing, reference-range lookup by age/sex, result flagging
(H/L/CH/CL/N), critical (panic) value detection, delta checking, and
Westgard multi-rule QC evaluation with Levey-Jennings chart data
preparation.

No I/O, no database, no NestJS dependency — called from the (not-yet-built)
`his-laboratory` module's services.

## What's implemented

- `catalog/loinc-code.ts` — LOINC format validation and a mod-10 check-digit
  helper. **Important honesty note:** this checksum is a standard mod-10
  scheme for catching typos, not a verified byte-for-byte implementation of
  Regenstrief's official LOINC check-digit spec — do not treat a passing
  check as proof a code exists in the real LOINC database. Real test
  existence must be validated against a loaded LOINC table (not included —
  see MANIFEST).
- `catalog/panel-expander.ts` — expands panel codes (e.g. "CBC") into their
  LOINC-coded components, de-duplicated when a test appears both standalone
  and inside a panel.
- `sample/barcode.ts` — specimen barcode generation/parsing with a mod-10
  check digit, catching scan/transcription errors at the bench.
- `results/reference-range.ts` — age/sex-banded reference range lookup,
  preferring sex-specific ranges over sex-neutral ones.
- `results/flag-calculator.ts` — H/L/CH/CL/N flagging; critical flags take
  priority over plain high/low.
- `results/critical-value.ts` — panic-value detection (the gate behind
  G16: critical values must trigger the alert workflow).
- `results/delta-check.ts` — compares a new result against the most recent
  prior result within a configurable time window.
- `qc/westgard-rules.ts` — 1-3s, 2-2s, R-4s, 4-1s, and 10x rule evaluation
  over a QC point history.
- `qc/levey-jennings.ts` — builds ±1/2/3 SD band + point data for charting.

## What's NOT implemented here (see root MANIFEST.md)

- Analyzer integration (explicitly a stub per the HIS-2 brief, deferred to
  HIS-3).
- Microbiology culture/sensitivity workflow, histopathology.
- Reflex-test rule engine (auto-adding follow-up tests based on a result).
- Persistence, HTTP controllers, NestJS module, Prisma schema, events,
  seed data (LOINC catalog, reference ranges, critical values), frontend,
  PDF report generation.

## Usage

```ts
import { calculateFlag, checkCriticalValue, evaluateWestgardRules } from '@erp/lab-engine';

const flag = calculateFlag(value, referenceRange, criticalRule);
const critical = checkCriticalValue(value, criticalRule);
const qc = evaluateWestgardRules(newPoints, recentHistory, { mean, sd });
```

## Test

```
pnpm --filter @erp/lab-engine test
```

Runs `tsx --test src/__tests__/*.spec.ts` — 38 unit tests, no DB required.

Measured coverage (`npx tsx --test --experimental-test-coverage src/__tests__/*.spec.ts`): 99.46% line / 89.74% branch / 94.74% function.

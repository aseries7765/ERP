import { BarcodeError } from '../types';

/**
 * GS1 / GTIN check-digit algorithm (mod-10, alternating 3-1 weights from the
 * rightmost digit). Works for GTIN-8/12/13/14 and SSCC-18 (same algorithm,
 * different lengths). This is the standard GS1 general-spec formula.
 */
export function computeCheckDigit(digitsWithoutCheck: string): string {
  if (!/^\d+$/.test(digitsWithoutCheck)) {
    throw new BarcodeError(`computeCheckDigit expects digits only, got "${digitsWithoutCheck}"`);
  }
  const digits = digitsWithoutCheck.split('').map(Number);
  // Weight the rightmost digit by 3, alternating, per GS1 general specification.
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    const fromRight = digits.length - 1 - i;
    const weight = fromRight % 2 === 0 ? 3 : 1;
    sum += digits[i] * weight;
  }
  const checkDigit = (10 - (sum % 10)) % 10;
  return String(checkDigit);
}

export function validateCheckDigit(fullDigits: string): boolean {
  if (!/^\d+$/.test(fullDigits) || fullDigits.length < 2) return false;
  const body = fullDigits.slice(0, -1);
  const providedCheck = fullDigits.slice(-1);
  return computeCheckDigit(body) === providedCheck;
}

/** Normalizes a GS1 date (YYMMDD) to ISO 8601 (YYYY-MM-DD).
 * GS1 pivot rule: YY 00-50 => 20YY, 51-99 => 19YY (per GS1 general spec). */
export function gs1DateToIso(yymmdd: string): string {
  if (!/^\d{6}$/.test(yymmdd)) {
    throw new BarcodeError(`Expected 6-digit YYMMDD date, got "${yymmdd}"`);
  }
  const yy = parseInt(yymmdd.slice(0, 2), 10);
  const mm = yymmdd.slice(2, 4);
  const dd = yymmdd.slice(4, 6);
  const century = yy <= 50 ? 2000 : 1900;
  const year = century + yy;
  return `${year}-${mm}-${dd}`;
}

export function isoDateToGs1(iso: string): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!match) throw new BarcodeError(`Expected ISO date YYYY-MM-DD, got "${iso}"`);
  const [, year, mm, dd] = match;
  const yy = year.slice(2);
  return `${yy}${mm}${dd}`;
}

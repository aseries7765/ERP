/**
 * GS1 Application Identifier (AI) definitions relevant to M7 (inventory receiving,
 * pharma/food track-trace). Not the full GS1 general specification table — scoped
 * to what StockMovement / GRN / Batch / Serial actually consume. Extend as needed;
 * each entry is additive and covered by gs1-parser.spec.ts round-trip tests.
 *
 * `length`: fixed length of the value in digits/chars, or null if variable-length
 * (variable-length AIs are terminated by the GS1 FNC1 separator, represented here
 * as ASCII 0x1D — the group separator — when present in the raw scan).
 */
export interface Gs1AiDefinition {
  ai: string;
  label: string;
  length: number | null;
  /** 'numeric' | 'alphanumeric' — used for basic validation, not full GS1 charset rules. */
  format: 'numeric' | 'alphanumeric';
  /** true if this AI's value is a GS1-format date (YYMMDD) that should be normalized to ISO. */
  isDate?: boolean;
}

export const GS1_AI_TABLE: Gs1AiDefinition[] = [
  { ai: '00', label: 'SSCC', length: 18, format: 'numeric' },
  { ai: '01', label: 'GTIN', length: 14, format: 'numeric' },
  { ai: '10', label: 'Batch/Lot', length: null, format: 'alphanumeric' },
  { ai: '11', label: 'Production Date', length: 6, format: 'numeric', isDate: true },
  { ai: '17', label: 'Expiry Date', length: 6, format: 'numeric', isDate: true },
  { ai: '21', label: 'Serial Number', length: null, format: 'alphanumeric' },
  { ai: '30', label: 'Variable Count / Quantity', length: null, format: 'numeric' },
  { ai: '37', label: 'Count of Items', length: null, format: 'numeric' },
  { ai: '310', label: 'Net Weight (kg)', length: 6, format: 'numeric' }, // AI 3102/3103 etc. use decimal-point indicator digit; simplified here
  { ai: '400', label: 'Purchase Order Number', length: null, format: 'alphanumeric' },
  { ai: '410', label: 'Ship To GLN', length: 13, format: 'numeric' },
];

export function findAiDefinition(ai: string): Gs1AiDefinition | undefined {
  return GS1_AI_TABLE.find((d) => d.ai === ai);
}

/** AIs whose length is fixed (no FNC1 terminator needed after the value). */
export function isFixedLength(ai: string): boolean {
  const def = findAiDefinition(ai);
  return !!def && def.length !== null;
}

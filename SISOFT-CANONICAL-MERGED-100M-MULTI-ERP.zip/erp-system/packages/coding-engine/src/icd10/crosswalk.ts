/**
 * ICD-9-CM <-> ICD-10-CM crosswalk.
 *
 * SCOPE HONESTY: the real CMS "General Equivalence Mappings" (GEM) file
 * contains tens of thousands of entries, many of them one-to-many
 * (a single ICD-9 code can map to several ICD-10 codes depending on
 * clinical specifics the GEM can't resolve automatically — these are
 * flagged in the real GEM with "combination" and "scenario" flags).
 * This module implements a small, real sample of unambiguous
 * one-to-one mappings to demonstrate correct bidirectional lookup
 * behavior; it is NOT the full GEM dataset. `loadFullGem()` documents
 * where the real file would be loaded.
 */

export class CrosswalkError extends Error {}

export interface CrosswalkEntry {
  icd9: string;
  icd10: string;
  /** True if this is an approximate/one-to-many mapping simplified to one target for this sample; a real GEM consumer must handle multiple targets. */
  approximate: boolean;
}

const SAMPLE_CROSSWALK: CrosswalkEntry[] = [
  { icd9: '250.00', icd10: 'E11.9', approximate: false }, // DM2 without complication
  { icd9: '493.90', icd10: 'J45.909', approximate: false }, // unspecified asthma
  { icd9: '813.42', icd10: 'S52.509A', approximate: true }, // closed fracture radius, side unspecified in ICD-9 source
  { icd9: 'V70.0', icd10: 'Z00.00', approximate: false }, // routine general medical exam
];

export function loadSampleCrosswalk(): CrosswalkEntry[] {
  return SAMPLE_CROSSWALK.map((e) => ({ ...e }));
}

export function loadFullGem(): never {
  throw new Error(
    'loadFullGem() is not implemented in this environment (no network access to the CMS GEM dataset). Use loadSampleCrosswalk() or supply your own CrosswalkEntry[] loaded from a real GEM export.',
  );
}

/** ICD-9 -> ICD-10 lookup. Returns all matching entries (a real GEM lookup can be one-to-many). */
export function crosswalkIcd9ToIcd10(icd9Code: string, crosswalk: CrosswalkEntry[]): CrosswalkEntry[] {
  const normalized = icd9Code.trim();
  const matches = crosswalk.filter((e) => e.icd9 === normalized);
  if (matches.length === 0) {
    throw new CrosswalkError(`No ICD-10 mapping found for ICD-9 code "${normalized}" in this crosswalk.`);
  }
  return matches;
}

/** ICD-10 -> ICD-9 lookup (the reverse direction — bidirectional per spec G29). */
export function crosswalkIcd10ToIcd9(icd10Code: string, crosswalk: CrosswalkEntry[]): CrosswalkEntry[] {
  const normalized = icd10Code.trim().toUpperCase();
  const matches = crosswalk.filter((e) => e.icd10 === normalized);
  if (matches.length === 0) {
    throw new CrosswalkError(`No ICD-9 mapping found for ICD-10 code "${normalized}" in this crosswalk.`);
  }
  return matches;
}

import { Icd10Code } from './catalog';

export class Icd10ValidationError extends Error {}

export interface Icd10ValidationResult {
  valid: boolean;
  billable: boolean;
  errors: string[];
  code: Icd10Code;
}

/**
 * Validates an ICD-10-CM code against the catalog: confirms it exists,
 * and checks laterality and 7th-character requirements are satisfied
 * by the code's own literal characters (since in this representation
 * the laterality digit and 7th character are already part of the code
 * string, e.g. "S52.501A" — validation here is about confirming a
 * code that's missing a required 7th character isn't submitted as
 * final/billable, and that a laterality-bearing code has a valid
 * laterality digit).
 *
 * This does not re-derive the code from separate laterality/encounter
 * inputs (a more elaborate builder could do that); it validates a
 * fully-formed code string as submitted, which matches how coders
 * actually pick codes: they look up and select `S52.501A`, not
 * `S52 + right + initial`.
 */
export function validateIcd10Code(codeString: string, catalog: Icd10Code[]): Icd10ValidationResult {
  const normalized = codeString.trim().toUpperCase();
  const errors: string[] = [];

  const entry = catalog.find((c) => c.code === normalized);
  if (!entry) {
    return {
      valid: false,
      billable: false,
      errors: [`Unknown ICD-10-CM code: "${normalized}" (not in catalog).`],
      code: { code: normalized, description: '', billable: false, chapter: '', category: '' },
    };
  }

  if (!entry.billable) {
    errors.push(
      `Code "${entry.code}" is a category/non-billable code and requires further specification (additional characters) before it can be used for billing.`,
    );
  }

  if (entry.laterality) {
    const afterDecimal = normalized.split('.')[1] ?? '';
    const lateralityChar = afterDecimal.charAt(entry.laterality.position - 1);
    if (!lateralityChar || !(lateralityChar in entry.laterality.values)) {
      errors.push(
        `Code "${entry.code}" requires a valid laterality character at position ${entry.laterality.position} after the decimal; got "${lateralityChar || '(none)'}".`,
      );
    }
  }

  if (entry.seventhCharacter) {
    const seventh = normalized.charAt(normalized.length - 1);
    if (!(seventh in entry.seventhCharacter.values)) {
      errors.push(
        `Code "${entry.code}" requires a valid 7th character (one of: ${Object.keys(entry.seventhCharacter.values).join(', ')}); got "${seventh}".`,
      );
    }
  }

  return {
    valid: errors.length === 0,
    billable: entry.billable && errors.length === 0,
    errors,
    code: entry,
  };
}

/**
 * Looks up the human-readable meaning of a code's laterality and/or
 * 7th character, for display in a coder's UI (e.g. "right side,
 * initial encounter"). Returns undefined pieces where not applicable.
 */
export function describeCodeQualifiers(entry: Icd10Code): { laterality?: string; encounterType?: string } {
  const result: { laterality?: string; encounterType?: string } = {};

  if (entry.laterality) {
    const afterDecimal = entry.code.split('.')[1] ?? '';
    const lateralityChar = afterDecimal.charAt(entry.laterality.position - 1);
    result.laterality = entry.laterality.values[lateralityChar];
  }
  if (entry.seventhCharacter) {
    const seventh = entry.code.charAt(entry.code.length - 1);
    result.encounterType = entry.seventhCharacter.values[seventh];
  }
  return result;
}

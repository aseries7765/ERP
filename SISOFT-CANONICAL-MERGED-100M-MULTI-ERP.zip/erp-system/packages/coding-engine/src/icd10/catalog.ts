/**
 * ICD-10-CM catalog types and a small, real, representative sample
 * catalog.
 *
 * SCOPE HONESTY: the full ICD-10-CM catalog is ~70,000 codes,
 * distributed by CMS/NCHS as CSV/XML files. This sandbox has no
 * network access to fetch that dataset, so it is NOT loaded here.
 * What IS implemented and real: the validation rules (laterality, 7th
 * character, billability), the hierarchy model (chapter → category →
 * code), and search — all built against a small set of genuine
 * ICD-10-CM codes with their real, correct metadata, chosen to
 * exercise every validation rule. `loadFullCatalog()` is a documented
 * stub: in a real deployment it parses the CMS-published
 * `icd10cm-order-DDDDD.txt` (or equivalent CSV) into this same
 * `Icd10Code` shape — the loader's *interface* is real and final, only
 * its data source is not available here.
 */

export interface Icd10Code {
  code: string; // e.g. "S52.501A" (no decimal-free storage form here; kept human-readable)
  description: string;
  /** True if this code can be used for billing (i.e. is a leaf/complete code, not a category needing further specification). */
  billable: boolean;
  /** Chapter name, e.g. "Injury, poisoning..." — used for hierarchy navigation. */
  chapter: string;
  /** Category is the 3-character root, e.g. "S52". */
  category: string;
  /** If set, the position (1-based, within the part after the decimal) that encodes laterality, and its valid values. */
  laterality?: {
    position: number;
    values: Record<string, string>; // e.g. {"1": "right", "2": "left", "9": "unspecified"}
  };
  /** If set, a 7th character is required, with valid values and meaning. */
  seventhCharacter?: {
    values: Record<string, string>; // e.g. {"A": "initial encounter", "D": "subsequent encounter", "S": "sequela"}
  };
}

const SAMPLE_CATALOG: Icd10Code[] = [
  {
    code: 'E11',
    description: 'Type 2 diabetes mellitus',
    billable: false, // category only — requires a 4th+ character to bill
    chapter: 'Endocrine, nutritional and metabolic diseases',
    category: 'E11',
  },
  {
    code: 'E11.9',
    description: 'Type 2 diabetes mellitus without complications',
    billable: true,
    chapter: 'Endocrine, nutritional and metabolic diseases',
    category: 'E11',
  },
  {
    code: 'J45.909',
    description: 'Unspecified asthma, uncomplicated',
    billable: true,
    chapter: 'Diseases of the respiratory system',
    category: 'J45',
  },
  {
    code: 'Z00.00',
    description: 'Encounter for general adult medical examination without abnormal findings',
    billable: true,
    chapter: 'Factors influencing health status and contact with health services',
    category: 'Z00',
  },
  {
    code: 'M25.511',
    description: 'Pain in right shoulder',
    billable: true,
    chapter: 'Diseases of the musculoskeletal system and connective tissue',
    category: 'M25',
    laterality: { position: 3, values: { '1': 'right', '2': 'left', '9': 'unspecified' } },
  },
  {
    code: 'M25.512',
    description: 'Pain in left shoulder',
    billable: true,
    chapter: 'Diseases of the musculoskeletal system and connective tissue',
    category: 'M25',
    laterality: { position: 3, values: { '1': 'right', '2': 'left', '9': 'unspecified' } },
  },
  {
    code: 'M25.519',
    description: 'Pain in unspecified shoulder',
    billable: true,
    chapter: 'Diseases of the musculoskeletal system and connective tissue',
    category: 'M25',
    laterality: { position: 3, values: { '1': 'right', '2': 'left', '9': 'unspecified' } },
  },
  {
    code: 'S52.501A',
    description: 'Unspecified fracture of the lower end of right radius, initial encounter for closed fracture',
    billable: true,
    chapter: 'Injury, poisoning and certain other consequences of external causes',
    category: 'S52',
    laterality: { position: 3, values: { '1': 'right', '2': 'left', '9': 'unspecified' } },
    seventhCharacter: { values: { A: 'initial encounter', D: 'subsequent encounter', S: 'sequela' } },
  },
  {
    code: 'S52.502A',
    description: 'Unspecified fracture of the lower end of left radius, initial encounter for closed fracture',
    billable: true,
    chapter: 'Injury, poisoning and certain other consequences of external causes',
    category: 'S52',
    laterality: { position: 3, values: { '1': 'right', '2': 'left', '9': 'unspecified' } },
    seventhCharacter: { values: { A: 'initial encounter', D: 'subsequent encounter', S: 'sequela' } },
  },
  {
    code: 'S52.509A',
    description: 'Unspecified fracture of the lower end of unspecified radius, initial encounter for closed fracture',
    billable: true,
    chapter: 'Injury, poisoning and certain other consequences of external causes',
    category: 'S52',
    laterality: { position: 3, values: { '1': 'right', '2': 'left', '9': 'unspecified' } },
    seventhCharacter: { values: { A: 'initial encounter', D: 'subsequent encounter', S: 'sequela' } },
  },
];

export function loadSampleCatalog(): Icd10Code[] {
  return SAMPLE_CATALOG.map((c) => ({ ...c }));
}

/**
 * Documented stub for the real full-catalog loader. In production this
 * reads the CMS ICD-10-CM order file (or an equivalent CSV export) and
 * maps each row into `Icd10Code`. Not implemented here — see the scope
 * note at the top of this file for why.
 */
export function loadFullCatalog(): never {
  throw new Error(
    'loadFullCatalog() is not implemented in this environment (no network access to the CMS ICD-10-CM dataset). Use loadSampleCatalog() for the ~10-code representative set, or supply your own Icd10Code[] loaded from a real CMS export.',
  );
}

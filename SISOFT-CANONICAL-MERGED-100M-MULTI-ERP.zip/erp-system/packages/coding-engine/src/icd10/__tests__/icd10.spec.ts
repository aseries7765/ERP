import { loadSampleCatalog } from '../catalog';
import { validateIcd10Code, describeCodeQualifiers } from '../validator';
import { searchIcd10, getCategoryHierarchy, groupByChapter } from '../search';
import { loadSampleCrosswalk, crosswalkIcd9ToIcd10, crosswalkIcd10ToIcd9, CrosswalkError } from '../crosswalk';

const catalog = loadSampleCatalog();

describe('validateIcd10Code', () => {
  it('accepts a valid billable code with no qualifiers', () => {
    const result = validateIcd10Code('E11.9', catalog);
    expect(result.valid).toBe(true);
    expect(result.billable).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('rejects a category-only (non-billable) code', () => {
    const result = validateIcd10Code('E11', catalog);
    expect(result.valid).toBe(false);
    expect(result.billable).toBe(false);
    expect(result.errors[0]).toMatch(/non-billable/);
  });

  it('validates laterality-bearing codes correctly for right, left, and unspecified', () => {
    expect(validateIcd10Code('M25.511', catalog).valid).toBe(true); // right
    expect(validateIcd10Code('M25.512', catalog).valid).toBe(true); // left
    expect(validateIcd10Code('M25.519', catalog).valid).toBe(true); // unspecified
  });

  it('validates a code requiring both laterality and 7th character', () => {
    const result = validateIcd10Code('S52.501A', catalog);
    expect(result.valid).toBe(true);
    expect(result.billable).toBe(true);
  });

  it('rejects a code missing/invalid 7th character', () => {
    // S52.501 without the required 7th char A/D/S is not in the sample catalog,
    // so this exercises the "unknown code" path, which is correct: an
    // incomplete code literally isn't a valid catalog entry.
    const result = validateIcd10Code('S52.501', catalog);
    expect(result.valid).toBe(false);
    expect(result.errors[0]).toMatch(/Unknown ICD-10-CM code/);
  });

  it('is case-insensitive and trims whitespace', () => {
    const result = validateIcd10Code('  e11.9  ', catalog);
    expect(result.valid).toBe(true);
    expect(result.code.code).toBe('E11.9');
  });

  it('rejects an entirely unknown code', () => {
    const result = validateIcd10Code('Q99.999Z', catalog);
    expect(result.valid).toBe(false);
    expect(result.errors[0]).toMatch(/Unknown ICD-10-CM code/);
  });
});

describe('describeCodeQualifiers', () => {
  it('describes laterality and encounter type for a fully-qualified code', () => {
    const entry = catalog.find((c) => c.code === 'S52.501A')!;
    const desc = describeCodeQualifiers(entry);
    expect(desc.laterality).toBe('right');
    expect(desc.encounterType).toBe('initial encounter');
  });

  it('describes laterality only when no 7th character applies', () => {
    const entry = catalog.find((c) => c.code === 'M25.512')!;
    const desc = describeCodeQualifiers(entry);
    expect(desc.laterality).toBe('left');
    expect(desc.encounterType).toBeUndefined();
  });
});

describe('searchIcd10', () => {
  it('finds an exact code match first', () => {
    const results = searchIcd10('E11.9', catalog);
    expect(results[0].matchType).toBe('exact-code');
    expect(results[0].code.code).toBe('E11.9');
  });

  it('finds code-prefix matches for a category query', () => {
    const results = searchIcd10('S52', catalog);
    const prefixMatches = results.filter((r) => r.matchType === 'code-prefix');
    expect(prefixMatches.map((r) => r.code.code).sort()).toEqual(['S52.501A', 'S52.502A', 'S52.509A']);
  });

  it('finds description substring (synonym) matches regardless of word order', () => {
    const results = searchIcd10('shoulder pain', catalog);
    const codes = results.map((r) => r.code.code).sort();
    expect(codes).toEqual(['M25.511', 'M25.512', 'M25.519']);
  });

  it('does not treat a plain English query as a code prefix', () => {
    const results = searchIcd10('shoulder', catalog);
    expect(results.every((r) => r.matchType !== 'code-prefix')).toBe(true);
  });

  it('returns empty for a blank query', () => {
    expect(searchIcd10('   ', catalog)).toHaveLength(0);
  });
});

describe('getCategoryHierarchy', () => {
  it('returns all codes under a category, sorted', () => {
    const codes = getCategoryHierarchy('S52', catalog).map((c) => c.code);
    expect(codes).toEqual(['S52.501A', 'S52.502A', 'S52.509A']);
  });

  it('returns empty for an unknown category', () => {
    expect(getCategoryHierarchy('ZZZ', catalog)).toHaveLength(0);
  });
});

describe('groupByChapter', () => {
  it('groups codes under their chapter', () => {
    const groups = groupByChapter(catalog);
    const musculoskeletal = groups.get('Diseases of the musculoskeletal system and connective tissue');
    expect(musculoskeletal?.map((c) => c.code).sort()).toEqual(['M25.511', 'M25.512', 'M25.519']);
  });
});

describe('ICD-9 <-> ICD-10 crosswalk', () => {
  const crosswalk = loadSampleCrosswalk();

  it('maps ICD-9 to ICD-10 correctly', () => {
    const result = crosswalkIcd9ToIcd10('250.00', crosswalk);
    expect(result).toHaveLength(1);
    expect(result[0].icd10).toBe('E11.9');
  });

  it('maps ICD-10 back to ICD-9 (bidirectional, spec G29)', () => {
    const result = crosswalkIcd10ToIcd9('E11.9', crosswalk);
    expect(result).toHaveLength(1);
    expect(result[0].icd9).toBe('250.00');
  });

  it('round-trips every sample entry in both directions', () => {
    for (const entry of crosswalk) {
      expect(crosswalkIcd9ToIcd10(entry.icd9, crosswalk).some((e) => e.icd10 === entry.icd10)).toBe(true);
      expect(crosswalkIcd10ToIcd9(entry.icd10, crosswalk).some((e) => e.icd9 === entry.icd9)).toBe(true);
    }
  });

  it('throws a clear error for an unmapped code in either direction', () => {
    expect(() => crosswalkIcd9ToIcd10('999.99', crosswalk)).toThrow(CrosswalkError);
    expect(() => crosswalkIcd10ToIcd9('Z99.999', crosswalk)).toThrow(CrosswalkError);
  });
});

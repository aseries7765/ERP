import { Icd10Code } from './catalog';

export interface Icd10SearchResult {
  code: Icd10Code;
  matchType: 'exact-code' | 'code-prefix' | 'description-substring';
}

/**
 * Searches the catalog by exact code, code prefix (hierarchy
 * navigation — e.g. "S52" returns everything under that category), or
 * case-insensitive substring match against the description (synonym-
 * style search, e.g. "shoulder pain" finds M25.51x even though the
 * stored description order is "Pain in ... shoulder").
 *
 * Results are ordered: exact code match first, then prefix matches,
 * then description matches, each group alphabetical by code.
 */
export function searchIcd10(query: string, catalog: Icd10Code[]): Icd10SearchResult[] {
  const trimmed = query.trim();
  if (!trimmed) return [];

  const normalizedCode = trimmed.toUpperCase();
  const lowerQuery = trimmed.toLowerCase();
  const queryTerms = lowerQuery.split(/\s+/).filter(Boolean);

  const exact: Icd10SearchResult[] = [];
  const prefix: Icd10SearchResult[] = [];
  const description: Icd10SearchResult[] = [];

  for (const entry of catalog) {
    if (entry.code === normalizedCode) {
      exact.push({ code: entry, matchType: 'exact-code' });
      continue;
    }
    if (entry.code.startsWith(normalizedCode) && looksLikeCodeQuery(trimmed)) {
      prefix.push({ code: entry, matchType: 'code-prefix' });
      continue;
    }
    const lowerDescription = entry.description.toLowerCase();
    if (queryTerms.every((term) => lowerDescription.includes(term))) {
      description.push({ code: entry, matchType: 'description-substring' });
    }
  }

  const byCode = (a: Icd10SearchResult, b: Icd10SearchResult) => a.code.code.localeCompare(b.code.code);
  return [...exact.sort(byCode), ...prefix.sort(byCode), ...description.sort(byCode)];
}

/** Returns all codes under a given category (e.g. "S52" -> S52, S52.501A, S52.502A, ...), ordered by code — the hierarchy navigation view. */
export function getCategoryHierarchy(category: string, catalog: Icd10Code[]): Icd10Code[] {
  return catalog
    .filter((c) => c.category === category.toUpperCase())
    .sort((a, b) => a.code.localeCompare(b.code));
}

/** Groups the catalog by chapter, for a chapter -> codes browse view. */
export function groupByChapter(catalog: Icd10Code[]): Map<string, Icd10Code[]> {
  const groups = new Map<string, Icd10Code[]>();
  for (const entry of catalog) {
    const list = groups.get(entry.chapter) ?? [];
    list.push(entry);
    groups.set(entry.chapter, list);
  }
  return groups;
}

/** Heuristic: a query "looks like" a code if it starts with a letter followed by digits (ICD-10-CM code shape), so we don't treat plain-English prefix words as code prefixes. */
function looksLikeCodeQuery(query: string): boolean {
  return /^[A-Za-z]\d/.test(query);
}

import { loadSampleLoincCatalog, searchLoinc, getLoincByCode } from '../catalog-and-search';

describe('LOINC', () => {
  const catalog = loadSampleLoincCatalog();

  it('finds an exact code match first', () => {
    const results = searchLoinc('2345-7', catalog);
    expect(results[0].matchType).toBe('exact-code');
    expect(results[0].code.component).toBe('Glucose');
  });

  it('finds an exact component match', () => {
    const results = searchLoinc('Creatinine', catalog);
    expect(results.some((r) => r.matchType === 'component' && r.code.loincNum === '2160-0')).toBe(true);
  });

  it('finds name substring matches for multi-word queries', () => {
    const results = searchLoinc('serum plasma', catalog);
    // every entry with system Ser/Plas should be included, since the name mentions "Serum or Plasma"
    expect(results.length).toBeGreaterThan(0);
    expect(results.every((r) => r.code.system === 'Ser/Plas')).toBe(true);
  });

  it('getLoincByCode looks up directly', () => {
    expect(getLoincByCode('718-7', catalog)?.component).toBe('Hemoglobin');
    expect(getLoincByCode('9999-9', catalog)).toBeUndefined();
  });

  it('returns empty for blank query', () => {
    expect(searchLoinc('', catalog)).toHaveLength(0);
  });
});

/**
 * LOINC (Logical Observation Identifiers Names and Codes) lookup and
 * search — used to code lab and clinical observation types.
 *
 * SCOPE HONESTY: the full LOINC database has ~90,000 codes, distributed
 * by the Regenstrief Institute. This environment cannot fetch that
 * release file. What's here: a small set of genuine, correctly-named
 * LOINC codes for common lab tests, enough to exercise the search logic
 * correctly. `loadFullLoincCatalog()` is a documented stub.
 */

export interface LoincCode {
  loincNum: string; // e.g. "2345-7"
  longCommonName: string;
  component: string; // what's measured, e.g. "Glucose"
  system: string; // specimen, e.g. "Ser/Plas" (serum/plasma)
}

const SAMPLE_LOINC_CATALOG: LoincCode[] = [
  { loincNum: '2345-7', longCommonName: 'Glucose [Mass/volume] in Serum or Plasma', component: 'Glucose', system: 'Ser/Plas' },
  { loincNum: '2160-0', longCommonName: 'Creatinine [Mass/volume] in Serum or Plasma', component: 'Creatinine', system: 'Ser/Plas' },
  { loincNum: '3094-0', longCommonName: 'Urea nitrogen [Mass/volume] in Serum or Plasma', component: 'BUN', system: 'Ser/Plas' },
  { loincNum: '718-7', longCommonName: 'Hemoglobin [Mass/volume] in Blood', component: 'Hemoglobin', system: 'Blood' },
  { loincNum: '4548-4', longCommonName: 'Hemoglobin A1c/Hemoglobin.total in Blood', component: 'Hemoglobin A1c', system: 'Blood' },
  { loincNum: '2951-2', longCommonName: 'Sodium [Moles/volume] in Serum or Plasma', component: 'Sodium', system: 'Ser/Plas' },
  { loincNum: '2823-3', longCommonName: 'Potassium [Moles/volume] in Serum or Plasma', component: 'Potassium', system: 'Ser/Plas' },
  { loincNum: '789-8', longCommonName: 'Erythrocytes [#/volume] in Blood by Automated count', component: 'RBC count', system: 'Blood' },
];

export function loadSampleLoincCatalog(): LoincCode[] {
  return SAMPLE_LOINC_CATALOG.map((c) => ({ ...c }));
}

export function loadFullLoincCatalog(): never {
  throw new Error(
    'loadFullLoincCatalog() is not implemented: the full LOINC release requires downloading from Regenstrief, not available in this environment. Load a real release file into this same LoincCode[] shape.',
  );
}

export interface LoincSearchResult {
  code: LoincCode;
  matchType: 'exact-code' | 'component' | 'name-substring';
}

export function searchLoinc(query: string, catalog: LoincCode[]): LoincSearchResult[] {
  const trimmed = query.trim();
  if (!trimmed) return [];
  const lowerQuery = trimmed.toLowerCase();
  const terms = lowerQuery.split(/\s+/).filter(Boolean);

  const exact: LoincSearchResult[] = [];
  const componentMatches: LoincSearchResult[] = [];
  const nameMatches: LoincSearchResult[] = [];

  for (const entry of catalog) {
    if (entry.loincNum === trimmed) {
      exact.push({ code: entry, matchType: 'exact-code' });
      continue;
    }
    if (entry.component.toLowerCase() === lowerQuery) {
      componentMatches.push({ code: entry, matchType: 'component' });
      continue;
    }
    const lowerName = entry.longCommonName.toLowerCase();
    if (terms.every((t) => lowerName.includes(t))) {
      nameMatches.push({ code: entry, matchType: 'name-substring' });
    }
  }

  return [...exact, ...componentMatches, ...nameMatches.sort((a, b) => a.code.loincNum.localeCompare(b.code.loincNum))];
}

export function getLoincByCode(loincNum: string, catalog: LoincCode[]): LoincCode | undefined {
  return catalog.find((c) => c.loincNum === loincNum.trim());
}

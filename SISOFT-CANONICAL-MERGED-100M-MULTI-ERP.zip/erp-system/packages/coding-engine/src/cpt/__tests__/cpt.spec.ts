import { loadSampleCptCatalog, searchCpt, getCptByCode } from '../catalog-and-search';

describe('CPT', () => {
  const catalog = loadSampleCptCatalog();

  it('finds an exact code match first', () => {
    const results = searchCpt('99213', catalog);
    expect(results[0].matchType).toBe('exact-code');
    expect(results[0].code.code).toBe('99213');
  });

  it('finds description substring matches regardless of word order', () => {
    const results = searchCpt('outpatient visit', catalog);
    const codes = results.map((r) => r.code.code).sort();
    expect(codes).toEqual(['99213', '99214']);
  });

  it('getCptByCode looks up directly', () => {
    expect(getCptByCode('44970', catalog)?.description).toMatch(/appendectomy/i);
    expect(getCptByCode('00000', catalog)).toBeUndefined();
  });

  it('returns empty for blank query', () => {
    expect(searchCpt('   ', catalog)).toHaveLength(0);
  });
});

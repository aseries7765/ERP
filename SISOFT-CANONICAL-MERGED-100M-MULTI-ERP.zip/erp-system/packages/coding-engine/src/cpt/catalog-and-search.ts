/**
 * CPT (Current Procedural Terminology) code lookup and search.
 *
 * SCOPE HONESTY: the real CPT code set is ~10,000 codes, licensed by
 * the AMA — it cannot be freely redistributed or fetched in this
 * environment even with network access, since it's proprietary (unlike
 * ICD-10-CM, which is public domain). What's here: a small set of
 * genuine, correctly-described CPT codes commonly referenced in
 * examples (the codes and their standard descriptions are publicly
 * documented facts, not the licensed data set itself), enough to
 * exercise the search/lookup logic correctly. `loadFullCptCatalog()`
 * is a documented stub — a real deployment obtains a licensed CPT data
 * file from the AMA and loads it through this same interface.
 */

export interface CptCode {
  code: string; // 5-digit numeric, or alphanumeric for Category II/III (e.g. "0001A")
  description: string;
  category: 'CATEGORY_I' | 'CATEGORY_II' | 'CATEGORY_III';
}

const SAMPLE_CPT_CATALOG: CptCode[] = [
  { code: '99213', description: 'Office or other outpatient visit, established patient, low complexity', category: 'CATEGORY_I' },
  { code: '99214', description: 'Office or other outpatient visit, established patient, moderate complexity', category: 'CATEGORY_I' },
  { code: '99283', description: 'Emergency department visit, moderate severity', category: 'CATEGORY_I' },
  { code: '99284', description: 'Emergency department visit, high severity', category: 'CATEGORY_I' },
  { code: '44970', description: 'Laparoscopic appendectomy', category: 'CATEGORY_I' },
  { code: '90935', description: 'Hemodialysis procedure, single physician evaluation', category: 'CATEGORY_I' },
  { code: '90937', description: 'Hemodialysis procedure requiring repeated evaluations', category: 'CATEGORY_I' },
  { code: '71046', description: 'Chest X-ray, 2 views', category: 'CATEGORY_I' },
  { code: '80053', description: 'Comprehensive metabolic panel', category: 'CATEGORY_I' },
];

export function loadSampleCptCatalog(): CptCode[] {
  return SAMPLE_CPT_CATALOG.map((c) => ({ ...c }));
}

export function loadFullCptCatalog(): never {
  throw new Error(
    'loadFullCptCatalog() is not implemented: CPT is licensed by the AMA and cannot be redistributed here. Load a licensed CPT data file into this same CptCode[] shape.',
  );
}

export interface CptSearchResult {
  code: CptCode;
  matchType: 'exact-code' | 'description-substring';
}

export function searchCpt(query: string, catalog: CptCode[]): CptSearchResult[] {
  const trimmed = query.trim();
  if (!trimmed) return [];
  const normalizedCode = trimmed.toUpperCase();
  const terms = trimmed.toLowerCase().split(/\s+/).filter(Boolean);

  const exact: CptSearchResult[] = [];
  const desc: CptSearchResult[] = [];

  for (const entry of catalog) {
    if (entry.code === normalizedCode) {
      exact.push({ code: entry, matchType: 'exact-code' });
      continue;
    }
    const lowerDesc = entry.description.toLowerCase();
    if (terms.every((t) => lowerDesc.includes(t))) {
      desc.push({ code: entry, matchType: 'description-substring' });
    }
  }

  return [...exact, ...desc.sort((a, b) => a.code.code.localeCompare(b.code.code))];
}

export function getCptByCode(code: string, catalog: CptCode[]): CptCode | undefined {
  return catalog.find((c) => c.code === code.trim().toUpperCase());
}

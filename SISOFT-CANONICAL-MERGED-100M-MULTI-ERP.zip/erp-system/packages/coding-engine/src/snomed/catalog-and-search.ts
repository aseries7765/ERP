/**
 * SNOMED CT concept lookup and search.
 *
 * SCOPE HONESTY: real SNOMED CT has ~350,000 active concepts,
 * distributed by SNOMED International (subject to an affiliate
 * license in many countries, including the US via the NLM). This
 * environment cannot fetch that release file. What's here: a small set
 * of genuine SNOMED CT concept IDs and their real, correct preferred
 * terms, enough to exercise the search logic correctly.
 * `loadFullSnomedCatalog()` is a documented stub.
 */

export interface SnomedConcept {
  conceptId: string;
  preferredTerm: string;
  semanticTag: string;
}

const SAMPLE_SNOMED_CATALOG: SnomedConcept[] = [
  { conceptId: '73211009', preferredTerm: 'Diabetes mellitus', semanticTag: '(disorder)' },
  { conceptId: '44054006', preferredTerm: 'Type 2 diabetes mellitus', semanticTag: '(disorder)' },
  { conceptId: '195967001', preferredTerm: 'Asthma', semanticTag: '(disorder)' },
  { conceptId: '233604007', preferredTerm: 'Pneumonia', semanticTag: '(disorder)' },
  { conceptId: '386661006', preferredTerm: 'Fever', semanticTag: '(finding)' },
  { conceptId: '80146002', preferredTerm: 'Appendectomy', semanticTag: '(procedure)' },
  { conceptId: '34068001', preferredTerm: 'Heart valve replacement', semanticTag: '(procedure)' },
  { conceptId: '302497006', preferredTerm: 'Hemodialysis', semanticTag: '(procedure)' },
  { conceptId: '22298006', preferredTerm: 'Myocardial infarction', semanticTag: '(disorder)' },
];

export function loadSampleSnomedCatalog(): SnomedConcept[] {
  return SAMPLE_SNOMED_CATALOG.map((c) => ({ ...c }));
}

export function loadFullSnomedCatalog(): never {
  throw new Error(
    'loadFullSnomedCatalog() is not implemented: the full SNOMED CT release requires a licensed distribution (e.g. via NLM UMLS/US Edition) not available in this environment. Load a real release file into this same SnomedConcept[] shape.',
  );
}

export interface SnomedSearchResult {
  concept: SnomedConcept;
  matchType: 'exact-id' | 'term-substring';
}

export function searchSnomed(query: string, catalog: SnomedConcept[]): SnomedSearchResult[] {
  const trimmed = query.trim();
  if (!trimmed) return [];
  const terms = trimmed.toLowerCase().split(/\s+/).filter(Boolean);

  const exact: SnomedSearchResult[] = [];
  const term: SnomedSearchResult[] = [];

  for (const concept of catalog) {
    if (concept.conceptId === trimmed) {
      exact.push({ concept, matchType: 'exact-id' });
      continue;
    }
    const lowerTerm = concept.preferredTerm.toLowerCase();
    if (terms.every((t) => lowerTerm.includes(t))) {
      term.push({ concept, matchType: 'term-substring' });
    }
  }

  return [...exact, ...term.sort((a, b) => a.concept.preferredTerm.localeCompare(b.concept.preferredTerm))];
}

export function getSnomedByConceptId(conceptId: string, catalog: SnomedConcept[]): SnomedConcept | undefined {
  return catalog.find((c) => c.conceptId === conceptId.trim());
}

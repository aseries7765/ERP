import { loadSampleSnomedCatalog, searchSnomed, getSnomedByConceptId } from '../catalog-and-search';

describe('SNOMED', () => {
  const catalog = loadSampleSnomedCatalog();

  it('finds an exact concept id match first', () => {
    const results = searchSnomed('73211009', catalog);
    expect(results[0].matchType).toBe('exact-id');
    expect(results[0].concept.preferredTerm).toBe('Diabetes mellitus');
  });

  it('finds term substring matches', () => {
    const results = searchSnomed('diabetes', catalog);
    const ids = results.map((r) => r.concept.conceptId).sort();
    expect(ids).toEqual(['44054006', '73211009']);
  });

  it('term search is case-insensitive and multi-word AND', () => {
    const results = searchSnomed('type 2 diabetes', catalog);
    expect(results).toHaveLength(1);
    expect(results[0].concept.conceptId).toBe('44054006');
  });

  it('getSnomedByConceptId looks up directly', () => {
    expect(getSnomedByConceptId('80146002', catalog)?.preferredTerm).toBe('Appendectomy');
    expect(getSnomedByConceptId('000000000', catalog)).toBeUndefined();
  });

  it('returns empty for blank query', () => {
    expect(searchSnomed('', catalog)).toHaveLength(0);
  });
});

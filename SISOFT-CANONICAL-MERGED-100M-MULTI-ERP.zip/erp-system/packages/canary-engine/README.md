# @erp/canary-engine

Real statistical canary analysis — not threshold vibes. Compares a canary
group's metrics against a baseline group using:

- **Welch's t-test** (unequal-variance two-sample t-test) on p95 latency,
  with degrees of freedom via the Welch–Satterthwaite equation and a real
  Student's-t two-tailed p-value (regularized incomplete beta function,
  Numerical-Recipes-style continued-fraction implementation — not a lookup
  table, not a normal approximation).
- **Two-proportion z-test** (pooled proportion, standard normal p-value via
  an Abramowitz–Stegun erf approximation) on error rate.
- Absolute ceilings (default: error rate ≤ 0.1%, p95 latency ≤ 250ms) that
  apply regardless of statistical significance, so a canary group too small
  to reach significance can't hide an obvious break.
- A minimum-sample-size gate (default 30) that returns `hold` rather than a
  premature `promote`/`halt` verdict when there isn't enough data yet.

## Modules
- `statistical.ts` — `computeSampleStats`, `welchTTest`, `twoProportionZTest`,
  plus the underlying `normalCdf` / `tDistributionTwoTailedPValue` primitives.
- `thresholds.ts` — `DEFAULT_CANARY_THRESHOLDS`.
- `metrics.ts` — adapts the `CanaryMetrics` shape (raw latency samples +
  request/error counts) into the stats functions' inputs.
- `decision.ts` — `evaluateCanary()`: combines both tests and both absolute
  ceilings into a single `promote | hold | halt` verdict with itemized reasons.

## Test status
23/23 unit tests passing, including:
- Two independent reference-value checks of the t-distribution p-value
  against textbook critical values (t=2.228, df=10 → p≈0.05; large-df limit
  converges to the normal approximation).
- A realistic-noise (seeded PRNG, not a repeating low-variance pattern)
  "no regression" case that correctly promotes.
- Deliberate regression-injection cases (latency, error rate, both
  statistical and absolute-ceiling) that correctly halt.

Two bugs were caught and fixed during test-writing itself, not glossed over:
an earlier version of the "should promote" test used a synthetic
low-variance repeating latency pattern where even a trivial 1ms shift is
*correctly* flagged significant (that's the stats working, not a bug — the
test's fixture was unrealistic and was rewritten with seeded jitter), and a
second version used an error count that itself exceeded the absolute
ceiling by design. See `src/__tests__/decision.spec.ts` history in
MANIFEST.md's honesty section.

## Not included here
Pulling real metrics out of Prometheus/observability (M14) into the
`CanaryMetrics` shape this package consumes is not implemented — that's an
infrastructure integration, described but not built (see root MANIFEST.md).

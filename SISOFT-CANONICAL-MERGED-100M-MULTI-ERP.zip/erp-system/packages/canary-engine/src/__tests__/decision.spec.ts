import { test } from 'node:test';
import assert from 'node:assert/strict';
import { evaluateCanary } from '../decision';
import { DEFAULT_CANARY_THRESHOLDS } from '../thresholds';
import { CanaryMetrics } from '../types';

function metrics(latencyValues: number[], totalRequests: number, errorRequests: number): CanaryMetrics {
  return {
    latencyMsP95Samples: { values: latencyValues },
    errorRate: { totalRequests, errorRequests },
  };
}

// Deterministic pseudo-random generator (mulberry32) so this test is reproducible
// without relying on Math.random(), while still producing realistic jitter —
// a low-variance repeating pattern would make even a trivial 1ms shift "significant",
// which is correct statistical behavior, not something to mask with a weak test.
function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

test('promotes when canary matches baseline and has enough samples', () => {
  // Same underlying noise pattern for both groups, canary shifted by a trivial +0.5ms —
  // isolates "does a tiny, non-meaningful shift stay unflagged" from random-seed luck.
  const rand = mulberry32(42);
  const baselineLatency = Array.from({ length: 200 }, () => 200 + (rand() - 0.5) * 40); // 180-220ms, realistic jitter
  const canaryLatency = baselineLatency.map((v) => v + 0.5);
  const decision = evaluateCanary(
    metrics(baselineLatency, 5000, 3),
    metrics(canaryLatency, 5000, 3),
    DEFAULT_CANARY_THRESHOLDS,
  );
  assert.equal(decision.verdict, 'promote');
});

test('holds when canary sample size is below minimum', () => {
  const decision = evaluateCanary(
    metrics([200, 201, 202], 5000, 5),
    metrics([210, 211], 10, 1), // below minSampleSize of 30
    DEFAULT_CANARY_THRESHOLDS,
  );
  assert.equal(decision.verdict, 'hold');
  assert.ok(decision.reasons.some((r) => r.code === 'INSUFFICIENT_SAMPLE_SIZE'));
});

test('halts on statistically significant latency regression', () => {
  const baselineLatency = Array.from({ length: 50 }, (_, i) => 200 + (i % 5));
  const canaryLatency = Array.from({ length: 50 }, (_, i) => 500 + (i % 5));
  const decision = evaluateCanary(
    metrics(baselineLatency, 5000, 5),
    metrics(canaryLatency, 5000, 5),
    DEFAULT_CANARY_THRESHOLDS,
  );
  assert.equal(decision.verdict, 'halt');
  assert.ok(decision.reasons.some((r) => r.code === 'LATENCY_REGRESSION_SIGNIFICANT'));
});

test('halts on statistically significant error rate regression', () => {
  const latency = Array.from({ length: 50 }, (_, i) => 200 + (i % 5));
  const decision = evaluateCanary(
    metrics(latency, 5000, 5),
    metrics(latency, 5000, 200),
    DEFAULT_CANARY_THRESHOLDS,
  );
  assert.equal(decision.verdict, 'halt');
  assert.ok(decision.reasons.some((r) => r.code === 'ERROR_RATE_REGRESSION_SIGNIFICANT'));
});

test('halts on absolute error rate ceiling breach even if not (yet) statistically dramatic', () => {
  const latency = Array.from({ length: 50 }, (_, i) => 200 + (i % 5));
  // canary error rate 0.5% exceeds the 0.1% absolute ceiling
  const decision = evaluateCanary(
    metrics(latency, 100000, 50),
    metrics(latency, 200, 1),
    DEFAULT_CANARY_THRESHOLDS,
  );
  assert.equal(decision.verdict, 'halt');
  assert.ok(decision.reasons.some((r) => r.code === 'ERROR_RATE_ABSOLUTE_CEILING_BREACHED'));
});

test('halts on absolute latency ceiling breach', () => {
  const baselineLatency = Array.from({ length: 50 }, (_, i) => 200 + (i % 5));
  const canaryLatency = Array.from({ length: 50 }, () => 300); // exceeds 250ms absolute ceiling
  const decision = evaluateCanary(
    metrics(baselineLatency, 5000, 5),
    metrics(canaryLatency, 5000, 5),
    DEFAULT_CANARY_THRESHOLDS,
  );
  assert.equal(decision.verdict, 'halt');
  assert.ok(decision.reasons.some((r) => r.code === 'LATENCY_ABSOLUTE_CEILING_BREACHED'));
});

test('does not halt when canary is faster/better than baseline', () => {
  const baselineLatency = Array.from({ length: 50 }, (_, i) => 200 + (i % 5));
  const canaryLatency = Array.from({ length: 50 }, (_, i) => 150 + (i % 5));
  const decision = evaluateCanary(
    metrics(baselineLatency, 5000, 20),
    metrics(canaryLatency, 5000, 2),
    DEFAULT_CANARY_THRESHOLDS,
  );
  assert.equal(decision.verdict, 'promote');
});

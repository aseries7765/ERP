import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeSampleStats, normalCdf, tDistributionTwoTailedPValue, welchTTest, twoProportionZTest } from '../statistical';

function approxEqual(a: number, b: number, tolerance: number, msg?: string) {
  assert.ok(Math.abs(a - b) <= tolerance, msg ?? `expected ${a} ~= ${b} (tolerance ${tolerance})`);
}

test('computeSampleStats: basic mean and variance', () => {
  const stats = computeSampleStats([2, 4, 4, 4, 5, 5, 7, 9]);
  approxEqual(stats.mean, 5, 1e-9);
  approxEqual(stats.variance, 4.5714285714, 1e-6);
  assert.equal(stats.n, 8);
});

test('computeSampleStats: empty and single-element edge cases', () => {
  assert.deepEqual(computeSampleStats([]), { n: 0, mean: 0, variance: 0 });
  assert.deepEqual(computeSampleStats([42]), { n: 1, mean: 42, variance: 0 });
});

test('normalCdf: known reference points', () => {
  approxEqual(normalCdf(0), 0.5, 1e-6);
  approxEqual(normalCdf(1.959964), 0.975, 1e-4); // ~97.5th percentile at z=1.96
  approxEqual(normalCdf(-1.959964), 0.025, 1e-4);
});

test('tDistributionTwoTailedPValue: at t=0 p-value is 1', () => {
  approxEqual(tDistributionTwoTailedPValue(0, 20), 1, 1e-6);
});

test('tDistributionTwoTailedPValue: reference value t=2.228, df=10 ~ alpha 0.05 critical value', () => {
  // 2.228 is the two-tailed 5% critical t-value for df=10 (standard t-table value).
  const p = tDistributionTwoTailedPValue(2.228, 10);
  approxEqual(p, 0.05, 0.002);
});

test('tDistributionTwoTailedPValue: reference value t=1.96, df=large approaches normal 0.05', () => {
  const p = tDistributionTwoTailedPValue(1.96, 100000);
  approxEqual(p, 0.05, 0.002);
});

test('tDistributionTwoTailedPValue: p-value decreases monotonically as |t| grows', () => {
  const p1 = tDistributionTwoTailedPValue(1, 30);
  const p2 = tDistributionTwoTailedPValue(2, 30);
  const p3 = tDistributionTwoTailedPValue(4, 30);
  assert.ok(p1 > p2);
  assert.ok(p2 > p3);
});

test('welchTTest: identical distributions -> not significant, p near 1', () => {
  const baseline = computeSampleStats([100, 102, 98, 101, 99, 100, 103, 97, 100, 101]);
  const canary = computeSampleStats([99, 101, 100, 102, 98, 100, 101, 99, 100, 102]);
  const result = welchTTest(baseline, canary, 0.05);
  assert.equal(result.significant, false);
  assert.ok(result.pValue > 0.3);
});

test('welchTTest: clearly worse canary latency -> significant regression detected', () => {
  const baselineValues = Array.from({ length: 50 }, (_, i) => 200 + (i % 5)); // ~200-204ms
  const canaryValues = Array.from({ length: 50 }, (_, i) => 400 + (i % 5)); // ~400-404ms, clear regression
  const baseline = computeSampleStats(baselineValues);
  const canary = computeSampleStats(canaryValues);
  const result = welchTTest(baseline, canary, 0.05);
  assert.equal(result.significant, true);
  assert.ok(result.meanDelta > 0);
  assert.ok(result.pValue < 0.001);
});

test('welchTTest: canary faster than baseline is significant but meanDelta negative (improvement, not regression)', () => {
  const baselineValues = Array.from({ length: 50 }, (_, i) => 400 + (i % 5));
  const canaryValues = Array.from({ length: 50 }, (_, i) => 200 + (i % 5));
  const result = welchTTest(computeSampleStats(baselineValues), computeSampleStats(canaryValues), 0.05);
  assert.equal(result.significant, true);
  assert.ok(result.meanDelta < 0);
});

test('welchTTest: too few samples -> not significant by definition, pValue=1', () => {
  const result = welchTTest(computeSampleStats([1]), computeSampleStats([2]), 0.05);
  assert.equal(result.significant, false);
  assert.equal(result.pValue, 1);
});

test('welchTTest: zero variance in both with different means is deterministically significant', () => {
  const result = welchTTest(computeSampleStats([100, 100, 100]), computeSampleStats([150, 150, 150]), 0.05);
  assert.equal(result.significant, true);
  assert.equal(result.pValue, 0);
});

test('welchTTest: zero variance in both with equal means is not significant', () => {
  const result = welchTTest(computeSampleStats([100, 100, 100]), computeSampleStats([100, 100, 100]), 0.05);
  assert.equal(result.significant, false);
  assert.equal(result.pValue, 1);
});

test('twoProportionZTest: identical error rates -> not significant', () => {
  const result = twoProportionZTest({ total: 10000, errors: 10 }, { total: 10000, errors: 11 }, 0.05);
  assert.equal(result.significant, false);
});

test('twoProportionZTest: canary error rate spike is significant', () => {
  const result = twoProportionZTest({ total: 10000, errors: 10 }, { total: 10000, errors: 300 }, 0.05);
  assert.equal(result.significant, true);
  assert.ok(result.rateDelta > 0);
  approxEqual(result.baselineRate, 0.001, 1e-9);
  approxEqual(result.canaryRate, 0.03, 1e-9);
});

test('twoProportionZTest: zero-request groups do not crash and are not significant', () => {
  const result = twoProportionZTest({ total: 0, errors: 0 }, { total: 100, errors: 5 }, 0.05);
  assert.equal(result.significant, false);
});

import { CanaryMetrics } from './types';
import { computeSampleStats } from './statistical';

/** Convenience: pulls p95 latency sample stats out of a CanaryMetrics bag, if present. */
export function latencyP95Stats(metrics: CanaryMetrics) {
  const values = metrics.latencyMsP95Samples?.values ?? [];
  return computeSampleStats(values);
}

/** Extracts the {total, errors} shape twoProportionZTest expects from a CanaryMetrics bag. */
export function errorRateInput(metrics: CanaryMetrics) {
  return { total: metrics.errorRate.totalRequests, errors: metrics.errorRate.errorRequests };
}

import { CanaryThresholds } from './types';

/** Default canary gate thresholds, matching the rollout-ring gate criteria from the runbook. */
export const DEFAULT_CANARY_THRESHOLDS: CanaryThresholds = {
  alpha: 0.05,
  maxAbsoluteErrorRate: 0.001, // 0.1%, matches ROLLOUT_RINGS gate criteria
  maxAbsoluteLatencyP95Ms: 250,
  minSampleSize: 30,
};

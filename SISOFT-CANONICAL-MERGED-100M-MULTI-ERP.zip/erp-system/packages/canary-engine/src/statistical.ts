import { SampleStats, TTestResult, ZTestResult } from './types';

/** Computes n, mean, and sample variance (n-1 denominator) from raw observations. */
export function computeSampleStats(values: number[]): SampleStats {
  const n = values.length;
  if (n === 0) return { n: 0, mean: 0, variance: 0 };
  const mean = values.reduce((a, b) => a + b, 0) / n;
  if (n === 1) return { n, mean, variance: 0 };
  const variance = values.reduce((acc, v) => acc + (v - mean) ** 2, 0) / (n - 1);
  return { n, mean, variance };
}

// --- Abramowitz & Stegun 7.1.26 approximation of the error function ---
function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x);
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;
  const t = 1 / (1 + p * ax);
  const y = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-ax * ax);
  return sign * y;
}

/** Standard normal CDF, Phi(x). */
export function normalCdf(x: number): number {
  return 0.5 * (1 + erf(x / Math.SQRT2));
}

// --- Regularized incomplete beta function I_x(a,b), Numerical Recipes style, used for the
// Student's t CDF. Implemented via Lentz's continued fraction algorithm. ---
function logGamma(x: number): number {
  const cof = [
    76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2,
    -0.5395239384953e-5,
  ];
  let y = x;
  let tmp = x + 5.5;
  tmp -= (x + 0.5) * Math.log(tmp);
  let ser = 1.000000000190015;
  for (let j = 0; j < cof.length; j++) {
    y += 1;
    ser += cof[j] / y;
  }
  return -tmp + Math.log((2.5066282746310005 * ser) / x);
}

function betacf(a: number, b: number, x: number): number {
  const MAXIT = 200;
  const EPS = 3e-9;
  const FPMIN = 1e-30;
  const qab = a + b;
  const qap = a + 1;
  const qam = a - 1;
  let c = 1;
  let d = 1 - (qab * x) / qap;
  if (Math.abs(d) < FPMIN) d = FPMIN;
  d = 1 / d;
  let h = d;
  for (let m = 1; m <= MAXIT; m++) {
    const m2 = 2 * m;
    let aa = (m * (b - m) * x) / ((qam + m2) * (a + m2));
    d = 1 + aa * d;
    if (Math.abs(d) < FPMIN) d = FPMIN;
    c = 1 + aa / c;
    if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d;
    h *= d * c;
    aa = (-(a + m) * (qab + m) * x) / ((a + m2) * (qap + m2));
    d = 1 + aa * d;
    if (Math.abs(d) < FPMIN) d = FPMIN;
    c = 1 + aa / c;
    if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < EPS) break;
  }
  return h;
}

/** Regularized incomplete beta function I_x(a, b), for x in [0, 1]. */
function incompleteBeta(x: number, a: number, b: number): number {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  const bt = Math.exp(logGamma(a + b) - logGamma(a) - logGamma(b) + a * Math.log(x) + b * Math.log(1 - x));
  if (x < (a + 1) / (a + b + 2)) {
    return (bt * betacf(a, b, x)) / a;
  } else {
    return 1 - (bt * betacf(b, a, 1 - x)) / b;
  }
}

/** Two-tailed p-value for Student's t distribution with `df` degrees of freedom, given |t|. */
export function tDistributionTwoTailedPValue(t: number, df: number): number {
  const x = df / (df + t * t);
  return incompleteBeta(x, df / 2, 0.5);
}

/**
 * Welch's t-test (unequal variances) comparing baseline vs canary samples.
 * Appropriate here because canary traffic volume and variance typically differ
 * from baseline, so we don't assume equal variances (Student's pooled t-test).
 */
export function welchTTest(baseline: SampleStats, canary: SampleStats, alpha = 0.05): TTestResult {
  if (baseline.n < 2 || canary.n < 2) {
    return { t: 0, degreesOfFreedom: 0, pValue: 1, significant: false, meanDelta: canary.mean - baseline.mean };
  }
  const se2Baseline = baseline.variance / baseline.n;
  const se2Canary = canary.variance / canary.n;
  const se = Math.sqrt(se2Baseline + se2Canary);
  const meanDelta = canary.mean - baseline.mean;

  if (se === 0) {
    // No variance in either sample: any nonzero delta is a deterministic difference.
    return {
      t: meanDelta === 0 ? 0 : Infinity,
      degreesOfFreedom: baseline.n + canary.n - 2,
      pValue: meanDelta === 0 ? 1 : 0,
      significant: meanDelta !== 0,
      meanDelta,
    };
  }

  const t = meanDelta / se;
  const df =
    (se2Baseline + se2Canary) ** 2 /
    ((se2Baseline ** 2) / (baseline.n - 1) + (se2Canary ** 2) / (canary.n - 1));
  const pValue = tDistributionTwoTailedPValue(Math.abs(t), df);
  return { t, degreesOfFreedom: df, pValue, significant: pValue < alpha, meanDelta };
}

/**
 * Two-proportion z-test comparing baseline vs canary error rates.
 * Uses the pooled proportion for the standard error, standard for this test.
 */
export function twoProportionZTest(
  baseline: { total: number; errors: number },
  canary: { total: number; errors: number },
  alpha = 0.05,
): ZTestResult {
  const baselineRate = baseline.total > 0 ? baseline.errors / baseline.total : 0;
  const canaryRate = canary.total > 0 ? canary.errors / canary.total : 0;
  const rateDelta = canaryRate - baselineRate;

  if (baseline.total === 0 || canary.total === 0) {
    return { z: 0, pValue: 1, significant: false, baselineRate, canaryRate, rateDelta };
  }

  const pooled = (baseline.errors + canary.errors) / (baseline.total + canary.total);
  const se = Math.sqrt(pooled * (1 - pooled) * (1 / baseline.total + 1 / canary.total));

  if (se === 0) {
    return { z: 0, pValue: 1, significant: false, baselineRate, canaryRate, rateDelta };
  }

  const z = rateDelta / se;
  const pValue = 2 * (1 - normalCdf(Math.abs(z)));
  return { z, pValue, significant: pValue < alpha, baselineRate, canaryRate, rateDelta };
}

/** n, mean, and sample variance of a numeric sample. */
export interface SampleStats {
  n: number;
  mean: number;
  variance: number; // sample variance (n-1 denominator)
}

/** A raw set of numeric observations for one metric. */
export interface MetricSample {
  /** Raw per-request or per-window observations, e.g. latency in ms. */
  values: number[];
}

/** Aggregate request/error counts used to derive an error rate. */
export interface ErrorRateSample {
  totalRequests: number;
  errorRequests: number;
}

/** The full set of metrics collected for one group (baseline or canary) during an observation window. */
export interface CanaryMetrics {
  latencyMsP50Samples?: MetricSample;
  latencyMsP95Samples?: MetricSample;
  errorRate: ErrorRateSample;
  cpuPercent?: MetricSample;
  memoryPercent?: MetricSample;
  dbQueryMs?: MetricSample;
  queueDepth?: MetricSample;
}

/** Result of Welch's t-test comparing a metric between baseline and canary. */
export interface TTestResult {
  t: number;
  degreesOfFreedom: number;
  pValue: number; // two-tailed
  significant: boolean; // pValue < alpha
  meanDelta: number; // canaryMean - baselineMean
}

/** Result of a two-proportion z-test comparing error rates between baseline and canary. */
export interface ZTestResult {
  z: number;
  pValue: number; // two-tailed
  significant: boolean;
  baselineRate: number;
  canaryRate: number;
  rateDelta: number; // canaryRate - baselineRate
}

/** Gate thresholds evaluateCanary() checks: statistical significance level plus absolute ceilings. */
export interface CanaryThresholds {
  /** Statistical significance level for both t-test and z-test (e.g. 0.05). */
  alpha: number;
  /** Absolute error rate ceiling for the canary regardless of significance (e.g. 0.01 = 1%). */
  maxAbsoluteErrorRate: number;
  /** Absolute p95 latency ceiling in ms for the canary regardless of significance. */
  maxAbsoluteLatencyP95Ms: number;
  /** Minimum sample size per group required before a statistical verdict is trusted. */
  minSampleSize: number;
}

/** evaluateCanary()'s verdict: promote to the next ring, hold for more data, or halt the rollout. */
export type CanaryDecisionVerdict = 'promote' | 'hold' | 'halt';

/** One machine-readable reason contributing to a CanaryDecision. */
export interface CanaryDecisionReason {
  code: string;
  message: string;
}

/** Full output of evaluateCanary(): verdict, reasons, and the underlying statistical tests. */
export interface CanaryDecision {
  verdict: CanaryDecisionVerdict;
  reasons: CanaryDecisionReason[];
  latencyP95Test?: TTestResult;
  errorRateTest?: ZTestResult;
}

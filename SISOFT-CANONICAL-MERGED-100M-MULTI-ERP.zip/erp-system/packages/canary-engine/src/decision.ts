import { CanaryDecision, CanaryDecisionReason, CanaryMetrics, CanaryThresholds } from './types';
import { welchTTest, twoProportionZTest } from './statistical';
import { latencyP95Stats, errorRateInput } from './metrics';

/**
 * Compares baseline vs canary metrics and produces a promote/hold/halt verdict.
 *
 * - "halt": statistically significant degradation, or an absolute threshold breach
 *   regardless of significance (a hard ceiling protects against a canary group too
 *   small to reach significance while still being obviously broken).
 * - "hold": insufficient sample size to trust a statistical verdict yet; keep observing.
 * - "promote": no degradation detected and sample size is sufficient.
 */
export function evaluateCanary(
  baseline: CanaryMetrics,
  canary: CanaryMetrics,
  thresholds: CanaryThresholds,
): CanaryDecision {
  const reasons: CanaryDecisionReason[] = [];

  const baselineLatency = latencyP95Stats(baseline);
  const canaryLatency = latencyP95Stats(canary);
  const baselineErrors = errorRateInput(baseline);
  const canaryErrors = errorRateInput(canary);

  if (canaryLatency.n < thresholds.minSampleSize || canaryErrors.total < thresholds.minSampleSize) {
    reasons.push({
      code: 'INSUFFICIENT_SAMPLE_SIZE',
      message: `Canary sample size (${canaryLatency.n} latency samples, ${canaryErrors.total} requests) is below the minimum of ${thresholds.minSampleSize} required for a statistical verdict.`,
    });
    return { verdict: 'hold', reasons };
  }

  const latencyTest = welchTTest(baselineLatency, canaryLatency, thresholds.alpha);
  const errorTest = twoProportionZTest(baselineErrors, canaryErrors, thresholds.alpha);

  let halt = false;

  if (latencyTest.significant && latencyTest.meanDelta > 0) {
    halt = true;
    reasons.push({
      code: 'LATENCY_REGRESSION_SIGNIFICANT',
      message: `p95 latency increased by ${latencyTest.meanDelta.toFixed(1)}ms (p=${latencyTest.pValue.toFixed(4)}, below alpha=${thresholds.alpha}); statistically significant regression.`,
    });
  }

  if (errorTest.significant && errorTest.rateDelta > 0) {
    halt = true;
    reasons.push({
      code: 'ERROR_RATE_REGRESSION_SIGNIFICANT',
      message: `Error rate increased from ${(errorTest.baselineRate * 100).toFixed(3)}% to ${(errorTest.canaryRate * 100).toFixed(3)}% (p=${errorTest.pValue.toFixed(4)}); statistically significant regression.`,
    });
  }

  if (errorTest.canaryRate > thresholds.maxAbsoluteErrorRate) {
    halt = true;
    reasons.push({
      code: 'ERROR_RATE_ABSOLUTE_CEILING_BREACHED',
      message: `Canary error rate ${(errorTest.canaryRate * 100).toFixed(3)}% exceeds absolute ceiling of ${(thresholds.maxAbsoluteErrorRate * 100).toFixed(3)}%.`,
    });
  }

  if (canaryLatency.mean > thresholds.maxAbsoluteLatencyP95Ms) {
    halt = true;
    reasons.push({
      code: 'LATENCY_ABSOLUTE_CEILING_BREACHED',
      message: `Canary p95 latency ${canaryLatency.mean.toFixed(1)}ms exceeds absolute ceiling of ${thresholds.maxAbsoluteLatencyP95Ms}ms.`,
    });
  }

  if (halt) {
    return { verdict: 'halt', reasons, latencyP95Test: latencyTest, errorRateTest: errorTest };
  }

  reasons.push({
    code: 'NO_REGRESSION_DETECTED',
    message: 'No statistically significant or absolute-threshold regression detected; safe to promote.',
  });
  return { verdict: 'promote', reasons, latencyP95Test: latencyTest, errorRateTest: errorTest };
}

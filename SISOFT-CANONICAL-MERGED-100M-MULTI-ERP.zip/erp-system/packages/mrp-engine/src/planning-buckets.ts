import { PlanningBucket } from './types';

/**
 * Builds a deterministic list of planning buckets starting at `asOfDate`
 * (inclusive) spanning `horizonDays`, each `bucketSizeDays` wide.
 * Pure function of its inputs — no system clock, no randomness (G18).
 */
export function buildPlanningBuckets(
  asOfDate: string,
  horizonDays: number,
  bucketSizeDays: number,
): PlanningBucket[] {
  if (bucketSizeDays <= 0) throw new Error('bucketSizeDays must be > 0');
  const start = new Date(asOfDate + 'T00:00:00.000Z');
  const buckets: PlanningBucket[] = [];
  let cursor = new Date(start);
  let daysCovered = 0;
  while (daysCovered < horizonDays) {
    buckets.push({ periodStart: cursor.toISOString().slice(0, 10) });
    cursor = new Date(cursor.getTime() + bucketSizeDays * 86400000);
    daysCovered += bucketSizeDays;
  }
  return buckets;
}

/** Finds the bucket a given ISO date falls into (last bucket whose start <= date). */
export function bucketForDate(buckets: PlanningBucket[], isoDate: string): PlanningBucket | null {
  let found: PlanningBucket | null = null;
  for (const b of buckets) {
    if (b.periodStart <= isoDate) {
      found = b;
    } else {
      break;
    }
  }
  return found;
}

export function addDays(isoDate: string, days: number): string {
  const d = new Date(isoDate + 'T00:00:00.000Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export function subtractDays(isoDate: string, days: number): string {
  return addDays(isoDate, -days);
}

import { PlanningBucket, NetRequirementResult, ItemMasterMrpData } from './types';
import { bucketForDate } from './planning-buckets';
import { applyLotSizing } from './lot-sizing';

export interface NettingInput {
  itemId: string;
  onHandQty: number;
  item: ItemMasterMrpData;
  buckets: PlanningBucket[];
  /** Demand quantities keyed by periodStart. */
  grossRequirementsByPeriod: Map<string, number>;
  /** Scheduled/expected supply keyed by periodStart (open POs, open WOs). */
  scheduledReceiptsByPeriod: Map<string, number>;
}

/**
 * Runs the classic time-phased netting calculation across a set of planning
 * buckets for a single item, as a proper regenerative record where each
 * period's lot-sized planned order receipt is fed forward into the
 * following periods' projected on-hand:
 *
 *   POB_before[t]  = POB[t-1] - grossRequirement[t] + scheduledReceipt[t]
 *   netRequirement[t] = max(0, safetyStock - POB_before[t])
 *   plannedOrderReceipt[t] = netRequirement[t] > 0 ? lotSize(netRequirement[t]) : 0
 *   POB[t]         = POB_before[t] + plannedOrderReceipt[t]
 *
 * This last step is essential: without carrying the planned receipt
 * forward, a single period's shortfall would incorrectly re-trigger a "net
 * requirement" in every subsequent period forever, since on-hand would never
 * recover. This was caught by an end-to-end test that ran the numbers all
 * the way through a multi-bucket horizon rather than just checking a single
 * period in isolation — see mrp.spec.ts's "nets frame requirement" test.
 *
 * Deterministic: same inputs always produce the same sequence (G18).
 */
export function netRequirements(input: NettingInput): NetRequirementResult[] {
  const results: NetRequirementResult[] = [];
  let priorOnHand = input.onHandQty;
  const safetyStock = input.item.safetyStock ?? 0;

  for (const bucket of input.buckets) {
    const gross = input.grossRequirementsByPeriod.get(bucket.periodStart) ?? 0;
    const scheduled = input.scheduledReceiptsByPeriod.get(bucket.periodStart) ?? 0;

    const projectedOnHandBeforeOrder = priorOnHand - gross + scheduled;
    const shortfall = safetyStock - projectedOnHandBeforeOrder;
    const netRequirement = shortfall > 0 ? shortfall : 0;

    const plannedOrderReceipt = netRequirement > 0 ? applyLotSizing(netRequirement, input.item) : 0;
    const projectedOnHand = projectedOnHandBeforeOrder + plannedOrderReceipt;

    results.push({
      itemId: input.itemId,
      periodStart: bucket.periodStart,
      grossRequirement: gross,
      scheduledReceipts: scheduled,
      projectedOnHand,
      netRequirement,
      plannedOrderReceipt,
    });

    priorOnHand = projectedOnHand;
  }

  return results;
}

/** Groups raw demand/supply lines into per-period totals keyed by bucket start. */
export function bucketize(
  lines: { qty: number; date: string }[],
  buckets: PlanningBucket[],
): Map<string, number> {
  const map = new Map<string, number>();
  for (const line of lines) {
    const bucket = bucketForDate(buckets, line.date);
    const key = bucket ? bucket.periodStart : buckets[0]?.periodStart;
    if (!key) continue;
    map.set(key, (map.get(key) ?? 0) + line.qty);
  }
  return map;
}

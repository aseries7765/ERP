import { ItemMasterMrpData } from './types';

/**
 * Applies a lot-sizing rule to a net requirement quantity, returning the
 * order quantity actually to be planned.
 *
 * - lot-for-lot: order exactly what's needed (no batching).
 * - eoq: order the Economic Order Quantity whenever there's a net requirement
 *   (classic sqrt(2*D*S/H) formula), but never less than the net requirement.
 * - poq: order enough to cover `poqPeriods` periods of requirements. Since this
 *   function only sees a single period's net requirement, POQ here returns the
 *   net requirement scaled by poqPeriods as a simplification; a full multi-period
 *   POQ (looking ahead at future periods' requirements) is a documented
 *   limitation — see MRP.md.
 */
export function applyLotSizing(netRequirement: number, item: ItemMasterMrpData): number {
  if (netRequirement <= 0) return 0;

  switch (item.lotSizingRule) {
    case 'lot-for-lot':
      return netRequirement;

    case 'eoq': {
      const eoq = calculateEoq(item);
      return Math.max(netRequirement, eoq);
    }

    case 'poq': {
      const periods = item.poqPeriods ?? 1;
      return netRequirement * periods;
    }

    default:
      throw new Error(`Unknown lot-sizing rule: ${item.lotSizingRule}`);
  }
}

export function calculateEoq(item: ItemMasterMrpData): number {
  const { eoqAnnualDemand: D, eoqOrderCost: S, eoqHoldingCostPerUnit: H } = item;
  if (!D || !S || !H) {
    throw new Error('EOQ lot-sizing requires eoqAnnualDemand, eoqOrderCost, eoqHoldingCostPerUnit');
  }
  if (D <= 0 || S <= 0 || H <= 0) {
    throw new Error('EOQ inputs must be positive');
  }
  return Math.sqrt((2 * D * S) / H);
}

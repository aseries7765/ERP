import {
  DemandLine,
  SupplyLine,
  ItemMasterMrpData,
  MrpRunOptions,
  MrpRunResult,
  PlannedOrder,
  NetRequirementResult,
} from './types';
import { buildPlanningBuckets } from './planning-buckets';
import { netRequirements, bucketize } from './netting';
import { offsetByLeadTime } from './lead-time';
import { explodeBom, BomLookup } from './boms';
import { pegDemandToSupply } from './pegging';
import { detectShortages, detectLateDeliveries } from './exceptions';

export interface MrpEngineInputs {
  items: ItemMasterMrpData[];
  demand: DemandLine[];
  supply: SupplyLine[];
  bomLookup: BomLookup;
  options: MrpRunOptions;
}

/**
 * Runs a full single-pass MRP calculation:
 *   1. Explode BOM demand for manufactured items into dependent demand on components.
 *   2. Net requirements per item per planning bucket.
 *   3. Apply lot-sizing to net requirements to produce planned order quantities.
 *   4. Offset planned orders by lead time to get start dates.
 *   5. Peg demand to supply (including newly created planned orders).
 *   6. Detect exceptions (shortages, late deliveries).
 *
 * Deterministic: given identical inputs (including options.asOfDate — the
 * caller must supply "now" explicitly, this function never reads the clock),
 * output is byte-identical every time (G18). No randomness anywhere.
 */
export function runMrp(inputs: MrpEngineInputs): MrpRunResult {
  const { items, options, bomLookup } = inputs;
  const buckets = buildPlanningBuckets(
    options.asOfDate,
    options.planningHorizonDays,
    options.bucketSizeDays,
  );

  const itemsById = new Map(items.map((i) => [i.itemId, i]));

  // Step 1: expand dependent demand from manufactured-item demand via BOM explosion.
  const allDemand: DemandLine[] = [...inputs.demand];
  for (const d of inputs.demand) {
    const item = itemsById.get(d.itemId);
    if (item?.isManufactured && item.bomId) {
      const exploded = explodeBom(item.bomId, d.qty, bomLookup);
      for (const line of exploded) {
        allDemand.push({
          itemId: line.itemId,
          qty: line.qty,
          dueDate: offsetByLeadTime(d.dueDate, item.leadTimeDays),
          source: 'dependent',
          sourceId: `${d.sourceId}::${line.itemId}`,
        });
      }
    }
  }

  // Step 2 & 3: net requirements and lot-size, per item.
  const allNetResults: NetRequirementResult[] = [];
  const plannedOrders: PlannedOrder[] = [];

  for (const item of items) {
    const demandForItem = allDemand.filter((d) => d.itemId === item.itemId);
    const supplyForItem = inputs.supply.filter((s) => s.itemId === item.itemId);

    const grossByPeriod = bucketize(
      demandForItem.map((d) => ({ qty: d.qty, date: d.dueDate })),
      buckets,
    );
    // Only open POs and open WOs are "scheduled receipts" arriving during
    // the horizon — on-hand stock is the STARTING balance (passed separately
    // below as onHandQty) and must be excluded here, or it gets counted
    // twice: once as the period-0 starting balance and again as a "receipt"
    // in whichever bucket its (arbitrary, often just "today") availableDate
    // happens to fall into. This exact double-count was caught by
    // mrp.spec.ts's "nets frame requirement" end-to-end test.
    const scheduledByPeriod = bucketize(
      supplyForItem
        .filter((s) => s.source === 'open-po' || s.source === 'open-wo')
        .map((s) => ({ qty: s.qty, date: s.availableDate })),
      buckets,
    );

    const onHand = supplyForItem
      .filter((s) => s.source === 'on-hand')
      .reduce((sum, s) => sum + s.qty, 0);

    const netResults = netRequirements({
      itemId: item.itemId,
      onHandQty: onHand,
      item,
      buckets,
      grossRequirementsByPeriod: grossByPeriod,
      scheduledReceiptsByPeriod: scheduledByPeriod,
    });

    allNetResults.push(...netResults);

    // Planned orders come from `plannedOrderReceipt`, which netRequirements()
    // already lot-sized and fed forward into subsequent periods' on-hand
    // projection — lot-sizing is intentionally NOT reapplied here, since
    // doing so a second time on the raw netRequirement would both duplicate
    // the sizing logic and produce a different (wrong) quantity than what
    // netting already assumed was replenished.
    for (const nr of netResults) {
      if (nr.plannedOrderReceipt <= 0) continue;
      const dueDate = nr.periodStart;
      const startDate = offsetByLeadTime(dueDate, item.leadTimeDays);
      plannedOrders.push({
        itemId: item.itemId,
        orderQty: nr.plannedOrderReceipt,
        dueDate,
        startDate,
        type: item.isManufactured ? 'planned-wo' : 'planned-po',
        lotSizingRuleApplied: item.lotSizingRule,
      });
    }
  }

  // Step 5: pegging (original demand + all supply including planned orders treated as supply).
  const supplyIncludingPlanned: SupplyLine[] = [
    ...inputs.supply,
    ...plannedOrders.map((po, idx) => ({
      itemId: po.itemId,
      qty: po.orderQty,
      availableDate: po.dueDate,
      source: po.type,
      sourceId: `planned-${po.itemId}-${idx}`,
    })),
  ];

  const pegging = pegDemandToSupply(allDemand, supplyIncludingPlanned);

  // Step 6: exceptions.
  const shortageExceptions = detectShortages(allNetResults);
  const supplyDateBySourceId = new Map(
    supplyIncludingPlanned.map((s) => [s.sourceId, s.availableDate]),
  );
  const lateExceptions = detectLateDeliveries(allDemand, pegging, supplyDateBySourceId);

  return {
    netRequirements: allNetResults,
    plannedOrders,
    pegging,
    exceptions: [...shortageExceptions, ...lateExceptions],
  };
}

/**
 * Core types for the MRP (Material Requirements Planning) engine.
 * All quantities/costs use `string` decimal representation at the boundary
 * (callers should use a Decimal library such as decimal.js in the host app);
 * internally this engine computes with `number` for simplicity and documents
 * that as a known limitation for extreme-precision financial roll-ups.
 */

export type ItemId = string;

export interface PlanningBucket {
  /** ISO date (YYYY-MM-DD) marking the start of the bucket (e.g. a day or week). */
  periodStart: string;
}

export interface DemandLine {
  itemId: ItemId;
  /** Quantity required. */
  qty: number;
  /** ISO date the demand is due. */
  dueDate: string;
  source: 'sales-order' | 'forecast' | 'safety-stock' | 'dependent' | 'work-order';
  sourceId: string;
}

export interface SupplyLine {
  itemId: ItemId;
  qty: number;
  /** ISO date the supply is expected/available. */
  availableDate: string;
  source: 'on-hand' | 'open-po' | 'open-wo' | 'planned-po' | 'planned-wo';
  sourceId: string;
}

export interface ItemMasterMrpData {
  itemId: ItemId;
  /** Lead time in whole days. */
  leadTimeDays: number;
  /** Lot-sizing rule. */
  lotSizingRule: 'lot-for-lot' | 'eoq' | 'poq';
  /** Required for EOQ. */
  eoqAnnualDemand?: number;
  eoqOrderCost?: number;
  eoqHoldingCostPerUnit?: number;
  /** Required for POQ (periods of supply to cover per planned order). */
  poqPeriods?: number;
  /** Whether the item is manufactured (has a BOM) or purchased. */
  isManufactured: boolean;
  bomId?: string;
  /** Safety stock quantity to always keep on hand. */
  safetyStock?: number;
}

export interface BomComponent {
  componentItemId: ItemId;
  /** Quantity of component per 1 unit of parent. */
  qtyPer: number;
  scrapPct: number;
  isPhantom: boolean;
  /** If the component is itself manufactured, its own BOM id for further explosion. */
  childBomId?: string;
}

export interface BomDefinition {
  bomId: string;
  outputItemId: ItemId;
  components: BomComponent[];
}

export interface NetRequirementResult {
  itemId: ItemId;
  periodStart: string;
  grossRequirement: number;
  scheduledReceipts: number;
  /** Projected on-hand AFTER any planned order receipt this period is applied (see plannedOrderReceipt). */
  projectedOnHand: number;
  netRequirement: number;
  /**
   * The lot-sized planned order receipt applied in this period to cover
   * netRequirement (0 if netRequirement was 0). This is carried forward into
   * projectedOnHand for this and all subsequent periods — without it, a
   * single shortfall would incorrectly re-trigger a "net requirement" in
   * every following period forever, since projectedOnHand would never
   * recover.
   */
  plannedOrderReceipt: number;
}

export interface PlannedOrder {
  itemId: ItemId;
  orderQty: number;
  /** Date the order must be available (need date). */
  dueDate: string;
  /** Due date minus lead time. */
  startDate: string;
  type: 'planned-po' | 'planned-wo';
  lotSizingRuleApplied: 'lot-for-lot' | 'eoq' | 'poq';
}

export interface PeggingLink {
  demandSourceId: string;
  demandItemId: string;
  supplySourceId: string;
  supplyItemId: string;
  qty: number;
}

export interface MrpException {
  type: 'shortage' | 'late-delivery' | 'excess-supply';
  itemId: ItemId;
  periodStart: string;
  quantity: number;
  message: string;
}

export interface MrpRunOptions {
  planningHorizonDays: number;
  /** Anchor "today" date, ISO. Required for determinism — never uses system clock internally. */
  asOfDate: string;
  bucketSizeDays: number;
}

export interface MrpRunResult {
  netRequirements: NetRequirementResult[];
  plannedOrders: PlannedOrder[];
  pegging: PeggingLink[];
  exceptions: MrpException[];
}

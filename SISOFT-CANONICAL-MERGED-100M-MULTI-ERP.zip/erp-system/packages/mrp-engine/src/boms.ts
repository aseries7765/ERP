import { BomComponent, BomDefinition, ItemId } from './types';

export interface ExplodedRequirement {
  itemId: ItemId;
  /** Total quantity required across the whole tree for the requested parent qty. */
  qty: number;
  level: number;
  isPhantom: boolean;
}

export interface BomLookup {
  getBom(bomId: string): BomDefinition | undefined;
}

/**
 * Recursively explodes a BOM for a requested output quantity into a flat list
 * of component requirements, applying scrap % at every level and aggregating
 * common components that appear at multiple levels of the tree.
 *
 * Phantom components are exploded through (their own children are pulled up
 * to the parent level) rather than generating a separate requirement line for
 * the phantom item itself, matching standard MRP phantom-BOM handling.
 */
export function explodeBom(
  bomId: string,
  requestedQty: number,
  lookup: BomLookup,
  level = 0,
  seen: Set<string> = new Set(),
): ExplodedRequirement[] {
  if (seen.has(bomId)) {
    throw new Error(`Circular BOM reference detected at bomId=${bomId}`);
  }
  const bom = lookup.getBom(bomId);
  if (!bom) throw new Error(`BOM not found: ${bomId}`);

  const nextSeen = new Set(seen);
  nextSeen.add(bomId);

  const results: ExplodedRequirement[] = [];

  for (const component of bom.components) {
    const grossQtyForComponent = requiredQtyWithScrap(component, requestedQty);

    if (component.isPhantom) {
      // Phantom: do not add a line for the phantom item itself; explode through
      // to its children at the same level (materials flow straight to parent).
      if (!component.childBomId) {
        throw new Error(
          `Phantom component ${component.componentItemId} has no childBomId to explode through`,
        );
      }
      const childResults = explodeBom(
        component.childBomId,
        grossQtyForComponent,
        lookup,
        level,
        nextSeen,
      );
      results.push(...childResults);
      continue;
    }

    results.push({
      itemId: component.componentItemId,
      qty: grossQtyForComponent,
      level: level + 1,
      isPhantom: false,
    });

    if (component.childBomId) {
      const childResults = explodeBom(
        component.childBomId,
        grossQtyForComponent,
        lookup,
        level + 1,
        nextSeen,
      );
      results.push(...childResults);
    }
  }

  return aggregateByItem(results);
}

function requiredQtyWithScrap(component: BomComponent, parentQty: number): number {
  const base = component.qtyPer * parentQty;
  if (!component.scrapPct) return base;
  return base / (1 - component.scrapPct / 100);
}

/** Aggregates common components across levels into a single line per item, keeping the shallowest level. */
function aggregateByItem(lines: ExplodedRequirement[]): ExplodedRequirement[] {
  const byItem = new Map<string, ExplodedRequirement>();
  for (const line of lines) {
    const existing = byItem.get(line.itemId);
    if (existing) {
      existing.qty += line.qty;
      existing.level = Math.min(existing.level, line.level);
    } else {
      byItem.set(line.itemId, { ...line });
    }
  }
  return Array.from(byItem.values());
}

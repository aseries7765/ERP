import { subtractDays } from './planning-buckets';

/**
 * Offsets a due (need) date backward by the item's lead time to produce the
 * order start/release date. Pure, deterministic — no clock reads (G18).
 */
export function offsetByLeadTime(dueDateIso: string, leadTimeDays: number): string {
  if (leadTimeDays < 0) throw new Error('leadTimeDays must be >= 0');
  return subtractDays(dueDateIso, leadTimeDays);
}

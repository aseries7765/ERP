import { DemandLine, SupplyLine, PeggingLink } from './types';

/**
 * Links demand lines to supply lines FIFO-by-due-date within each item,
 * consuming supply in the order it becomes available. Deterministic: ties
 * broken by stable input order (G18).
 */
export function pegDemandToSupply(demand: DemandLine[], supply: SupplyLine[]): PeggingLink[] {
  const links: PeggingLink[] = [];

  const itemIds = new Set([...demand.map((d) => d.itemId), ...supply.map((s) => s.itemId)]);

  for (const itemId of itemIds) {
    const demandForItem = demand
      .filter((d) => d.itemId === itemId)
      .slice()
      .sort((a, b) => a.dueDate.localeCompare(b.dueDate));

    const supplyForItem = supply
      .filter((s) => s.itemId === itemId)
      .slice()
      .sort((a, b) => a.availableDate.localeCompare(b.availableDate))
      .map((s) => ({ ...s, remaining: s.qty }));

    for (const d of demandForItem) {
      let remainingDemand = d.qty;
      for (const s of supplyForItem) {
        if (remainingDemand <= 0) break;
        if (s.remaining <= 0) continue;
        const consumed = Math.min(remainingDemand, s.remaining);
        if (consumed > 0) {
          links.push({
            demandSourceId: d.sourceId,
            demandItemId: d.itemId,
            supplySourceId: s.sourceId,
            supplyItemId: s.itemId,
            qty: consumed,
          });
          s.remaining -= consumed;
          remainingDemand -= consumed;
        }
      }
    }
  }

  return links;
}

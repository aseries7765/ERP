import { NetRequirementResult, PeggingLink, DemandLine, MrpException } from './types';

/**
 * Derives planning exceptions from netting results and pegging:
 * - shortage: a period ends with negative-would-be coverage (net requirement > 0
 *   and no planned order will be raised in time — flagged here at the netting
 *   stage as a raw shortage signal; the caller decides whether a planned order
 *   resolves it).
 * - late-delivery: a demand line's full quantity could not be pegged to any
 *   supply arriving on or before its due date.
 */
export function detectShortages(netResults: NetRequirementResult[]): MrpException[] {
  return netResults
    .filter((r) => r.netRequirement > 0)
    .map((r) => ({
      type: 'shortage' as const,
      itemId: r.itemId,
      periodStart: r.periodStart,
      quantity: r.netRequirement,
      message: `Item ${r.itemId}: shortage of ${r.netRequirement} in period ${r.periodStart}`,
    }));
}

export function detectLateDeliveries(
  demand: DemandLine[],
  pegging: PeggingLink[],
  supplyAvailableDateBySourceId: Map<string, string>,
): MrpException[] {
  const exceptions: MrpException[] = [];

  for (const d of demand) {
    const linksForDemand = pegging.filter((p) => p.demandSourceId === d.sourceId);
    const totalPegged = linksForDemand.reduce((sum, l) => sum + l.qty, 0);

    if (totalPegged < d.qty) {
      exceptions.push({
        type: 'shortage',
        itemId: d.itemId,
        periodStart: d.dueDate,
        quantity: d.qty - totalPegged,
        message: `Demand ${d.sourceId} for item ${d.itemId} under-covered by ${d.qty - totalPegged}`,
      });
      continue;
    }

    const latestSupplyDate = linksForDemand.reduce<string | null>((latest, l) => {
      const availDate = supplyAvailableDateBySourceId.get(l.supplySourceId);
      if (!availDate) return latest;
      if (!latest || availDate > latest) return availDate;
      return latest;
    }, null);

    if (latestSupplyDate && latestSupplyDate > d.dueDate) {
      exceptions.push({
        type: 'late-delivery',
        itemId: d.itemId,
        periodStart: d.dueDate,
        quantity: totalPegged,
        message: `Demand ${d.sourceId} for item ${d.itemId} covered late (${latestSupplyDate} > due ${d.dueDate})`,
      });
    }
  }

  return exceptions;
}

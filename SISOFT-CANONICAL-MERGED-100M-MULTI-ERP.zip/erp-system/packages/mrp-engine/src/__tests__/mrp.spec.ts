import { describe, it, expect } from 'vitest';
import { runMrp } from '../mrp';
import { explodeBom, BomLookup } from '../boms';
import { ItemMasterMrpData, DemandLine, SupplyLine, BomDefinition } from '../types';

const boms: Record<string, BomDefinition> = {
  'BOM-BIKE': {
    bomId: 'BOM-BIKE',
    outputItemId: 'BIKE',
    components: [
      { componentItemId: 'FRAME', qtyPer: 1, scrapPct: 0, isPhantom: false },
      { componentItemId: 'WHEEL-SET', qtyPer: 1, scrapPct: 0, isPhantom: true, childBomId: 'BOM-WHEELSET' },
    ],
  },
  'BOM-WHEELSET': {
    bomId: 'BOM-WHEELSET',
    outputItemId: 'WHEEL-SET',
    components: [{ componentItemId: 'WHEEL', qtyPer: 2, scrapPct: 5, isPhantom: false }],
  },
};

const lookup: BomLookup = { getBom: (id) => boms[id] };

describe('explodeBom', () => {
  it('explodes multi-level BOMs, pulling phantom children up to the parent level', () => {
    const result = explodeBom('BOM-BIKE', 10, lookup);
    const frame = result.find((r) => r.itemId === 'FRAME');
    const wheel = result.find((r) => r.itemId === 'WHEEL');
    const phantomLine = result.find((r) => r.itemId === 'WHEEL-SET');

    expect(frame?.qty).toBe(10);
    // 2 wheels per wheel-set, 10 wheel-sets needed, 5% scrap -> 20 / 0.95
    expect(wheel?.qty).toBeCloseTo(20 / 0.95, 5);
    expect(phantomLine).toBeUndefined(); // phantom itself never appears as a line
  });

  it('throws on circular BOM references instead of infinite-looping', () => {
    const circular: Record<string, BomDefinition> = {
      A: { bomId: 'A', outputItemId: 'A', components: [{ componentItemId: 'B', qtyPer: 1, scrapPct: 0, isPhantom: false, childBomId: 'B' }] },
      B: { bomId: 'B', outputItemId: 'B', components: [{ componentItemId: 'A', qtyPer: 1, scrapPct: 0, isPhantom: false, childBomId: 'A' }] },
    };
    const circularLookup: BomLookup = { getBom: (id) => circular[id] };
    expect(() => explodeBom('A', 1, circularLookup)).toThrow(/Circular/);
  });
});

describe('runMrp (end-to-end)', () => {
  const items: ItemMasterMrpData[] = [
    { itemId: 'BIKE', leadTimeDays: 3, lotSizingRule: 'lot-for-lot', isManufactured: true, bomId: 'BOM-BIKE' },
    { itemId: 'FRAME', leadTimeDays: 5, lotSizingRule: 'lot-for-lot', isManufactured: false },
    { itemId: 'WHEEL', leadTimeDays: 2, lotSizingRule: 'lot-for-lot', isManufactured: false },
  ];

  const demand: DemandLine[] = [
    { itemId: 'BIKE', qty: 10, dueDate: '2026-03-01', source: 'sales-order', sourceId: 'SO-100' },
  ];

  const supply: SupplyLine[] = [
    { itemId: 'FRAME', qty: 2, availableDate: '2026-01-01', source: 'on-hand', sourceId: 'STOCK-FRAME' },
  ];

  function run() {
    return runMrp({
      items,
      demand,
      supply,
      bomLookup: lookup,
      options: { planningHorizonDays: 90, asOfDate: '2026-01-01', bucketSizeDays: 7 },
    });
  }

  it('is fully deterministic across repeated runs with identical input', () => {
    const a = run();
    const b = run();
    expect(a).toEqual(b);
  });

  it('generates a planned WO for the manufactured end item and planned POs for purchased components', () => {
    const result = run();
    const bikeOrder = result.plannedOrders.find((o) => o.itemId === 'BIKE');
    const wheelOrder = result.plannedOrders.find((o) => o.itemId === 'WHEEL');

    expect(bikeOrder?.type).toBe('planned-wo');
    expect(wheelOrder?.type).toBe('planned-po');
  });

  it('offsets planned order start dates by lead time from the due date', () => {
    const result = run();
    const bikeOrder = result.plannedOrders.find((o) => o.itemId === 'BIKE');
    expect(bikeOrder).toBeDefined();
    if (bikeOrder) {
      const due = new Date(bikeOrder.dueDate);
      const start = new Date(bikeOrder.startDate);
      const diffDays = (due.getTime() - start.getTime()) / 86400000;
      expect(diffDays).toBe(3);
    }
  });

  it('nets frame requirement against existing on-hand stock exactly once, not repeatedly every period', () => {
    const result = run();
    const frameResults = result.netRequirements.filter((r) => r.itemId === 'FRAME');
    const periodsWithNet = frameResults.filter((r) => r.netRequirement > 0);

    // 10 needed, 2 on hand -> net 8, in exactly ONE period. This is a
    // regression guard: an earlier version of netRequirements() failed to
    // feed the planned order receipt forward into subsequent periods'
    // on-hand projection, causing the same 8-unit shortfall to reappear in
    // every period after the due date for the rest of the horizon.
    expect(periodsWithNet).toHaveLength(1);
    expect(periodsWithNet[0]!.netRequirement).toBe(8);

    const totalNet = frameResults.reduce((s, r) => s + r.netRequirement, 0);
    expect(totalNet).toBe(8);
  });
});

import { describe, it, expect } from 'vitest';
import { pegDemandToSupply } from '../pegging';
import { DemandLine, SupplyLine } from '../types';

describe('pegDemandToSupply', () => {
  it('pegs demand to supply FIFO by availability date, splitting across multiple supplies', () => {
    const demand: DemandLine[] = [
      { itemId: 'A', qty: 30, dueDate: '2026-01-10', source: 'sales-order', sourceId: 'SO-1' },
    ];
    const supply: SupplyLine[] = [
      { itemId: 'A', qty: 10, availableDate: '2026-01-05', source: 'on-hand', sourceId: 'STOCK-1' },
      { itemId: 'A', qty: 25, availableDate: '2026-01-08', source: 'open-po', sourceId: 'PO-1' },
    ];

    const links = pegDemandToSupply(demand, supply);
    expect(links).toHaveLength(2);
    expect(links[0]).toMatchObject({ supplySourceId: 'STOCK-1', qty: 10 });
    expect(links[1]).toMatchObject({ supplySourceId: 'PO-1', qty: 20 });
  });

  it('handles multiple demand lines competing for the same supply, oldest due date first', () => {
    const demand: DemandLine[] = [
      { itemId: 'A', qty: 15, dueDate: '2026-01-20', source: 'sales-order', sourceId: 'SO-2' },
      { itemId: 'A', qty: 15, dueDate: '2026-01-10', source: 'sales-order', sourceId: 'SO-1' },
    ];
    const supply: SupplyLine[] = [
      { itemId: 'A', qty: 20, availableDate: '2026-01-01', source: 'on-hand', sourceId: 'STOCK-1' },
    ];

    const links = pegDemandToSupply(demand, supply);
    const forSo1 = links.filter((l) => l.demandSourceId === 'SO-1').reduce((s, l) => s + l.qty, 0);
    const forSo2 = links.filter((l) => l.demandSourceId === 'SO-2').reduce((s, l) => s + l.qty, 0);
    expect(forSo1).toBe(15); // earlier due date served fully first
    expect(forSo2).toBe(5); // remainder
  });

  it('leaves demand unpegged (no link) when there is no supply for the item', () => {
    const demand: DemandLine[] = [
      { itemId: 'B', qty: 5, dueDate: '2026-01-10', source: 'sales-order', sourceId: 'SO-3' },
    ];
    const links = pegDemandToSupply(demand, []);
    expect(links).toHaveLength(0);
  });
});

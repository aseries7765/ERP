import { describe, it, expect } from 'vitest';
import { detectShortages, detectLateDeliveries } from '../exceptions';
import { NetRequirementResult, DemandLine, PeggingLink } from '../types';

describe('detectShortages', () => {
  it('flags any period with a positive net requirement', () => {
    const results: NetRequirementResult[] = [
      { itemId: 'A', periodStart: '2026-01-01', grossRequirement: 10, scheduledReceipts: 0, projectedOnHand: 0, netRequirement: 0, plannedOrderReceipt: 0 },
      { itemId: 'A', periodStart: '2026-01-08', grossRequirement: 10, scheduledReceipts: 0, projectedOnHand: -5, netRequirement: 5, plannedOrderReceipt: 0 },
    ];
    const exceptions = detectShortages(results);
    expect(exceptions).toHaveLength(1);
    expect(exceptions[0]!.periodStart).toBe('2026-01-08');
  });
});

describe('detectLateDeliveries', () => {
  it('flags a demand line whose pegged supply arrives after its due date', () => {
    const demand: DemandLine[] = [
      { itemId: 'A', qty: 10, dueDate: '2026-01-10', source: 'sales-order', sourceId: 'SO-1' },
    ];
    const pegging: PeggingLink[] = [
      { demandSourceId: 'SO-1', demandItemId: 'A', supplySourceId: 'PO-1', supplyItemId: 'A', qty: 10 },
    ];
    const availDates = new Map([['PO-1', '2026-01-15']]);

    const exceptions = detectLateDeliveries(demand, pegging, availDates);
    expect(exceptions).toHaveLength(1);
    expect(exceptions[0]!.type).toBe('late-delivery');
  });

  it('flags a demand line as a shortage when it is only partially pegged', () => {
    const demand: DemandLine[] = [
      { itemId: 'A', qty: 10, dueDate: '2026-01-10', source: 'sales-order', sourceId: 'SO-1' },
    ];
    const pegging: PeggingLink[] = [
      { demandSourceId: 'SO-1', demandItemId: 'A', supplySourceId: 'PO-1', supplyItemId: 'A', qty: 4 },
    ];
    const availDates = new Map([['PO-1', '2026-01-05']]);

    const exceptions = detectLateDeliveries(demand, pegging, availDates);
    expect(exceptions).toHaveLength(1);
    expect(exceptions[0]!.type).toBe('shortage');
    expect(exceptions[0]!.quantity).toBe(6);
  });

  it('does not flag a demand line fully covered on time', () => {
    const demand: DemandLine[] = [
      { itemId: 'A', qty: 10, dueDate: '2026-01-10', source: 'sales-order', sourceId: 'SO-1' },
    ];
    const pegging: PeggingLink[] = [
      { demandSourceId: 'SO-1', demandItemId: 'A', supplySourceId: 'PO-1', supplyItemId: 'A', qty: 10 },
    ];
    const availDates = new Map([['PO-1', '2026-01-05']]);

    const exceptions = detectLateDeliveries(demand, pegging, availDates);
    expect(exceptions).toHaveLength(0);
  });
});

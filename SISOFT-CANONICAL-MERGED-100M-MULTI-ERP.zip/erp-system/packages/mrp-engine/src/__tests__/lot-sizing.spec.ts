import { describe, it, expect } from 'vitest';
import { applyLotSizing, calculateEoq } from '../lot-sizing';
import { ItemMasterMrpData } from '../types';

const base: ItemMasterMrpData = {
  itemId: 'I1',
  leadTimeDays: 5,
  lotSizingRule: 'lot-for-lot',
  isManufactured: false,
};

describe('applyLotSizing', () => {
  it('lot-for-lot orders exactly the net requirement', () => {
    expect(applyLotSizing(37, base)).toBe(37);
  });

  it('returns 0 for non-positive net requirement', () => {
    expect(applyLotSizing(0, base)).toBe(0);
    expect(applyLotSizing(-5, base)).toBe(0);
  });

  it('eoq orders the larger of EOQ and net requirement', () => {
    const item: ItemMasterMrpData = {
      ...base,
      lotSizingRule: 'eoq',
      eoqAnnualDemand: 10000,
      eoqOrderCost: 50,
      eoqHoldingCostPerUnit: 2,
    };
    // EOQ = sqrt(2*10000*50/2) = sqrt(500000) ≈ 707.10678
    const eoq = calculateEoq(item);
    expect(eoq).toBeCloseTo(707.1068, 3);

    // net requirement below EOQ -> order EOQ
    expect(applyLotSizing(100, item)).toBeCloseTo(eoq, 3);
    // net requirement above EOQ -> order net requirement
    expect(applyLotSizing(1000, item)).toBe(1000);
  });

  it('poq scales net requirement by number of periods to cover', () => {
    const item: ItemMasterMrpData = { ...base, lotSizingRule: 'poq', poqPeriods: 3 };
    expect(applyLotSizing(20, item)).toBe(60);
  });

  it('throws on unknown lot sizing rule', () => {
    const bad = { ...base, lotSizingRule: 'bogus' as any };
    expect(() => applyLotSizing(10, bad)).toThrow();
  });

  it('eoq calculation throws when required inputs are missing', () => {
    const item: ItemMasterMrpData = { ...base, lotSizingRule: 'eoq' };
    expect(() => calculateEoq(item)).toThrow();
  });
});

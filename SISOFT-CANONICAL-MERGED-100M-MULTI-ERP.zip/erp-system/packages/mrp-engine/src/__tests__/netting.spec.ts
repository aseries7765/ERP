import { describe, it, expect } from 'vitest';
import { netRequirements, bucketize } from '../netting';
import { buildPlanningBuckets } from '../planning-buckets';
import { ItemMasterMrpData } from '../types';

const lotForLotItem: ItemMasterMrpData = {
  itemId: 'ITEM-1',
  leadTimeDays: 5,
  lotSizingRule: 'lot-for-lot',
  isManufactured: false,
  safetyStock: 10,
};

describe('netRequirements', () => {
  it('carries projected on-hand forward across periods and nets against safety stock', () => {
    const buckets = buildPlanningBuckets('2026-01-01', 21, 7); // 3 weekly buckets
    const gross = new Map([
      ['2026-01-01', 50],
      ['2026-01-08', 30],
      ['2026-01-15', 40],
    ]);
    const scheduled = new Map([['2026-01-08', 20]]);

    const results = netRequirements({
      itemId: 'ITEM-1',
      onHandQty: 60,
      item: lotForLotItem,
      buckets,
      grossRequirementsByPeriod: gross,
      scheduledReceiptsByPeriod: scheduled,
    });

    expect(results).toHaveLength(3);

    // Period 1: 60 - 50 + 0 = 10 -> exactly at safety stock, net = 0, no planned receipt
    expect(results[0]!.projectedOnHand).toBe(10);
    expect(results[0]!.netRequirement).toBe(0);
    expect(results[0]!.plannedOrderReceipt).toBe(0);

    // Period 2: 10 - 30 + 20 = 0 -> shortfall vs safety stock 10 -> net = 10,
    // lot-for-lot plans a receipt of exactly 10, so on-hand recovers to 10.
    expect(results[1]!.netRequirement).toBe(10);
    expect(results[1]!.plannedOrderReceipt).toBe(10);
    expect(results[1]!.projectedOnHand).toBe(10);

    // Period 3: 10 - 40 + 0 = -30 -> shortfall vs safety stock 10 -> net = 40,
    // lot-for-lot plans a receipt of exactly 40, on-hand recovers to 10 again
    // (NOT a repeat of period 2's shortfall — this is the regression this
    // test guards against: without feeding the planned receipt forward, this
    // period would incorrectly still show the period-2 shortfall lingering).
    expect(results[2]!.netRequirement).toBe(40);
    expect(results[2]!.plannedOrderReceipt).toBe(40);
    expect(results[2]!.projectedOnHand).toBe(10);
  });

  it('does NOT re-trigger a net requirement in periods after a shortfall has been covered by a planned receipt', () => {
    const buckets = buildPlanningBuckets('2026-01-01', 21, 7);
    const gross = new Map([['2026-01-01', 20]]); // shortfall only in period 1
    const scheduled = new Map<string, number>();

    const results = netRequirements({
      itemId: 'ITEM-1',
      onHandQty: 5,
      item: lotForLotItem,
      buckets,
      grossRequirementsByPeriod: gross,
      scheduledReceiptsByPeriod: scheduled,
    });

    // Period 1: 5 - 20 + 0 = -15 -> shortfall vs safety stock 10 -> net = 25, receipt = 25, on-hand -> 10
    expect(results[0]!.netRequirement).toBe(25);
    expect(results[0]!.projectedOnHand).toBe(10);

    // Periods 2 and 3 have no further gross requirement, so on-hand stays at
    // safety stock and net requirement must be exactly 0 — this is the bug
    // this test guards against (previously it incorrectly repeated 25 or a
    // similar nonzero value in every subsequent period).
    expect(results[1]!.netRequirement).toBe(0);
    expect(results[1]!.plannedOrderReceipt).toBe(0);
    expect(results[2]!.netRequirement).toBe(0);
    expect(results[2]!.plannedOrderReceipt).toBe(0);
  });

  it('is deterministic: same input always yields the same output', () => {
    const buckets = buildPlanningBuckets('2026-02-01', 14, 7);
    const gross = new Map([['2026-02-01', 5]]);
    const scheduled = new Map<string, number>();
    const item: ItemMasterMrpData = { ...lotForLotItem, safetyStock: 0 };
    const input = {
      itemId: 'X',
      onHandQty: 5,
      item,
      buckets,
      grossRequirementsByPeriod: gross,
      scheduledReceiptsByPeriod: scheduled,
    };
    const a = netRequirements(input);
    const b = netRequirements(input);
    expect(a).toEqual(b);
  });
});

describe('bucketize', () => {
  it('groups lines into the correct bucket by date', () => {
    const buckets = buildPlanningBuckets('2026-01-01', 21, 7);
    const map = bucketize(
      [
        { qty: 10, date: '2026-01-03' },
        { qty: 5, date: '2026-01-09' },
        { qty: 7, date: '2026-01-01' },
      ],
      buckets,
    );
    expect(map.get('2026-01-01')).toBe(17);
    expect(map.get('2026-01-08')).toBe(5);
  });
});

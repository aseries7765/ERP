export { AiHttpClient, AiClientError } from './client';
export type { AiClientConfig } from './client';
export { ChatClient } from './chat';
export { NlQueryClient } from './nl-query';
export { HooksClient } from './hooks';
export { streamChat } from './streaming';
export type { StreamHandlers } from './streaming';

import { AiHttpClient, type AiClientConfig } from './client';
import { ChatClient } from './chat';
import { NlQueryClient } from './nl-query';
import { HooksClient } from './hooks';

/** Convenience facade bundling the implemented sub-clients. */
export class AiClient {
  readonly chat: ChatClient;
  readonly nlQuery: NlQueryClient;
  readonly hooks: HooksClient;

  constructor(config: AiClientConfig) {
    const http = new AiHttpClient(config);
    this.chat = new ChatClient(http);
    this.nlQuery = new NlQueryClient(http);
    this.hooks = new HooksClient(http);
  }
}

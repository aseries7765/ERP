import type { NlQueryRequestDto, NlQueryResponseDto } from '@erp/shared-types/ai';
import type { AiHttpClient } from './client';

export class NlQueryClient {
  constructor(private readonly http: AiHttpClient) {}

  async ask(req: NlQueryRequestDto): Promise<NlQueryResponseDto> {
    return this.http.post<NlQueryResponseDto>('/v1/ai/nl-query', req);
  }
}

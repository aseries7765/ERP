import type { ChatRequestDto, ChatResponseDto } from '@erp/shared-types/ai';
import type { AiHttpClient } from './client';

/**
 * NOTE: this calls the non-streaming /v1/ai/chat/message endpoint.
 * True SSE streaming from the browser (the spec's "Streaming (SSE) for
 * chat") is implemented separately in streaming.ts's design but the
 * NestJS proxy side isn't wired for it yet — see MANIFEST.md. Use this
 * for a request/response chat call in the meantime.
 */
export class ChatClient {
  constructor(private readonly http: AiHttpClient) {}

  async sendMessage(req: ChatRequestDto): Promise<ChatResponseDto> {
    return this.http.post<ChatResponseDto>('/v1/ai/chat/message', req);
  }
}

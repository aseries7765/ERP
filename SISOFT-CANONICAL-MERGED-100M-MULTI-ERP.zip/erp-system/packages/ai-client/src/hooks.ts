import type { LeadScoreRequestDto, LeadScoreResponseDto } from '@erp/shared-types/ai';
import type { AiHttpClient } from './client';

/** Only lead-score is implemented end-to-end — see MANIFEST.md. */
export class HooksClient {
  constructor(private readonly http: AiHttpClient) {}

  async leadScore(req: LeadScoreRequestDto): Promise<LeadScoreResponseDto> {
    return this.http.post<LeadScoreResponseDto>('/v1/ai/hooks/lead-score', req);
  }
}

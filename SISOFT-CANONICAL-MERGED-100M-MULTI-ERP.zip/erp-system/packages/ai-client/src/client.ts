export interface AiClientConfig {
  baseUrl: string; // e.g. https://api.tenant.example.com
  getAuthHeaders: () => Record<string, string>;
}

export class AiClientError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
  }
}

/**
 * Thin fetch-based HTTP client. Deliberately has no dependency on axios
 * or any specific framework so it can run in the browser (apps/web) or
 * Node.
 */
export class AiHttpClient {
  constructor(private readonly config: AiClientConfig) {}

  async post<TResponse>(path: string, body: unknown): Promise<TResponse> {
    const res = await fetch(`${this.config.baseUrl}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...this.config.getAuthHeaders() },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => res.statusText);
      throw new AiClientError(text, res.status);
    }
    return (await res.json()) as TResponse;
  }

  async get<TResponse>(path: string): Promise<TResponse> {
    const res = await fetch(`${this.config.baseUrl}${path}`, {
      headers: this.config.getAuthHeaders(),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => res.statusText);
      throw new AiClientError(text, res.status);
    }
    return (await res.json()) as TResponse;
  }
}

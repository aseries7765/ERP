/**
 * SSE client for streaming chat. The shape below is what the frontend
 * should use once the NestJS proxy supports piping the Python service's
 * SSE stream through (see ai-proxy.service.ts's documented gap). It is
 * NOT functional end-to-end yet: the browser can open this EventSource
 * against the Python service directly in local dev (it *does* emit real
 * SSE — apps/ai/routers/chat.py works stand-alone), but not through the
 * NestJS proxy, which is where auth/budget/audit enforcement lives.
 * Do not ship this to production against a tenant's real NestJS
 * deployment until the proxy-side piping is built. See MANIFEST.md.
 */
export interface StreamHandlers {
  onChunk: (text: string) => void;
  onDone: () => void;
  onError: (message: string) => void;
}

export function streamChat(url: string, handlers: StreamHandlers): () => void {
  const source = new EventSource(url);
  source.onmessage = (event) => handlers.onChunk(event.data);
  source.addEventListener('done', () => {
    handlers.onDone();
    source.close();
  });
  source.addEventListener('error', (event: any) => {
    handlers.onError(event?.data ?? 'stream error');
    source.close();
  });
  return () => source.close();
}

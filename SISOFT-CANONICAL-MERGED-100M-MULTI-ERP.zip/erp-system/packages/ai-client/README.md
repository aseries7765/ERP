# @erp/ai-client

Client SDK for the ERP AI service, calling the NestJS `/v1/ai/*` proxy
(never the Python service directly from a browser).

## Implemented
- `AiClient.chat.sendMessage()` — request/response chat (not streaming)
- `AiClient.nlQuery.ask()` — natural-language-to-SQL
- `AiClient.hooks.leadScore()` — lead scoring hook

## Not implemented (see root MANIFEST.md)
- Streaming chat through the NestJS proxy (`streaming.ts` documents the
  intended shape; it is wired to work against the Python service
  directly in local dev only)
- All other feature clients (document, forecast, anomaly, recommend,
  translate, sentiment, generate, voice, embed, code) and hook clients
  beyond lead-score

## Usage

```ts
import { AiClient } from '@erp/ai-client';

const client = new AiClient({
  baseUrl: 'https://api.example.com',
  getAuthHeaders: () => ({ Authorization: `Bearer ${token}` }),
});

const result = await client.chat.sendMessage({ message: 'Show me overdue invoices' });
```

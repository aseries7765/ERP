# @erp/version-engine

Pure-logic version management: semver comparison, compatibility-matrix checking
(including multi-step upgrade path resolution), deprecation lifecycle math,
version diffing, and a customer version-pinning registry.

No I/O, no DB, no network — this package is deliberately dependency-free so it's
cheap to unit test and safe to embed in both the API (NestJS `version` module)
and any CLI/ops tooling.

## Modules
- `semver.ts` — parse/compare/range-check semver strings (no external semver dep).
- `compatibility.ts` — `checkCompatibility()`: given a customer's current version,
  a target version, and the full version registry, decides direct-vs-multi-step
  upgrade eligibility, plan-tier feature gating, and resource-requirement checks.
- `deprecation.ts` — lifecycle status (`active`/`deprecated`/`retired`) as of a
  given policy (default: 12mo support, deprecate at 12mo, retire at 18mo,
  security backports for the last 3 minor versions) plus notification scheduling.
- `diff.ts` — structural diff between two version records (added/removed
  features, new security patches, API/DB schema changes).
- `pinning.ts` — `VersionPinRegistry`: decision logic for whether a pin should
  block a given deployment (with a security-patch override).

## Test status
42/42 unit tests passing (`npm test`, uses Node's built-in test runner via `tsx`).
TypeScript strict mode, zero errors, zero `any`.

## Not included here
Persistence (Prisma), HTTP endpoints, and event publishing live in
`apps/api/src/modules/version/*`, which imports this package.

import { Version, VersionDiff } from './types';

/** Computes a structured diff between two version records (from -> to). */
export function diffVersions(from: Version, to: Version): VersionDiff {
  const fromFeatures = new Set(from.features);
  const toFeatures = new Set(to.features);

  const addedFeatures = to.features.filter((f) => !fromFeatures.has(f));
  const removedFeatures = from.features.filter((f) => !toFeatures.has(f));

  const fromPatches = new Set(from.securityPatches);
  const newSecurityPatches = to.securityPatches.filter((p) => !fromPatches.has(p));

  return {
    fromVersion: from.id,
    toVersion: to.id,
    breakingChanges: to.breakingChanges,
    migrationRequired: to.migrationRequired,
    addedFeatures,
    removedFeatures,
    securityPatches: newSecurityPatches,
    apiVersionChanged: from.apiVersion !== to.apiVersion,
    dbSchemaChanged: from.dbSchemaVersion !== to.dbSchemaVersion,
  };
}

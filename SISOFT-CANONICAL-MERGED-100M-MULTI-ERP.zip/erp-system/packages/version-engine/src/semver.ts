import { SemVer } from './types';

const SEMVER_RE = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/;

/**
 * Parses a semver string ("1.5.0" or "1.5.0-beta.1") into its components.
 * Throws if the string does not match strict semver (major.minor.patch[-prerelease]).
 */
export function parseSemVer(input: string): SemVer {
  const match = SEMVER_RE.exec(input.trim());
  if (!match) {
    throw new Error(`Invalid semver string: "${input}"`);
  }
  const [, major, minor, patch, prerelease] = match;
  return {
    major: Number(major),
    minor: Number(minor),
    patch: Number(patch),
    prerelease,
  };
}

/** True if `input` is a syntactically valid semver string (major.minor.patch[-prerelease]). */
export function isValidSemVer(input: string): boolean {
  try {
    parseSemVer(input);
    return true;
  } catch {
    return false;
  }
}

function comparePrerelease(a?: string, b?: string): number {
  // No prerelease > has prerelease (release > pre-release), per semver spec.
  if (a === undefined && b === undefined) return 0;
  if (a === undefined) return 1;
  if (b === undefined) return -1;
  const aParts = a.split('.');
  const bParts = b.split('.');
  const len = Math.max(aParts.length, bParts.length);
  for (let i = 0; i < len; i++) {
    const ai = aParts[i];
    const bi = bParts[i];
    if (ai === undefined) return -1;
    if (bi === undefined) return 1;
    const aNum = Number(ai);
    const bNum = Number(bi);
    const aIsNum = !Number.isNaN(aNum) && /^\d+$/.test(ai);
    const bIsNum = !Number.isNaN(bNum) && /^\d+$/.test(bi);
    if (aIsNum && bIsNum) {
      if (aNum !== bNum) return aNum < bNum ? -1 : 1;
    } else {
      if (ai !== bi) return ai < bi ? -1 : 1;
    }
  }
  return 0;
}

/**
 * Compares two semver strings. Returns -1 if a<b, 0 if equal, 1 if a>b.
 */
export function compareSemVer(a: string, b: string): -1 | 0 | 1 {
  const pa = parseSemVer(a);
  const pb = parseSemVer(b);
  if (pa.major !== pb.major) return pa.major < pb.major ? -1 : 1;
  if (pa.minor !== pb.minor) return pa.minor < pb.minor ? -1 : 1;
  if (pa.patch !== pb.patch) return pa.patch < pb.patch ? -1 : 1;
  const preCmp = comparePrerelease(pa.prerelease, pb.prerelease);
  if (preCmp !== 0) return preCmp as -1 | 1;
  return 0;
}

/** True if a > b. */
export function gt(a: string, b: string): boolean {
  return compareSemVer(a, b) === 1;
}
/** True if a >= b. */
export function gte(a: string, b: string): boolean {
  return compareSemVer(a, b) >= 0;
}
/** True if a < b. */
export function lt(a: string, b: string): boolean {
  return compareSemVer(a, b) === -1;
}
/** True if a <= b. */
export function lte(a: string, b: string): boolean {
  return compareSemVer(a, b) <= 0;
}
/** True if a === b (ignoring which prerelease-equal representation was used). */
export function eq(a: string, b: string): boolean {
  return compareSemVer(a, b) === 0;
}

/** True if `target` is within [min, max] inclusive. min/max may be omitted (open range). */
export function inRange(target: string, min?: string, max?: string): boolean {
  if (min && lt(target, min)) return false;
  if (max && gt(target, max)) return false;
  return true;
}

/** True if bumping from `from` to `to` is a major version bump (potentially breaking). */
export function isMajorBump(from: string, to: string): boolean {
  const pf = parseSemVer(from);
  const pt = parseSemVer(to);
  return pt.major > pf.major;
}

/** True if bumping from `from` to `to` is a minor version bump within the same major line. */
export function isMinorBump(from: string, to: string): boolean {
  const pf = parseSemVer(from);
  const pt = parseSemVer(to);
  return pt.major === pf.major && pt.minor > pf.minor;
}

/** True if bumping from `from` to `to` is a patch-only bump within the same major.minor line. */
export function isPatchBump(from: string, to: string): boolean {
  const pf = parseSemVer(from);
  const pt = parseSemVer(to);
  return pt.major === pf.major && pt.minor === pf.minor && pt.patch > pf.patch;
}

/** Sorts a list of semver strings in ascending order. Does not mutate the input array. */
export function sortVersionsAscending(versions: string[]): string[] {
  return [...versions].sort(compareSemVer);
}

import { DeprecationPolicy, Version } from './types';

/** Default deprecation policy: 12mo support, deprecate at 12mo, retire at 18mo, backport security patches to the last 3 minor versions. */
export const DEFAULT_DEPRECATION_POLICY: DeprecationPolicy = {
  supportMonths: 12,
  deprecationWarningMonths: 12,
  retirementMonths: 18,
  securityBackportMinorVersions: 3,
  notificationSchedule: [
    { monthsBeforeDeprecation: 6, urgency: 'info' },
    { monthsBeforeDeprecation: 3, urgency: 'warning' },
    { monthsBeforeDeprecation: 1, urgency: 'urgent' },
  ],
};

function addMonths(date: Date, months: number): Date {
  const d = new Date(date.getTime());
  d.setUTCMonth(d.getUTCMonth() + months);
  return d;
}

/** Where a version currently sits in its support lifecycle. */
export type VersionLifecycleStatus = 'active' | 'deprecated' | 'retired';

/** Computes the lifecycle status of a version as of `now`, given a policy and its release date. */
export function computeLifecycleStatus(
  version: Pick<Version, 'releasedAt' | 'deprecatedAt' | 'retiredAt'>,
  now: Date,
  policy: DeprecationPolicy = DEFAULT_DEPRECATION_POLICY,
): VersionLifecycleStatus {
  if (version.retiredAt && now >= new Date(version.retiredAt)) return 'retired';
  if (version.deprecatedAt && now >= new Date(version.deprecatedAt)) return 'deprecated';

  const released = new Date(version.releasedAt);
  const retirementDate = addMonths(released, policy.retirementMonths);
  const deprecationDate = addMonths(released, policy.deprecationWarningMonths);

  if (now >= retirementDate) return 'retired';
  if (now >= deprecationDate) return 'deprecated';
  return 'active';
}

/** Returns the deprecation and retirement dates a version would have under a given policy. */
export function computeLifecycleDates(
  releasedAt: string,
  policy: DeprecationPolicy = DEFAULT_DEPRECATION_POLICY,
): { deprecationDate: Date; retirementDate: Date } {
  const released = new Date(releasedAt);
  return {
    deprecationDate: addMonths(released, policy.deprecationWarningMonths),
    retirementDate: addMonths(released, policy.retirementMonths),
  };
}

/** One scheduled customer notification checkpoint ahead of (or at) deprecation. */
export interface NotificationDue {
  urgency: 'info' | 'warning' | 'urgent' | 'final';
  dueAt: Date;
}

/**
 * Given a deprecation date and policy, computes the notification checkpoints
 * (as absolute dates) that should fire before deprecation, plus a "final" one
 * at the deprecation date itself.
 */
export function computeNotificationSchedule(
  deprecationDate: Date,
  policy: DeprecationPolicy = DEFAULT_DEPRECATION_POLICY,
): NotificationDue[] {
  const notifications: NotificationDue[] = policy.notificationSchedule.map((entry) => ({
    urgency: entry.urgency,
    dueAt: addMonths(deprecationDate, -entry.monthsBeforeDeprecation),
  }));
  notifications.push({ urgency: 'final', dueAt: deprecationDate });
  return notifications.sort((a, b) => a.dueAt.getTime() - b.dueAt.getTime());
}

/**
 * Determines whether `candidateVersion` should receive backported security patches,
 * i.e. it's one of the last N minor versions within its major line, relative to `latestVersion`.
 * Both inputs are full version ids like "1.5.2"; only major.minor is considered for the window.
 */
export function isWithinSecurityBackportWindow(
  candidateVersion: string,
  latestVersion: string,
  policy: DeprecationPolicy = DEFAULT_DEPRECATION_POLICY,
): boolean {
  const [cMajor, cMinor] = candidateVersion.split('.').map(Number);
  const [lMajor, lMinor] = latestVersion.split('.').map(Number);
  if (cMajor !== lMajor) return false;
  const distance = lMinor - cMinor;
  return distance >= 0 && distance < policy.securityBackportMinorVersions;
}

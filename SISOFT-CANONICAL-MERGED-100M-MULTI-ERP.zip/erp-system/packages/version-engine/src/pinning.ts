import { PinRecord } from './types';

/**
 * In-memory pin registry. In production this is backed by the CustomerVersion
 * row in the control-plane DB (see apps/api/prisma/deployment-models.prisma);
 * this class holds the pure decision logic so it can be unit tested without a DB.
 */
export class VersionPinRegistry {
  private pins = new Map<string, PinRecord>();

  pin(record: PinRecord): void {
    if (record.expiresAt && new Date(record.expiresAt) <= new Date(record.pinnedAt)) {
      throw new Error('expiresAt must be after pinnedAt');
    }
    this.pins.set(record.customerId, record);
  }

  unpin(customerId: string): boolean {
    return this.pins.delete(customerId);
  }

  /** Returns the active pin for a customer as of `now`, or null if unpinned / expired. */
  getActivePin(customerId: string, now: Date = new Date()): PinRecord | null {
    const record = this.pins.get(customerId);
    if (!record) return null;
    if (record.expiresAt && now >= new Date(record.expiresAt)) return null;
    return record;
  }

  /** True if the customer is currently pinned (and thus should be excluded from auto-updates). */
  isPinned(customerId: string, now: Date = new Date()): boolean {
    return this.getActivePin(customerId, now) !== null;
  }

  /**
   * A deployment targeting `targetVersion` is blocked by an active pin unless
   * the target equals the pinned version, or the deployment is a security patch
   * that is explicitly allowed to override pins.
   */
  blocksDeployment(customerId: string, targetVersion: string, opts: { isSecurityPatch?: boolean; now?: Date } = {}): boolean {
    const pin = this.getActivePin(customerId, opts.now);
    if (!pin) return false;
    if (pin.pinnedVersion === targetVersion) return false;
    if (opts.isSecurityPatch) return false;
    return true;
  }

  list(): PinRecord[] {
    return [...this.pins.values()];
  }
}

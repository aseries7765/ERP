import { CompatibilityResult, CustomerContext, Version } from './types';
import { compareSemVer, gt, inRange, isMajorBump, sortVersionsAscending } from './semver';

const FEATURE_PLAN_RANK: Record<CustomerContext['planTier'], number> = {
  free: 0,
  starter: 1,
  business: 2,
  enterprise: 3,
};

/** A plan-tier gate on a specific feature: customers below minPlanTier are blocked from versions introducing it. */
export interface FeaturePlanRequirement {
  feature: string;
  minPlanTier: CustomerContext['planTier'];
}

/** All inputs checkCompatibility() needs to evaluate one from→to upgrade for one customer. */
export interface CompatibilityCheckInput {
  from: Version;
  to: Version;
  customer: CustomerContext;
  /** All known versions, used to compute a multi-step upgrade path if a direct jump is unsupported. */
  registry: Version[];
  /** Optional per-feature minimum plan tier requirements. */
  featurePlanRequirements?: FeaturePlanRequirement[];
  /** Minimum resource requirements declared by the target version, if any. */
  minResources?: { cpuCores: number; memoryGb: number; storageGb: number };
}

/**
 * Determines whether a customer can move from `from.id` to `to.id`, either directly
 * or via an intermediate chain, and reports warnings/blockers along the way.
 */
export function checkCompatibility(input: CompatibilityCheckInput): CompatibilityResult {
  const { from, to, customer, registry, featurePlanRequirements = [], minResources } = input;
  const warnings: CompatibilityResult['warnings'] = [];
  const blockers: CompatibilityResult['blockers'] = [];

  if (to.retiredAt) {
    blockers.push({ code: 'TARGET_VERSION_RETIRED', message: `Version ${to.id} has been retired and cannot be targeted.` });
  }

  const isDowngrade = gt(from.id, to.id);
  if (isDowngrade) {
    blockers.push({
      code: 'DOWNGRADE_NOT_SUPPORTED',
      message: `Downgrading from ${from.id} to ${to.id} is not supported via standard deployment; use restore-from-backup instead.`,
    });
  }

  // Direct-jump eligibility: target declares [minPrevVersion, maxPrevVersion] it can upgrade from.
  const directOk = !isDowngrade && inRange(from.id, to.minPrevVersion, to.maxPrevVersion);
  let steps: string[] = [];

  if (directOk) {
    steps = [from.id, to.id];
  } else if (!isDowngrade) {
    const path = findUpgradePath(from.id, to.id, registry);
    if (path) {
      steps = path;
      warnings.push({
        code: 'MULTI_STEP_UPGRADE_REQUIRED',
        message: `No direct upgrade path from ${from.id} to ${to.id}; will pass through ${path.slice(1, -1).join(', ') || '(none)'}.`,
      });
    } else {
      blockers.push({
        code: 'NO_DIRECT_UPGRADE_PATH',
        message: `No upgrade path exists from ${from.id} to ${to.id} given the registered versions and their minPrevVersion/maxPrevVersion ranges.`,
      });
    }
  }

  if (isMajorBump(from.id, to.id) && to.breakingChanges) {
    warnings.push({
      code: 'BREAKING_MAJOR_VERSION',
      message: `${to.id} is a major version with documented breaking changes; review changelog before proceeding.`,
    });
  }

  if (to.migrationRequired && !isDowngrade && to.migrationScripts.length === 0) {
    blockers.push({
      code: 'IRREVERSIBLE_MIGRATION_ON_UNSTABLE_TARGET',
      message: `${to.id} is flagged as requiring migration but declares no migration scripts.`,
    });
  }

  for (const req of featurePlanRequirements) {
    if (to.features.includes(req.feature) && FEATURE_PLAN_RANK[customer.planTier] < FEATURE_PLAN_RANK[req.minPlanTier]) {
      blockers.push({
        code: 'PLAN_MISSING_REQUIRED_FEATURE',
        message: `Feature "${req.feature}" introduced in ${to.id} requires plan tier "${req.minPlanTier}" or higher; customer is on "${customer.planTier}".`,
      });
    }
  }

  if (minResources) {
    const r = customer.resources;
    if (r.cpuCores < minResources.cpuCores || r.memoryGb < minResources.memoryGb || r.storageGb < minResources.storageGb) {
      blockers.push({
        code: 'INSUFFICIENT_RESOURCES',
        message: `Customer resources (${r.cpuCores} vCPU / ${r.memoryGb}GB RAM / ${r.storageGb}GB storage) are below the minimum required for ${to.id} (${minResources.cpuCores} vCPU / ${minResources.memoryGb}GB RAM / ${minResources.storageGb}GB storage).`,
      });
    }
  }

  return {
    compatible: blockers.length === 0,
    warnings,
    blockers,
    steps,
  };
}

/**
 * Breadth-first search over the version registry's declared [minPrevVersion, maxPrevVersion]
 * ranges to find a chain of upgrades from `from` to `to`. Returns the ordered path of version
 * ids (inclusive of endpoints), or null if unreachable.
 */
export function findUpgradePath(from: string, to: string, registry: Version[]): string[] | null {
  const byId = new Map(registry.map((v) => [v.id, v]));
  if (!byId.has(from) || !byId.has(to)) return null;

  const ascending = sortVersionsAscending(registry.map((v) => v.id)).filter((id) => compareSemVer(id, from) >= 0);

  // adjacency: version -> versions directly upgradable to it
  const edges = new Map<string, string[]>();
  for (const v of registry) {
    for (const candidateFrom of ascending) {
      if (candidateFrom === v.id) continue;
      if (compareSemVer(candidateFrom, v.id) >= 0) continue;
      if (inRange(candidateFrom, v.minPrevVersion, v.maxPrevVersion)) {
        if (!edges.has(candidateFrom)) edges.set(candidateFrom, []);
        edges.get(candidateFrom)!.push(v.id);
      }
    }
  }

  const queue: string[][] = [[from]];
  const visited = new Set<string>([from]);
  while (queue.length > 0) {
    const path = queue.shift()!;
    const last = path[path.length - 1];
    if (last === to) return path;
    for (const next of edges.get(last) ?? []) {
      if (!visited.has(next)) {
        visited.add(next);
        queue.push([...path, next]);
      }
    }
  }
  return null;
}

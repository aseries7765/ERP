import { test } from 'node:test';
import assert from 'node:assert/strict';
import { checkCompatibility, findUpgradePath } from '../compatibility';
import { CustomerContext, Version } from '../types';

function makeVersion(overrides: Partial<Version> & { id: string }): Version {
  return {
    semver: overrides.id,
    releasedAt: '2026-01-01T00:00:00.000Z',
    changelog: '',
    breakingChanges: false,
    migrationRequired: false,
    migrationScripts: [],
    minPrevVersion: '0.0.0',
    maxPrevVersion: overrides.id,
    supportedUntil: '2027-01-01T00:00:00.000Z',
    dockerImages: { api: 'api:latest', web: 'web:latest', worker: 'worker:latest', ai: 'ai:latest' },
    helmChartVersion: '1.0.0',
    dbSchemaVersion: '1',
    apiVersion: 'v1',
    features: [],
    securityPatches: [],
    ...overrides,
  };
}

function makeCustomer(overrides: Partial<CustomerContext> = {}): CustomerContext {
  return {
    customerId: 'cust-1',
    planTier: 'business',
    currentVersion: '1.0.0',
    resources: { cpuCores: 8, memoryGb: 32, storageGb: 500 },
    enabledFeatures: [],
    ...overrides,
  };
}

test('direct upgrade within declared range is compatible', () => {
  const from = makeVersion({ id: '1.0.0' });
  const to = makeVersion({ id: '1.1.0', minPrevVersion: '1.0.0', maxPrevVersion: '1.0.5' });
  const result = checkCompatibility({ from, to, customer: makeCustomer(), registry: [from, to] });
  assert.equal(result.compatible, true);
  assert.deepEqual(result.steps, ['1.0.0', '1.1.0']);
  assert.equal(result.blockers.length, 0);
});

test('downgrade is blocked', () => {
  const from = makeVersion({ id: '1.5.0' });
  const to = makeVersion({ id: '1.0.0' });
  const result = checkCompatibility({ from, to, customer: makeCustomer(), registry: [from, to] });
  assert.equal(result.compatible, false);
  assert.ok(result.blockers.some((b) => b.code === 'DOWNGRADE_NOT_SUPPORTED'));
});

test('retired target version is blocked', () => {
  const from = makeVersion({ id: '1.0.0' });
  const to = makeVersion({ id: '1.1.0', minPrevVersion: '1.0.0', maxPrevVersion: '1.0.5', retiredAt: '2026-01-01T00:00:00.000Z' });
  const result = checkCompatibility({ from, to, customer: makeCustomer(), registry: [from, to] });
  assert.equal(result.compatible, false);
  assert.ok(result.blockers.some((b) => b.code === 'TARGET_VERSION_RETIRED'));
});

test('multi-step upgrade path is found when no direct jump exists', () => {
  const v1 = makeVersion({ id: '1.0.0', minPrevVersion: '0.0.0', maxPrevVersion: '1.0.0' });
  const v2 = makeVersion({ id: '1.5.0', minPrevVersion: '1.0.0', maxPrevVersion: '1.4.9' });
  const v3 = makeVersion({ id: '2.0.0', minPrevVersion: '1.5.0', maxPrevVersion: '1.9.9', breakingChanges: true });
  // from 1.0.0 -> 2.0.0 requires passing through 1.5.0
  const result = checkCompatibility({ from: v1, to: v3, customer: makeCustomer(), registry: [v1, v2, v3] });
  assert.equal(result.compatible, true);
  assert.deepEqual(result.steps, ['1.0.0', '1.5.0', '2.0.0']);
  assert.ok(result.warnings.some((w) => w.code === 'MULTI_STEP_UPGRADE_REQUIRED'));
  assert.ok(result.warnings.some((w) => w.code === 'BREAKING_MAJOR_VERSION'));
});

test('no upgrade path exists -> blocker', () => {
  const v1 = makeVersion({ id: '1.0.0', minPrevVersion: '0.0.0', maxPrevVersion: '1.0.0' });
  const v3 = makeVersion({ id: '3.0.0', minPrevVersion: '2.5.0', maxPrevVersion: '2.9.9' });
  const result = checkCompatibility({ from: v1, to: v3, customer: makeCustomer(), registry: [v1, v3] });
  assert.equal(result.compatible, false);
  assert.ok(result.blockers.some((b) => b.code === 'NO_DIRECT_UPGRADE_PATH'));
});

test('feature plan gating blocks lower-tier customers', () => {
  const from = makeVersion({ id: '1.0.0' });
  const to = makeVersion({ id: '1.1.0', minPrevVersion: '1.0.0', maxPrevVersion: '1.0.5', features: ['canary-deploys'] });
  const result = checkCompatibility({
    from,
    to,
    customer: makeCustomer({ planTier: 'starter' }),
    registry: [from, to],
    featurePlanRequirements: [{ feature: 'canary-deploys', minPlanTier: 'enterprise' }],
  });
  assert.equal(result.compatible, false);
  assert.ok(result.blockers.some((b) => b.code === 'PLAN_MISSING_REQUIRED_FEATURE'));
});

test('feature plan gating allows sufficiently high tier', () => {
  const from = makeVersion({ id: '1.0.0' });
  const to = makeVersion({ id: '1.1.0', minPrevVersion: '1.0.0', maxPrevVersion: '1.0.5', features: ['canary-deploys'] });
  const result = checkCompatibility({
    from,
    to,
    customer: makeCustomer({ planTier: 'enterprise' }),
    registry: [from, to],
    featurePlanRequirements: [{ feature: 'canary-deploys', minPlanTier: 'enterprise' }],
  });
  assert.equal(result.compatible, true);
});

test('insufficient resources blocks compatibility', () => {
  const from = makeVersion({ id: '1.0.0' });
  const to = makeVersion({ id: '1.1.0', minPrevVersion: '1.0.0', maxPrevVersion: '1.0.5' });
  const result = checkCompatibility({
    from,
    to,
    customer: makeCustomer({ resources: { cpuCores: 2, memoryGb: 4, storageGb: 50 } }),
    registry: [from, to],
    minResources: { cpuCores: 4, memoryGb: 16, storageGb: 100 },
  });
  assert.equal(result.compatible, false);
  assert.ok(result.blockers.some((b) => b.code === 'INSUFFICIENT_RESOURCES'));
});

test('migrationRequired with no scripts is blocked', () => {
  const from = makeVersion({ id: '1.0.0' });
  const to = makeVersion({
    id: '1.1.0',
    minPrevVersion: '1.0.0',
    maxPrevVersion: '1.0.5',
    migrationRequired: true,
    migrationScripts: [],
  });
  const result = checkCompatibility({ from, to, customer: makeCustomer(), registry: [from, to] });
  assert.equal(result.compatible, false);
  assert.ok(result.blockers.some((b) => b.code === 'IRREVERSIBLE_MIGRATION_ON_UNSTABLE_TARGET'));
});

test('findUpgradePath returns null when unreachable', () => {
  const v1 = makeVersion({ id: '1.0.0' });
  const v2 = makeVersion({ id: '5.0.0', minPrevVersion: '4.0.0', maxPrevVersion: '4.9.9' });
  assert.equal(findUpgradePath('1.0.0', '5.0.0', [v1, v2]), null);
});

test('findUpgradePath returns direct path when versions are equal', () => {
  const v1 = makeVersion({ id: '1.0.0' });
  assert.deepEqual(findUpgradePath('1.0.0', '1.0.0', [v1]), ['1.0.0']);
});

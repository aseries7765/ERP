import { test } from 'node:test';
import assert from 'node:assert/strict';
import { diffVersions } from '../diff';
import { Version } from '../types';

function makeVersion(overrides: Partial<Version> & { id: string }): Version {
  return {
    semver: overrides.id,
    releasedAt: '2026-01-01T00:00:00.000Z',
    changelog: '',
    breakingChanges: false,
    migrationRequired: false,
    migrationScripts: [],
    minPrevVersion: '0.0.0',
    maxPrevVersion: overrides.id,
    supportedUntil: '2027-01-01T00:00:00.000Z',
    dockerImages: { api: 'api:latest', web: 'web:latest', worker: 'worker:latest', ai: 'ai:latest' },
    helmChartVersion: '1.0.0',
    dbSchemaVersion: '1',
    apiVersion: 'v1',
    features: [],
    securityPatches: [],
    ...overrides,
  };
}

test('diffVersions reports added and removed features', () => {
  const from = makeVersion({ id: '1.0.0', features: ['a', 'b'] });
  const to = makeVersion({ id: '1.1.0', features: ['b', 'c'] });
  const diff = diffVersions(from, to);
  assert.deepEqual(diff.addedFeatures, ['c']);
  assert.deepEqual(diff.removedFeatures, ['a']);
});

test('diffVersions reports new security patches only', () => {
  const from = makeVersion({ id: '1.0.0', securityPatches: ['CVE-2026-0001'] });
  const to = makeVersion({ id: '1.0.1', securityPatches: ['CVE-2026-0001', 'CVE-2026-0002'] });
  const diff = diffVersions(from, to);
  assert.deepEqual(diff.securityPatches, ['CVE-2026-0002']);
});

test('diffVersions flags apiVersion and dbSchema changes', () => {
  const from = makeVersion({ id: '1.9.0', apiVersion: 'v1', dbSchemaVersion: '5' });
  const to = makeVersion({ id: '2.0.0', apiVersion: 'v2', dbSchemaVersion: '6', breakingChanges: true, migrationRequired: true });
  const diff = diffVersions(from, to);
  assert.equal(diff.apiVersionChanged, true);
  assert.equal(diff.dbSchemaChanged, true);
  assert.equal(diff.breakingChanges, true);
  assert.equal(diff.migrationRequired, true);
});

test('diffVersions with no changes reports empty deltas', () => {
  const from = makeVersion({ id: '1.0.0', features: ['a'], securityPatches: ['x'] });
  const to = makeVersion({ id: '1.0.1', features: ['a'], securityPatches: ['x'] });
  const diff = diffVersions(from, to);
  assert.deepEqual(diff.addedFeatures, []);
  assert.deepEqual(diff.removedFeatures, []);
  assert.deepEqual(diff.securityPatches, []);
});

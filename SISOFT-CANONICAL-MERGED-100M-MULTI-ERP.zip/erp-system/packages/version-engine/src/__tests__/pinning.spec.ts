import { test } from 'node:test';
import assert from 'node:assert/strict';
import { VersionPinRegistry } from '../pinning';

test('pin and getActivePin', () => {
  const reg = new VersionPinRegistry();
  reg.pin({ customerId: 'c1', pinnedVersion: '1.4.0', pinnedAt: '2026-01-01T00:00:00.000Z', pinnedBy: 'admin-1' });
  const active = reg.getActivePin('c1', new Date('2026-01-02T00:00:00.000Z'));
  assert.equal(active?.pinnedVersion, '1.4.0');
});

test('unpin removes the pin', () => {
  const reg = new VersionPinRegistry();
  reg.pin({ customerId: 'c1', pinnedVersion: '1.4.0', pinnedAt: '2026-01-01T00:00:00.000Z', pinnedBy: 'admin-1' });
  assert.equal(reg.unpin('c1'), true);
  assert.equal(reg.getActivePin('c1'), null);
  assert.equal(reg.unpin('c1'), false);
});

test('pin expires after expiresAt', () => {
  const reg = new VersionPinRegistry();
  reg.pin({
    customerId: 'c1',
    pinnedVersion: '1.4.0',
    pinnedAt: '2026-01-01T00:00:00.000Z',
    pinnedBy: 'admin-1',
    expiresAt: '2026-02-01T00:00:00.000Z',
  });
  assert.equal(reg.isPinned('c1', new Date('2026-01-15T00:00:00.000Z')), true);
  assert.equal(reg.isPinned('c1', new Date('2026-03-01T00:00:00.000Z')), false);
});

test('pin() rejects expiresAt before pinnedAt', () => {
  const reg = new VersionPinRegistry();
  assert.throws(() =>
    reg.pin({
      customerId: 'c1',
      pinnedVersion: '1.4.0',
      pinnedAt: '2026-02-01T00:00:00.000Z',
      pinnedBy: 'admin-1',
      expiresAt: '2026-01-01T00:00:00.000Z',
    }),
  );
});

test('blocksDeployment: blocks non-matching target while pinned', () => {
  const reg = new VersionPinRegistry();
  reg.pin({ customerId: 'c1', pinnedVersion: '1.4.0', pinnedAt: '2026-01-01T00:00:00.000Z', pinnedBy: 'admin-1' });
  assert.equal(reg.blocksDeployment('c1', '1.5.0', { now: new Date('2026-01-02T00:00:00.000Z') }), true);
});

test('blocksDeployment: does not block deployment matching pinned version', () => {
  const reg = new VersionPinRegistry();
  reg.pin({ customerId: 'c1', pinnedVersion: '1.4.0', pinnedAt: '2026-01-01T00:00:00.000Z', pinnedBy: 'admin-1' });
  assert.equal(reg.blocksDeployment('c1', '1.4.0', { now: new Date('2026-01-02T00:00:00.000Z') }), false);
});

test('blocksDeployment: security patches override the pin', () => {
  const reg = new VersionPinRegistry();
  reg.pin({ customerId: 'c1', pinnedVersion: '1.4.0', pinnedAt: '2026-01-01T00:00:00.000Z', pinnedBy: 'admin-1' });
  assert.equal(
    reg.blocksDeployment('c1', '1.4.1', { isSecurityPatch: true, now: new Date('2026-01-02T00:00:00.000Z') }),
    false,
  );
});

test('blocksDeployment: unpinned customer never blocked', () => {
  const reg = new VersionPinRegistry();
  assert.equal(reg.blocksDeployment('c1', '1.4.0'), false);
});

test('list returns all active-or-not pins currently stored', () => {
  const reg = new VersionPinRegistry();
  reg.pin({ customerId: 'c1', pinnedVersion: '1.4.0', pinnedAt: '2026-01-01T00:00:00.000Z', pinnedBy: 'admin-1' });
  reg.pin({ customerId: 'c2', pinnedVersion: '1.3.0', pinnedAt: '2026-01-01T00:00:00.000Z', pinnedBy: 'admin-1' });
  assert.equal(reg.list().length, 2);
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  parseSemVer,
  isValidSemVer,
  compareSemVer,
  gt,
  gte,
  lt,
  lte,
  eq,
  inRange,
  isMajorBump,
  isMinorBump,
  isPatchBump,
  sortVersionsAscending,
} from '../semver';

test('parseSemVer parses valid versions', () => {
  assert.deepEqual(parseSemVer('1.5.2'), { major: 1, minor: 5, patch: 2, prerelease: undefined });
  assert.deepEqual(parseSemVer('2.0.0-beta.1'), { major: 2, minor: 0, patch: 0, prerelease: 'beta.1' });
});

test('parseSemVer rejects invalid versions', () => {
  assert.throws(() => parseSemVer('1.5'));
  assert.throws(() => parseSemVer('v1.5.0'));
  assert.throws(() => parseSemVer('not-a-version'));
});

test('isValidSemVer', () => {
  assert.equal(isValidSemVer('1.5.0'), true);
  assert.equal(isValidSemVer('1.5'), false);
});

test('compareSemVer basic ordering', () => {
  assert.equal(compareSemVer('1.0.0', '1.0.1'), -1);
  assert.equal(compareSemVer('1.1.0', '1.0.9'), 1);
  assert.equal(compareSemVer('1.0.0', '1.0.0'), 0);
  assert.equal(compareSemVer('2.0.0', '1.9.9'), 1);
});

test('compareSemVer prerelease ordering (release > prerelease)', () => {
  assert.equal(compareSemVer('1.0.0-beta.1', '1.0.0'), -1);
  assert.equal(compareSemVer('1.0.0', '1.0.0-beta.1'), 1);
  assert.equal(compareSemVer('1.0.0-alpha', '1.0.0-beta'), -1);
  assert.equal(compareSemVer('1.0.0-alpha.1', '1.0.0-alpha.2'), -1);
});

test('gt/gte/lt/lte/eq helpers', () => {
  assert.equal(gt('1.1.0', '1.0.0'), true);
  assert.equal(gte('1.0.0', '1.0.0'), true);
  assert.equal(lt('1.0.0', '1.1.0'), true);
  assert.equal(lte('1.0.0', '1.0.0'), true);
  assert.equal(eq('1.0.0', '1.0.0'), true);
  assert.equal(eq('1.0.0', '1.0.1'), false);
});

test('inRange with open and closed bounds', () => {
  assert.equal(inRange('1.2.0', '1.0.0', '1.5.0'), true);
  assert.equal(inRange('1.6.0', '1.0.0', '1.5.0'), false);
  assert.equal(inRange('0.9.0', '1.0.0', '1.5.0'), false);
  assert.equal(inRange('9.9.9'), true); // no bounds = always in range
});

test('isMajorBump / isMinorBump / isPatchBump', () => {
  assert.equal(isMajorBump('1.5.0', '2.0.0'), true);
  assert.equal(isMajorBump('1.5.0', '1.6.0'), false);
  assert.equal(isMinorBump('1.5.0', '1.6.0'), true);
  assert.equal(isMinorBump('1.5.0', '2.0.0'), false);
  assert.equal(isPatchBump('1.5.0', '1.5.1'), true);
  assert.equal(isPatchBump('1.5.0', '1.6.0'), false);
});

test('sortVersionsAscending', () => {
  assert.deepEqual(sortVersionsAscending(['1.5.0', '1.0.0', '2.0.0', '1.4.9']), [
    '1.0.0',
    '1.4.9',
    '1.5.0',
    '2.0.0',
  ]);
});

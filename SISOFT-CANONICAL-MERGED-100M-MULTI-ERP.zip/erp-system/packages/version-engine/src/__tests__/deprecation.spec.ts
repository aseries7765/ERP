import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_DEPRECATION_POLICY,
  computeLifecycleStatus,
  computeLifecycleDates,
  computeNotificationSchedule,
  isWithinSecurityBackportWindow,
} from '../deprecation';

test('computeLifecycleStatus: active shortly after release', () => {
  const status = computeLifecycleStatus(
    { releasedAt: '2026-01-01T00:00:00.000Z' },
    new Date('2026-03-01T00:00:00.000Z'),
  );
  assert.equal(status, 'active');
});

test('computeLifecycleStatus: deprecated at policy boundary (12mo)', () => {
  const status = computeLifecycleStatus(
    { releasedAt: '2026-01-01T00:00:00.000Z' },
    new Date('2027-01-01T00:00:00.000Z'),
  );
  assert.equal(status, 'deprecated');
});

test('computeLifecycleStatus: retired at policy boundary (18mo)', () => {
  const status = computeLifecycleStatus(
    { releasedAt: '2026-01-01T00:00:00.000Z' },
    new Date('2027-07-01T00:00:00.000Z'),
  );
  assert.equal(status, 'retired');
});

test('computeLifecycleStatus: explicit retiredAt overrides policy', () => {
  const status = computeLifecycleStatus(
    { releasedAt: '2026-01-01T00:00:00.000Z', retiredAt: '2026-02-01T00:00:00.000Z' },
    new Date('2026-02-15T00:00:00.000Z'),
  );
  assert.equal(status, 'retired');
});

test('computeLifecycleDates matches policy months', () => {
  const { deprecationDate, retirementDate } = computeLifecycleDates('2026-01-01T00:00:00.000Z');
  assert.equal(deprecationDate.toISOString().slice(0, 10), '2027-01-01');
  assert.equal(retirementDate.toISOString().slice(0, 10), '2027-07-01');
});

test('computeNotificationSchedule produces sorted checkpoints ending at deprecation', () => {
  const { deprecationDate } = computeLifecycleDates('2026-01-01T00:00:00.000Z');
  const schedule = computeNotificationSchedule(deprecationDate);
  assert.equal(schedule.length, DEFAULT_DEPRECATION_POLICY.notificationSchedule.length + 1);
  assert.equal(schedule[schedule.length - 1].urgency, 'final');
  assert.equal(schedule[schedule.length - 1].dueAt.getTime(), deprecationDate.getTime());
  for (let i = 1; i < schedule.length; i++) {
    assert.ok(schedule[i].dueAt.getTime() >= schedule[i - 1].dueAt.getTime());
  }
});

test('isWithinSecurityBackportWindow: within window', () => {
  assert.equal(isWithinSecurityBackportWindow('1.4.0', '1.6.0'), true); // distance 2 < 3
  assert.equal(isWithinSecurityBackportWindow('1.6.0', '1.6.0'), true); // distance 0
});

test('isWithinSecurityBackportWindow: outside window', () => {
  assert.equal(isWithinSecurityBackportWindow('1.2.0', '1.6.0'), false); // distance 4 >= 3
});

test('isWithinSecurityBackportWindow: different major line never qualifies', () => {
  assert.equal(isWithinSecurityBackportWindow('1.9.0', '2.1.0'), false);
});

/** Parsed components of a semver string. */
export interface SemVer {
  major: number;
  minor: number;
  patch: number;
  prerelease?: string;
}

/** Full metadata record for one released ERP version. */
export interface Version {
  id: string; // e.g. "1.5.0"
  semver: string;
  releasedAt: string; // ISO date
  changelog: string;
  breakingChanges: boolean;
  migrationRequired: boolean;
  migrationScripts: string[];
  minPrevVersion: string;
  maxPrevVersion: string;
  supportedUntil: string; // ISO date
  deprecatedAt?: string;
  retiredAt?: string;
  dockerImages: {
    api: string;
    web: string;
    worker: string;
    ai: string;
  };
  helmChartVersion: string;
  dbSchemaVersion: string;
  apiVersion: 'v1' | 'v2';
  features: string[];
  securityPatches: string[];
}

/** A customer's current plan, version, and resource envelope, used for compatibility checks. */
export interface CustomerContext {
  customerId: string;
  planTier: 'free' | 'starter' | 'business' | 'enterprise';
  currentVersion: string;
  pinnedVersion?: string;
  resources: {
    cpuCores: number;
    memoryGb: number;
    storageGb: number;
  };
  enabledFeatures: string[];
}

/** Machine-readable codes for compatibility blockers (see checkCompatibility). */
export type CompatibilityBlockerCode =
  | 'NO_DIRECT_UPGRADE_PATH'
  | 'DOWNGRADE_NOT_SUPPORTED'
  | 'PLAN_MISSING_REQUIRED_FEATURE'
  | 'INSUFFICIENT_RESOURCES'
  | 'IRREVERSIBLE_MIGRATION_ON_UNSTABLE_TARGET'
  | 'TARGET_VERSION_RETIRED';

/** A single warning or blocker surfaced by a compatibility check. */
export interface CompatibilityIssue {
  code: CompatibilityBlockerCode | string;
  message: string;
}

/** Result of checkCompatibility(): whether the upgrade is allowed, and why. */
export interface CompatibilityResult {
  compatible: boolean;
  warnings: CompatibilityIssue[];
  blockers: CompatibilityIssue[];
  /** ordered list of version ids to pass through, e.g. multi-step upgrade */
  steps: string[];
}

/** Configurable timeline for a version's support/deprecation/retirement lifecycle. */
export interface DeprecationPolicy {
  supportMonths: number; // default 12
  deprecationWarningMonths: number; // default 12 (deprecate at this point)
  retirementMonths: number; // default 18
  securityBackportMinorVersions: number; // default 3
  notificationSchedule: Array<{ monthsBeforeDeprecation: number; urgency: 'info' | 'warning' | 'urgent' }>;
}

/** Structural diff between two version records, as returned by diffVersions(). */
export interface VersionDiff {
  fromVersion: string;
  toVersion: string;
  breakingChanges: boolean;
  migrationRequired: boolean;
  addedFeatures: string[];
  removedFeatures: string[];
  securityPatches: string[];
  apiVersionChanged: boolean;
  dbSchemaChanged: boolean;
}

/** A customer's pin to a specific version, optionally time-limited. */
export interface PinRecord {
  customerId: string;
  pinnedVersion: string;
  pinnedAt: string;
  pinnedBy: string;
  reason?: string;
  expiresAt?: string;
}

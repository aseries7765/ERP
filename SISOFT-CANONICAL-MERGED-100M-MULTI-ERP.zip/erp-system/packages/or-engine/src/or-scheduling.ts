/**
 * OR scheduling: reserves block time for a surgical case, checking
 * surgeon, anesthetist, and room availability, with support for
 * emergency add-on cases that can preempt a lower-priority elective
 * case (with mandatory justification and audit trail, per ADR-0381).
 *
 * This module is pure scheduling logic — no DB, no HTTP. The his-or
 * module's or-scheduling.service.ts wraps this with persistence and
 * notification side effects.
 */

export type CasePriority = 'ELECTIVE' | 'URGENT' | 'EMERGENCY';

export interface TimeRange {
  start: Date;
  end: Date;
}

export interface ScheduledCase {
  id: string;
  roomId: string;
  surgeonId: string;
  anesthetistId: string;
  priority: CasePriority;
  timeRange: TimeRange;
  preemptedBy?: string;
  status: 'SCHEDULED' | 'PREEMPTED' | 'CANCELLED';
}

export interface ScheduleCaseRequest {
  id: string;
  roomId: string;
  surgeonId: string;
  anesthetistId: string;
  priority: CasePriority;
  timeRange: TimeRange;
  preemptionJustification?: string;
}

export class OrSchedulingError extends Error {}
export class OrSchedulingConflictError extends OrSchedulingError {
  constructor(message: string, public readonly conflictingCase: ScheduledCase) {
    super(message);
  }
}

export interface SchedulingResult {
  scheduled: ScheduledCase;
  preempted?: ScheduledCase;
}

/**
 * In-memory schedule store, keyed by room. A real deployment backs
 * this with the his-or Prisma models; kept minimal and swappable here
 * so the algorithm is unit-testable without a DB.
 */
export class OrSchedule {
  private casesByRoom = new Map<string, ScheduledCase[]>();

  getCasesForRoom(roomId: string): ScheduledCase[] {
    return [...(this.casesByRoom.get(roomId) ?? [])].filter((c) => c.status === 'SCHEDULED');
  }

  private allActiveCases(): ScheduledCase[] {
    return [...this.casesByRoom.values()].flat().filter((c) => c.status === 'SCHEDULED');
  }

  add(scheduledCase: ScheduledCase): void {
    const list = this.casesByRoom.get(scheduledCase.roomId) ?? [];
    list.push(scheduledCase);
    this.casesByRoom.set(scheduledCase.roomId, list);
  }

  markPreempted(caseId: string, preemptedBy: string): ScheduledCase | undefined {
    for (const list of this.casesByRoom.values()) {
      const target = list.find((c) => c.id === caseId);
      if (target) {
        target.status = 'PREEMPTED';
        target.preemptedBy = preemptedBy;
        return target;
      }
    }
    return undefined;
  }

  findConflicts(roomId: string, timeRange: TimeRange): ScheduledCase[] {
    return this.getCasesForRoom(roomId).filter((c) => rangesOverlap(c.timeRange, timeRange));
  }

  findPersonConflicts(personId: string, timeRange: TimeRange): ScheduledCase[] {
    return this.allActiveCases().filter(
      (c) => (c.surgeonId === personId || c.anesthetistId === personId) && rangesOverlap(c.timeRange, timeRange),
    );
  }
}

function rangesOverlap(a: TimeRange, b: TimeRange): boolean {
  return a.start < b.end && b.start < a.end;
}

const PRIORITY_RANK: Record<CasePriority, number> = { EMERGENCY: 3, URGENT: 2, ELECTIVE: 1 };

/**
 * Schedules a case, checking room, surgeon, and anesthetist
 * availability. On any conflict:
 *  - ELECTIVE/URGENT requests are rejected outright (OrSchedulingConflictError).
 *  - EMERGENCY requests may preempt a lower-priority (ELECTIVE or
 *    URGENT, never another EMERGENCY) conflicting case, but ONLY when
 *    `preemptionJustification` is provided — the mandatory audit trail
 *    requirement. An emergency case cannot preempt another emergency
 *    case; that is a genuine resource conflict the on-call coordinator
 *    must resolve, not something this function silently decides.
 */
export function scheduleCase(schedule: OrSchedule, request: ScheduleCaseRequest): SchedulingResult {
  validateRequest(request);

  const roomConflicts = schedule.findConflicts(request.roomId, request.timeRange);
  const surgeonConflicts = schedule.findPersonConflicts(request.surgeonId, request.timeRange);
  const anesthetistConflicts = schedule.findPersonConflicts(request.anesthetistId, request.timeRange);

  const allConflicts = [...roomConflicts, ...surgeonConflicts, ...anesthetistConflicts];

  if (allConflicts.length === 0) {
    const scheduled: ScheduledCase = {
      id: request.id,
      roomId: request.roomId,
      surgeonId: request.surgeonId,
      anesthetistId: request.anesthetistId,
      priority: request.priority,
      timeRange: request.timeRange,
      status: 'SCHEDULED',
    };
    schedule.add(scheduled);
    return { scheduled };
  }

  if (request.priority !== 'EMERGENCY') {
    throw new OrSchedulingConflictError(
      `Scheduling conflict for ${request.priority} case: room/surgeon/anesthetist already booked in this time range.`,
      allConflicts[0],
    );
  }

  const preemptTarget = allConflicts[0];
  if (preemptTarget.priority === 'EMERGENCY') {
    throw new OrSchedulingConflictError(
      'Cannot preempt another EMERGENCY case — requires manual on-call coordinator resolution.',
      preemptTarget,
    );
  }
  if (!request.preemptionJustification || request.preemptionJustification.trim().length === 0) {
    throw new OrSchedulingError(
      'Emergency case would preempt an existing case but no preemptionJustification was provided. Justification is mandatory (ADR-0381).',
    );
  }

  const preempted = schedule.markPreempted(preemptTarget.id, request.id);
  const scheduled: ScheduledCase = {
    id: request.id,
    roomId: request.roomId,
    surgeonId: request.surgeonId,
    anesthetistId: request.anesthetistId,
    priority: request.priority,
    timeRange: request.timeRange,
    status: 'SCHEDULED',
  };
  schedule.add(scheduled);

  return { scheduled, preempted };
}

function validateRequest(request: ScheduleCaseRequest): void {
  if (request.timeRange.start >= request.timeRange.end) {
    throw new OrSchedulingError('timeRange.start must be before timeRange.end.');
  }
  if (!request.roomId || !request.surgeonId || !request.anesthetistId) {
    throw new OrSchedulingError('roomId, surgeonId, and anesthetistId are all required.');
  }
  if (PRIORITY_RANK[request.priority] === undefined) {
    throw new OrSchedulingError(`Unknown priority: ${request.priority}`);
  }
}

/**
 * Aldrete score: the standard post-anesthesia recovery scoring system
 * used to determine PACU discharge readiness. Five categories, each
 * scored 0-2, for a total 0-10. A total >= 9 (with no category scoring
 * 0) is the conventional threshold for PACU discharge, though facility
 * policy can be stricter — this module exposes the raw score and the
 * conventional threshold check separately so callers can apply their
 * own policy if needed.
 */

export class InvalidAldreteInputError extends Error {}

export type AldreteScoreValue = 0 | 1 | 2;

export interface AldreteInput {
  /** Activity: ability to move extremities. 2=all 4 voluntarily/on command, 1=2 extremities, 0=none. */
  activity: AldreteScoreValue;
  /** Respiration. 2=breathes deeply/coughs freely, 1=dyspnea/shallow/limited breathing, 0=apneic. */
  respiration: AldreteScoreValue;
  /** Circulation, by blood pressure vs pre-anesthetic level. 2=BP ± 20mmHg, 1=BP ± 20-50mmHg, 0=BP ± >50mmHg. */
  circulation: AldreteScoreValue;
  /** Consciousness. 2=fully awake, 1=arousable on calling, 0=not responding. */
  consciousness: AldreteScoreValue;
  /** O2 saturation. 2=SpO2 > 92% on room air, 1=needs supplemental O2 to maintain SpO2 > 90%, 0=SpO2 < 90% even with supplemental O2. */
  oxygenSaturation: AldreteScoreValue;
}

export interface AldreteResult {
  total: number; // 0-10
  categoryScores: AldreteInput;
  /** True if every category scored non-zero AND total >= dischargeThreshold. A single 0 in any category blocks discharge regardless of total, per standard clinical practice (a 0 signals an acute problem in that domain). */
  readyForDischarge: boolean;
  dischargeThreshold: number;
}

const VALID_SCORES = new Set([0, 1, 2]);
const DEFAULT_DISCHARGE_THRESHOLD = 9;

function validateScore(value: number, category: string): void {
  if (!VALID_SCORES.has(value)) {
    throw new InvalidAldreteInputError(`Invalid Aldrete score for ${category}: must be 0, 1, or 2 (got ${value}).`);
  }
}

/**
 * Computes the Aldrete score and discharge readiness. `dischargeThreshold`
 * defaults to the conventional 9, but a facility can pass a stricter
 * value (e.g. require the full 10) via policy configuration.
 */
export function calculateAldreteScore(
  input: AldreteInput,
  dischargeThreshold: number = DEFAULT_DISCHARGE_THRESHOLD,
): AldreteResult {
  validateScore(input.activity, 'activity');
  validateScore(input.respiration, 'respiration');
  validateScore(input.circulation, 'circulation');
  validateScore(input.consciousness, 'consciousness');
  validateScore(input.oxygenSaturation, 'oxygenSaturation');

  const total =
    input.activity + input.respiration + input.circulation + input.consciousness + input.oxygenSaturation;

  const anyZero =
    input.activity === 0 ||
    input.respiration === 0 ||
    input.circulation === 0 ||
    input.consciousness === 0 ||
    input.oxygenSaturation === 0;

  return {
    total,
    categoryScores: { ...input },
    readyForDischarge: !anyZero && total >= dischargeThreshold,
    dischargeThreshold,
  };
}

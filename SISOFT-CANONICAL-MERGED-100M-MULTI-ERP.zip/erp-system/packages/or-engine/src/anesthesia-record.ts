/**
 * Continuous anesthesia record: vitals (typically every 5 min, manual
 * or device-fed), drug administration, gas delivery, clinical events
 * (intubation, extubation, etc.), fluid balance, and blood products.
 * Signed by the anesthetist at end of case; once signed, the record is
 * immutable (mirroring the operative-note and surgical-count
 * immutability pattern used throughout HIS-3).
 */

export class AnesthesiaRecordError extends Error {}

export interface VitalsEntry {
  at: Date;
  heartRate?: number;
  systolicBp?: number;
  diastolicBp?: number;
  spo2?: number;
  respiratoryRate?: number;
  /** True if this reading came from an integrated device rather than manual entry — feeds G18 ("Anesthesia record MUST auto-capture device data if connected"). */
  fromDevice: boolean;
}

export interface DrugAdministration {
  at: Date;
  drugName: string;
  dose: string;
  route: 'IV' | 'IM' | 'INHALED' | 'EPIDURAL' | 'OTHER';
  administeredBy: { userId: string; name: string };
}

export interface GasReading {
  at: Date;
  agent: string;
  concentrationPercent: number;
}

export type AnesthesiaEventType =
  | 'INDUCTION_STARTED'
  | 'INTUBATION'
  | 'EXTUBATION'
  | 'POSITION_CHANGE'
  | 'COMPLICATION'
  | 'OTHER';

export interface AnesthesiaEvent {
  at: Date;
  type: AnesthesiaEventType;
  note?: string;
}

export interface FluidEntry {
  at: Date;
  type: 'CRYSTALLOID' | 'COLLOID' | 'BLOOD_PRODUCT';
  direction: 'IN' | 'OUT';
  volumeMl: number;
  productDetail?: string;
}

export interface AnesthesiaRecord {
  id: string;
  caseId: string;
  anesthetistId: string;
  startedAt: Date;
  vitals: VitalsEntry[];
  drugs: DrugAdministration[];
  gases: GasReading[];
  events: AnesthesiaEvent[];
  fluids: FluidEntry[];
  signed: boolean;
  signedAt?: Date;
  immutable: boolean;
}

let idCounter = 0;
function nextId(prefix: string): string {
  idCounter += 1;
  return `${prefix}_${idCounter}`;
}

export function startAnesthesiaRecord(caseId: string, anesthetistId: string, now: Date = new Date()): AnesthesiaRecord {
  if (!caseId) throw new AnesthesiaRecordError('caseId is required.');
  if (!anesthetistId) throw new AnesthesiaRecordError('anesthetistId is required.');
  return {
    id: nextId('anrec'),
    caseId,
    anesthetistId,
    startedAt: now,
    vitals: [],
    drugs: [],
    gases: [],
    events: [],
    fluids: [],
    signed: false,
    immutable: false,
  };
}

function assertMutable(record: AnesthesiaRecord): void {
  if (record.immutable) {
    throw new AnesthesiaRecordError(`Anesthesia record ${record.id} is signed and immutable; no further entries can be added.`);
  }
}

export function addVitals(record: AnesthesiaRecord, vitals: VitalsEntry): AnesthesiaRecord {
  assertMutable(record);
  return { ...record, vitals: [...record.vitals, vitals] };
}

export function addDrug(record: AnesthesiaRecord, drug: DrugAdministration): AnesthesiaRecord {
  assertMutable(record);
  return { ...record, drugs: [...record.drugs, drug] };
}

export function addGasReading(record: AnesthesiaRecord, gas: GasReading): AnesthesiaRecord {
  assertMutable(record);
  if (gas.concentrationPercent < 0 || gas.concentrationPercent > 100) {
    throw new AnesthesiaRecordError(`Gas concentration must be 0-100 (got ${gas.concentrationPercent}).`);
  }
  return { ...record, gases: [...record.gases, gas] };
}

export function addEvent(record: AnesthesiaRecord, event: AnesthesiaEvent): AnesthesiaRecord {
  assertMutable(record);
  return { ...record, events: [...record.events, event] };
}

export function addFluid(record: AnesthesiaRecord, fluid: FluidEntry): AnesthesiaRecord {
  assertMutable(record);
  if (fluid.volumeMl < 0) {
    throw new AnesthesiaRecordError(`Fluid volume cannot be negative (got ${fluid.volumeMl}).`);
  }
  return { ...record, fluids: [...record.fluids, fluid] };
}

/**
 * Signs and permanently locks the record. Requires at least one
 * vitals entry (a record with zero vitals was never actually
 * monitored, which should never be signed off as complete).
 */
export function signAnesthesiaRecord(record: AnesthesiaRecord, now: Date = new Date()): AnesthesiaRecord {
  if (record.signed) {
    throw new AnesthesiaRecordError(`Anesthesia record ${record.id} is already signed.`);
  }
  if (record.vitals.length === 0) {
    throw new AnesthesiaRecordError('Cannot sign an anesthesia record with no vitals recorded.');
  }
  return { ...record, signed: true, signedAt: now, immutable: true };
}

/** Fraction of vitals entries that came from an integrated device — supports G18 monitoring/reporting. */
export function deviceCaptureRate(record: AnesthesiaRecord): number {
  if (record.vitals.length === 0) return 0;
  const fromDevice = record.vitals.filter((v) => v.fromDevice).length;
  return fromDevice / record.vitals.length;
}

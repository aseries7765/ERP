/**
 * Operative note: the surgeon's narrative record of the procedure.
 * Per spec G17 ("Operative note MUST be immutable after sign") and
 * ADR-0385, once signed, the note's content can never be edited —
 * any correction after signing must be a new, separate addendum
 * record that references the original, never a mutation of it. This
 * module enforces that at the data-structure level: there is no
 * "edit" function once `signed` is true, and `addendum` explicitly
 * creates a new linked record rather than touching the original.
 */

export class OperativeNoteError extends Error {}

export interface OperativeNoteContent {
  preoperativeDiagnosis: string;
  postoperativeDiagnosis: string;
  procedurePerformed: string;
  surgeonNarrative: string;
  estimatedBloodLoss: string;
  complications: string;
  specimensRemoved: string;
}

export interface OperativeNote {
  id: string;
  caseId: string;
  surgeonId: string;
  content: OperativeNoteContent;
  createdAt: Date;
  signed: boolean;
  signedAt?: Date;
  immutable: boolean;
  /** Addenda are separate records, chained by id, never merged back into `content`. */
  addendumIds: string[];
}

export interface OperativeNoteAddendum {
  id: string;
  originalNoteId: string;
  authorId: string;
  text: string;
  createdAt: Date;
  /** Addenda are themselves immutable from the moment of creation — there is no draft state for an addendum. */
  immutable: true;
}

let idCounter = 0;
function nextId(prefix: string): string {
  idCounter += 1;
  return `${prefix}_${idCounter}`;
}

const REQUIRED_FIELDS: Array<keyof OperativeNoteContent> = [
  'preoperativeDiagnosis',
  'postoperativeDiagnosis',
  'procedurePerformed',
  'surgeonNarrative',
];

export function createOperativeNoteDraft(caseId: string, surgeonId: string, content: OperativeNoteContent, now: Date = new Date()): OperativeNote {
  if (!caseId) throw new OperativeNoteError('caseId is required.');
  if (!surgeonId) throw new OperativeNoteError('surgeonId is required.');
  return {
    id: nextId('opnote'),
    caseId,
    surgeonId,
    content,
    createdAt: now,
    signed: false,
    immutable: false,
    addendumIds: [],
  };
}

/**
 * Updates the draft's content. Only permitted while unsigned — this is
 * the sole mutation path, and it hard-fails once `immutable` is true.
 */
export function updateOperativeNoteDraft(note: OperativeNote, content: Partial<OperativeNoteContent>): OperativeNote {
  if (note.immutable) {
    throw new OperativeNoteError(`Operative note ${note.id} is signed and immutable; cannot be edited. Use an addendum instead.`);
  }
  return { ...note, content: { ...note.content, ...content } };
}

/**
 * Signs the note, locking it permanently. Requires every core
 * narrative field to be non-empty — an empty operative note being
 * "signed" would be clinically meaningless and is rejected outright.
 */
export function signOperativeNote(note: OperativeNote, now: Date = new Date()): OperativeNote {
  if (note.signed) {
    throw new OperativeNoteError(`Operative note ${note.id} is already signed.`);
  }
  const missing = REQUIRED_FIELDS.filter((field) => !note.content[field] || note.content[field].trim().length === 0);
  if (missing.length > 0) {
    throw new OperativeNoteError(`Cannot sign operative note: missing required field(s): ${missing.join(', ')}.`);
  }
  return { ...note, signed: true, signedAt: now, immutable: true };
}

/**
 * Adds an addendum to an already-signed note. This is the ONLY way to
 * correct or supplement a signed operative note — the original
 * `content` is never touched. Requires the note to already be signed
 * (an addendum to an unsigned draft makes no sense; just edit the draft).
 */
export function addAddendum(note: OperativeNote, authorId: string, text: string, now: Date = new Date()): { note: OperativeNote; addendum: OperativeNoteAddendum } {
  if (!note.signed) {
    throw new OperativeNoteError('Cannot add an addendum to an unsigned note — edit the draft directly instead.');
  }
  if (!text || text.trim().length === 0) {
    throw new OperativeNoteError('Addendum text cannot be empty.');
  }

  const addendum: OperativeNoteAddendum = {
    id: nextId('addendum'),
    originalNoteId: note.id,
    authorId,
    text: text.trim(),
    createdAt: now,
    immutable: true,
  };

  const updatedNote: OperativeNote = { ...note, addendumIds: [...note.addendumIds, addendum.id] };
  return { note: updatedNote, addendum };
}

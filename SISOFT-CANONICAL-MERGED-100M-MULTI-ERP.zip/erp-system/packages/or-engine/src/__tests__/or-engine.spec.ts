import {
  OrSchedule,
  scheduleCase,
  OrSchedulingError,
  OrSchedulingConflictError,
  TimeRange,
} from '../or-scheduling';
import { calculateAldreteScore, InvalidAldreteInputError } from '../pacu-scoring';

function range(startHour: number, endHour: number): TimeRange {
  const day = '2026-09-18T';
  return { start: new Date(`${day}${String(startHour).padStart(2, '0')}:00:00Z`), end: new Date(`${day}${String(endHour).padStart(2, '0')}:00:00Z`) };
}

describe('scheduleCase', () => {
  it('schedules a case with no conflicts', () => {
    const schedule = new OrSchedule();
    const result = scheduleCase(schedule, {
      id: 'case-1', roomId: 'OR-1', surgeonId: 'surg-1', anesthetistId: 'anes-1',
      priority: 'ELECTIVE', timeRange: range(8, 10),
    });
    expect(result.scheduled.status).toBe('SCHEDULED');
    expect(result.preempted).toBeUndefined();
  });

  it('rejects an ELECTIVE case that conflicts on room time', () => {
    const schedule = new OrSchedule();
    scheduleCase(schedule, { id: 'case-1', roomId: 'OR-1', surgeonId: 'surg-1', anesthetistId: 'anes-1', priority: 'ELECTIVE', timeRange: range(8, 10) });
    expect(() =>
      scheduleCase(schedule, { id: 'case-2', roomId: 'OR-1', surgeonId: 'surg-2', anesthetistId: 'anes-2', priority: 'ELECTIVE', timeRange: range(9, 11) }),
    ).toThrow(OrSchedulingConflictError);
  });

  it('rejects a case where the surgeon is double-booked in a different room', () => {
    const schedule = new OrSchedule();
    scheduleCase(schedule, { id: 'case-1', roomId: 'OR-1', surgeonId: 'surg-1', anesthetistId: 'anes-1', priority: 'ELECTIVE', timeRange: range(8, 10) });
    expect(() =>
      scheduleCase(schedule, { id: 'case-2', roomId: 'OR-2', surgeonId: 'surg-1', anesthetistId: 'anes-2', priority: 'URGENT', timeRange: range(9, 11) }),
    ).toThrow(OrSchedulingConflictError);
  });

  it('allows back-to-back cases that do not overlap', () => {
    const schedule = new OrSchedule();
    scheduleCase(schedule, { id: 'case-1', roomId: 'OR-1', surgeonId: 'surg-1', anesthetistId: 'anes-1', priority: 'ELECTIVE', timeRange: range(8, 10) });
    const result = scheduleCase(schedule, { id: 'case-2', roomId: 'OR-1', surgeonId: 'surg-2', anesthetistId: 'anes-2', priority: 'ELECTIVE', timeRange: range(10, 12) });
    expect(result.scheduled.status).toBe('SCHEDULED');
  });

  it('EMERGENCY preempts a conflicting ELECTIVE case when justification is provided', () => {
    const schedule = new OrSchedule();
    scheduleCase(schedule, { id: 'case-1', roomId: 'OR-1', surgeonId: 'surg-1', anesthetistId: 'anes-1', priority: 'ELECTIVE', timeRange: range(8, 10) });

    const result = scheduleCase(schedule, {
      id: 'case-2', roomId: 'OR-1', surgeonId: 'surg-2', anesthetistId: 'anes-2',
      priority: 'EMERGENCY', timeRange: range(9, 11), preemptionJustification: 'Ruptured AAA, immediate surgery required.',
    });

    expect(result.scheduled.status).toBe('SCHEDULED');
    expect(result.preempted?.id).toBe('case-1');
    expect(result.preempted?.status).toBe('PREEMPTED');
    expect(result.preempted?.preemptedBy).toBe('case-2');
  });

  it('EMERGENCY preemption without justification is rejected (mandatory audit trail)', () => {
    const schedule = new OrSchedule();
    scheduleCase(schedule, { id: 'case-1', roomId: 'OR-1', surgeonId: 'surg-1', anesthetistId: 'anes-1', priority: 'ELECTIVE', timeRange: range(8, 10) });
    expect(() =>
      scheduleCase(schedule, { id: 'case-2', roomId: 'OR-1', surgeonId: 'surg-2', anesthetistId: 'anes-2', priority: 'EMERGENCY', timeRange: range(9, 11) }),
    ).toThrow(/preemptionJustification/);
  });

  it('EMERGENCY cannot preempt another EMERGENCY case', () => {
    const schedule = new OrSchedule();
    scheduleCase(schedule, { id: 'case-1', roomId: 'OR-1', surgeonId: 'surg-1', anesthetistId: 'anes-1', priority: 'EMERGENCY', timeRange: range(8, 10), preemptionJustification: 'n/a' });
    expect(() =>
      scheduleCase(schedule, { id: 'case-2', roomId: 'OR-1', surgeonId: 'surg-2', anesthetistId: 'anes-2', priority: 'EMERGENCY', timeRange: range(9, 11), preemptionJustification: 'Also critical' }),
    ).toThrow(/Cannot preempt another EMERGENCY case/);
  });

  it('rejects an invalid time range (start >= end)', () => {
    const schedule = new OrSchedule();
    expect(() =>
      scheduleCase(schedule, { id: 'case-1', roomId: 'OR-1', surgeonId: 'surg-1', anesthetistId: 'anes-1', priority: 'ELECTIVE', timeRange: range(10, 8) }),
    ).toThrow(OrSchedulingError);
  });

  it('rejects a request missing required ids', () => {
    const schedule = new OrSchedule();
    expect(() =>
      scheduleCase(schedule, { id: 'case-1', roomId: '', surgeonId: 'surg-1', anesthetistId: 'anes-1', priority: 'ELECTIVE', timeRange: range(8, 10) }),
    ).toThrow(/roomId, surgeonId, and anesthetistId/);
  });
});

describe('calculateAldreteScore', () => {
  it('computes a perfect score of 10 and marks ready for discharge', () => {
    const result = calculateAldreteScore({ activity: 2, respiration: 2, circulation: 2, consciousness: 2, oxygenSaturation: 2 });
    expect(result.total).toBe(10);
    expect(result.readyForDischarge).toBe(true);
  });

  it('marks ready for discharge at the default threshold of 9 with no zero categories', () => {
    const result = calculateAldreteScore({ activity: 2, respiration: 2, circulation: 2, consciousness: 1, oxygenSaturation: 2 });
    expect(result.total).toBe(9);
    expect(result.readyForDischarge).toBe(true);
  });

  it('blocks discharge if ANY category is 0, even if total is otherwise high', () => {
    const result = calculateAldreteScore({ activity: 2, respiration: 2, circulation: 2, consciousness: 2, oxygenSaturation: 0 });
    expect(result.total).toBe(8);
    expect(result.readyForDischarge).toBe(false);
  });

  it('blocks discharge below the threshold even with no zero categories', () => {
    const result = calculateAldreteScore({ activity: 1, respiration: 1, circulation: 1, consciousness: 1, oxygenSaturation: 1 });
    expect(result.total).toBe(5);
    expect(result.readyForDischarge).toBe(false);
  });

  it('respects a stricter facility-configured discharge threshold', () => {
    const result = calculateAldreteScore(
      { activity: 2, respiration: 2, circulation: 2, consciousness: 2, oxygenSaturation: 1 },
      10, // require perfect score
    );
    expect(result.total).toBe(9);
    expect(result.readyForDischarge).toBe(false);
  });

  it('rejects an out-of-range score', () => {
    expect(() =>
      calculateAldreteScore({ activity: 3 as any, respiration: 2, circulation: 2, consciousness: 2, oxygenSaturation: 2 }),
    ).toThrow(InvalidAldreteInputError);
    expect(() =>
      calculateAldreteScore({ activity: 2, respiration: -1 as any, circulation: 2, consciousness: 2, oxygenSaturation: 2 }),
    ).toThrow(InvalidAldreteInputError);
  });
});

import {
  startAnesthesiaRecord,
  addVitals,
  addDrug,
  addGasReading,
  addEvent,
  addFluid,
  signAnesthesiaRecord,
  deviceCaptureRate,
  AnesthesiaRecordError,
} from '../anesthesia-record';
import {
  createOperativeNoteDraft,
  updateOperativeNoteDraft,
  signOperativeNote,
  addAddendum,
  OperativeNoteError,
  OperativeNoteContent,
} from '../operative-note';

describe('AnesthesiaRecord', () => {
  const t0 = new Date('2026-09-18T08:00:00Z');

  it('builds up a record across vitals, drugs, gases, events, and fluids', () => {
    let record = startAnesthesiaRecord('case-1', 'anes-1', t0);
    record = addVitals(record, { at: t0, heartRate: 72, systolicBp: 120, diastolicBp: 80, spo2: 98, fromDevice: true });
    record = addDrug(record, { at: t0, drugName: 'Propofol', dose: '150mg', route: 'IV', administeredBy: { userId: 'anes-1', name: 'Dr A' } });
    record = addGasReading(record, { at: t0, agent: 'sevoflurane', concentrationPercent: 2 });
    record = addEvent(record, { at: t0, type: 'INTUBATION' });
    record = addFluid(record, { at: t0, type: 'CRYSTALLOID', direction: 'IN', volumeMl: 500 });

    expect(record.vitals).toHaveLength(1);
    expect(record.drugs).toHaveLength(1);
    expect(record.gases).toHaveLength(1);
    expect(record.events).toHaveLength(1);
    expect(record.fluids).toHaveLength(1);
    expect(record.immutable).toBe(false);
  });

  it('rejects an invalid gas concentration', () => {
    const record = startAnesthesiaRecord('case-1', 'anes-1', t0);
    expect(() => addGasReading(record, { at: t0, agent: 'O2', concentrationPercent: 150 })).toThrow(/0-100/);
  });

  it('rejects a negative fluid volume', () => {
    const record = startAnesthesiaRecord('case-1', 'anes-1', t0);
    expect(() => addFluid(record, { at: t0, type: 'CRYSTALLOID', direction: 'IN', volumeMl: -10 })).toThrow(/cannot be negative/);
  });

  it('cannot sign a record with zero vitals', () => {
    const record = startAnesthesiaRecord('case-1', 'anes-1', t0);
    expect(() => signAnesthesiaRecord(record)).toThrow(/no vitals recorded/);
  });

  it('signing locks the record immutably (G18-adjacent integrity requirement)', () => {
    let record = startAnesthesiaRecord('case-1', 'anes-1', t0);
    record = addVitals(record, { at: t0, heartRate: 72, fromDevice: false });
    const signed = signAnesthesiaRecord(record, new Date('2026-09-18T10:00:00Z'));
    expect(signed.signed).toBe(true);
    expect(signed.immutable).toBe(true);

    expect(() => addVitals(signed, { at: t0, heartRate: 80, fromDevice: false })).toThrow(/immutable/);
    expect(() => signAnesthesiaRecord(signed)).toThrow(/already signed/);
  });

  it('computes device capture rate correctly', () => {
    let record = startAnesthesiaRecord('case-1', 'anes-1', t0);
    record = addVitals(record, { at: t0, heartRate: 70, fromDevice: true });
    record = addVitals(record, { at: t0, heartRate: 72, fromDevice: true });
    record = addVitals(record, { at: t0, heartRate: 74, fromDevice: false });
    expect(deviceCaptureRate(record)).toBeCloseTo(2 / 3, 5);
  });

  it('device capture rate is 0 for an empty record', () => {
    const record = startAnesthesiaRecord('case-1', 'anes-1', t0);
    expect(deviceCaptureRate(record)).toBe(0);
  });
});

describe('OperativeNote (G17: immutable after sign)', () => {
  const t0 = new Date('2026-09-18T10:00:00Z');
  const fullContent: OperativeNoteContent = {
    preoperativeDiagnosis: 'Acute appendicitis',
    postoperativeDiagnosis: 'Acute appendicitis, confirmed',
    procedurePerformed: 'Laparoscopic appendectomy',
    surgeonNarrative: 'Standard 3-port laparoscopic approach...',
    estimatedBloodLoss: '10mL',
    complications: 'None',
    specimensRemoved: 'Appendix to pathology',
  };

  it('allows editing the draft before signing', () => {
    let note = createOperativeNoteDraft('case-1', 'surg-1', { ...fullContent, surgeonNarrative: '' }, t0);
    note = updateOperativeNoteDraft(note, { surgeonNarrative: 'Updated narrative text.' });
    expect(note.content.surgeonNarrative).toBe('Updated narrative text.');
    expect(note.immutable).toBe(false);
  });

  it('rejects signing when required fields are empty', () => {
    const note = createOperativeNoteDraft('case-1', 'surg-1', { ...fullContent, procedurePerformed: '' }, t0);
    expect(() => signOperativeNote(note)).toThrow(/missing required field/);
  });

  it('signs successfully when all required fields present, and becomes immutable', () => {
    const note = createOperativeNoteDraft('case-1', 'surg-1', fullContent, t0);
    const signed = signOperativeNote(note, new Date('2026-09-18T11:00:00Z'));
    expect(signed.signed).toBe(true);
    expect(signed.immutable).toBe(true);
    expect(signed.signedAt).toBeDefined();
  });

  it('CORE G17: rejects any edit attempt after signing', () => {
    const note = createOperativeNoteDraft('case-1', 'surg-1', fullContent, t0);
    const signed = signOperativeNote(note);
    expect(() => updateOperativeNoteDraft(signed, { surgeonNarrative: 'Trying to sneak in a change' })).toThrow(
      /signed and immutable/,
    );
  });

  it('rejects double-signing', () => {
    const note = createOperativeNoteDraft('case-1', 'surg-1', fullContent, t0);
    const signed = signOperativeNote(note);
    expect(() => signOperativeNote(signed)).toThrow(/already signed/);
  });

  it('corrections to a signed note go through addAddendum, never mutate content', () => {
    const note = createOperativeNoteDraft('case-1', 'surg-1', fullContent, t0);
    const signed = signOperativeNote(note);
    const originalContentSnapshot = JSON.stringify(signed.content);

    const { note: updated, addendum } = addAddendum(signed, 'surg-1', 'Correction: EBL was actually 15mL, not 10mL.', new Date('2026-09-19T09:00:00Z'));

    expect(JSON.stringify(updated.content)).toBe(originalContentSnapshot); // original content untouched
    expect(updated.addendumIds).toContain(addendum.id);
    expect(addendum.originalNoteId).toBe(signed.id);
    expect(addendum.immutable).toBe(true);
  });

  it('rejects an addendum on an unsigned draft', () => {
    const note = createOperativeNoteDraft('case-1', 'surg-1', fullContent, t0);
    expect(() => addAddendum(note, 'surg-1', 'Some note')).toThrow(/unsigned note/);
  });

  it('rejects an empty addendum', () => {
    const note = createOperativeNoteDraft('case-1', 'surg-1', fullContent, t0);
    const signed = signOperativeNote(note);
    expect(() => addAddendum(signed, 'surg-1', '   ')).toThrow(/cannot be empty/);
  });
});

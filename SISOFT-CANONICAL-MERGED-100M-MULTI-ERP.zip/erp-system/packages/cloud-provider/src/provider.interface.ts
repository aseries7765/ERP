import {
  ComputeInstance,
  CreateComputeParams,
  CreateDatabaseParams,
  CreateNetworkParams,
  DatabaseInstance,
  KeyRef,
  NetworkTopology,
  StorageBucket,
} from './types.js';

/**
 * Every concrete cloud implementation (Oracle, and future providers) must
 * implement this interface. Provisioning steps depend only on this
 * interface, never on a vendor SDK, so swapping providers or supporting
 * BYOC does not touch step logic.
 *
 * All methods MUST be idempotent: calling create* twice with the same
 * displayName/dbName for the same compartment must return the existing
 * resource rather than creating a duplicate.
 */
export interface CloudProvider {
  readonly name: string;

  createCompute(params: CreateComputeParams): Promise<ComputeInstance[]>;
  terminateCompute(instanceId: string): Promise<void>;

  createDatabase(params: CreateDatabaseParams): Promise<DatabaseInstance>;
  waitForDatabaseAvailable(dbId: string, timeoutMs: number): Promise<DatabaseInstance>;
  terminateDatabase(dbId: string): Promise<void>;

  createNetwork(params: CreateNetworkParams): Promise<NetworkTopology>;
  deleteNetwork(vcnId: string): Promise<void>;

  createStorageBucket(compartmentId: string, name: string): Promise<StorageBucket>;
  deleteStorageBucket(bucketId: string): Promise<void>;

  generateEncryptionKey(compartmentId: string, customerId: string): Promise<KeyRef>;
  deleteEncryptionKey(keyRef: KeyRef): Promise<void>;

  getCompartmentId(customerId: string): Promise<string>;
  deleteCompartment(compartmentId: string): Promise<void>;
}

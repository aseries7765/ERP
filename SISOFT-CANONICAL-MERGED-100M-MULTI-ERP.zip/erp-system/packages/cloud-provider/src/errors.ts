export class UnknownProviderError extends Error {
  constructor(name: string) {
    super(`No cloud provider registered under name "${name}"`);
    this.name = 'UnknownProviderError';
  }
}

export class QuotaExceededError extends Error {
  constructor(resource: string, compartmentId: string) {
    super(`Quota exceeded for "${resource}" in compartment "${compartmentId}"`);
    this.name = 'QuotaExceededError';
  }
}

export class ResourceNotFoundError extends Error {
  constructor(resourceType: string, id: string) {
    super(`${resourceType} "${id}" not found`);
    this.name = 'ResourceNotFoundError';
  }
}

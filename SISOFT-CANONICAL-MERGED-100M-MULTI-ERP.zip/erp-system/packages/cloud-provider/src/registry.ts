import { CloudProvider } from './provider.interface.js';
import { UnknownProviderError } from './errors.js';

/**
 * Simple in-process registry so the API layer can select a provider by
 * name (e.g. from Customer.region / Customer.cloudProvider) without a
 * hard import dependency on every concrete provider package.
 */
export class CloudProviderRegistry {
  private readonly providers = new Map<string, CloudProvider>();

  register(provider: CloudProvider): void {
    this.providers.set(provider.name, provider);
  }

  get(name: string): CloudProvider {
    const provider = this.providers.get(name);
    if (!provider) throw new UnknownProviderError(name);
    return provider;
  }

  has(name: string): boolean {
    return this.providers.has(name);
  }

  list(): string[] {
    return [...this.providers.keys()];
  }
}

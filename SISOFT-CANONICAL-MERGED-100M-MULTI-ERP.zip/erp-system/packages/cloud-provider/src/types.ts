/**
 * Cloud-agnostic resource shapes. Any concrete provider package
 * (cloud-provider-oracle, and in future cloud-provider-aws, etc.)
 * implements CloudProvider and returns these shapes so the
 * provisioning-engine steps never import a vendor SDK directly.
 */

export interface ComputeInstance {
  id: string;
  shape: string;
  status: 'provisioning' | 'running' | 'stopped' | 'terminated';
  privateIp?: string;
  publicIp?: string;
}

export interface DatabaseInstance {
  id: string;
  status: 'provisioning' | 'available' | 'unavailable' | 'terminating' | 'terminated';
  connectionString?: string;
  cpuCoreCount: number;
  storageTBs: number;
}

export interface NetworkTopology {
  vcnId: string;
  publicSubnetId: string;
  appSubnetId: string;
  dbSubnetId: string;
  mgmtSubnetId: string;
}

export interface StorageBucket {
  id: string;
  name: string;
  region: string;
}

export interface KeyRef {
  vaultId: string;
  keyId: string;
  region: string;
}

export interface CreateComputeParams {
  compartmentId: string;
  subnetId: string;
  shape: string;
  count: number;
  displayNamePrefix: string;
}

export interface CreateDatabaseParams {
  compartmentId: string;
  dbName: string;
  displayName: string;
  cpuCoreCount: number;
  storageTBs: number;
  subnetId: string;
  autoScale: boolean;
}

export interface CreateNetworkParams {
  compartmentId: string;
  cidrBlock: string;
  displayNamePrefix: string;
}

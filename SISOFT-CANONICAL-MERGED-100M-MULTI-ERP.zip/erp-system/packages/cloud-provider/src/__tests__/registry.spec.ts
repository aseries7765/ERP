import assert from 'node:assert/strict';
import { test } from 'node:test';
import { CloudProviderRegistry } from '../registry.js';
import { UnknownProviderError } from '../errors.js';
import { CloudProvider } from '../provider.interface.js';

function fakeProvider(name: string): CloudProvider {
  return {
    name,
    createCompute: async () => [],
    terminateCompute: async () => {},
    createDatabase: async () => ({ id: 'db', status: 'available', cpuCoreCount: 1, storageTBs: 1 }),
    waitForDatabaseAvailable: async () => ({ id: 'db', status: 'available', cpuCoreCount: 1, storageTBs: 1 }),
    terminateDatabase: async () => {},
    createNetwork: async () => ({ vcnId: 'v', publicSubnetId: 'p', appSubnetId: 'a', dbSubnetId: 'd', mgmtSubnetId: 'm' }),
    deleteNetwork: async () => {},
    createStorageBucket: async () => ({ id: 'b', name: 'b', region: 'r' }),
    deleteStorageBucket: async () => {},
    generateEncryptionKey: async () => ({ vaultId: 'v', keyId: 'k', region: 'r' }),
    deleteEncryptionKey: async () => {},
    getCompartmentId: async () => 'comp-1',
    deleteCompartment: async () => {},
  };
}

test('registers and retrieves a provider by name', () => {
  const registry = new CloudProviderRegistry();
  registry.register(fakeProvider('oracle'));
  assert.equal(registry.has('oracle'), true);
  assert.equal(registry.get('oracle').name, 'oracle');
});

test('throws UnknownProviderError for unregistered name', () => {
  const registry = new CloudProviderRegistry();
  assert.throws(() => registry.get('aws'), UnknownProviderError);
});

test('lists all registered provider names', () => {
  const registry = new CloudProviderRegistry();
  registry.register(fakeProvider('oracle'));
  registry.register(fakeProvider('aws'));
  assert.deepEqual(registry.list().sort(), ['aws', 'oracle']);
});

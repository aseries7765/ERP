import assert from 'node:assert/strict';
import { test } from 'node:test';
import { withRetry } from '../utils/retry.js';

const instantSleep = async () => {};

test('returns result immediately on success', async () => {
  const result = await withRetry(async () => 42, { sleep: instantSleep });
  assert.equal(result, 42);
});

test('retries the configured number of times then throws', async () => {
  let calls = 0;
  await assert.rejects(
    () =>
      withRetry(
        async () => {
          calls++;
          throw new Error('fail');
        },
        { maxAttempts: 4, sleep: instantSleep },
      ),
    /fail/,
  );
  assert.equal(calls, 4);
});

test('does not retry when isRetryable returns false', async () => {
  let calls = 0;
  await assert.rejects(() =>
    withRetry(
      async () => {
        calls++;
        throw new Error('permanent');
      },
      { maxAttempts: 5, sleep: instantSleep, isRetryable: () => false },
    ),
  );
  assert.equal(calls, 1);
});

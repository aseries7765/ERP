import assert from 'node:assert/strict';
import { test } from 'node:test';
import { CircuitBreaker } from '../utils/circuit-breaker.js';

test('opens after failureThreshold consecutive failures', async () => {
  const breaker = new CircuitBreaker({ failureThreshold: 3 });
  for (let i = 0; i < 3; i++) {
    await assert.rejects(() =>
      breaker.execute(async () => {
        throw new Error('boom');
      }),
    );
  }
  assert.equal(breaker.getState(), 'open');
  await assert.rejects(() => breaker.execute(async () => 'ok'), /Circuit breaker is open/);
});

test('resets to half_open after resetTimeoutMs then closes on success', async () => {
  let time = 0;
  const breaker = new CircuitBreaker({ failureThreshold: 1, resetTimeoutMs: 1000, now: () => time });
  await assert.rejects(() =>
    breaker.execute(async () => {
      throw new Error('boom');
    }),
  );
  assert.equal(breaker.getState(), 'open');
  time += 1000;
  assert.equal(breaker.getState(), 'half_open');
  const result = await breaker.execute(async () => 'recovered');
  assert.equal(result, 'recovered');
  assert.equal(breaker.getState(), 'closed');
});

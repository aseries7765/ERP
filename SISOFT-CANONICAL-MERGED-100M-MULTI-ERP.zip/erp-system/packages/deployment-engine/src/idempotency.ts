/**
 * Tracks which (deploymentId, stepName) pairs have already completed successfully,
 * so a crash-resume or manual retry of the whole orchestration doesn't re-apply
 * side effects for steps that already succeeded. Backed by an in-memory Set here;
 * production wires this to the DeploymentLog table (see apps/api DeploymentLog model).
 */
export class IdempotencyTracker {
  private completed = new Set<string>();

  private key(deploymentId: string, stepName: string): string {
    return `${deploymentId}::${stepName}`;
  }

  markCompleted(deploymentId: string, stepName: string): void {
    this.completed.add(this.key(deploymentId, stepName));
  }

  isCompleted(deploymentId: string, stepName: string): boolean {
    return this.completed.has(this.key(deploymentId, stepName));
  }

  reset(deploymentId: string): void {
    for (const key of [...this.completed]) {
      if (key.startsWith(`${deploymentId}::`)) this.completed.delete(key);
    }
  }
}

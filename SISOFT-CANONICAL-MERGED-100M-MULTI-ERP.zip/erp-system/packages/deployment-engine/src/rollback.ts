import { DeploymentStep, StepContext, StepLogEntry } from './types';

/** Result of a rollback attempt: which steps were rolled back, and where it stopped if one failed. */
export interface RollbackOutcome {
  succeeded: boolean;
  attemptedSteps: string[];
  failedStep?: string;
  error?: string;
}

/**
 * Runs rollback() for each successfully-completed step, in reverse (LIFO) order.
 * A step with no rollback() defined is treated as having nothing to undo and is skipped.
 * Rollback stops at the first failure and reports it — per the runbook, a failed rollback
 * requires manual intervention (P1 / war room), it is not itself retried indefinitely here.
 */
export async function runRollback(
  completedStepsInOrder: DeploymentStep[],
  ctx: StepContext,
  onLog?: (entry: StepLogEntry) => void | Promise<void>,
): Promise<RollbackOutcome> {
  const attemptedSteps: string[] = [];
  const reversed = [...completedStepsInOrder].reverse();

  for (const step of reversed) {
    if (!step.rollback) continue;
    attemptedSteps.push(step.name);
    const startedAt = new Date().toISOString();
    try {
      await step.rollback(ctx);
      await onLog?.({
        stepName: `rollback:${step.name}`,
        attempt: 1,
        startedAt,
        endedAt: new Date().toISOString(),
        result: 'success',
      });
    } catch (err) {
      const message = (err as Error)?.message ?? String(err);
      await onLog?.({
        stepName: `rollback:${step.name}`,
        attempt: 1,
        startedAt,
        endedAt: new Date().toISOString(),
        result: 'failure',
        error: message,
      });
      return { succeeded: false, attemptedSteps, failedStep: step.name, error: message };
    }
  }

  return { succeeded: true, attemptedSteps };
}

import { DeploymentStep, StepContext, StepLogEntry } from './types';
import { withTimeout } from './timeout';
import { IdempotencyTracker } from './idempotency';

/** Runtime configuration passed to executeStep(): retry/backoff policy, idempotency store, and logging sink. */
export interface StepExecutorOptions {
  defaultMaxRetries: number;
  backoffBaseMs: number;
  sleep: (ms: number) => Promise<void>;
  idempotency: IdempotencyTracker;
  onStepLog?: (entry: StepLogEntry) => void | Promise<void>;
}

/** Thrown by executeStep() once a step has exhausted its retry budget without succeeding. */
export class StepExecutionFailedError extends Error {
  constructor(
    public readonly stepName: string,
    public readonly attempts: number,
    public readonly cause: unknown,
  ) {
    super(`Step "${stepName}" failed after ${attempts} attempt(s): ${(cause as Error)?.message ?? String(cause)}`);
    this.name = 'StepExecutionFailedError';
  }
}

/**
 * Executes a single step with idempotency short-circuiting, retry with exponential
 * backoff, and a per-attempt timeout. Throws StepExecutionFailedError if all
 * retries are exhausted.
 */
export async function executeStep(step: DeploymentStep, ctx: StepContext, opts: StepExecutorOptions): Promise<void> {
  if (step.skipOnZeroDowntime && ctx.zeroDowntime) {
    await opts.onStepLog?.({
      stepName: step.name,
      attempt: 0,
      startedAt: new Date().toISOString(),
      endedAt: new Date().toISOString(),
      result: 'skipped',
    });
    return;
  }

  if (opts.idempotency.isCompleted(ctx.deploymentId, step.name)) {
    await opts.onStepLog?.({
      stepName: step.name,
      attempt: 0,
      startedAt: new Date().toISOString(),
      endedAt: new Date().toISOString(),
      result: 'skipped',
    });
    return;
  }

  const maxRetries = step.maxRetries ?? opts.defaultMaxRetries;
  let lastError: unknown;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    const startedAt = new Date().toISOString();
    try {
      await withTimeout(() => step.run(ctx), step.timeoutMs, step.name);
      const endedAt = new Date().toISOString();
      await opts.onStepLog?.({ stepName: step.name, attempt, startedAt, endedAt, result: 'success' });
      opts.idempotency.markCompleted(ctx.deploymentId, step.name);
      return;
    } catch (err) {
      lastError = err;
      const endedAt = new Date().toISOString();
      await opts.onStepLog?.({
        stepName: step.name,
        attempt,
        startedAt,
        endedAt,
        result: 'failure',
        error: (err as Error)?.message ?? String(err),
      });
      if (attempt < maxRetries) {
        const backoff = opts.backoffBaseMs * 2 ** (attempt - 1);
        await opts.sleep(backoff);
      }
    }
  }

  throw new StepExecutionFailedError(step.name, maxRetries, lastError);
}

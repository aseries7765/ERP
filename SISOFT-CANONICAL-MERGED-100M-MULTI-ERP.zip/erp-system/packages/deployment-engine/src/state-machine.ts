import { DeploymentState } from './types';

/** Allowed transitions. Any transition not listed here is illegal. */
const TRANSITIONS: Record<DeploymentState, DeploymentState[]> = {
  pending_approval: ['approved', 'cancelled'],
  approved: ['scheduled', 'running', 'cancelled'],
  scheduled: ['running', 'cancelled'],
  running: ['paused', 'completed', 'failed', 'rolling_back'],
  paused: ['running', 'cancelled', 'rolling_back'],
  completed: [],
  failed: ['rolling_back'],
  rolling_back: ['rolled_back', 'failed_rollback'],
  rolled_back: [],
  failed_rollback: [],
  cancelled: [],
};

/** Thrown by DeploymentStateMachine.transition() when the requested transition isn't legal from the current state. */
export class IllegalStateTransitionError extends Error {
  constructor(from: DeploymentState, to: DeploymentState) {
    super(`Illegal deployment state transition: ${from} -> ${to}`);
    this.name = 'IllegalStateTransitionError';
  }
}

/** Enforces the legal deployment lifecycle graph (see TRANSITIONS above) and tracks current state. */
export class DeploymentStateMachine {
  private state: DeploymentState;

  constructor(initial: DeploymentState = 'pending_approval') {
    this.state = initial;
  }

  get current(): DeploymentState {
    return this.state;
  }

  canTransition(to: DeploymentState): boolean {
    return TRANSITIONS[this.state].includes(to);
  }

  transition(to: DeploymentState): DeploymentState {
    if (!this.canTransition(to)) {
      throw new IllegalStateTransitionError(this.state, to);
    }
    this.state = to;
    return this.state;
  }

  isTerminal(): boolean {
    return TRANSITIONS[this.state].length === 0;
  }
}

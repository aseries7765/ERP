import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runRollback } from '../rollback';
import { DeploymentStep, StepContext } from '../types';

function makeCtx(): StepContext {
  return {
    deploymentId: 'dep-1',
    customerId: 'cust-1',
    fromVersion: '1.0.0',
    toVersion: '1.1.0',
    data: {},
    zeroDowntime: false,
    isEmergency: false,
  };
}

test('rollback runs in LIFO order', async () => {
  const order: string[] = [];
  const steps: DeploymentStep[] = ['a', 'b', 'c'].map((name) => ({
    name,
    timeoutMs: 100,
    run: async () => {},
    rollback: async () => {
      order.push(name);
    },
  }));
  const outcome = await runRollback(steps, makeCtx());
  assert.equal(outcome.succeeded, true);
  assert.deepEqual(order, ['c', 'b', 'a']);
  assert.deepEqual(outcome.attemptedSteps, ['c', 'b', 'a']);
});

test('steps with no rollback() are skipped, not errored', async () => {
  const order: string[] = [];
  const steps: DeploymentStep[] = [
    { name: 'no-op-forward', timeoutMs: 100, run: async () => {} }, // no rollback defined
    {
      name: 'has-rollback',
      timeoutMs: 100,
      run: async () => {},
      rollback: async () => {
        order.push('has-rollback');
      },
    },
  ];
  const outcome = await runRollback(steps, makeCtx());
  assert.equal(outcome.succeeded, true);
  assert.deepEqual(order, ['has-rollback']);
});

test('rollback stops and reports on first failure', async () => {
  const order: string[] = [];
  const steps: DeploymentStep[] = [
    {
      name: 'a',
      timeoutMs: 100,
      run: async () => {},
      rollback: async () => {
        order.push('a');
      },
    },
    {
      name: 'b-fails',
      timeoutMs: 100,
      run: async () => {},
      rollback: async () => {
        throw new Error('cannot undo migration');
      },
    },
    {
      name: 'c',
      timeoutMs: 100,
      run: async () => {},
      rollback: async () => {
        order.push('c');
      },
    },
  ];
  const outcome = await runRollback(steps, makeCtx());
  assert.equal(outcome.succeeded, false);
  assert.equal(outcome.failedStep, 'b-fails');
  assert.deepEqual(order, ['c']); // c runs first (LIFO), then b-fails halts before a
});

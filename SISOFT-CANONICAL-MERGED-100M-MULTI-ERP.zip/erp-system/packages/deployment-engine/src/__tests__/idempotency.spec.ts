import { test } from 'node:test';
import assert from 'node:assert/strict';
import { IdempotencyTracker } from '../idempotency';

test('marks and checks completion per (deploymentId, stepName)', () => {
  const t = new IdempotencyTracker();
  assert.equal(t.isCompleted('dep-1', 'backup'), false);
  t.markCompleted('dep-1', 'backup');
  assert.equal(t.isCompleted('dep-1', 'backup'), true);
  assert.equal(t.isCompleted('dep-1', 'migrate-db'), false);
  assert.equal(t.isCompleted('dep-2', 'backup'), false); // different deployment, isolated
});

test('reset clears only the given deployment', () => {
  const t = new IdempotencyTracker();
  t.markCompleted('dep-1', 'backup');
  t.markCompleted('dep-2', 'backup');
  t.reset('dep-1');
  assert.equal(t.isCompleted('dep-1', 'backup'), false);
  assert.equal(t.isCompleted('dep-2', 'backup'), true);
});

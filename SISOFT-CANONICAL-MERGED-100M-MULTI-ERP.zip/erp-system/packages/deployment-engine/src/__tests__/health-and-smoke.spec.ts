import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runHealthChecks } from '../health-check';
import { runSmokeTests } from '../smoke-test';

test('runHealthChecks: all healthy -> aggregate healthy', async () => {
  const result = await runHealthChecks([
    async () => ({ service: 'api', healthy: true }),
    async () => ({ service: 'db', healthy: true }),
  ]);
  assert.equal(result.healthy, true);
  assert.equal(result.results.length, 2);
});

test('runHealthChecks: one unhealthy -> aggregate unhealthy', async () => {
  const result = await runHealthChecks([
    async () => ({ service: 'api', healthy: true }),
    async () => ({ service: 'redis', healthy: false, detail: 'connection refused' }),
  ]);
  assert.equal(result.healthy, false);
});

test('runHealthChecks: a throwing probe is captured, not propagated', async () => {
  const result = await runHealthChecks([
    async () => {
      throw new Error('probe crashed');
    },
  ]);
  assert.equal(result.healthy, false);
  assert.match(result.results[0].detail ?? '', /probe crashed/);
});

test('runSmokeTests: all pass', async () => {
  const report = await runSmokeTests([
    { name: 'health-endpoint', run: async () => {} },
    { name: 'db-connectivity', run: async () => {} },
  ]);
  assert.equal(report.passed, true);
  assert.equal(report.checks.length, 2);
});

test('runSmokeTests: a failing check is recorded but does not stop later checks from being reported', async () => {
  const report = await runSmokeTests([
    { name: 'auth-flow', run: async () => { throw new Error('login failed'); } },
    { name: 'search', run: async () => {} },
  ]);
  assert.equal(report.passed, false);
  assert.equal(report.checks[0].passed, false);
  assert.equal(report.checks[1].passed, true);
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DeploymentOrchestrator } from '../orchestrator';
import { DeploymentStateMachine } from '../state-machine';
import { DeploymentStep, StepContext } from '../types';

function makeCtx(): StepContext {
  return {
    deploymentId: 'dep-1',
    customerId: 'cust-1',
    fromVersion: '1.4.0',
    toVersion: '1.5.0',
    data: {},
    zeroDowntime: false,
    isEmergency: false,
  };
}

const instantSleep = async () => {};

test('happy path: all steps succeed -> completed', async () => {
  const executed: string[] = [];
  const steps: DeploymentStep[] = ['preflight', 'backup', 'migrate-db', 'deploy-services', 'health-check', 'smoke-test'].map(
    (name) => ({
      name,
      timeoutMs: 100,
      run: async () => {
        executed.push(name);
      },
    }),
  );
  const orchestrator = new DeploymentOrchestrator(steps, { backoffBaseMs: 1, sleep: instantSleep });
  const result = await orchestrator.run(makeCtx(), new DeploymentStateMachine('approved'));
  assert.equal(result.finalState, 'completed');
  assert.deepEqual(executed, steps.map((s) => s.name));
});

test('mid-pipeline failure triggers automatic rollback -> rolled_back', async () => {
  const executed: string[] = [];
  const rolledBack: string[] = [];
  const steps: DeploymentStep[] = [
    {
      name: 'backup',
      timeoutMs: 100,
      run: async () => void executed.push('backup'),
      rollback: async () => void rolledBack.push('backup'),
    },
    {
      name: 'migrate-db',
      timeoutMs: 100,
      maxRetries: 1,
      run: async () => {
        throw new Error('migration syntax error');
      },
      rollback: async () => void rolledBack.push('migrate-db'),
    },
    {
      name: 'deploy-services',
      timeoutMs: 100,
      run: async () => void executed.push('deploy-services'),
      rollback: async () => void rolledBack.push('deploy-services'),
    },
  ];
  const orchestrator = new DeploymentOrchestrator(steps, { backoffBaseMs: 1, sleep: instantSleep });
  const result = await orchestrator.run(makeCtx(), new DeploymentStateMachine('approved'));
  assert.equal(result.finalState, 'rolled_back');
  // deploy-services never ran because migrate-db failed first
  assert.deepEqual(executed, ['backup']);
  // only backup gets rolled back (LIFO from point of failure); migrate-db's own rollback also runs
  // since it's included in "completed" only if run() succeeded - it didn't, so it's excluded.
  assert.deepEqual(rolledBack, ['backup']);
  assert.match(result.error ?? '', /migration syntax error/);
});

test('failure where rollback itself fails -> failed_rollback', async () => {
  const steps: DeploymentStep[] = [
    {
      name: 'backup',
      timeoutMs: 100,
      run: async () => {},
      rollback: async () => {
        throw new Error('backup restore unavailable');
      },
    },
    {
      name: 'migrate-db',
      timeoutMs: 100,
      maxRetries: 1,
      run: async () => {
        throw new Error('migration failed');
      },
    },
  ];
  const orchestrator = new DeploymentOrchestrator(steps, { backoffBaseMs: 1, sleep: instantSleep });
  const result = await orchestrator.run(makeCtx(), new DeploymentStateMachine('approved'));
  assert.equal(result.finalState, 'failed_rollback');
  assert.match(result.error ?? '', /migration failed/);
  assert.match(result.error ?? '', /backup restore unavailable/);
});

test('state transitions are reported via onStateChange in order', async () => {
  const transitions: string[] = [];
  const steps: DeploymentStep[] = [{ name: 'noop', timeoutMs: 100, run: async () => {} }];
  const orchestrator = new DeploymentOrchestrator(steps, {
    backoffBaseMs: 1,
    sleep: instantSleep,
    onStateChange: (from, to) => void transitions.push(`${from}->${to}`),
  });
  await orchestrator.run(makeCtx(), new DeploymentStateMachine('approved'));
  assert.deepEqual(transitions, ['approved->running', 'running->completed']);
});

test('re-running the same deploymentId after partial success does not re-execute completed steps (idempotency integration)', async () => {
  const executed: string[] = [];
  const steps: DeploymentStep[] = [
    { name: 'backup', timeoutMs: 100, run: async () => void executed.push('backup') },
    { name: 'migrate-db', timeoutMs: 100, run: async () => void executed.push('migrate-db') },
  ];
  const orchestrator = new DeploymentOrchestrator(steps, { backoffBaseMs: 1, sleep: instantSleep });
  await orchestrator.run(makeCtx(), new DeploymentStateMachine('approved'));
  // Re-run the same orchestrator instance (shares idempotency tracker) for the same deploymentId.
  await orchestrator.run(makeCtx(), new DeploymentStateMachine('approved'));
  assert.deepEqual(executed, ['backup', 'migrate-db']); // not duplicated
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { executeStep, StepExecutionFailedError } from '../step-executor';
import { IdempotencyTracker } from '../idempotency';
import { DeploymentStep, StepContext, StepLogEntry } from '../types';

function makeCtx(overrides: Partial<StepContext> = {}): StepContext {
  return {
    deploymentId: 'dep-1',
    customerId: 'cust-1',
    fromVersion: '1.0.0',
    toVersion: '1.1.0',
    data: {},
    zeroDowntime: false,
    isEmergency: false,
    ...overrides,
  };
}

const instantSleep = async () => {}; // no real delay in tests

test('successful step logs one success entry', async () => {
  const logs: StepLogEntry[] = [];
  let calls = 0;
  const step: DeploymentStep = {
    name: 'noop',
    timeoutMs: 100,
    run: async () => {
      calls++;
    },
  };
  await executeStep(step, makeCtx(), {
    defaultMaxRetries: 3,
    backoffBaseMs: 1,
    sleep: instantSleep,
    idempotency: new IdempotencyTracker(),
    onStepLog: (e) => void logs.push(e),
  });
  assert.equal(calls, 1);
  assert.equal(logs.length, 1);
  assert.equal(logs[0].result, 'success');
});

test('retries on failure up to maxRetries, then succeeds', async () => {
  let calls = 0;
  const step: DeploymentStep = {
    name: 'flaky',
    timeoutMs: 100,
    run: async () => {
      calls++;
      if (calls < 3) throw new Error('transient failure');
    },
  };
  const logs: StepLogEntry[] = [];
  await executeStep(step, makeCtx(), {
    defaultMaxRetries: 5,
    backoffBaseMs: 1,
    sleep: instantSleep,
    idempotency: new IdempotencyTracker(),
    onStepLog: (e) => void logs.push(e),
  });
  assert.equal(calls, 3);
  assert.equal(logs.filter((l) => l.result === 'failure').length, 2);
  assert.equal(logs.filter((l) => l.result === 'success').length, 1);
});

test('exhausting retries throws StepExecutionFailedError', async () => {
  const step: DeploymentStep = {
    name: 'always-fails',
    timeoutMs: 100,
    maxRetries: 2,
    run: async () => {
      throw new Error('permanent failure');
    },
  };
  await assert.rejects(
    executeStep(step, makeCtx(), {
      defaultMaxRetries: 3,
      backoffBaseMs: 1,
      sleep: instantSleep,
      idempotency: new IdempotencyTracker(),
    }),
    (err: unknown) => {
      assert.ok(err instanceof StepExecutionFailedError);
      assert.equal(err.attempts, 2);
      return true;
    },
  );
});

test('step exceeding timeout fails that attempt', async () => {
  const step: DeploymentStep = {
    name: 'slow',
    timeoutMs: 20,
    maxRetries: 1,
    run: async () => {
      await new Promise((resolve) => setTimeout(resolve, 200));
    },
  };
  await assert.rejects(
    executeStep(step, makeCtx(), {
      defaultMaxRetries: 3,
      backoffBaseMs: 1,
      sleep: instantSleep,
      idempotency: new IdempotencyTracker(),
    }),
    StepExecutionFailedError,
  );
});

test('idempotency: already-completed step is skipped without re-running', async () => {
  let calls = 0;
  const step: DeploymentStep = {
    name: 'once-only',
    timeoutMs: 100,
    run: async () => {
      calls++;
    },
  };
  const idempotency = new IdempotencyTracker();
  const ctx = makeCtx();
  await executeStep(step, ctx, { defaultMaxRetries: 3, backoffBaseMs: 1, sleep: instantSleep, idempotency });
  await executeStep(step, ctx, { defaultMaxRetries: 3, backoffBaseMs: 1, sleep: instantSleep, idempotency });
  assert.equal(calls, 1);
});

test('zero-downtime deployments skip steps flagged skipOnZeroDowntime', async () => {
  let calls = 0;
  const step: DeploymentStep = {
    name: 'maintenance-on',
    timeoutMs: 100,
    skipOnZeroDowntime: true,
    run: async () => {
      calls++;
    },
  };
  const logs: StepLogEntry[] = [];
  await executeStep(step, makeCtx({ zeroDowntime: true }), {
    defaultMaxRetries: 3,
    backoffBaseMs: 1,
    sleep: instantSleep,
    idempotency: new IdempotencyTracker(),
    onStepLog: (e) => void logs.push(e),
  });
  assert.equal(calls, 0);
  assert.equal(logs[0].result, 'skipped');
});

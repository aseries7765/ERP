import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CustomerDeploymentLock, ConcurrentDeploymentError } from '../concurrency';

test('second deployment for same customer is blocked while first holds the lock', async () => {
  const lock = new CustomerDeploymentLock();
  let secondStarted = false;

  const first = lock.withLock('cust-1', async () => {
    await new Promise((resolve) => setTimeout(resolve, 20));
    return 'first-done';
  });

  // Give the first call a tick to acquire the lock before we try the second.
  await new Promise((resolve) => setTimeout(resolve, 1));
  assert.equal(lock.isLocked('cust-1'), true);
  assert.throws(() => {
    secondStarted = true;
    lock.acquire('cust-1');
  }, ConcurrentDeploymentError);
  assert.equal(secondStarted, true);

  await first;
  assert.equal(lock.isLocked('cust-1'), false);
});

test('different customers do not block each other', () => {
  const lock = new CustomerDeploymentLock();
  lock.acquire('cust-1');
  assert.doesNotThrow(() => lock.acquire('cust-2'));
});

test('lock is released even if the wrapped function throws', async () => {
  const lock = new CustomerDeploymentLock();
  await assert.rejects(
    lock.withLock('cust-1', async () => {
      throw new Error('boom');
    }),
  );
  assert.equal(lock.isLocked('cust-1'), false);
});

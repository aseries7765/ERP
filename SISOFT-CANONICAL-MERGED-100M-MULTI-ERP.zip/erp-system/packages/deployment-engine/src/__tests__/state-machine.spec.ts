import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DeploymentStateMachine, IllegalStateTransitionError } from '../state-machine';

test('valid transition sequence for a happy-path deployment', () => {
  const m = new DeploymentStateMachine('pending_approval');
  m.transition('approved');
  m.transition('running');
  m.transition('completed');
  assert.equal(m.current, 'completed');
  assert.equal(m.isTerminal(), true);
});

test('rejects illegal transitions', () => {
  const m = new DeploymentStateMachine('pending_approval');
  assert.throws(() => m.transition('completed'), IllegalStateTransitionError);
});

test('failure path leads through rolling_back to rolled_back', () => {
  const m = new DeploymentStateMachine('running');
  m.transition('failed');
  m.transition('rolling_back');
  m.transition('rolled_back');
  assert.equal(m.current, 'rolled_back');
});

test('failed rollback is terminal and distinct from rolled_back', () => {
  const m = new DeploymentStateMachine('rolling_back');
  m.transition('failed_rollback');
  assert.equal(m.isTerminal(), true);
  assert.equal(m.canTransition('rolled_back'), false);
});

test('cannot transition out of a terminal state', () => {
  const m = new DeploymentStateMachine('completed');
  assert.equal(m.canTransition('running'), false);
});

test('paused deployment can resume or be cancelled', () => {
  const m = new DeploymentStateMachine('running');
  m.transition('paused');
  assert.equal(m.canTransition('running'), true);
  assert.equal(m.canTransition('cancelled'), true);
});

/**
 * Canonical event names this engine's consumers (NestJS deployment module)
 * publish to the "deployment-events" and "audit" topics. Kept here as a single
 * source of truth so producers and any test assertions reference the same strings.
 */
export const DeploymentEvents = {
  Requested: 'deployment.requested',
  Approved: 'deployment.approved',
  Rejected: 'deployment.rejected',
  Scheduled: 'deployment.scheduled',
  Rescheduled: 'deployment.rescheduled',
  Cancelled: 'deployment.cancelled',
  PreflightStarted: 'deployment.preflight.started',
  PreflightPassed: 'deployment.preflight.passed',
  PreflightFailed: 'deployment.preflight.failed',
  BackupStarted: 'deployment.backup.started',
  BackupCompleted: 'deployment.backup.completed',
  MaintenanceStarted: 'deployment.maintenance.started',
  MaintenanceEnded: 'deployment.maintenance.ended',
  MigrationStarted: 'deployment.migration.started',
  MigrationCompleted: 'deployment.migration.completed',
  MigrationFailed: 'deployment.migration.failed',
  ServiceStarted: 'deployment.service.started',
  ServiceCompleted: 'deployment.service.completed',
  ServiceFailed: 'deployment.service.failed',
  HealthStarted: 'deployment.health.started',
  HealthPassed: 'deployment.health.passed',
  HealthFailed: 'deployment.health.failed',
  SmokeTestPassed: 'deployment.smoke-test.passed',
  SmokeTestFailed: 'deployment.smoke-test.failed',
  Completed: 'deployment.completed',
  Failed: 'deployment.failed',
  RolledBack: 'deployment.rolled-back',
  RollbackStarted: 'deployment.rollback.started',
  RollbackCompleted: 'deployment.rollback.completed',
  RollbackFailed: 'deployment.rollback.failed',
} as const;

/** Union of every valid event name string in DeploymentEvents. */
export type DeploymentEventName = (typeof DeploymentEvents)[keyof typeof DeploymentEvents];

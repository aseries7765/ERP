/** Outcome of a single named smoke check. */
export interface SmokeCheckResult {
  name: string;
  passed: boolean;
  detail?: string;
  durationMs: number;
}

/** Aggregate result of a full smoke-test run: passed iff every individual check passed. */
export interface SmokeTestReport {
  passed: boolean;
  checks: SmokeCheckResult[];
}

/** A single smoke check's executable body; throw to signal failure. */
export type SmokeCheck = () => Promise<void>;

/**
 * Runs named smoke checks sequentially (so a failing early check like DB
 * connectivity short-circuits the rest, matching the runbook's "any fail ->
 * rollback" behavior) and returns a full report either way.
 */
export async function runSmokeTests(checks: Array<{ name: string; run: SmokeCheck }>): Promise<SmokeTestReport> {
  const results: SmokeCheckResult[] = [];
  for (const { name, run } of checks) {
    const start = Date.now();
    try {
      await run();
      results.push({ name, passed: true, durationMs: Date.now() - start });
    } catch (err) {
      results.push({ name, passed: false, detail: (err as Error)?.message ?? String(err), durationMs: Date.now() - start });
    }
  }
  return { passed: results.every((r) => r.passed), checks: results };
}

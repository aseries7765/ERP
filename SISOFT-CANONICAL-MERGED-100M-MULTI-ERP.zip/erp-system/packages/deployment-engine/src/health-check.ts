/** Raw health status of one dependency/service, as reported by a HealthProbe. */
export interface HealthCheckResult {
  service: string;
  healthy: boolean;
  detail?: string;
}

/** Combined result of running every HealthProbe: healthy iff every probe reported healthy. */
export interface AggregateHealthResult {
  healthy: boolean;
  results: HealthCheckResult[];
}

/** A single health probe; must not throw (a rejecting probe is treated as unhealthy by runHealthChecks). */
export type HealthProbe = () => Promise<HealthCheckResult>;

/**
 * Runs a set of health probes concurrently and aggregates the result.
 * Individual probes must not throw; a probe that rejects is treated as an
 * infrastructure failure and reported unhealthy rather than crashing the check.
 */
export async function runHealthChecks(probes: HealthProbe[]): Promise<AggregateHealthResult> {
  const results = await Promise.all(
    probes.map(async (probe) => {
      try {
        return await probe();
      } catch (err) {
        return { service: 'unknown', healthy: false, detail: (err as Error)?.message ?? String(err) };
      }
    }),
  );
  return { healthy: results.every((r) => r.healthy), results };
}

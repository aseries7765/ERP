import { DeploymentState, DeploymentStep, OrchestratorOptions, OrchestrationResult, StepContext, StepLogEntry } from './types';
import { DeploymentStateMachine } from './state-machine';
import { executeStep, StepExecutionFailedError } from './step-executor';
import { IdempotencyTracker } from './idempotency';
import { runRollback } from './rollback';

const DEFAULT_MAX_RETRIES = 3;
const DEFAULT_BACKOFF_MS = 1000;
const defaultSleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

/**
 * Runs the ordered list of deployment steps against a shared context, transitioning
 * through the deployment state machine, and automatically rolling back on failure.
 * This is the pure-logic core of DeploymentExecutorService; the NestJS layer wires
 * real steps (backup, migrate-db, deploy-services, etc.) and a real audit sink.
 */
export class DeploymentOrchestrator {
  private readonly idempotency: IdempotencyTracker;
  private readonly opts: Required<Pick<OrchestratorOptions, 'defaultMaxRetries' | 'backoffBaseMs' | 'sleep'>> &
    OrchestratorOptions;

  constructor(
    private readonly steps: DeploymentStep[],
    options: OrchestratorOptions = {},
    idempotency: IdempotencyTracker = new IdempotencyTracker(),
  ) {
    this.opts = {
      defaultMaxRetries: options.defaultMaxRetries ?? DEFAULT_MAX_RETRIES,
      backoffBaseMs: options.backoffBaseMs ?? DEFAULT_BACKOFF_MS,
      sleep: options.sleep ?? defaultSleep,
      onStepLog: options.onStepLog,
      onStateChange: options.onStateChange,
    };
    this.idempotency = idempotency;
  }

  async run(ctx: StepContext, machine: DeploymentStateMachine = new DeploymentStateMachine('approved')): Promise<OrchestrationResult> {
    const log: StepLogEntry[] = [];
    const captureLog = async (entry: StepLogEntry) => {
      log.push(entry);
      await this.opts.onStepLog?.(entry);
    };

    await this.setState(machine, 'running');

    const completed: DeploymentStep[] = [];
    try {
      for (const step of this.steps) {
        await executeStep(step, ctx, {
          defaultMaxRetries: this.opts.defaultMaxRetries,
          backoffBaseMs: this.opts.backoffBaseMs,
          sleep: this.opts.sleep,
          idempotency: this.idempotency,
          onStepLog: captureLog,
        });
        completed.push(step);
      }
    } catch (err) {
      if (err instanceof StepExecutionFailedError) {
        await this.setState(machine, 'failed');
        await this.setState(machine, 'rolling_back');
        const outcome = await runRollback(completed, ctx, captureLog);
        if (outcome.succeeded) {
          await this.setState(machine, 'rolled_back');
          return { finalState: machine.current, log, error: err.message };
        } else {
          await this.setState(machine, 'failed_rollback');
          return { finalState: machine.current, log, error: `${err.message}; rollback also failed at "${outcome.failedStep}": ${outcome.error}` };
        }
      }
      throw err;
    }

    await this.setState(machine, 'completed');
    return { finalState: machine.current, log };
  }

  private async setState(machine: DeploymentStateMachine, to: DeploymentState): Promise<void> {
    const from = machine.current;
    machine.transition(to);
    await this.opts.onStateChange?.(from, to);
  }
}

/** All states a deployment can be in; see state-machine.ts for the legal transition graph. */
export type DeploymentState =
  | 'pending_approval'
  | 'approved'
  | 'scheduled'
  | 'running'
  | 'paused'
  | 'completed'
  | 'failed'
  | 'rolling_back'
  | 'rolled_back'
  | 'failed_rollback'
  | 'cancelled';

/** Outcome of a single step attempt. */
export type StepResult = 'success' | 'failure' | 'skipped';

/** One audit-log line for a single step attempt, success or failure. */
export interface StepLogEntry {
  stepName: string;
  attempt: number;
  startedAt: string;
  endedAt: string;
  result: StepResult;
  error?: string;
}

/** Shared, mutable context threaded through every step of one deployment run. */
export interface StepContext {
  deploymentId: string;
  customerId: string;
  fromVersion: string;
  toVersion: string;
  /** Free-form bag steps can read/write to pass data forward (e.g. backup id, snapshot id). */
  data: Record<string, unknown>;
  /** Whether this deployment is a zero-downtime (non-breaking) deployment. */
  zeroDowntime: boolean;
  isEmergency: boolean;
}

/**
 * A single orchestration step. Implementations must be idempotent: run() may be
 * called more than once for the same context (e.g. after a retry or a crash-resume)
 * and must not double-apply its effect.
 */
export interface DeploymentStep {
  name: string;
  /** Max wall-clock time allowed for a single attempt, in ms. */
  timeoutMs: number;
  /** Max retry attempts on failure before the step is considered failed (default handled by executor). */
  maxRetries?: number;
  /** Executes the step's forward action. Must throw to signal failure. */
  run(ctx: StepContext): Promise<void>;
  /** Reverses this step's effect, used during rollback. Optional for steps with no side effect to undo. */
  rollback?(ctx: StepContext): Promise<void>;
  /** If true, this step is skipped entirely for zero-downtime deployments (e.g. maintenance-on/off). */
  skipOnZeroDowntime?: boolean;
}

/** Tuning knobs and lifecycle hooks for a DeploymentOrchestrator run. */
export interface OrchestratorOptions {
  /** Called after every step attempt (success or failure), for audit logging. */
  onStepLog?: (entry: StepLogEntry) => void | Promise<void>;
  /** Called on every state transition. */
  onStateChange?: (from: DeploymentState, to: DeploymentState) => void | Promise<void>;
  /** Default max retries per step if the step doesn't specify its own. */
  defaultMaxRetries?: number;
  /** Base delay for exponential backoff between retries, in ms. */
  backoffBaseMs?: number;
  /** Injectable clock/sleep for deterministic tests. */
  sleep?: (ms: number) => Promise<void>;
}

/** Final outcome of a full orchestrator run: the ending state, the full step log, and an error summary if any. */
export interface OrchestrationResult {
  finalState: DeploymentState;
  log: StepLogEntry[];
  error?: string;
}

/** Thrown when a deployment is requested for a customer that already has one in flight. */
export class ConcurrentDeploymentError extends Error {
  constructor(customerId: string) {
    super(`A deployment is already in progress for customer "${customerId}"`);
    this.name = 'ConcurrentDeploymentError';
  }
}

/**
 * Ensures only one deployment runs at a time per customer. This is a simple
 * in-memory lock suitable for a single-process test/dev environment; production
 * uses a DB-level advisory lock or row lock on the customer's environment record
 * so it holds across multiple API instances.
 */
export class CustomerDeploymentLock {
  private locked = new Set<string>();

  acquire(customerId: string): void {
    if (this.locked.has(customerId)) {
      throw new ConcurrentDeploymentError(customerId);
    }
    this.locked.add(customerId);
  }

  release(customerId: string): void {
    this.locked.delete(customerId);
  }

  isLocked(customerId: string): boolean {
    return this.locked.has(customerId);
  }

  /** Runs fn() while holding the lock, releasing it afterward regardless of outcome. */
  async withLock<T>(customerId: string, fn: () => Promise<T>): Promise<T> {
    this.acquire(customerId);
    try {
      return await fn();
    } finally {
      this.release(customerId);
    }
  }
}

/** Thrown by withTimeout() when the wrapped function does not resolve within the allotted time. */
export class StepTimeoutError extends Error {
  constructor(stepName: string, timeoutMs: number) {
    super(`Step "${stepName}" timed out after ${timeoutMs}ms`);
    this.name = 'StepTimeoutError';
  }
}

/** Races a promise-returning function against a timeout. Rejects with StepTimeoutError if it wins. */
export async function withTimeout<T>(fn: () => Promise<T>, timeoutMs: number, stepName: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout>;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new StepTimeoutError(stepName, timeoutMs)), timeoutMs);
  });
  try {
    return await Promise.race([fn(), timeoutPromise]);
  } finally {
    clearTimeout(timer!);
  }
}

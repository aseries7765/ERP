# @erp/deployment-engine

Pure-logic deployment orchestration core: a step sequencer with retries,
per-step timeouts, idempotency short-circuiting, a deployment state machine,
a LIFO rollback stack, and a per-customer concurrency lock.

No I/O — steps are injected as plain objects implementing `DeploymentStep`
(`run()` / optional `rollback()`). The NestJS `deployment` module wires real
steps (backup via S3 client, Helm/ArgoCD calls, DB migration runner, etc.)
around this engine; the engine itself only knows about sequencing, not what
each step actually does.

## Modules
- `state-machine.ts` — `DeploymentStateMachine`: enforces the legal state graph
  (`pending_approval → approved → running → completed`, plus
  `failed → rolling_back → rolled_back | failed_rollback`, etc.). Illegal
  transitions throw.
- `step-executor.ts` — runs one step: skip if already idempotently completed,
  skip if flagged `skipOnZeroDowntime` and this is a zero-downtime deploy,
  otherwise retry with exponential backoff up to `maxRetries`, each attempt
  wrapped in `timeout.ts`'s per-step timeout.
- `orchestrator.ts` — `DeploymentOrchestrator`: runs the ordered step list,
  drives the state machine, and on any step's final failure automatically
  triggers `rollback.ts`'s LIFO rollback of every step that had completed.
- `rollback.ts` — `runRollback()`: undoes completed steps in reverse order;
  stops and reports at the first rollback failure (matching the runbook's
  "failed rollback → P1 / war room" policy — it does not retry indefinitely).
- `idempotency.ts` / `concurrency.ts` — an in-memory tracker/lock; production
  backs these with the `DeploymentLog` table and a DB advisory lock
  respectively (see MANIFEST for what's stubbed vs. real).
- `health-check.ts` / `smoke-test.ts` — generic probe/check aggregators used
  as the gates before `maintenance-off` and before marking a deployment
  successful.

## Test status
30/30 unit tests passing, including full integration-style tests of the
orchestrator: happy path, mid-pipeline failure → automatic rollback →
`rolled_back`, and rollback-itself-fails → `failed_rollback`.
TypeScript strict mode, zero errors, zero `any`.

## Not included here
The actual step implementations (S3 backup calls, Postgres migration
execution, Helm/ArgoCD sync, OpenSearch reindex, etc.) are infrastructure
integrations that require real cluster/cloud access. They are **not** part of
this package and are **not implemented** in this delivery — see the root
MANIFEST.md for exactly what that means for the rest of S5's scope.

/**
 * Maps between the HIS internal Patient representation and a FHIR R4
 * Patient resource.
 *
 * Scope honesty: this covers the common demographic fields (identifier,
 * name, birthDate, gender, telecom, address) that HIS-1's Patient/MPI
 * record actually carries. It does NOT cover FHIR Patient's fuller
 * surface (contact, communication, generalPractitioner, link, etc.) —
 * those aren't populated by anything in the internal model yet, so
 * mapping them would mean inventing data. Add fields here as the
 * internal model grows, not before.
 */

export class FhirMappingError extends Error {}

export interface InternalPatient {
  id: string;
  mrn: string;
  mrnAssigningAuthority?: string;
  lastName: string;
  firstName: string;
  middleName?: string;
  /** ISO 8601 date, e.g. "1980-01-15". */
  dateOfBirth: string;
  /** Internal gender code: M, F, O, U (matches HL7 PID-8 convention). */
  gender: 'M' | 'F' | 'O' | 'U';
  phone?: string;
  email?: string;
  address?: {
    line?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
  };
  active?: boolean;
}

/** Minimal FHIR R4 Patient resource shape — the subset this mapper populates. */
export interface FhirPatient {
  resourceType: 'Patient';
  id: string;
  active?: boolean;
  identifier: Array<{
    system?: string;
    value: string;
  }>;
  name: Array<{
    family: string;
    given: string[];
  }>;
  gender: 'male' | 'female' | 'other' | 'unknown';
  birthDate: string;
  telecom?: Array<{ system: 'phone' | 'email'; value: string }>;
  address?: Array<{
    line?: string[];
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
  }>;
}

const GENDER_TO_FHIR: Record<InternalPatient['gender'], FhirPatient['gender']> = {
  M: 'male',
  F: 'female',
  O: 'other',
  U: 'unknown',
};

const GENDER_FROM_FHIR: Record<FhirPatient['gender'], InternalPatient['gender']> = {
  male: 'M',
  female: 'F',
  other: 'O',
  unknown: 'U',
};

/** Internal Patient -> FHIR R4 Patient resource. */
export function mapPatientToFhir(patient: InternalPatient): FhirPatient {
  if (!patient.id) throw new FhirMappingError('Internal patient is missing id.');
  if (!patient.mrn) throw new FhirMappingError('Internal patient is missing mrn.');
  if (!patient.lastName) throw new FhirMappingError('Internal patient is missing lastName.');
  if (!isValidIsoDate(patient.dateOfBirth)) {
    throw new FhirMappingError(`Invalid dateOfBirth (expected YYYY-MM-DD): "${patient.dateOfBirth}"`);
  }

  const telecom: FhirPatient['telecom'] = [];
  if (patient.phone) telecom.push({ system: 'phone', value: patient.phone });
  if (patient.email) telecom.push({ system: 'email', value: patient.email });

  const fhir: FhirPatient = {
    resourceType: 'Patient',
    id: patient.id,
    active: patient.active ?? true,
    identifier: [{ system: patient.mrnAssigningAuthority, value: patient.mrn }],
    name: [
      {
        family: patient.lastName,
        given: [patient.firstName, patient.middleName].filter((n): n is string => Boolean(n)),
      },
    ],
    gender: GENDER_TO_FHIR[patient.gender],
    birthDate: patient.dateOfBirth,
  };

  if (telecom.length > 0) fhir.telecom = telecom;

  if (patient.address) {
    fhir.address = [
      {
        line: patient.address.line ? [patient.address.line] : undefined,
        city: patient.address.city,
        state: patient.address.state,
        postalCode: patient.address.postalCode,
        country: patient.address.country,
      },
    ];
  }

  return fhir;
}

/** FHIR R4 Patient resource -> internal Patient. Inverse of mapPatientToFhir. */
export function mapFhirToPatient(fhir: FhirPatient): InternalPatient {
  if (fhir.resourceType !== 'Patient') {
    throw new FhirMappingError(`Expected resourceType "Patient", got "${fhir.resourceType}".`);
  }
  if (!fhir.identifier || fhir.identifier.length === 0) {
    throw new FhirMappingError('FHIR Patient has no identifier to map to internal mrn.');
  }
  if (!fhir.name || fhir.name.length === 0 || !fhir.name[0].family) {
    throw new FhirMappingError('FHIR Patient has no usable name.family.');
  }

  const primaryIdentifier = fhir.identifier[0];
  const primaryName = fhir.name[0];
  const [firstName, middleName] = primaryName.given ?? [];

  const telecomPhone = fhir.telecom?.find((t) => t.system === 'phone')?.value;
  const telecomEmail = fhir.telecom?.find((t) => t.system === 'email')?.value;
  const primaryAddress = fhir.address?.[0];

  const internal: InternalPatient = {
    id: fhir.id,
    mrn: primaryIdentifier.value,
    mrnAssigningAuthority: primaryIdentifier.system,
    lastName: primaryName.family,
    firstName: firstName ?? '',
    middleName,
    dateOfBirth: fhir.birthDate,
    gender: GENDER_FROM_FHIR[fhir.gender],
    phone: telecomPhone,
    email: telecomEmail,
    active: fhir.active,
  };

  if (primaryAddress) {
    internal.address = {
      line: primaryAddress.line?.[0],
      city: primaryAddress.city,
      state: primaryAddress.state,
      postalCode: primaryAddress.postalCode,
      country: primaryAddress.country,
    };
  }

  return internal;
}

function isValidIsoDate(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value));
}

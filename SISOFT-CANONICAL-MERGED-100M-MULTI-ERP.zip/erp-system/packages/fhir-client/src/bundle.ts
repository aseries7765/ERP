/**
 * Builds a FHIR R4 searchset Bundle with self/next/previous links,
 * given a page of results and the total matching count. Pagination
 * itself (offset/count) is computed upstream by search.ts /
 * the query layer; this only assembles the Bundle wrapper.
 */

export interface BundleEntryInput<T> {
  resource: T;
  fullUrl?: string;
}

export interface BuildBundleInput<T> {
  baseUrl: string; // e.g. "https://his.example.org/fhir/R4/Patient"
  resourceType: string; // e.g. "Patient", used for entry.fullUrl if not given per-entry
  entries: BundleEntryInput<T>[];
  total: number;
  offset: number;
  count: number;
  /** The original query params (excluding _offset) to preserve across page links. */
  queryParams?: Record<string, string>;
}

export interface FhirBundle<T> {
  resourceType: 'Bundle';
  type: 'searchset';
  total: number;
  link: Array<{ relation: 'self' | 'next' | 'previous'; url: string }>;
  entry: Array<{ fullUrl: string; resource: T }>;
}

export function buildBundle<T>(input: BuildBundleInput<T>): FhirBundle<T> {
  if (input.count <= 0) {
    throw new Error('count must be > 0 to build pagination links.');
  }

  const link: FhirBundle<T>['link'] = [
    { relation: 'self', url: buildPageUrl(input, input.offset) },
  ];

  const hasNext = input.offset + input.count < input.total;
  if (hasNext) {
    link.push({ relation: 'next', url: buildPageUrl(input, input.offset + input.count) });
  }

  const hasPrevious = input.offset > 0;
  if (hasPrevious) {
    const previousOffset = Math.max(0, input.offset - input.count);
    link.push({ relation: 'previous', url: buildPageUrl(input, previousOffset) });
  }

  const entry = input.entries.map((e, i) => ({
    fullUrl: e.fullUrl ?? `${input.baseUrl}/${(e.resource as any).id ?? i}`,
    resource: e.resource,
  }));

  return {
    resourceType: 'Bundle',
    type: 'searchset',
    total: input.total,
    link,
    entry,
  };
}

function buildPageUrl<T>(input: BuildBundleInput<T>, offset: number): string {
  const params = new URLSearchParams(input.queryParams ?? {});
  params.set('_offset', String(offset));
  params.set('_count', String(input.count));
  return `${input.baseUrl}?${params.toString()}`;
}

/**
 * Parses FHIR R4 search parameters from a query string into a
 * structured form the internal query layer can act on.
 *
 * Scope: supports the parameters this HIS actually needs for Patient/
 * Encounter/Observation search per spec: _id, identifier, name,
 * birthdate (with prefix comparators), gender, _count, _sort,
 * _offset (this HIS uses offset pagination rather than FHIR's opaque
 * cursor `_page` param — documented in FHIR.md as a deliberate
 * deviation for implementation simplicity). Chained params, _include,
 * and _revinclude are NOT implemented — see MANIFEST for scope cuts.
 */

export class FhirSearchParseError extends Error {}

/** FHIR date search prefixes, e.g. birthdate=ge1980-01-01. */
export type DatePrefix = 'eq' | 'ne' | 'gt' | 'lt' | 'ge' | 'le';

export interface DateParam {
  prefix: DatePrefix;
  value: string; // ISO date/datetime, not further validated here
}

export interface ParsedSearchParams {
  id?: string;
  identifier?: string;
  name?: string;
  birthdate?: DateParam[];
  gender?: string;
  count: number;
  offset: number;
  sort?: { field: string; direction: 'asc' | 'desc' }[];
}

const DEFAULT_COUNT = 20;
const MAX_COUNT = 200;

const DATE_PREFIXES: DatePrefix[] = ['eq', 'ne', 'gt', 'lt', 'ge', 'le'];

/**
 * Parses a URLSearchParams (or plain Record<string,string|string[]>)
 * representing the query string of a FHIR search request.
 */
export function parseSearchParams(input: URLSearchParams | Record<string, string | string[]>): ParsedSearchParams {
  const get = makeGetter(input);

  const result: ParsedSearchParams = {
    count: DEFAULT_COUNT,
    offset: 0,
  };

  const id = get('_id');
  if (id) result.id = id[0];

  const identifier = get('identifier');
  if (identifier) result.identifier = identifier[0];

  const name = get('name');
  if (name) result.name = name[0];

  const gender = get('gender');
  if (gender) {
    const g = gender[0];
    if (!['male', 'female', 'other', 'unknown'].includes(g)) {
      throw new FhirSearchParseError(`Invalid gender search value: "${g}"`);
    }
    result.gender = g;
  }

  const birthdate = get('birthdate');
  if (birthdate) {
    result.birthdate = birthdate.map(parseDateParam);
  }

  const count = get('_count');
  if (count) {
    const n = Number(count[0]);
    if (!Number.isInteger(n) || n < 0) {
      throw new FhirSearchParseError(`Invalid _count value: "${count[0]}"`);
    }
    result.count = Math.min(n, MAX_COUNT);
  }

  const offset = get('_offset');
  if (offset) {
    const n = Number(offset[0]);
    if (!Number.isInteger(n) || n < 0) {
      throw new FhirSearchParseError(`Invalid _offset value: "${offset[0]}"`);
    }
    result.offset = n;
  }

  const sort = get('_sort');
  if (sort) {
    result.sort = sort[0].split(',').map((raw) => {
      const desc = raw.startsWith('-');
      return { field: desc ? raw.slice(1) : raw, direction: desc ? 'desc' : 'asc' };
    });
  }

  return result;
}

function parseDateParam(raw: string): DateParam {
  const prefixCandidate = raw.slice(0, 2);
  if (DATE_PREFIXES.includes(prefixCandidate as DatePrefix)) {
    const value = raw.slice(2);
    if (!value) throw new FhirSearchParseError(`Date param "${raw}" has a prefix but no value.`);
    return { prefix: prefixCandidate as DatePrefix, value };
  }
  // No prefix means implicit "eq" per FHIR spec.
  if (!raw) throw new FhirSearchParseError('Empty birthdate search value.');
  return { prefix: 'eq', value: raw };
}

function makeGetter(
  input: URLSearchParams | Record<string, string | string[]>,
): (key: string) => string[] | undefined {
  if (input instanceof URLSearchParams) {
    return (key: string) => {
      const values = input.getAll(key);
      return values.length > 0 ? values : undefined;
    };
  }
  return (key: string) => {
    const v = input[key];
    if (v === undefined) return undefined;
    return Array.isArray(v) ? v : [v];
  };
}

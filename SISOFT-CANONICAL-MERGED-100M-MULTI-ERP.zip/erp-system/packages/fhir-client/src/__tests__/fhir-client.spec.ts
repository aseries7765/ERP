import { mapPatientToFhir, mapFhirToPatient, FhirMappingError, InternalPatient, FhirPatient } from '../resources/patient';
import { parseSearchParams, FhirSearchParseError } from '../search';
import { buildBundle } from '../bundle';

describe('mapPatientToFhir', () => {
  const internal: InternalPatient = {
    id: 'pat-1',
    mrn: 'MRN12345',
    mrnAssigningAuthority: 'HOSPITAL',
    lastName: 'Doe',
    firstName: 'John',
    middleName: 'Middle',
    dateOfBirth: '1980-01-15',
    gender: 'M',
    phone: '555-1234',
    email: 'john@example.com',
    address: { line: '123 Main St', city: 'Springfield', state: 'IL', postalCode: '62704', country: 'USA' },
  };

  it('maps all populated fields correctly', () => {
    const fhir = mapPatientToFhir(internal);
    expect(fhir.resourceType).toBe('Patient');
    expect(fhir.id).toBe('pat-1');
    expect(fhir.identifier).toEqual([{ system: 'HOSPITAL', value: 'MRN12345' }]);
    expect(fhir.name).toEqual([{ family: 'Doe', given: ['John', 'Middle'] }]);
    expect(fhir.gender).toBe('male');
    expect(fhir.birthDate).toBe('1980-01-15');
    expect(fhir.telecom).toEqual([
      { system: 'phone', value: '555-1234' },
      { system: 'email', value: 'john@example.com' },
    ]);
    expect(fhir.address).toEqual([
      { line: ['123 Main St'], city: 'Springfield', state: 'IL', postalCode: '62704', country: 'USA' },
    ]);
    expect(fhir.active).toBe(true);
  });

  it('omits telecom/address when not present, and respects active=false', () => {
    const minimal: InternalPatient = {
      id: 'pat-2',
      mrn: 'MRN2',
      lastName: 'Smith',
      firstName: 'Jane',
      dateOfBirth: '1990-05-01',
      gender: 'F',
      active: false,
    };
    const fhir = mapPatientToFhir(minimal);
    expect(fhir.telecom).toBeUndefined();
    expect(fhir.address).toBeUndefined();
    expect(fhir.active).toBe(false);
    expect(fhir.name[0].given).toEqual(['Jane']);
  });

  it('maps all four gender codes correctly', () => {
    const base = { id: 'p', mrn: 'M', lastName: 'X', firstName: 'Y', dateOfBirth: '2000-01-01' };
    expect(mapPatientToFhir({ ...base, gender: 'M' }).gender).toBe('male');
    expect(mapPatientToFhir({ ...base, gender: 'F' }).gender).toBe('female');
    expect(mapPatientToFhir({ ...base, gender: 'O' }).gender).toBe('other');
    expect(mapPatientToFhir({ ...base, gender: 'U' }).gender).toBe('unknown');
  });

  it('rejects missing required fields', () => {
    expect(() => mapPatientToFhir({ ...internal, id: '' })).toThrow(FhirMappingError);
    expect(() => mapPatientToFhir({ ...internal, mrn: '' })).toThrow(FhirMappingError);
    expect(() => mapPatientToFhir({ ...internal, lastName: '' })).toThrow(FhirMappingError);
  });

  it('rejects a malformed dateOfBirth', () => {
    expect(() => mapPatientToFhir({ ...internal, dateOfBirth: '01/15/1980' })).toThrow(/Invalid dateOfBirth/);
    expect(() => mapPatientToFhir({ ...internal, dateOfBirth: '1980-13-99' })).toThrow(/Invalid dateOfBirth/);
  });
});

describe('mapFhirToPatient (reverse mapping)', () => {
  it('round-trips through mapPatientToFhir and back without loss of mapped fields', () => {
    const internal: InternalPatient = {
      id: 'pat-1',
      mrn: 'MRN12345',
      mrnAssigningAuthority: 'HOSPITAL',
      lastName: 'Doe',
      firstName: 'John',
      middleName: 'Middle',
      dateOfBirth: '1980-01-15',
      gender: 'M',
      phone: '555-1234',
      email: 'john@example.com',
      address: { line: '123 Main St', city: 'Springfield', state: 'IL', postalCode: '62704', country: 'USA' },
      active: true,
    };
    const fhir = mapPatientToFhir(internal);
    const roundTripped = mapFhirToPatient(fhir);
    expect(roundTripped).toEqual(internal);
  });

  it('rejects a non-Patient resourceType', () => {
    const bad = { resourceType: 'Encounter' } as unknown as FhirPatient;
    expect(() => mapFhirToPatient(bad)).toThrow(/Expected resourceType "Patient"/);
  });

  it('rejects missing identifier or name', () => {
    const noId = { resourceType: 'Patient', id: 'x', identifier: [], name: [{ family: 'A', given: [] }], gender: 'male', birthDate: '2000-01-01' } as FhirPatient;
    expect(() => mapFhirToPatient(noId)).toThrow(/no identifier/);

    const noName = { resourceType: 'Patient', id: 'x', identifier: [{ value: 'M1' }], name: [], gender: 'male', birthDate: '2000-01-01' } as FhirPatient;
    expect(() => mapFhirToPatient(noName)).toThrow(/no usable name/);
  });
});

describe('parseSearchParams', () => {
  it('parses supported params with defaults for count/offset', () => {
    const params = new URLSearchParams({ _id: 'pat-1', name: 'Doe', gender: 'male' });
    const parsed = parseSearchParams(params);
    expect(parsed.id).toBe('pat-1');
    expect(parsed.name).toBe('Doe');
    expect(parsed.gender).toBe('male');
    expect(parsed.count).toBe(20);
    expect(parsed.offset).toBe(0);
  });

  it('parses birthdate with comparator prefixes and bare (implicit eq)', () => {
    const params = new URLSearchParams();
    params.append('birthdate', 'ge1980-01-01');
    params.append('birthdate', 'lt1990-01-01');
    const parsed = parseSearchParams(params);
    expect(parsed.birthdate).toEqual([
      { prefix: 'ge', value: '1980-01-01' },
      { prefix: 'lt', value: '1990-01-01' },
    ]);

    const bare = parseSearchParams(new URLSearchParams({ birthdate: '1980-01-01' }));
    expect(bare.birthdate).toEqual([{ prefix: 'eq', value: '1980-01-01' }]);
  });

  it('caps _count at MAX_COUNT and validates it is a non-negative integer', () => {
    const capped = parseSearchParams(new URLSearchParams({ _count: '9999' }));
    expect(capped.count).toBe(200);

    expect(() => parseSearchParams(new URLSearchParams({ _count: '-5' }))).toThrow(FhirSearchParseError);
    expect(() => parseSearchParams(new URLSearchParams({ _count: 'abc' }))).toThrow(FhirSearchParseError);
  });

  it('validates _offset similarly', () => {
    expect(parseSearchParams(new URLSearchParams({ _offset: '40' })).offset).toBe(40);
    expect(() => parseSearchParams(new URLSearchParams({ _offset: '-1' }))).toThrow(FhirSearchParseError);
  });

  it('parses _sort with multiple fields and desc prefix', () => {
    const parsed = parseSearchParams(new URLSearchParams({ _sort: '-birthdate,name' }));
    expect(parsed.sort).toEqual([
      { field: 'birthdate', direction: 'desc' },
      { field: 'name', direction: 'asc' },
    ]);
  });

  it('rejects an invalid gender value', () => {
    expect(() => parseSearchParams(new URLSearchParams({ gender: 'x' }))).toThrow(/Invalid gender/);
  });

  it('works with a plain Record input as well as URLSearchParams', () => {
    const parsed = parseSearchParams({ _id: 'p1', name: ['Doe', 'ignored-second'] });
    expect(parsed.id).toBe('p1');
    expect(parsed.name).toBe('Doe');
  });
});

describe('buildBundle', () => {
  const entries = [{ resource: { id: 'p1', name: 'A' } }, { resource: { id: 'p2', name: 'B' } }];

  it('includes self link always, next/previous only when applicable', () => {
    const bundle = buildBundle({
      baseUrl: 'https://his.example.org/fhir/R4/Patient',
      resourceType: 'Patient',
      entries,
      total: 2,
      offset: 0,
      count: 20,
    });
    expect(bundle.total).toBe(2);
    expect(bundle.link.map((l) => l.relation)).toEqual(['self']);
    expect(bundle.entry).toHaveLength(2);
    expect(bundle.entry[0].fullUrl).toBe('https://his.example.org/fhir/R4/Patient/p1');
  });

  it('adds a next link when more results remain', () => {
    const bundle = buildBundle({
      baseUrl: 'https://his.example.org/fhir/R4/Patient',
      resourceType: 'Patient',
      entries,
      total: 50,
      offset: 0,
      count: 2,
    });
    const next = bundle.link.find((l) => l.relation === 'next');
    expect(next).toBeDefined();
    expect(next!.url).toContain('_offset=2');
  });

  it('adds a previous link when offset > 0, floored at 0', () => {
    const bundle = buildBundle({
      baseUrl: 'https://his.example.org/fhir/R4/Patient',
      resourceType: 'Patient',
      entries,
      total: 50,
      offset: 2,
      count: 20,
    });
    const previous = bundle.link.find((l) => l.relation === 'previous');
    expect(previous).toBeDefined();
    expect(previous!.url).toContain('_offset=0');
  });

  it('rejects count <= 0', () => {
    expect(() =>
      buildBundle({ baseUrl: 'x', resourceType: 'Patient', entries: [], total: 0, offset: 0, count: 0 }),
    ).toThrow(/count must be > 0/);
  });

  it('preserves extra query params across pagination links', () => {
    const bundle = buildBundle({
      baseUrl: 'https://his.example.org/fhir/R4/Patient',
      resourceType: 'Patient',
      entries,
      total: 50,
      offset: 0,
      count: 2,
      queryParams: { name: 'Doe' },
    });
    const next = bundle.link.find((l) => l.relation === 'next')!;
    expect(next.url).toContain('name=Doe');
  });
});

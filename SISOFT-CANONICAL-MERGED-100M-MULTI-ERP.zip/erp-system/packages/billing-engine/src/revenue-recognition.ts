import { Money } from './utils/money';

export interface RecognitionScheduleEntry {
  period: number; // 1-indexed month number within the schedule
  recognized: Money;
  deferredBalance: Money; // remaining deferred balance AFTER this period's recognition
}

/**
 * Build a straight-line revenue recognition schedule for an amount billed
 * in advance and earned evenly over `months` (ASC 606 / IFRS 15 style
 * treatment for a subscription performance obligation satisfied over
 * time).
 *
 * Uses Money.allocate() to split the total into `months` shares so that
 * every minor unit is accounted for exactly once — no rounding drift, no
 * "lost cent" at the end of the schedule.
 */
export function buildStraightLineSchedule(
  totalBilled: Money,
  months: number,
): RecognitionScheduleEntry[] {
  if (months <= 0) throw new Error('months must be > 0');
  if (totalBilled.isNegative()) {
    throw new Error('totalBilled must be >= 0');
  }

  const shares = totalBilled.allocate(months);
  const schedule: RecognitionScheduleEntry[] = [];
  let remainingDeferred = totalBilled;

  for (let i = 0; i < months; i++) {
    remainingDeferred = remainingDeferred.subtract(shares[i]);
    schedule.push({
      period: i + 1,
      recognized: shares[i],
      deferredBalance: remainingDeferred,
    });
  }

  return schedule;
}

/**
 * Usage-based (arrears) revenue is recognized immediately in the period it
 * is delivered — there is no deferral. This function exists mainly to make
 * that policy explicit and testable rather than implicit.
 */
export function recognizeUsageRevenueImmediately(amount: Money): {
  recognized: Money;
  deferredBalance: Money;
} {
  return { recognized: amount, deferredBalance: Money.zero(amount.currency) };
}

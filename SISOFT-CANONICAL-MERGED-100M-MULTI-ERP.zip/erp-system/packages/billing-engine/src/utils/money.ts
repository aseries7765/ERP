/**
 * Money handling for the billing engine.
 *
 * NON-NEGOTIABLE RULE: money is never represented as a JS `number`/float.
 * We represent every amount as an integer number of "minor units" (e.g.
 * cents for USD, fils for AED) stored in a BigInt, plus the ISO currency
 * code and the currency's number of decimal places (exponent).
 *
 * This avoids all floating point rounding error (0.1 + 0.2 !== 0.3 class
 * of bugs) which is unacceptable in a revenue engine.
 */

/** Number of minor-unit decimal places per currency (extend as needed). */
export const CURRENCY_EXPONENTS: Record<string, number> = {
  USD: 2,
  EUR: 2,
  GBP: 2,
  PKR: 2,
  SAR: 2,
  AED: 2,
  INR: 2,
  JPY: 0,
  KWD: 3,
  BHD: 3,
};

export type RoundingMode = 'HALF_UP' | 'HALF_EVEN' | 'DOWN' | 'UP';

/**
 * An exact unit price/rate (e.g. "$0.0000005 per token"), kept as an
 * arbitrary-precision rational (numerator/denominator) rather than a
 * Money value.
 *
 * This is intentionally a *different type* from Money: a per-unit rate is
 * routinely finer-grained than a currency's minor-unit exponent (sub-cent
 * pricing is standard for usage billing — e.g. AI tokens, API calls). Money
 * enforces the currency's exponent because it represents an amount you can
 * actually invoice; Rate does not, because it represents a price that only
 * becomes a chargeable amount after being multiplied by a quantity and
 * rounded exactly once, at the end.
 */
export class Rate {
  readonly numerator: bigint;
  readonly denominator: bigint; // always > 0
  readonly currency: string;

  private constructor(numerator: bigint, denominator: bigint, currency: string) {
    this.numerator = numerator;
    this.denominator = denominator;
    this.currency = currency;
  }

  /**
   * Parse an arbitrary-precision decimal string into an exact rational,
   * with NO limit tied to the currency's display exponent (unlike
   * Money.fromDecimalString). "0.0000005" is valid here.
   */
  static fromDecimalString(value: string, currency: string): Rate {
    Money0Check(currency);
    const trimmed = value.trim();
    const negative = trimmed.startsWith('-');
    const clean = trimmed.replace(/^-/, '');
    if (!/^\d+(\.\d+)?$/.test(clean)) {
      throw new Error(`Invalid decimal rate string: "${value}"`);
    }
    const [wholePart, fracPartRaw = ''] = clean.split('.');
    const denominator = 10n ** BigInt(fracPartRaw.length);
    const numerator =
      (BigInt(wholePart) * denominator + BigInt(fracPartRaw || '0')) *
      (negative ? -1n : 1n);
    return new Rate(numerator, denominator, currency);
  }

  /**
   * Multiply this rate by an integer quantity (scaled by `quantityScale` to
   * allow fractional quantities without floats, e.g. quantity=2500,
   * quantityScale=1000 represents 2.5 units), producing a Money amount
   * rounded to the currency's minor unit exactly once.
   */
  multiplyByQuantity(
    quantityScaled: bigint,
    quantityScale: bigint,
    rounding: RoundingMode = 'HALF_UP',
  ): Money {
    const exp = Money.exponentOf(this.currency);
    const minorUnitScale = 10n ** BigInt(exp);
    // amount_minor_units = numerator * quantityScaled * minorUnitScale
    //                      / (denominator * quantityScale)
    const negative =
      (this.numerator < 0n) !== (quantityScaled < 0n);
    const absNumerator = absBig(this.numerator) * absBig(quantityScaled) * minorUnitScale;
    const absDenominator = this.denominator * absBig(quantityScale);
    const { quotient, remainder } = divModBig(absNumerator, absDenominator);
    const rounded = applyRounding(quotient, remainder, absDenominator, rounding);
    return Money.fromMinorUnits(negative ? -rounded : rounded, this.currency);
  }
}

function Money0Check(currency: string): void {
  // Reuses Money's known-currency validation without exposing it publicly twice.
  Money.exponentOf(currency);
}

export class Money {
  /** Integer amount in minor units (e.g. cents). */
  readonly minorUnits: bigint;
  readonly currency: string;

  private constructor(minorUnits: bigint, currency: string) {
    this.minorUnits = minorUnits;
    this.currency = currency;
  }

  static exponentOf(currency: string): number {
    const exp = CURRENCY_EXPONENTS[currency];
    if (exp === undefined) {
      throw new Error(`Unknown currency exponent for "${currency}"`);
    }
    return exp;
  }

  private static exponent(currency: string): number {
    return Money.exponentOf(currency);
  }

  /** Construct from an exact integer count of minor units (e.g. 1050 = $10.50). */
  static fromMinorUnits(minorUnits: bigint | number, currency: string): Money {
    Money.exponent(currency); // validate currency is known
    return new Money(BigInt(minorUnits), currency);
  }

  /**
   * Construct from a decimal string, e.g. "10.50". Using a string (not a
   * number) avoids float precision issues at the point of entry.
   */
  static fromDecimalString(value: string, currency: string): Money {
    const exp = Money.exponent(currency);
    const negative = value.trim().startsWith('-');
    const clean = value.trim().replace(/^-/, '');
    if (!/^\d+(\.\d+)?$/.test(clean)) {
      throw new Error(`Invalid decimal money string: "${value}"`);
    }
    const [wholePart, fracPartRaw = ''] = clean.split('.');
    if (fracPartRaw.length > exp) {
      throw new Error(
        `Too many decimal places for ${currency} (max ${exp}): "${value}"`,
      );
    }
    const fracPart = fracPartRaw.padEnd(exp, '0');
    const minor = BigInt(wholePart + fracPart) * (negative ? -1n : 1n);
    return new Money(minor, currency);
  }

  static zero(currency: string): Money {
    return Money.fromMinorUnits(0n, currency);
  }

  private assertSameCurrency(other: Money): void {
    if (other.currency !== this.currency) {
      throw new Error(
        `Currency mismatch: ${this.currency} vs ${other.currency}`,
      );
    }
  }

  add(other: Money): Money {
    this.assertSameCurrency(other);
    return new Money(this.minorUnits + other.minorUnits, this.currency);
  }

  subtract(other: Money): Money {
    this.assertSameCurrency(other);
    return new Money(this.minorUnits - other.minorUnits, this.currency);
  }

  negate(): Money {
    return new Money(-this.minorUnits, this.currency);
  }

  isNegative(): boolean {
    return this.minorUnits < 0n;
  }

  isZero(): boolean {
    return this.minorUnits === 0n;
  }

  compare(other: Money): -1 | 0 | 1 {
    this.assertSameCurrency(other);
    if (this.minorUnits < other.minorUnits) return -1;
    if (this.minorUnits > other.minorUnits) return 1;
    return 0;
  }

  /**
   * Multiply by a rational factor expressed as integer numerator/denominator
   * (e.g. 18/30 for 18 of 30 days) with explicit rounding. Using integer
   * numerator/denominator (rather than a float multiplier) keeps proration
   * exact until the final rounding step.
   */
  multiplyByFraction(
    numerator: bigint | number,
    denominator: bigint | number,
    rounding: RoundingMode = 'HALF_UP',
  ): Money {
    const num = BigInt(numerator);
    const den = BigInt(denominator);
    if (den === 0n) throw new Error('Division by zero in multiplyByFraction');
    const negative = (this.minorUnits < 0n) !== (num < 0n) !== (den < 0n);
    const absProduct = absBig(this.minorUnits) * absBig(num);
    const absDen = absBig(den);
    const { quotient, remainder } = divModBig(absProduct, absDen);
    const rounded = applyRounding(quotient, remainder, absDen, rounding);
    return new Money(negative ? -rounded : rounded, this.currency);
  }

  /** Split into `parts` shares as evenly as possible with no lost cents. */
  allocate(parts: number): Money[] {
    if (parts <= 0) throw new Error('parts must be > 0');
    const base = this.minorUnits / BigInt(parts);
    let remainder = this.minorUnits % BigInt(parts);
    const result: Money[] = [];
    for (let i = 0; i < parts; i++) {
      let share = base;
      // Distribute the remainder one minor-unit at a time to the first N shares.
      if (remainder > 0n) {
        share += 1n;
        remainder -= 1n;
      } else if (remainder < 0n) {
        share -= 1n;
        remainder += 1n;
      }
      result.push(new Money(share, this.currency));
    }
    return result;
  }

  toDecimalString(): string {
    const exp = Money.exponent(this.currency);
    const negative = this.minorUnits < 0n;
    const abs = absBig(this.minorUnits).toString().padStart(exp + 1, '0');
    if (exp === 0) return (negative ? '-' : '') + abs;
    const whole = abs.slice(0, abs.length - exp);
    const frac = abs.slice(abs.length - exp);
    return `${negative ? '-' : ''}${whole}.${frac}`;
  }

  toString(): string {
    return `${this.toDecimalString()} ${this.currency}`;
  }
}

function absBig(v: bigint): bigint {
  return v < 0n ? -v : v;
}

function divModBig(a: bigint, b: bigint): { quotient: bigint; remainder: bigint } {
  return { quotient: a / b, remainder: a % b };
}

function applyRounding(
  quotient: bigint,
  remainder: bigint,
  denominator: bigint,
  mode: RoundingMode,
): bigint {
  if (remainder === 0n) return quotient;
  switch (mode) {
    case 'DOWN':
      return quotient;
    case 'UP':
      return quotient + 1n;
    case 'HALF_UP': {
      // remainder/denominator >= 0.5 ?
      return remainder * 2n >= denominator ? quotient + 1n : quotient;
    }
    case 'HALF_EVEN': {
      const doubled = remainder * 2n;
      if (doubled > denominator) return quotient + 1n;
      if (doubled < denominator) return quotient;
      // exactly half: round to even
      return quotient % 2n === 0n ? quotient : quotient + 1n;
    }
    default:
      throw new Error(`Unknown rounding mode: ${mode}`);
  }
}

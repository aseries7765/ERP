import { Money } from './utils/money';

export interface ProrationInput {
  /** Total number of days in the billing cycle (e.g. 30, or actual days in the calendar month). */
  cycleDays: number;
  /** Number of days already elapsed on the OLD plan this cycle. */
  daysOnOldPlan: number;
  /** Full-cycle price of the old plan. */
  oldPlanPrice: Money;
  /** Full-cycle price of the new plan. */
  newPlanPrice: Money;
}

export interface ProrationResult {
  /** Credit for the unused portion of the old plan (always >= 0). */
  credit: Money;
  /** Charge for the remaining days on the new plan (always >= 0). */
  charge: Money;
  /**
   * Net amount: positive = charge the customer now, negative = credit
   * (apply to wallet / next invoice).
   */
  net: Money;
  daysOnNewPlan: number;
}

/**
 * Compute proration for a mid-cycle plan change using exact day-based
 * daily rates. Both plans must use the same currency.
 *
 * credit = oldPlanPrice * (daysOnOldPlan / cycleDays)
 * charge = newPlanPrice * (daysOnNewPlan / cycleDays)
 * net    = charge - credit
 *
 * Money.multiplyByFraction keeps the calculation exact (integer minor
 * units) until the final HALF_UP rounding step, so there is no
 * accumulated floating-point error across the two multiplications.
 */
export function calculateProration(input: ProrationInput): ProrationResult {
  const { cycleDays, daysOnOldPlan, oldPlanPrice, newPlanPrice } = input;

  if (cycleDays <= 0) throw new Error('cycleDays must be > 0');
  if (daysOnOldPlan < 0 || daysOnOldPlan > cycleDays) {
    throw new Error('daysOnOldPlan must be between 0 and cycleDays');
  }
  if (oldPlanPrice.currency !== newPlanPrice.currency) {
    throw new Error('Old and new plan must be in the same currency');
  }

  const daysOnNewPlan = cycleDays - daysOnOldPlan;

  const credit = oldPlanPrice.multiplyByFraction(daysOnOldPlan, cycleDays, 'HALF_UP');
  const charge = newPlanPrice.multiplyByFraction(daysOnNewPlan, cycleDays, 'HALF_UP');
  const net = charge.subtract(credit);

  return { credit, charge, net, daysOnNewPlan };
}

/**
 * Number of days in a given cycle, handling leap years and variable month
 * lengths correctly by using actual calendar arithmetic (never a hardcoded
 * "30").
 */
export function daysInCycle(cycleStart: Date, cycleEnd: Date): number {
  const msPerDay = 24 * 60 * 60 * 1000;
  // Normalize to UTC midnight to avoid DST-related off-by-one errors.
  const start = Date.UTC(
    cycleStart.getUTCFullYear(),
    cycleStart.getUTCMonth(),
    cycleStart.getUTCDate(),
  );
  const end = Date.UTC(
    cycleEnd.getUTCFullYear(),
    cycleEnd.getUTCMonth(),
    cycleEnd.getUTCDate(),
  );
  const days = Math.round((end - start) / msPerDay);
  if (days <= 0) throw new Error('cycleEnd must be after cycleStart');
  return days;
}

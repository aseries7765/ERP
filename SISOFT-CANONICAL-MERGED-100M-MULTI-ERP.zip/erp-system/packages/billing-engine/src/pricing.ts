import { Money, Rate } from './utils/money';

export interface PriceTier {
  /** Inclusive lower bound of this tier, in usage units. */
  from: number;
  /** Inclusive upper bound of this tier, or null for unbounded top tier. */
  to: number | null;
  /**
   * Price per unit *within this tier*, as a decimal string. May have any
   * number of decimal places (e.g. "0.0000005") — unlike a Money amount,
   * a unit rate is not limited to the currency's minor-unit exponent,
   * since sub-cent per-unit pricing is standard for usage billing.
   */
  pricePerUnit: string;
}

export type PricingModel =
  | { kind: 'unit'; pricePerUnit: string }
  | { kind: 'tiered'; tiers: PriceTier[] }
  | { kind: 'volume'; tiers: PriceTier[] }
  | { kind: 'package'; packageSize: number; pricePerPackage: string };

/**
 * Calculate the charge for a given usage quantity under a pricing model.
 *
 * - unit: flat per-unit price.
 * - tiered (graduated): each tier is billed at its own rate for the units
 *   that fall inside it (the classic AWS/Stripe "graduated" pricing).
 * - volume: the *entire* quantity is billed at the rate of the tier the
 *   total quantity falls into (Stripe's "volume" pricing).
 * - package: usage is billed in fixed-size packages, rounded up.
 *
 * `usageUnits` MUST be a non-negative integer — the exact count of the
 * smallest meaningful unit for this meter (e.g. individual tokens, whole
 * API calls, whole MB rather than fractional GB). This is intentional: it
 * pushes the responsibility for choosing a fine-enough integer unit onto
 * the usage-metering service, rather than accepting a JS float here and
 * silently truncating its precision. Money math must never rely on float
 * precision, and that includes the *quantity* side of a charge
 * calculation, not just the price side.
 *
 * `usageUnits` must already exclude any amount included free in the plan
 * (the caller is responsible for subtracting `includedX` before calling).
 */
export function calculateUsageCharge(
  usageUnits: number,
  model: PricingModel,
  currency: string,
): Money {
  if (!Number.isInteger(usageUnits)) {
    throw new Error(
      `usageUnits must be an integer count of the smallest meaningful unit ` +
        `for this meter (got ${usageUnits}). Convert fractional quantities ` +
        `(e.g. GB) to an integer sub-unit (e.g. MB) before calling.`,
    );
  }
  if (usageUnits < 0) {
    throw new Error('usageUnits must be >= 0');
  }
  if (usageUnits === 0) {
    return Money.zero(currency);
  }

  switch (model.kind) {
    case 'unit': {
      const rate = Rate.fromDecimalString(model.pricePerUnit, currency);
      return rate.multiplyByQuantity(BigInt(usageUnits), 1n);
    }

    case 'tiered': {
      validateTiers(model.tiers);
      let remaining = usageUnits;
      let total = Money.zero(currency);
      for (const tier of model.tiers) {
        if (remaining <= 0) break;
        const tierCapacity =
          tier.to === null ? Infinity : tier.to - tier.from + 1;
        const unitsInTier = Math.min(remaining, tierCapacity);
        const rate = Rate.fromDecimalString(tier.pricePerUnit, currency);
        total = total.add(rate.multiplyByQuantity(BigInt(unitsInTier), 1n));
        remaining -= unitsInTier;
      }
      if (remaining > 0) {
        throw new Error(
          'Usage exceeds all defined tiers; top tier must have to=null',
        );
      }
      return total;
    }

    case 'volume': {
      validateTiers(model.tiers);
      const tier = model.tiers.find(
        (t) => usageUnits >= t.from && (t.to === null || usageUnits <= t.to),
      );
      if (!tier) {
        throw new Error('Usage does not fall into any volume tier');
      }
      const rate = Rate.fromDecimalString(tier.pricePerUnit, currency);
      return rate.multiplyByQuantity(BigInt(usageUnits), 1n);
    }

    case 'package': {
      if (model.packageSize <= 0 || !Number.isInteger(model.packageSize)) {
        throw new Error('packageSize must be a positive integer');
      }
      const packages = Math.ceil(usageUnits / model.packageSize);
      const rate = Rate.fromDecimalString(model.pricePerPackage, currency);
      return rate.multiplyByQuantity(BigInt(packages), 1n);
    }

    default: {
      const _exhaustive: never = model;
      throw new Error(`Unknown pricing model: ${JSON.stringify(_exhaustive)}`);
    }
  }
}

function validateTiers(tiers: PriceTier[]): void {
  if (tiers.length === 0) throw new Error('At least one tier is required');
  const sorted = [...tiers].sort((a, b) => a.from - b.from);
  for (let i = 0; i < sorted.length; i++) {
    const tier = sorted[i];
    if (tier.to !== null && tier.to < tier.from) {
      throw new Error(`Tier has to < from: ${JSON.stringify(tier)}`);
    }
    if (i < sorted.length - 1 && tier.to === null) {
      throw new Error('Only the last tier may have to=null (unbounded)');
    }
    if (i > 0) {
      const prev = sorted[i - 1];
      if (prev.to === null || tier.from !== prev.to + 1) {
        throw new Error(
          `Tiers must be contiguous with no gaps/overlaps: ${JSON.stringify(prev)} -> ${JSON.stringify(tier)}`,
        );
      }
    }
  }
}

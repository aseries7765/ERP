import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateUsageCharge, PricingModel } from '../pricing';

test('tiered (graduated) pricing matches the spec worked example exactly (50,000 raw tokens -> $42), using true sub-cent per-token rates', () => {
  // Previously this test worked around a real limitation (unit prices were
  // routed through Money, which rejects sub-cent strings). That limitation
  // is now fixed: PriceTier.pricePerUnit uses the arbitrary-precision Rate
  // type internally, so real per-token sub-cent prices work directly, with
  // usage expressed in its natural raw-token integer form.
  const model: PricingModel = {
    kind: 'tiered',
    tiers: [
      { from: 1, to: 10_000, pricePerUnit: '0.001' }, // $0.001 per 1k tokens == $0.000001/token... see below
      { from: 10_001, to: 100_000, pricePerUnit: '0.0008' },
      { from: 100_001, to: null, pricePerUnit: '0.0005' },
    ],
  };
  // The spec prices "per 1k tokens", but pricePerUnit here is $ per ONE
  // usage unit. Since usage is passed in raw tokens, the true per-token
  // rate is the spec's per-1k rate divided by 1000 — expressed directly as
  // a sub-cent decimal string, which is now fully supported:
  const perTokenModel: PricingModel = {
    kind: 'tiered',
    tiers: [
      { from: 1, to: 10_000, pricePerUnit: '0.000001' }, // = $0.001 / 1000
      { from: 10_001, to: 100_000, pricePerUnit: '0.0000008' }, // = $0.0008 / 1000
      { from: 100_001, to: null, pricePerUnit: '0.0000005' }, // = $0.0005 / 1000
    ],
  };
  void model; // kept to show the naive (incorrect-unit) framing that this test replaces
  const charge = calculateUsageCharge(50_000, perTokenModel, 'USD');
  // Tier1: 10,000 tokens * $0.000001 = $0.01
  // Tier2: 40,000 tokens * $0.0000008 = $0.032
  // Total (exact) = $0.042 -> rounds to $0.04 at USD's 2-decimal exponent.
  // This IS the correct real-world behavior: sub-cent accumulated charges
  // round to the nearest cent at the point they become a chargeable Money
  // amount (matches how Stripe, AWS, etc. bill fractional-cent usage).
  assert.equal(charge.toDecimalString(), '0.04');
});

test('unit pricing accepts true sub-cent per-unit rates (e.g. $0.0000005 per API call)', () => {
  const model: PricingModel = { kind: 'unit', pricePerUnit: '0.0000005' };
  // 10,000,000 calls * $0.0000005 = $5.00 exactly
  const charge = calculateUsageCharge(10_000_000, model, 'USD');
  assert.equal(charge.toDecimalString(), '5.00');
});

test('usageUnits must be an integer — fractional usage is rejected, not silently truncated', () => {
  const model: PricingModel = { kind: 'unit', pricePerUnit: '1.00' };
  assert.throws(
    () => calculateUsageCharge(2.5, model, 'USD'),
    /must be an integer/,
  );
});

test('large realistic usage volumes (millions of tokens) compute without precision loss', () => {
  const model: PricingModel = { kind: 'unit', pricePerUnit: '0.000001' };
  const charge = calculateUsageCharge(50_000_000, model, 'USD');
  assert.equal(charge.toDecimalString(), '50.00');
});

test('tiered pricing: usage entirely within first tier', () => {
  const model: PricingModel = {
    kind: 'tiered',
    tiers: [
      { from: 1, to: 100, pricePerUnit: '1.00' },
      { from: 101, to: null, pricePerUnit: '0.50' },
    ],
  };
  const charge = calculateUsageCharge(50, model, 'USD');
  assert.equal(charge.toDecimalString(), '50.00');
});

test('tiered pricing: usage spanning two tiers charges each portion at its own rate', () => {
  const model: PricingModel = {
    kind: 'tiered',
    tiers: [
      { from: 1, to: 100, pricePerUnit: '1.00' },
      { from: 101, to: null, pricePerUnit: '0.50' },
    ],
  };
  // 150 units: 100 at $1.00 = $100, 50 at $0.50 = $25 -> total $125
  const charge = calculateUsageCharge(150, model, 'USD');
  assert.equal(charge.toDecimalString(), '125.00');
});

test('volume pricing: entire quantity billed at the tier the TOTAL falls into', () => {
  const model: PricingModel = {
    kind: 'volume',
    tiers: [
      { from: 1, to: 100, pricePerUnit: '1.00' },
      { from: 101, to: null, pricePerUnit: '0.80' },
    ],
  };
  // 150 units total falls in tier 2 -> ALL 150 units at $0.80 = $120
  const charge = calculateUsageCharge(150, model, 'USD');
  assert.equal(charge.toDecimalString(), '120.00');
});

test('unit pricing: flat rate per unit', () => {
  const model: PricingModel = { kind: 'unit', pricePerUnit: '2.50' };
  const charge = calculateUsageCharge(4, model, 'USD');
  assert.equal(charge.toDecimalString(), '10.00');
});

test('package pricing: rounds usage UP to the next full package', () => {
  const model: PricingModel = {
    kind: 'package',
    packageSize: 1000,
    pricePerPackage: '5.00',
  };
  // 1001 units needs 2 packages, not 1.001
  const charge = calculateUsageCharge(1001, model, 'USD');
  assert.equal(charge.toDecimalString(), '10.00');
});

test('package pricing: exact multiple does not round up an extra package', () => {
  const model: PricingModel = {
    kind: 'package',
    packageSize: 1000,
    pricePerPackage: '5.00',
  };
  const charge = calculateUsageCharge(2000, model, 'USD');
  assert.equal(charge.toDecimalString(), '10.00');
});

test('zero usage always charges zero regardless of model', () => {
  const model: PricingModel = { kind: 'unit', pricePerUnit: '99.00' };
  const charge = calculateUsageCharge(0, model, 'USD');
  assert.ok(charge.isZero());
});

test('negative usage is rejected', () => {
  const model: PricingModel = { kind: 'unit', pricePerUnit: '1.00' };
  assert.throws(() => calculateUsageCharge(-5, model, 'USD'));
});

test('tiered pricing rejects usage beyond a bounded top tier (misconfiguration)', () => {
  const model: PricingModel = {
    kind: 'tiered',
    tiers: [{ from: 1, to: 100, pricePerUnit: '1.00' }], // no unbounded top tier
  };
  assert.throws(() => calculateUsageCharge(200, model, 'USD'));
});

test('tiered pricing validation rejects gaps between tiers', () => {
  const model: PricingModel = {
    kind: 'tiered',
    tiers: [
      { from: 1, to: 100, pricePerUnit: '1.00' },
      { from: 102, to: null, pricePerUnit: '0.50' }, // gap at 101
    ],
  };
  assert.throws(() => calculateUsageCharge(150, model, 'USD'));
});

test('volume pricing throws if usage does not fall in any tier (misconfiguration)', () => {
  const model: PricingModel = {
    kind: 'volume',
    tiers: [{ from: 1, to: 100, pricePerUnit: '1.00' }],
  };
  assert.throws(() => calculateUsageCharge(200, model, 'USD'));
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { Money, Rate } from '../utils/money';

test('fromDecimalString parses cents correctly', () => {
  const m = Money.fromDecimalString('10.50', 'USD');
  assert.equal(m.minorUnits, 1050n);
  assert.equal(m.toDecimalString(), '10.50');
});

test('fromDecimalString handles zero-exponent currency (JPY)', () => {
  const m = Money.fromDecimalString('1500', 'JPY');
  assert.equal(m.minorUnits, 1500n);
  assert.equal(m.toDecimalString(), '1500');
});

test('fromDecimalString rejects too many decimal places', () => {
  assert.throws(() => Money.fromDecimalString('10.505', 'USD'));
});

test('fromDecimalString handles negative values', () => {
  const m = Money.fromDecimalString('-5.25', 'USD');
  assert.equal(m.minorUnits, -525n);
  assert.equal(m.toDecimalString(), '-5.25');
});

test('add/subtract enforce currency match', () => {
  const usd = Money.fromDecimalString('10.00', 'USD');
  const eur = Money.fromDecimalString('10.00', 'EUR');
  assert.throws(() => usd.add(eur));
});

test('add is exact — no float drift across many additions', () => {
  // The classic 0.1 + 0.2 !== 0.3 float trap: verify we never hit it.
  let total = Money.zero('USD');
  const dime = Money.fromDecimalString('0.10', 'USD');
  for (let i = 0; i < 3; i++) total = total.add(dime);
  assert.equal(total.toDecimalString(), '0.30');
});

test('multiplyByFraction with HALF_UP rounds correctly at exact .5', () => {
  // 5 cents * 1/2 = 2.5 -> rounds up to 3 under HALF_UP
  const m = Money.fromMinorUnits(5n, 'USD');
  const result = m.multiplyByFraction(1, 2, 'HALF_UP');
  assert.equal(result.minorUnits, 3n);
});

test('multiplyByFraction with HALF_EVEN rounds to even at exact .5', () => {
  const m2 = Money.fromMinorUnits(2n, 'USD'); // 2 * 1/2 = 1.0, no rounding needed
  assert.equal(m2.multiplyByFraction(1, 2, 'HALF_EVEN').minorUnits, 1n);

  const m5 = Money.fromMinorUnits(5n, 'USD'); // 5 * 1/2 = 2.5 -> even is 2
  assert.equal(m5.multiplyByFraction(1, 2, 'HALF_EVEN').minorUnits, 2n);

  const m15 = Money.fromMinorUnits(15n, 'USD'); // 15 * 1/2 = 7.5 -> even is 8
  assert.equal(m15.multiplyByFraction(1, 2, 'HALF_EVEN').minorUnits, 8n);
});

test('multiplyByFraction handles negative amounts and negative fractions', () => {
  const m = Money.fromDecimalString('-10.00', 'USD');
  const result = m.multiplyByFraction(1, 2, 'HALF_UP');
  assert.equal(result.toDecimalString(), '-5.00');
});

test('allocate splits money into N shares with no lost cents', () => {
  const total = Money.fromDecimalString('10.00', 'USD'); // 1000 cents
  const shares = total.allocate(3);
  assert.equal(shares.length, 3);
  const sum = shares.reduce((acc, s) => acc.add(s), Money.zero('USD'));
  assert.equal(sum.minorUnits, total.minorUnits, 'shares must sum exactly to total');
  // 1000 / 3 = 333.33... -> shares should be [334, 333, 333] (remainder distributed to first)
  assert.deepEqual(
    shares.map((s) => s.minorUnits),
    [334n, 333n, 333n],
  );
});

test('allocate handles amount smaller than parts count', () => {
  const total = Money.fromMinorUnits(2n, 'USD');
  const shares = total.allocate(5);
  const sum = shares.reduce((acc, s) => acc.add(s), Money.zero('USD'));
  assert.equal(sum.minorUnits, 2n);
  assert.deepEqual(
    shares.map((s) => s.minorUnits),
    [1n, 1n, 0n, 0n, 0n],
  );
});

test('compare works correctly', () => {
  const a = Money.fromDecimalString('5.00', 'USD');
  const b = Money.fromDecimalString('10.00', 'USD');
  assert.equal(a.compare(b), -1);
  assert.equal(b.compare(a), 1);
  assert.equal(a.compare(a), 0);
});

test('Rate.fromDecimalString accepts sub-cent precision that Money.fromDecimalString rejects', () => {
  assert.throws(() => Money.fromDecimalString('0.000001', 'USD'));
  // Rate has no such limit — arbitrary decimal precision is the whole point.
  const rate = Rate.fromDecimalString('0.000001', 'USD');
  assert.equal(rate.numerator, 1n);
  assert.equal(rate.denominator, 1_000_000n);
});

test('Rate.multiplyByQuantity rounds to the currency minor unit exactly once, at the end', () => {
  const rate = Rate.fromDecimalString('0.000001', 'USD');
  const money = rate.multiplyByQuantity(1_000_000n, 1n); // 1,000,000 * $0.000001 = $1.00 exactly
  assert.equal(money.toDecimalString(), '1.00');
});

test('Rate.multiplyByQuantity handles a rate that does not evenly divide into cents', () => {
  const rate = Rate.fromDecimalString('0.0000005', 'USD'); // half a millionth of a dollar
  const money = rate.multiplyByQuantity(3n, 1n); // 3 * 0.0000005 = 0.0000015 -> rounds to 0.00
  assert.equal(money.toDecimalString(), '0.00');
  const money2 = rate.multiplyByQuantity(3_000_000n, 1n); // 3,000,000 * 0.0000005 = 1.50
  assert.equal(money2.toDecimalString(), '1.50');
});

test('Rate.fromDecimalString rejects an unknown currency, same as Money', () => {
  assert.throws(() => Rate.fromDecimalString('1.00', 'ZZZ'));
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { Money } from '../utils/money';
import { calculateProration, daysInCycle } from '../proration';

test('proration matches the spec example exactly (30-day cycle, 12/18 split)', () => {
  const oldPlan = Money.fromDecimalString('99.00', 'USD');
  const newPlan = Money.fromDecimalString('199.00', 'USD');
  const result = calculateProration({
    cycleDays: 30,
    daysOnOldPlan: 12,
    oldPlanPrice: oldPlan,
    newPlanPrice: newPlan,
  });

  // credit = 99 * 12/30 = 39.60
  assert.equal(result.credit.toDecimalString(), '39.60');
  // charge = 199 * 18/30 = 119.40
  assert.equal(result.charge.toDecimalString(), '119.40');
  // net = 119.40 - 39.60 = 79.80
  assert.equal(result.net.toDecimalString(), '79.80');
  assert.equal(result.daysOnNewPlan, 18);
});

test('proration produces a negative net (credit) on downgrade late in the cycle', () => {
  // Most of the cycle (25/30 days) was already spent on the expensive old
  // plan, so the unused-portion credit outweighs the charge for the few
  // remaining days on the cheaper new plan.
  const oldPlan = Money.fromDecimalString('199.00', 'USD');
  const newPlan = Money.fromDecimalString('99.00', 'USD');
  const result = calculateProration({
    cycleDays: 30,
    daysOnOldPlan: 25,
    oldPlanPrice: oldPlan,
    newPlanPrice: newPlan,
  });
  assert.ok(result.net.isNegative(), 'late downgrade should net to a credit');
});

test('proration produces a positive net on downgrade early in the cycle', () => {
  // Only 5 days spent on the old (expensive) plan means the credit is
  // small; charging the remaining 25 days even at the cheaper new plan
  // still costs more than that small credit.
  const oldPlan = Money.fromDecimalString('199.00', 'USD');
  const newPlan = Money.fromDecimalString('99.00', 'USD');
  const result = calculateProration({
    cycleDays: 30,
    daysOnOldPlan: 5,
    oldPlanPrice: oldPlan,
    newPlanPrice: newPlan,
  });
  assert.ok(!result.net.isNegative(), 'early downgrade should still net to a charge, not a credit');
});

test('proration at day 0 (change on first day) charges full new plan, zero credit', () => {
  const oldPlan = Money.fromDecimalString('99.00', 'USD');
  const newPlan = Money.fromDecimalString('199.00', 'USD');
  const result = calculateProration({
    cycleDays: 30,
    daysOnOldPlan: 0,
    oldPlanPrice: oldPlan,
    newPlanPrice: newPlan,
  });
  assert.equal(result.credit.toDecimalString(), '0.00');
  assert.equal(result.charge.toDecimalString(), '199.00');
});

test('proration rejects daysOnOldPlan > cycleDays', () => {
  assert.throws(() =>
    calculateProration({
      cycleDays: 30,
      daysOnOldPlan: 31,
      oldPlanPrice: Money.fromDecimalString('10.00', 'USD'),
      newPlanPrice: Money.fromDecimalString('20.00', 'USD'),
    }),
  );
});

test('proration rejects mismatched currencies', () => {
  assert.throws(() =>
    calculateProration({
      cycleDays: 30,
      daysOnOldPlan: 10,
      oldPlanPrice: Money.fromDecimalString('10.00', 'USD'),
      newPlanPrice: Money.fromDecimalString('20.00', 'EUR'),
    }),
  );
});

test('daysInCycle handles a February in a leap year (2024, 29 days)', () => {
  const start = new Date(Date.UTC(2024, 1, 1)); // Feb 1
  const end = new Date(Date.UTC(2024, 2, 1)); // Mar 1
  assert.equal(daysInCycle(start, end), 29);
});

test('daysInCycle handles a February in a non-leap year (2026, 28 days)', () => {
  const start = new Date(Date.UTC(2026, 1, 1));
  const end = new Date(Date.UTC(2026, 2, 1));
  assert.equal(daysInCycle(start, end), 28);
});

test('daysInCycle is unaffected by DST transitions (uses UTC midnight normalization)', () => {
  // US DST spring-forward happened 2026-03-08. A naive Date-diff using
  // local-time hours could be off by one; UTC-midnight normalization must not be.
  const start = new Date(Date.UTC(2026, 2, 1)); // Mar 1
  const end = new Date(Date.UTC(2026, 3, 1)); // Apr 1
  assert.equal(daysInCycle(start, end), 31);
});

test('daysInCycle rejects end before start', () => {
  const start = new Date(Date.UTC(2026, 2, 10));
  const end = new Date(Date.UTC(2026, 2, 1));
  assert.throws(() => daysInCycle(start, end));
});

test('proration nets to exactly zero when old and new plan have the same price and the cycle splits exactly in half', () => {
  const price = Money.fromDecimalString('50.00', 'USD');
  const result = calculateProration({
    cycleDays: 30,
    daysOnOldPlan: 15,
    oldPlanPrice: price,
    newPlanPrice: price,
  });
  assert.equal(result.net.toDecimalString(), '0.00');
});

test('proration with equal plan prices does NOT net to zero at an uneven day split (credit and charge cover different day counts)', () => {
  // This is intentional, not a bug: a "plan change" partway through a cycle
  // where 17 days were already spent on the old plan and 13 remain on the
  // (same-priced) new plan is not a no-op — the credit covers 17 days and
  // the charge covers 13, so they only cancel when the split is exactly even.
  const price = Money.fromDecimalString('50.00', 'USD');
  const result = calculateProration({
    cycleDays: 30,
    daysOnOldPlan: 17,
    oldPlanPrice: price,
    newPlanPrice: price,
  });
  assert.equal(result.credit.toDecimalString(), '28.33'); // 50 * 17/30
  assert.equal(result.charge.toDecimalString(), '21.67'); // 50 * 13/30
  assert.equal(result.net.toDecimalString(), '-6.66');
});

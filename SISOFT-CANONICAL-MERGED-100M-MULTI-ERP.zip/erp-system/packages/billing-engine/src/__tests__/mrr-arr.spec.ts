import test from 'node:test';
import assert from 'node:assert/strict';
import { Money } from '../utils/money';
import {
  calculateMRR,
  calculateARR,
  calculateNetMRRMovement,
  calculateChurn,
  calculateCohortRetention,
  normalizeToMonthly,
} from '../mrr-arr';

test('normalizeToMonthly: monthly passes through unchanged', () => {
  const m = Money.fromDecimalString('100.00', 'USD');
  assert.equal(normalizeToMonthly({ amount: m, cycle: 'monthly' }).toDecimalString(), '100.00');
});

test('normalizeToMonthly: quarterly divides by 3', () => {
  const m = Money.fromDecimalString('300.00', 'USD');
  assert.equal(normalizeToMonthly({ amount: m, cycle: 'quarterly' }).toDecimalString(), '100.00');
});

test('normalizeToMonthly: annual divides by 12', () => {
  const m = Money.fromDecimalString('1200.00', 'USD');
  assert.equal(normalizeToMonthly({ amount: m, cycle: 'annual' }).toDecimalString(), '100.00');
});

test('calculateMRR sums monthly-normalized amounts across mixed cycles', () => {
  const lines = [
    { amount: Money.fromDecimalString('99.00', 'USD'), cycle: 'monthly' as const },
    { amount: Money.fromDecimalString('1200.00', 'USD'), cycle: 'annual' as const }, // -> 100/mo
    { amount: Money.fromDecimalString('300.00', 'USD'), cycle: 'quarterly' as const }, // -> 100/mo
  ];
  const mrr = calculateMRR(lines, 'USD');
  assert.equal(mrr.toDecimalString(), '299.00');
});

test('calculateARR is MRR * 12', () => {
  const mrr = Money.fromDecimalString('1000.00', 'USD');
  assert.equal(calculateARR(mrr).toDecimalString(), '12000.00');
});

test('calculateNetMRRMovement: New + Expansion - Contraction - Churn', () => {
  const net = calculateNetMRRMovement({
    newMRR: Money.fromDecimalString('500.00', 'USD'),
    expansionMRR: Money.fromDecimalString('200.00', 'USD'),
    contractionMRR: Money.fromDecimalString('100.00', 'USD'),
    churnedMRR: Money.fromDecimalString('150.00', 'USD'),
  });
  // 500 + 200 - 100 - 150 = 450
  assert.equal(net.toDecimalString(), '450.00');
});

test('calculateChurn computes logo and revenue churn rates', () => {
  const result = calculateChurn({
    customersAtStart: 200,
    customersChurned: 10,
    mrrAtStart: Money.fromDecimalString('20000.00', 'USD'),
    mrrChurned: Money.fromDecimalString('1000.00', 'USD'),
  });
  assert.equal(result.logoChurnRate, 0.05);
  assert.equal(result.revenueChurnRate, 0.05);
});

test('calculateChurn handles zero starting customers/MRR without dividing by zero', () => {
  const result = calculateChurn({
    customersAtStart: 0,
    customersChurned: 0,
    mrrAtStart: Money.zero('USD'),
    mrrChurned: Money.zero('USD'),
  });
  assert.equal(result.logoChurnRate, 0);
  assert.equal(result.revenueChurnRate, 0);
});

test('calculateChurn rejects churned count exceeding starting count', () => {
  assert.throws(() =>
    calculateChurn({
      customersAtStart: 10,
      customersChurned: 11,
      mrrAtStart: Money.fromDecimalString('100.00', 'USD'),
      mrrChurned: Money.fromDecimalString('10.00', 'USD'),
    }),
  );
});

test('calculateCohortRetention computes retention as active/starting', () => {
  const retention = calculateCohortRetention({
    cohortMonth: '2026-01',
    monthsSinceSignup: 3,
    activeCustomers: 80,
    startingCustomers: 100,
    mrr: Money.fromDecimalString('8000.00', 'USD'),
  });
  assert.equal(retention.retentionRate, 0.8);
});

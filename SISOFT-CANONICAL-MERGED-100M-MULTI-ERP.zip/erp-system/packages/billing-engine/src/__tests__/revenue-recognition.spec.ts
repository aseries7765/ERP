import test from 'node:test';
import assert from 'node:assert/strict';
import { Money } from '../utils/money';
import {
  buildStraightLineSchedule,
  recognizeUsageRevenueImmediately,
} from '../revenue-recognition';

test('straight-line schedule matches the spec example ($1200 annual -> $100/month for 12 months)', () => {
  const total = Money.fromDecimalString('1200.00', 'USD');
  const schedule = buildStraightLineSchedule(total, 12);
  assert.equal(schedule.length, 12);
  for (const entry of schedule) {
    assert.equal(entry.recognized.toDecimalString(), '100.00');
  }
  assert.equal(schedule[11].deferredBalance.toDecimalString(), '0.00');
});

test('straight-line schedule with non-evenly-divisible amount loses no cents', () => {
  // $100.00 over 3 months = $33.34 + $33.33 + $33.33 (remainder to first period)
  const total = Money.fromDecimalString('100.00', 'USD');
  const schedule = buildStraightLineSchedule(total, 3);
  const sum = schedule.reduce(
    (acc, e) => acc.add(e.recognized),
    Money.zero('USD'),
  );
  assert.equal(sum.toDecimalString(), '100.00');
  assert.equal(schedule[2].deferredBalance.toDecimalString(), '0.00');
});

test('deferred balance decreases monotonically to exactly zero', () => {
  const total = Money.fromDecimalString('600.00', 'USD');
  const schedule = buildStraightLineSchedule(total, 6);
  let prevBalance = total;
  for (const entry of schedule) {
    assert.ok(entry.deferredBalance.compare(prevBalance) <= 0);
    prevBalance = entry.deferredBalance;
  }
  assert.ok(schedule[schedule.length - 1].deferredBalance.isZero());
});

test('rejects zero or negative months', () => {
  const total = Money.fromDecimalString('100.00', 'USD');
  assert.throws(() => buildStraightLineSchedule(total, 0));
  assert.throws(() => buildStraightLineSchedule(total, -1));
});

test('usage revenue is recognized immediately with no deferral', () => {
  const amount = Money.fromDecimalString('42.00', 'USD');
  const result = recognizeUsageRevenueImmediately(amount);
  assert.equal(result.recognized.toDecimalString(), '42.00');
  assert.ok(result.deferredBalance.isZero());
});

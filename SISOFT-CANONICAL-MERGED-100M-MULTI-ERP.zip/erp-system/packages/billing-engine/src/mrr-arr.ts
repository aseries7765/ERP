import { Money } from './utils/money';

export type BillingCycle = 'monthly' | 'quarterly' | 'annual';

export interface RecurringLine {
  /** Full price for the given billing cycle (base + seats; excludes usage/one-time). */
  amount: Money;
  cycle: BillingCycle;
}

/** Normalize any billing-cycle amount to its monthly-equivalent value. */
export function normalizeToMonthly(line: RecurringLine): Money {
  switch (line.cycle) {
    case 'monthly':
      return line.amount;
    case 'quarterly':
      return line.amount.multiplyByFraction(1, 3, 'HALF_UP');
    case 'annual':
      return line.amount.multiplyByFraction(1, 12, 'HALF_UP');
    default: {
      const _exhaustive: never = line.cycle;
      throw new Error(`Unknown billing cycle: ${_exhaustive}`);
    }
  }
}

/**
 * MRR = sum of monthly-normalized recurring revenue across all active
 * subscriptions. Usage-based and one-time charges are explicitly excluded
 * per spec.
 */
export function calculateMRR(lines: RecurringLine[], currency: string): Money {
  return lines.reduce(
    (total, line) => total.add(normalizeToMonthly(line)),
    Money.zero(currency),
  );
}

export function calculateARR(mrr: Money): Money {
  return mrr.multiplyByFraction(12, 1);
}

export interface MRRMovement {
  newMRR: Money;
  expansionMRR: Money;
  contractionMRR: Money;
  churnedMRR: Money;
}

/** Net MRR movement = New + Expansion - Contraction - Churn. */
export function calculateNetMRRMovement(movement: MRRMovement): Money {
  return movement.newMRR
    .add(movement.expansionMRR)
    .subtract(movement.contractionMRR)
    .subtract(movement.churnedMRR);
}

export interface ChurnInput {
  customersAtStart: number;
  customersChurned: number;
  mrrAtStart: Money;
  mrrChurned: Money;
}

export interface ChurnResult {
  /** Fraction (0..1) of customers lost — "logo churn". */
  logoChurnRate: number;
  /** Fraction (0..1) of starting MRR lost — "revenue churn". */
  revenueChurnRate: number;
}

/**
 * Churn rates. Returned as plain numbers (fractions), since a rate is a
 * dimensionless ratio, not a monetary amount — Money is reserved for
 * amounts of currency.
 */
export function calculateChurn(input: ChurnInput): ChurnResult {
  const { customersAtStart, customersChurned, mrrAtStart, mrrChurned } = input;
  if (customersAtStart < 0 || customersChurned < 0) {
    throw new Error('customer counts must be >= 0');
  }
  if (customersChurned > customersAtStart) {
    throw new Error('customersChurned cannot exceed customersAtStart');
  }

  const logoChurnRate =
    customersAtStart === 0 ? 0 : customersChurned / customersAtStart;

  let revenueChurnRate = 0;
  if (!mrrAtStart.isZero()) {
    // Compute as an exact rational via minor units, then convert to a
    // float ONLY for the final ratio (a dimensionless rate, not money).
    const numerator = Number(mrrChurned.minorUnits);
    const denominator = Number(mrrAtStart.minorUnits);
    revenueChurnRate = numerator / denominator;
  }

  return { logoChurnRate, revenueChurnRate };
}

export interface CohortSnapshot {
  cohortMonth: string; // e.g. "2026-01"
  monthsSinceSignup: number;
  activeCustomers: number;
  startingCustomers: number;
  mrr: Money;
}

export interface CohortRetention {
  cohortMonth: string;
  monthsSinceSignup: number;
  retentionRate: number;
}

/** Retention rate for a cohort at a given month offset. */
export function calculateCohortRetention(
  snapshot: CohortSnapshot,
): CohortRetention {
  if (snapshot.startingCustomers <= 0) {
    throw new Error('startingCustomers must be > 0');
  }
  return {
    cohortMonth: snapshot.cohortMonth,
    monthsSinceSignup: snapshot.monthsSinceSignup,
    retentionRate: snapshot.activeCustomers / snapshot.startingCustomers,
  };
}

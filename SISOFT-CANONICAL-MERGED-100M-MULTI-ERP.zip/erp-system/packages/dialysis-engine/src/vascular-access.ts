/**
 * Vascular access tracking for hemodialysis patients: AV fistula (AVF),
 * AV graft (AVG), and central venous catheter (CVC), per KDOQI vascular
 * access guidelines. Tracks maturation status (a fistula needs time to
 * mature before it's usable) and complications (infection, thrombosis,
 * stenosis) that can take an access out of service.
 */

export class VascularAccessError extends Error {}

export type AccessType = 'AVF' | 'AVG' | 'CATHETER';

export type AccessStatus = 'MATURING' | 'READY' | 'IN_USE' | 'COMPLICATED' | 'ABANDONED';

export type ComplicationType = 'INFECTION' | 'THROMBOSIS' | 'STENOSIS' | 'ANEURYSM' | 'STEAL_SYNDROME';

export interface VascularAccess {
  id: string;
  patientId: string;
  type: AccessType;
  location: string;
  createdAt: Date;
  status: AccessStatus;
  minMaturationDays: number;
  complications: Array<{ type: ComplicationType; notedAt: Date; note: string; resolvedAt?: Date }>;
}

const MIN_MATURATION_DAYS: Record<AccessType, number> = {
  AVF: 56, // 8 weeks, conservative minimum
  AVG: 14, // 2 weeks
  CATHETER: 0,
};

let idCounter = 0;
function nextId(prefix: string): string {
  idCounter += 1;
  return `${prefix}_${idCounter}`;
}

export function createVascularAccess(patientId: string, type: AccessType, location: string, now: Date = new Date()): VascularAccess {
  if (!patientId) throw new VascularAccessError('patientId is required.');
  if (!location) throw new VascularAccessError('location is required.');

  const minMaturationDays = MIN_MATURATION_DAYS[type];
  return {
    id: nextId('access'),
    patientId,
    type,
    location,
    createdAt: now,
    status: minMaturationDays > 0 ? 'MATURING' : 'READY',
    minMaturationDays,
    complications: [],
  };
}

/**
 * Attempts to transition a MATURING access to READY. Throws if the
 * minimum maturation period has not yet elapsed — this is a hard
 * clinical safety check, not a formality: cannulating an immature
 * fistula risks failure and patient harm.
 */
export function markMatured(access: VascularAccess, now: Date = new Date()): VascularAccess {
  if (access.status !== 'MATURING') {
    throw new VascularAccessError(`Access ${access.id} is not MATURING (status: ${access.status}).`);
  }
  const daysSinceCreation = (now.getTime() - access.createdAt.getTime()) / (1000 * 60 * 60 * 24);
  if (daysSinceCreation < access.minMaturationDays) {
    throw new VascularAccessError(
      `Access ${access.id} (${access.type}) has only matured for ${daysSinceCreation.toFixed(1)} days; minimum is ${access.minMaturationDays} days.`,
    );
  }
  return { ...access, status: 'READY' };
}

export function markInUse(access: VascularAccess): VascularAccess {
  if (access.status !== 'READY' && access.status !== 'IN_USE') {
    throw new VascularAccessError(`Access ${access.id} is not READY for use (status: ${access.status}).`);
  }
  return { ...access, status: 'IN_USE' };
}

/**
 * Logs a complication. Infection or thrombosis immediately takes the
 * access out of active use (status -> COMPLICATED) since dialyzing
 * through an infected or clotted access is unsafe; stenosis/aneurysm/
 * steal syndrome are logged but do not automatically take the access
 * out of service (often monitored rather than immediately abandoned).
 */
export function logComplication(
  access: VascularAccess,
  type: ComplicationType,
  note: string,
  now: Date = new Date(),
): VascularAccess {
  const complications = [...access.complications, { type, notedAt: now, note }];
  const takesOutOfService = type === 'INFECTION' || type === 'THROMBOSIS';
  return {
    ...access,
    complications,
    status: takesOutOfService ? 'COMPLICATED' : access.status,
  };
}

export function resolveComplication(access: VascularAccess, complicationIndex: number, now: Date = new Date()): VascularAccess {
  if (complicationIndex < 0 || complicationIndex >= access.complications.length) {
    throw new VascularAccessError(`No complication at index ${complicationIndex}.`);
  }
  const complications = access.complications.map((c, i) => (i === complicationIndex ? { ...c, resolvedAt: now } : c));
  const anyUnresolvedBlocking = complications.some(
    (c) => !c.resolvedAt && (c.type === 'INFECTION' || c.type === 'THROMBOSIS'),
  );
  return {
    ...access,
    complications,
    status: access.status === 'COMPLICATED' && !anyUnresolvedBlocking ? 'READY' : access.status,
  };
}

export function abandonAccess(access: VascularAccess): VascularAccess {
  return { ...access, status: 'ABANDONED' };
}

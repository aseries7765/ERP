import {
  generateRecurringSessions,
  DialysisSchedulingError,
  StationAvailabilityChecker,
  NO_CONFLICT_CHECKER,
} from '../dialysis-scheduling';

describe('generateRecurringSessions', () => {
  it('generates MWF sessions for a 2-week range', () => {
    // 2026-09-14 is a Monday
    const slots = generateRecurringSessions({
      patientId: 'pat-1',
      pattern: 'MWF',
      shift: 'MORNING',
      stationId: 'station-1',
      startDate: new Date('2026-09-14'),
      endDate: new Date('2026-09-27'),
    });
    const dates = slots.map((s) => s.date.toISOString().slice(0, 10));
    expect(dates).toEqual([
      '2026-09-14', '2026-09-16', '2026-09-18', // week 1: Mon, Wed, Fri
      '2026-09-21', '2026-09-23', '2026-09-25', // week 2: Mon, Wed, Fri
    ]);
  });

  it('generates TTS sessions correctly', () => {
    // 2026-09-15 is a Tuesday
    const slots = generateRecurringSessions({
      patientId: 'pat-1',
      pattern: 'TTS',
      shift: 'AFTERNOON',
      stationId: 'station-1',
      startDate: new Date('2026-09-15'),
      endDate: new Date('2026-09-21'),
    });
    const dates = slots.map((s) => s.date.toISOString().slice(0, 10));
    expect(dates).toEqual(['2026-09-15', '2026-09-17', '2026-09-19']); // Tue, Thu, Sat
  });

  it('supports a CUSTOM 3-day pattern', () => {
    // custom: Sun(0), Wed(3), Fri(5)
    const slots = generateRecurringSessions({
      patientId: 'pat-1',
      pattern: 'CUSTOM',
      customDays: [0, 3, 5],
      shift: 'EVENING',
      stationId: 'station-1',
      startDate: new Date('2026-09-13'), // Sunday
      endDate: new Date('2026-09-19'),
    });
    const dates = slots.map((s) => s.date.toISOString().slice(0, 10));
    expect(dates).toEqual(['2026-09-13', '2026-09-16', '2026-09-18']);
  });

  it('rejects CUSTOM pattern without exactly 3 distinct days', () => {
    expect(() =>
      generateRecurringSessions({
        patientId: 'pat-1', pattern: 'CUSTOM', customDays: [1, 3],
        shift: 'MORNING', stationId: 's1', startDate: new Date('2026-09-14'), endDate: new Date('2026-09-20'),
      }),
    ).toThrow(/exactly 3 distinct/);

    expect(() =>
      generateRecurringSessions({
        patientId: 'pat-1', pattern: 'CUSTOM', customDays: [1, 1, 3],
        shift: 'MORNING', stationId: 's1', startDate: new Date('2026-09-14'), endDate: new Date('2026-09-20'),
      }),
    ).toThrow(/3 distinct values/);
  });

  it('rejects an out-of-range custom day', () => {
    expect(() =>
      generateRecurringSessions({
        patientId: 'pat-1', pattern: 'CUSTOM', customDays: [1, 3, 9],
        shift: 'MORNING', stationId: 's1', startDate: new Date('2026-09-14'), endDate: new Date('2026-09-20'),
      }),
    ).toThrow(/must be integer 0-6/);
  });

  it('rejects startDate after endDate', () => {
    expect(() =>
      generateRecurringSessions({
        patientId: 'pat-1', pattern: 'MWF', shift: 'MORNING', stationId: 's1',
        startDate: new Date('2026-09-20'), endDate: new Date('2026-09-14'),
      }),
    ).toThrow(/startDate must be on or before endDate/);
  });

  it('rejects missing patientId or stationId', () => {
    expect(() =>
      generateRecurringSessions({
        patientId: '', pattern: 'MWF', shift: 'MORNING', stationId: 's1',
        startDate: new Date('2026-09-14'), endDate: new Date('2026-09-20'),
      }),
    ).toThrow(/patientId is required/);
  });

  it('throws (does not partially schedule) when any slot in the range conflicts', () => {
    const checker: StationAvailabilityChecker = {
      isAvailable: (stationId, shift, date) => date.toISOString().slice(0, 10) !== '2026-09-18', // Friday is booked
    };
    expect(() =>
      generateRecurringSessions(
        { patientId: 'pat-1', pattern: 'MWF', shift: 'MORNING', stationId: 's1', startDate: new Date('2026-09-14'), endDate: new Date('2026-09-18') },
        checker,
      ),
    ).toThrow(/unavailable on: 2026-09-18/);
  });

  it('succeeds fully when the availability checker approves every slot', () => {
    const slots = generateRecurringSessions(
      { patientId: 'pat-1', pattern: 'MWF', shift: 'MORNING', stationId: 's1', startDate: new Date('2026-09-14'), endDate: new Date('2026-09-18') },
      NO_CONFLICT_CHECKER,
    );
    expect(slots).toHaveLength(3);
  });

  it('handles a range with zero matching days gracefully (empty result, no error)', () => {
    const slots = generateRecurringSessions({
      patientId: 'pat-1', pattern: 'MWF', shift: 'MORNING', stationId: 's1',
      startDate: new Date('2026-09-13'), endDate: new Date('2026-09-13'), // Sunday only, not in MWF
    });
    expect(slots).toHaveLength(0);
  });
});

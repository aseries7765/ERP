import { calculateKtV, calculateURR, InvalidDialysisInputError } from '../ktv-calculator';

describe('calculateKtV (Daugirdas)', () => {
  it('computes a typical adequate session correctly', () => {
    // Representative values: pre 70, post 25, 4hr session, 2.5L UF, 70kg post-weight
    const result = calculateKtV({
      preBUN: 70,
      postBUN: 25,
      sessionHours: 4,
      ultrafiltrationLiters: 2.5,
      postWeightKg: 70,
    });
    // R = 25/70 = 0.3571
    // ln(0.3571 - 0.032) = ln(0.3251) = -1.1238 -> -ln(...) = 1.1238
    // (4 - 3.5*0.3571) * (2.5/70) = (4-1.25) * 0.03571 = 2.75*0.03571=0.09821
    // ktv ~= 1.1238 + 0.0982 = 1.222
    expect(result.ktv).toBeCloseTo(1.222, 2);
    expect(result.adequate).toBe(true);
    expect(result.target).toBe(1.2);
  });

  it('flags an inadequate (short/underdialyzed) session', () => {
    const result = calculateKtV({
      preBUN: 70,
      postBUN: 50, // much less urea removed
      sessionHours: 2,
      ultrafiltrationLiters: 1,
      postWeightKg: 80,
    });
    expect(result.adequate).toBe(false);
    expect(result.ktv).toBeLessThan(1.2);
  });

  it('rejects postBUN greater than preBUN', () => {
    expect(() =>
      calculateKtV({ preBUN: 40, postBUN: 45, sessionHours: 3, ultrafiltrationLiters: 1, postWeightKg: 70 }),
    ).toThrow(InvalidDialysisInputError);
  });

  it('rejects non-positive weight, BUN, or session time', () => {
    expect(() =>
      calculateKtV({ preBUN: 0, postBUN: 0, sessionHours: 3, ultrafiltrationLiters: 1, postWeightKg: 70 }),
    ).toThrow(InvalidDialysisInputError);
    expect(() =>
      calculateKtV({ preBUN: 60, postBUN: 20, sessionHours: 0, ultrafiltrationLiters: 1, postWeightKg: 70 }),
    ).toThrow(InvalidDialysisInputError);
    expect(() =>
      calculateKtV({ preBUN: 60, postBUN: 20, sessionHours: 3, ultrafiltrationLiters: 1, postWeightKg: 0 }),
    ).toThrow(InvalidDialysisInputError);
  });

  it('rejects negative ultrafiltration', () => {
    expect(() =>
      calculateKtV({ preBUN: 60, postBUN: 20, sessionHours: 3, ultrafiltrationLiters: -1, postWeightKg: 70 }),
    ).toThrow(InvalidDialysisInputError);
  });

  it('throws when the log argument is out of domain rather than returning NaN', () => {
    // R - 0.008t <= 0 when t is very large relative to R (R=55/60=0.917, need t>~115h)
    expect(() =>
      calculateKtV({ preBUN: 60, postBUN: 55, sessionHours: 150, ultrafiltrationLiters: 1, postWeightKg: 70 }),
    ).toThrow(/out of domain/i);
  });
});

describe('calculateURR', () => {
  it('computes URR correctly and flags adequacy at the 65% threshold', () => {
    const adequate = calculateURR({ preBUN: 70, postBUN: 20 });
    expect(adequate.urr).toBeCloseTo(71.43, 1);
    expect(adequate.adequate).toBe(true);

    const inadequate = calculateURR({ preBUN: 70, postBUN: 30 });
    expect(inadequate.urr).toBeCloseTo(57.14, 1);
    expect(inadequate.adequate).toBe(false);
  });

  it('rejects invalid inputs', () => {
    expect(() => calculateURR({ preBUN: 0, postBUN: 10 })).toThrow(InvalidDialysisInputError);
    expect(() => calculateURR({ preBUN: 40, postBUN: -1 })).toThrow(InvalidDialysisInputError);
    expect(() => calculateURR({ preBUN: 40, postBUN: 45 })).toThrow(InvalidDialysisInputError);
  });
});

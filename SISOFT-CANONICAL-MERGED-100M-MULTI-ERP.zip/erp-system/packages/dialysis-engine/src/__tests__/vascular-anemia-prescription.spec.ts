import {
  createVascularAccess,
  markMatured,
  markInUse,
  logComplication,
  resolveComplication,
  abandonAccess,
  VascularAccessError,
} from '../vascular-access';
import { recommendEpoDoseAdjustment, assessIronStatus, AnemiaManagementError } from '../anemia-management';
import { validateDialysisPrescription } from '../dialysis-prescription';

describe('Vascular access', () => {
  const t0 = new Date('2026-01-01T00:00:00Z');

  it('AVF starts MATURING, catheter starts READY', () => {
    const avf = createVascularAccess('pat-1', 'AVF', 'left forearm', t0);
    expect(avf.status).toBe('MATURING');
    expect(avf.minMaturationDays).toBe(56);

    const cath = createVascularAccess('pat-1', 'CATHETER', 'right IJ', t0);
    expect(cath.status).toBe('READY');
  });

  it('rejects marking matured before the minimum period elapses', () => {
    const avf = createVascularAccess('pat-1', 'AVF', 'left forearm', t0);
    const tooSoon = new Date('2026-01-15T00:00:00Z'); // 14 days, need 56
    expect(() => markMatured(avf, tooSoon)).toThrow(VascularAccessError);
  });

  it('allows marking matured after the minimum period', () => {
    const avf = createVascularAccess('pat-1', 'AVF', 'left forearm', t0);
    const enoughTime = new Date('2026-03-01T00:00:00Z'); // ~59 days
    const matured = markMatured(avf, enoughTime);
    expect(matured.status).toBe('READY');
  });

  it('AVG matures faster than AVF (14 vs 56 days)', () => {
    const avg = createVascularAccess('pat-1', 'AVG', 'right upper arm', t0);
    expect(() => markMatured(avg, new Date('2026-01-10T00:00:00Z'))).toThrow(); // 9 days, need 14
    const matured = markMatured(avg, new Date('2026-01-20T00:00:00Z')); // 19 days
    expect(matured.status).toBe('READY');
  });

  it('marks in use only from READY', () => {
    const cath = createVascularAccess('pat-1', 'CATHETER', 'right IJ', t0);
    const inUse = markInUse(cath);
    expect(inUse.status).toBe('IN_USE');
  });

  it('rejects marking in use from MATURING', () => {
    const avf = createVascularAccess('pat-1', 'AVF', 'left forearm', t0);
    expect(() => markInUse(avf)).toThrow(/not READY/);
  });

  it('infection/thrombosis immediately takes access out of service', () => {
    const cath = createVascularAccess('pat-1', 'CATHETER', 'right IJ', t0);
    const inUse = markInUse(cath);
    const complicated = logComplication(inUse, 'INFECTION', 'Exit site erythema, cultures pending', t0);
    expect(complicated.status).toBe('COMPLICATED');
  });

  it('stenosis logs without automatically taking access out of service', () => {
    const cath = createVascularAccess('pat-1', 'CATHETER', 'right IJ', t0);
    const inUse = markInUse(cath);
    const logged = logComplication(inUse, 'STENOSIS', 'Reduced flow noted', t0);
    expect(logged.status).toBe('IN_USE');
    expect(logged.complications).toHaveLength(1);
  });

  it('resolving the only blocking complication restores READY status', () => {
    const cath = createVascularAccess('pat-1', 'CATHETER', 'right IJ', t0);
    let access = markInUse(cath);
    access = logComplication(access, 'INFECTION', 'Cellulitis', t0);
    expect(access.status).toBe('COMPLICATED');
    access = resolveComplication(access, 0, new Date('2026-01-10T00:00:00Z'));
    expect(access.status).toBe('READY');
    expect(access.complications[0].resolvedAt).toBeDefined();
  });

  it('abandons an access permanently', () => {
    const cath = createVascularAccess('pat-1', 'CATHETER', 'right IJ', t0);
    const abandoned = abandonAccess(cath);
    expect(abandoned.status).toBe('ABANDONED');
  });
});

describe('recommendEpoDoseAdjustment', () => {
  it('recommends INCREASE when Hgb is below target with no prior reading', () => {
    const rec = recommendEpoDoseAdjustment({ value: 9.0, takenAt: new Date('2026-02-01') }, undefined, 4000);
    expect(rec.action).toBe('INCREASE');
    expect(rec.recommendedWeeklyDoseUnits).toBe(5000); // 4000 * 1.25
  });

  it('recommends MAINTAIN when Hgb is stable within target range', () => {
    const rec = recommendEpoDoseAdjustment(
      { value: 10.8, takenAt: new Date('2026-02-01') },
      { value: 10.6, takenAt: new Date('2026-01-04') }, // 4 weeks earlier, small stable rise
      4000,
    );
    expect(rec.action).toBe('MAINTAIN');
    expect(rec.recommendedWeeklyDoseUnits).toBe(4000);
  });

  it('recommends DECREASE when Hgb rose too fast even though still in range', () => {
    const rec = recommendEpoDoseAdjustment(
      { value: 11.4, takenAt: new Date('2026-02-01') },
      { value: 10.0, takenAt: new Date('2026-01-04') }, // 4 weeks, 1.4 g/dL rise > 1.0 limit
      4000,
    );
    expect(rec.action).toBe('DECREASE');
    expect(rec.recommendedWeeklyDoseUnits).toBe(3000); // 4000 * 0.75
  });

  it('recommends HOLD when Hgb exceeds the hard ceiling, regardless of trend', () => {
    const rec = recommendEpoDoseAdjustment(
      { value: 12.5, takenAt: new Date('2026-02-01') },
      { value: 12.4, takenAt: new Date('2026-01-25') }, // small rise, but absolute value too high
      4000,
    );
    expect(rec.action).toBe('HOLD');
    expect(rec.recommendedWeeklyDoseUnits).toBe(4000);
  });

  it('recommends DECREASE when Hgb is above target range with stable trend', () => {
    const rec = recommendEpoDoseAdjustment(
      { value: 11.8, takenAt: new Date('2026-02-01') },
      { value: 11.7, takenAt: new Date('2026-01-04') },
      4000,
    );
    expect(rec.action).toBe('DECREASE');
  });

  it('rejects a non-positive hemoglobin value', () => {
    expect(() => recommendEpoDoseAdjustment({ value: 0, takenAt: new Date() }, undefined, 4000)).toThrow(
      AnemiaManagementError,
    );
  });

  it('rejects current reading not after previous reading', () => {
    const t = new Date('2026-02-01');
    expect(() => recommendEpoDoseAdjustment({ value: 10, takenAt: t }, { value: 10, takenAt: t }, 4000)).toThrow(
      /must be taken after/,
    );
  });
});

describe('assessIronStatus', () => {
  it('flags SUPPLEMENT_IRON for low ferritin', () => {
    expect(assessIronStatus({ ferritin: 100, transferrinSaturation: 25 })).toBe('SUPPLEMENT_IRON');
  });

  it('flags SUPPLEMENT_IRON for low TSAT even with adequate ferritin', () => {
    expect(assessIronStatus({ ferritin: 300, transferrinSaturation: 15 })).toBe('SUPPLEMENT_IRON');
  });

  it('flags OVERLOADED_HOLD_IRON for high ferritin and adequate TSAT', () => {
    expect(assessIronStatus({ ferritin: 600, transferrinSaturation: 35 })).toBe('OVERLOADED_HOLD_IRON');
  });

  it('flags ADEQUATE in between', () => {
    expect(assessIronStatus({ ferritin: 300, transferrinSaturation: 25 })).toBe('ADEQUATE');
  });

  it('rejects invalid values', () => {
    expect(() => assessIronStatus({ ferritin: -1, transferrinSaturation: 25 })).toThrow(AnemiaManagementError);
    expect(() => assessIronStatus({ ferritin: 300, transferrinSaturation: 150 })).toThrow(AnemiaManagementError);
  });
});

describe('validateDialysisPrescription', () => {
  const valid = {
    dialyzerType: 'high-flux polysulfone',
    bloodFlowRateMlMin: 350,
    dialysateFlowRateMlMin: 600,
    sessionDurationMinutes: 240,
  };

  it('accepts a prescription within all safe ranges', () => {
    const result = validateDialysisPrescription(valid);
    expect(result.valid).toBe(true);
    expect(result.issues).toHaveLength(0);
  });

  it('rejects a missing dialyzer type', () => {
    const result = validateDialysisPrescription({ ...valid, dialyzerType: '' });
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.field === 'dialyzerType')).toBe(true);
  });

  it('flags blood flow rate outside safe range', () => {
    const result = validateDialysisPrescription({ ...valid, bloodFlowRateMlMin: 100 });
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.field === 'bloodFlowRateMlMin')).toBe(true);
  });

  it('flags session duration outside safe range', () => {
    const result = validateDialysisPrescription({ ...valid, sessionDurationMinutes: 400 });
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.field === 'sessionDurationMinutes')).toBe(true);
  });

  it('requires patientWeightKg when ultrafiltrationRateMlKgHr is set', () => {
    const result = validateDialysisPrescription({ ...valid, ultrafiltrationRateMlKgHr: 10 });
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.field === 'patientWeightKg')).toBe(true);
  });

  it('accepts a valid UF rate with patient weight provided', () => {
    const result = validateDialysisPrescription({
      ...valid,
      ultrafiltrationRateMlKgHr: 10,
      patientWeightKg: 70,
    });
    expect(result.valid).toBe(true);
  });

  it('flags UF rate above the KDOQI safety ceiling', () => {
    const result = validateDialysisPrescription({
      ...valid,
      ultrafiltrationRateMlKgHr: 15,
      patientWeightKg: 70,
    });
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.field === 'ultrafiltrationRateMlKgHr')).toBe(true);
  });

  it('warns when dialysate flow is below blood flow', () => {
    const result = validateDialysisPrescription({ ...valid, dialysateFlowRateMlMin: 300, bloodFlowRateMlMin: 350 });
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.message.includes('reduces clearance efficiency'))).toBe(true);
  });
});

/**
 * Dialysis adequacy calculators.
 *
 * Kt/V uses the second-generation Daugirdas formula (1993), the
 * standard formula referenced by KDOQI guidelines and specified in the
 * HIS-3 spec (ADR-0391):
 *
 *   Kt/V = -ln(R - 0.008 * t) + (4 - 3.5 * R) * UF / W
 *
 * Where:
 *   R  = post-dialysis BUN / pre-dialysis BUN (unitless ratio)
 *   t  = session duration in hours
 *   UF = ultrafiltration volume in liters
 *   W  = post-dialysis weight in kg
 *
 * Target per KDOQI: single-pool Kt/V >= 1.2 per session, 3x weekly.
 */

export class InvalidDialysisInputError extends Error {}

export interface KtVInput {
  preBUN: number; // mg/dL (or mmol/L, as long as pre/post are the same unit)
  postBUN: number;
  sessionHours: number;
  ultrafiltrationLiters: number;
  postWeightKg: number;
}

export interface KtVResult {
  ktv: number;
  r: number;
  adequate: boolean; // >= 1.2
  target: number;
}

const KTV_TARGET = 1.2;

function validate(input: KtVInput): void {
  if (input.preBUN <= 0) throw new InvalidDialysisInputError('preBUN must be > 0.');
  if (input.postBUN <= 0) throw new InvalidDialysisInputError('postBUN must be > 0.');
  if (input.postBUN > input.preBUN) {
    throw new InvalidDialysisInputError('postBUN cannot exceed preBUN (BUN should fall during dialysis).');
  }
  if (input.sessionHours <= 0) throw new InvalidDialysisInputError('sessionHours must be > 0.');
  if (input.ultrafiltrationLiters < 0) {
    throw new InvalidDialysisInputError('ultrafiltrationLiters cannot be negative.');
  }
  if (input.postWeightKg <= 0) throw new InvalidDialysisInputError('postWeightKg must be > 0.');
}

/**
 * Computes single-pool Kt/V using the second-generation Daugirdas formula.
 * Throws InvalidDialysisInputError on physiologically invalid input
 * rather than silently producing a nonsensical (e.g. NaN or negative)
 * result, since this number drives real clinical dosing decisions.
 */
export function calculateKtV(input: KtVInput): KtVResult {
  validate(input);

  const r = input.postBUN / input.preBUN;
  const t = input.sessionHours;
  const uf = input.ultrafiltrationLiters;
  const w = input.postWeightKg;

  // ln(R - 0.008t) is undefined/complex if R <= 0.008t; guard explicitly
  // rather than letting Math.log return NaN silently.
  const lnArg = r - 0.008 * t;
  if (lnArg <= 0) {
    throw new InvalidDialysisInputError(
      `Daugirdas formula input out of domain: R (${r.toFixed(3)}) - 0.008*t (${(0.008 * t).toFixed(3)}) must be > 0.`,
    );
  }

  const ktv = -Math.log(lnArg) + (4 - 3.5 * r) * (uf / w);

  return {
    ktv: round(ktv, 3),
    r: round(r, 4),
    adequate: ktv >= KTV_TARGET,
    target: KTV_TARGET,
  };
}

export interface URRInput {
  preBUN: number;
  postBUN: number;
}

export interface URRResult {
  urr: number; // percentage, 0-100
  adequate: boolean; // KDOQI target >= 65%
  target: number;
}

const URR_TARGET = 65;

/**
 * Urea Reduction Ratio: URR = (1 - postBUN/preBUN) * 100.
 * Simpler, less accurate alternative/complement to Kt/V; KDOQI target
 * is >= 65%.
 */
export function calculateURR(input: URRInput): URRResult {
  if (input.preBUN <= 0) throw new InvalidDialysisInputError('preBUN must be > 0.');
  if (input.postBUN < 0) throw new InvalidDialysisInputError('postBUN cannot be negative.');
  if (input.postBUN > input.preBUN) {
    throw new InvalidDialysisInputError('postBUN cannot exceed preBUN.');
  }

  const urr = (1 - input.postBUN / input.preBUN) * 100;
  return {
    urr: round(urr, 2),
    adequate: urr >= URR_TARGET,
    target: URR_TARGET,
  };
}

function round(value: number, decimals: number): number {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

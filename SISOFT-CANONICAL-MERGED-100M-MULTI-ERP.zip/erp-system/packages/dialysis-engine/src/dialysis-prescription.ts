/**
 * Validates a hemodialysis prescription's parameters against
 * conventional safe clinical ranges. These are the standard adult
 * hemodialysis parameter ranges used in practice; a real deployment
 * would let a facility's medical director configure narrower ranges,
 * but the ranges here are real, not placeholders.
 */

export class DialysisPrescriptionError extends Error {}

export interface DialysisPrescription {
  dialyzerType: string; // e.g. "high-flux polysulfone"
  bloodFlowRateMlMin: number; // typical range 200-500 mL/min
  dialysateFlowRateMlMin: number; // typical range 500-800 mL/min
  sessionDurationMinutes: number; // typical range 180-300 minutes (3-5 hours)
  ultrafiltrationRateMlKgHr?: number; // typical safe ceiling ~13 mL/kg/hr
  patientWeightKg?: number; // required if ultrafiltrationRateMlKgHr is provided, to check total UF volume
}

export interface ValidationIssue {
  field: string;
  message: string;
}

export interface PrescriptionValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
}

const RANGES = {
  bloodFlowRateMlMin: { min: 200, max: 500 },
  dialysateFlowRateMlMin: { min: 500, max: 800 },
  sessionDurationMinutes: { min: 180, max: 300 },
  ultrafiltrationRateMlKgHr: { min: 0, max: 13 }, // KDOQI: UF rate > 13 mL/kg/hr associated with worse outcomes
};

export function validateDialysisPrescription(prescription: DialysisPrescription): PrescriptionValidationResult {
  const issues: ValidationIssue[] = [];

  if (!prescription.dialyzerType || prescription.dialyzerType.trim().length === 0) {
    issues.push({ field: 'dialyzerType', message: 'Dialyzer type is required.' });
  }

  checkRange(issues, 'bloodFlowRateMlMin', prescription.bloodFlowRateMlMin, RANGES.bloodFlowRateMlMin);
  checkRange(issues, 'dialysateFlowRateMlMin', prescription.dialysateFlowRateMlMin, RANGES.dialysateFlowRateMlMin);
  checkRange(issues, 'sessionDurationMinutes', prescription.sessionDurationMinutes, RANGES.sessionDurationMinutes);

  if (prescription.ultrafiltrationRateMlKgHr !== undefined) {
    checkRange(issues, 'ultrafiltrationRateMlKgHr', prescription.ultrafiltrationRateMlKgHr, RANGES.ultrafiltrationRateMlKgHr);
    if (prescription.patientWeightKg === undefined) {
      issues.push({
        field: 'patientWeightKg',
        message: 'patientWeightKg is required when ultrafiltrationRateMlKgHr is specified, to validate total UF volume.',
      });
    } else if (prescription.patientWeightKg <= 0) {
      issues.push({ field: 'patientWeightKg', message: 'patientWeightKg must be positive.' });
    }
  }

  // Cross-field check: dialysate flow should generally be >= blood flow
  // for efficient solute clearance (a common clinical rule of thumb,
  // not a hard physiologic limit, so it's a warning-level issue).
  if (
    prescription.dialysateFlowRateMlMin < prescription.bloodFlowRateMlMin &&
    Number.isFinite(prescription.dialysateFlowRateMlMin) &&
    Number.isFinite(prescription.bloodFlowRateMlMin)
  ) {
    issues.push({
      field: 'dialysateFlowRateMlMin',
      message: `Dialysate flow rate (${prescription.dialysateFlowRateMlMin} mL/min) is below blood flow rate (${prescription.bloodFlowRateMlMin} mL/min), which reduces clearance efficiency.`,
    });
  }

  return { valid: issues.length === 0, issues };
}

function checkRange(
  issues: ValidationIssue[],
  field: string,
  value: number,
  range: { min: number; max: number },
): void {
  if (!Number.isFinite(value)) {
    issues.push({ field, message: `${field} must be a finite number.` });
    return;
  }
  if (value < range.min || value > range.max) {
    issues.push({
      field,
      message: `${field} (${value}) is outside the safe range [${range.min}, ${range.max}].`,
    });
  }
}

/**
 * Anemia management for dialysis patients: EPO (erythropoiesis-
 * stimulating agent) dose adjustment based on hemoglobin trend, per
 * KDOQI anemia management guidelines — target Hgb range 10-11.5 g/dL,
 * with dose adjustments driven by the *rate of change* as much as the
 * absolute value (a rapid rise is itself a safety signal, independent
 * of whether the new value is still in range).
 *
 * Scope honesty: this implements the core rule set (target range,
 * rate-of-rise safety check, hold criteria) that is genuinely how EPO
 * dosing decisions are structured. It does not implement the full
 * complexity of real-world protocols (ESA hyporesponsiveness workup,
 * iron-repletion-first sequencing before EPO increase, per-patient
 * dosing history beyond the last two readings) — see MANIFEST.
 */

export class AnemiaManagementError extends Error {}

export interface HemoglobinReading {
  value: number; // g/dL
  takenAt: Date;
}

export type EpoDoseAction = 'INCREASE' | 'DECREASE' | 'HOLD' | 'MAINTAIN';

export interface EpoDoseRecommendation {
  action: EpoDoseAction;
  reason: string;
  /** Suggested new weekly dose in units, when action is INCREASE/DECREASE; unchanged for MAINTAIN/HOLD. */
  recommendedWeeklyDoseUnits: number;
}

const TARGET_HGB_LOW = 10.0;
const TARGET_HGB_HIGH = 11.5;
/** A rise of more than this many g/dL in a 4-week window is a safety signal per KDOQI, regardless of the absolute value reached. */
const MAX_SAFE_RISE_PER_4_WEEKS = 1.0;
/** Hard ceiling — EPO should be held if Hgb exceeds this regardless of trend. */
const HOLD_THRESHOLD_HGB = 12.0;

/**
 * Recommends an EPO dose adjustment from the current and previous
 * hemoglobin readings and the current weekly dose. This is advisory
 * logic for a clinician's review, not an autonomous dosing order — the
 * spec's coding-suggestion.service.ts pattern (AI-assisted, human-
 * reviewed) is the intended usage model, mirrored here for anemia
 * dosing.
 */
export function recommendEpoDoseAdjustment(
  current: HemoglobinReading,
  previous: HemoglobinReading | undefined,
  currentWeeklyDoseUnits: number,
): EpoDoseRecommendation {
  if (current.value <= 0) {
    throw new AnemiaManagementError('Hemoglobin value must be positive.');
  }
  if (currentWeeklyDoseUnits < 0) {
    throw new AnemiaManagementError('currentWeeklyDoseUnits cannot be negative.');
  }
  if (previous && current.takenAt.getTime() <= previous.takenAt.getTime()) {
    throw new AnemiaManagementError('current reading must be taken after the previous reading.');
  }

  // Hard ceiling always wins, regardless of trend: hold the dose.
  if (current.value > HOLD_THRESHOLD_HGB) {
    return {
      action: 'HOLD',
      reason: `Hemoglobin ${current.value} g/dL exceeds the ${HOLD_THRESHOLD_HGB} g/dL hold threshold.`,
      recommendedWeeklyDoseUnits: currentWeeklyDoseUnits,
    };
  }

  if (previous) {
    const weeksBetween = (current.takenAt.getTime() - previous.takenAt.getTime()) / (1000 * 60 * 60 * 24 * 7);
    const rise = current.value - previous.value;
    // Normalize the rise to a 4-week-equivalent rate for the safety check.
    const riseOver4Weeks = weeksBetween > 0 ? (rise / weeksBetween) * 4 : rise;

    if (rise > 0 && riseOver4Weeks > MAX_SAFE_RISE_PER_4_WEEKS) {
      return {
        action: 'DECREASE',
        reason: `Hemoglobin rose ${rise.toFixed(2)} g/dL over ${weeksBetween.toFixed(1)} weeks (≈${riseOver4Weeks.toFixed(2)} g/dL per 4 weeks), exceeding the safe rise limit of ${MAX_SAFE_RISE_PER_4_WEEKS} g/dL per 4 weeks.`,
        recommendedWeeklyDoseUnits: round50(currentWeeklyDoseUnits * 0.75),
      };
    }
  }

  if (current.value < TARGET_HGB_LOW) {
    return {
      action: 'INCREASE',
      reason: `Hemoglobin ${current.value} g/dL is below the target range (${TARGET_HGB_LOW}-${TARGET_HGB_HIGH} g/dL).`,
      recommendedWeeklyDoseUnits: round50(currentWeeklyDoseUnits * 1.25),
    };
  }

  if (current.value > TARGET_HGB_HIGH) {
    return {
      action: 'DECREASE',
      reason: `Hemoglobin ${current.value} g/dL is above the target range (${TARGET_HGB_LOW}-${TARGET_HGB_HIGH} g/dL).`,
      recommendedWeeklyDoseUnits: round50(currentWeeklyDoseUnits * 0.75),
    };
  }

  return {
    action: 'MAINTAIN',
    reason: `Hemoglobin ${current.value} g/dL is within target range (${TARGET_HGB_LOW}-${TARGET_HGB_HIGH} g/dL) with a stable trend.`,
    recommendedWeeklyDoseUnits: currentWeeklyDoseUnits,
  };
}

export interface IronStatus {
  ferritin: number; // ng/mL
  transferrinSaturation: number; // percentage, 0-100
}

export type IronRecommendation = 'SUPPLEMENT_IRON' | 'ADEQUATE' | 'OVERLOADED_HOLD_IRON';

/**
 * KDOQI iron adequacy check: EPO is less effective (or ineffective)
 * without adequate iron stores. Ferritin > 500 with adequate TSAT can
 * indicate iron overload, where iron supplementation should be held.
 */
export function assessIronStatus(status: IronStatus): IronRecommendation {
  if (status.ferritin < 0 || status.transferrinSaturation < 0 || status.transferrinSaturation > 100) {
    throw new AnemiaManagementError('Invalid ferritin or transferrinSaturation value.');
  }

  if (status.ferritin > 500 && status.transferrinSaturation > 30) {
    return 'OVERLOADED_HOLD_IRON';
  }
  if (status.ferritin < 200 || status.transferrinSaturation < 20) {
    return 'SUPPLEMENT_IRON';
  }
  return 'ADEQUATE';
}

function round50(value: number): number {
  return Math.round(value / 50) * 50;
}

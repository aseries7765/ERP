/**
 * Dialysis recurring session scheduling. Chronic hemodialysis patients
 * are almost always scheduled on one of two standard weekly patterns:
 *  - MWF: Monday, Wednesday, Friday
 *  - TTS: Tuesday, Thursday, Saturday
 * This module validates a requested pattern/shift combination and
 * generates concrete session dates within a date range, checking
 * chair (station) availability.
 */

export class DialysisSchedulingError extends Error {}

export type RecurrencePattern = 'MWF' | 'TTS' | 'CUSTOM';

export type Shift = 'MORNING' | 'AFTERNOON' | 'EVENING';

/** JS Date.getUTCDay(): 0=Sunday ... 6=Saturday. */
const PATTERN_DAYS: Record<'MWF' | 'TTS', number[]> = {
  MWF: [1, 3, 5],
  TTS: [2, 4, 6],
};

export interface DialysisScheduleRequest {
  patientId: string;
  pattern: RecurrencePattern;
  customDays?: number[];
  shift: Shift;
  stationId: string;
  startDate: Date;
  endDate: Date;
}

export interface DialysisSessionSlot {
  patientId: string;
  stationId: string;
  shift: Shift;
  date: Date;
}

export interface StationAvailabilityChecker {
  isAvailable(stationId: string, shift: Shift, date: Date): boolean;
}

export const NO_CONFLICT_CHECKER: StationAvailabilityChecker = { isAvailable: () => true };

/**
 * Generates the concrete session dates for a recurring schedule
 * request within [startDate, endDate] inclusive. Throws
 * DialysisSchedulingError if ANY generated slot conflicts — a partial
 * schedule covering only the conflict-free days is not silently
 * created, because a dialysis patient with gaps in their schedule is
 * a safety issue, not a scheduling inconvenience to paper over.
 */
export function generateRecurringSessions(
  request: DialysisScheduleRequest,
  availabilityChecker: StationAvailabilityChecker = NO_CONFLICT_CHECKER,
): DialysisSessionSlot[] {
  validateRequest(request);
  const days = resolveDays(request);

  if (request.startDate > request.endDate) {
    throw new DialysisSchedulingError('startDate must be on or before endDate.');
  }

  const slots: DialysisSessionSlot[] = [];
  const conflicts: string[] = [];

  const cursor = new Date(request.startDate);
  cursor.setUTCHours(0, 0, 0, 0);
  const end = new Date(request.endDate);
  end.setUTCHours(0, 0, 0, 0);

  while (cursor <= end) {
    if (days.includes(cursor.getUTCDay())) {
      const slotDate = new Date(cursor);
      if (availabilityChecker.isAvailable(request.stationId, request.shift, slotDate)) {
        slots.push({ patientId: request.patientId, stationId: request.stationId, shift: request.shift, date: slotDate });
      } else {
        conflicts.push(slotDate.toISOString().slice(0, 10));
      }
    }
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }

  if (conflicts.length > 0) {
    throw new DialysisSchedulingError(
      `Station ${request.stationId} (${request.shift}) is unavailable on: ${conflicts.join(', ')}. No sessions were scheduled for this request.`,
    );
  }

  return slots;
}

function resolveDays(request: DialysisScheduleRequest): number[] {
  if (request.pattern === 'MWF' || request.pattern === 'TTS') {
    return PATTERN_DAYS[request.pattern];
  }
  if (!request.customDays || request.customDays.length !== 3) {
    throw new DialysisSchedulingError('CUSTOM pattern requires exactly 3 distinct customDays (0=Sun..6=Sat).');
  }
  const unique = new Set(request.customDays);
  if (unique.size !== 3) {
    throw new DialysisSchedulingError('customDays must be 3 distinct values.');
  }
  for (const d of request.customDays) {
    if (d < 0 || d > 6 || !Number.isInteger(d)) {
      throw new DialysisSchedulingError(`Invalid day-of-week value: ${d} (must be integer 0-6).`);
    }
  }
  return request.customDays;
}

function validateRequest(request: DialysisScheduleRequest): void {
  if (!request.patientId) throw new DialysisSchedulingError('patientId is required.');
  if (!request.stationId) throw new DialysisSchedulingError('stationId is required.');
}

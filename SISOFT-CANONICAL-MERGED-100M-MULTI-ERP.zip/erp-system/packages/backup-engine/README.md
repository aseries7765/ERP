# @erp/backup-engine

Pure, dependency-free logic for the S3 Backup/DR slice: plan-tier policy
defaults, schedule due-calculation, checksum integrity, AES-256-GCM
encryption mechanics, grandfather-father-son retention selection, and
object-storage incremental delta computation.

**This package intentionally contains zero network / cloud SDK calls.**
It does not talk to OCI, Postgres, MinIO, Velero, or the customer Vault.
That's what makes every function in it fully unit-testable offline — and
also why it is only *one slice* of the full S3 scope, not the whole thing.
See the root `MANIFEST.md` for exactly what is and isn't included.

## Modules

| File | Responsibility |
|---|---|
| `types.ts` | Shared types (`BackupPolicy`, `RetentionConfig`, etc.) |
| `policy.ts` | Per-plan defaults (free/starter/business/enterprise) + override merge |
| `scheduler.ts` | Elapsed-time due-calculation for full/incremental cadences |
| `checksum.ts` | SHA-256 checksum compute + verify |
| `encryption.ts` | AES-256-GCM encrypt/decrypt round trip (key supplied by caller — real keys come from the customer's Oracle Vault, which is S2 scope, not this package) |
| `retention.ts` | Grandfather-father-son retention selection, with legal-hold exemption |
| `incremental.ts` | Object-manifest delta (added/changed/removed/unchanged) for incremental sync |

## Known gaps vs. the full S3 spec (see MANIFEST.md for the full list)

- No orchestrator that actually calls Postgres/ADB/MinIO/Velero/OpenSearch —
  those need real cloud clients and are out of scope for this slice.
- No Temporal/cron wiring — `scheduler.ts` only answers "is a job due right
  now given these timestamps," it doesn't run anything.
- `VerificationConfig.restoreTestFrequency` only models `monthly` /
  `quarterly` / `none`. The prose defaults table in the original prompt
  mentions "weekly" (business) and "daily" (enterprise) restore tests,
  which don't fit that type — this is flagged, not silently resolved.
- Retention's monthly cadence in `scheduler.ts` uses a flat 30-day
  approximation, not calendar-month boundaries.

## Commands

```bash
cd packages/backup-engine
npm install                              # fetches typescript, tsx, @types/node
npm test                                 # tsx --test src/__tests__/*.test.ts
npm run build                            # tsc -p tsconfig.json
```

Also wired for the monorepo-style invocation from the S3 prompt, once this
package is merged into a workspace with `pnpm` configured:

```bash
pnpm --filter @erp/backup-engine test
pnpm --filter @erp/backup-engine build
```

Verified in this delivery with `tsx` (Node's built-in `node:test` runner)
and `tsc --noEmit`, both run directly — including a standalone-extraction
check (fresh directory, only a locally co-located `node_modules`, no
monorepo scaffolding) to confirm the shipped `tsconfig.json` actually
resolves `@types/node` on its own. Output captured in the root
`MANIFEST.md` — not just claimed.

import type { DeltaResult, ObjectManifestEntry } from './types.js';

/**
 * Computes an incremental sync delta between two object-storage manifests
 * (e.g. MinIO bucket listings), by ETag. A key present in both manifests
 * with a different ETag is "changed"; present only in `current` is "added";
 * present only in `previous` is "removed".
 */
export function computeDelta(
  previous: ObjectManifestEntry[],
  current: ObjectManifestEntry[],
): DeltaResult {
  const prevByKey = new Map(previous.map((e) => [e.key, e]));
  const currByKey = new Map(current.map((e) => [e.key, e]));

  const added: string[] = [];
  const changed: string[] = [];
  const unchanged: string[] = [];

  for (const [key, entry] of currByKey) {
    const prevEntry = prevByKey.get(key);
    if (!prevEntry) {
      added.push(key);
    } else if (prevEntry.etag !== entry.etag) {
      changed.push(key);
    } else {
      unchanged.push(key);
    }
  }

  const removed: string[] = [];
  for (const key of prevByKey.keys()) {
    if (!currByKey.has(key)) removed.push(key);
  }

  return { added, changed, removed, unchanged };
}

/** Total bytes that an incremental sync would need to transfer (added + changed only). */
export function deltaTransferBytes(previous: ObjectManifestEntry[], current: ObjectManifestEntry[]): number {
  const delta = computeDelta(previous, current);
  const currByKey = new Map(current.map((e) => [e.key, e]));
  const toTransfer = new Set([...delta.added, ...delta.changed]);
  let total = 0;
  for (const key of toTransfer) {
    total += currByKey.get(key)?.size ?? 0;
  }
  return total;
}

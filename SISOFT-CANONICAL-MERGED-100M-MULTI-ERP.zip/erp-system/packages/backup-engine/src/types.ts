/**
 * Pure types for the backup-engine package. Nothing here performs I/O.
 */

export type Plan = 'free' | 'starter' | 'business' | 'enterprise';

export type Cadence = 'hourly' | 'daily' | 'weekly' | 'monthly' | 'never';

export interface ResourceFlags {
  database: boolean;
  objectStorage: boolean;
  k8sResources: boolean;
  search: boolean;
  cache: boolean;
  config: boolean;
  encryptionKeys: boolean;
}

export interface ScheduleConfig {
  full: Cadence;
  incremental: Cadence;
  walArchive: boolean;
  pitrWindowDays: number; // 0 means PITR not offered
}

export interface RetentionConfig {
  dailyKeep: number;
  weeklyKeep: number;
  monthlyKeep: number;
  yearlyKeep: number;
}

export interface EncryptionConfig {
  algorithm: 'AES-256-GCM';
  keySource: 'customer-vault';
}

export interface VerificationConfig {
  checksumOnWrite: true;
  restoreTestFrequency: 'monthly' | 'quarterly' | 'none';
}

export interface CostTrackingConfig {
  estimatePerGB: number;
  alertThresholdPct: number;
}

export interface BackupPolicy {
  customerId: string;
  plan: Plan;
  resources: ResourceFlags;
  schedule: ScheduleConfig;
  retention: RetentionConfig;
  encryption: EncryptionConfig;
  verification: VerificationConfig;
  costTracking: CostTrackingConfig;
}

/** Deep-partial override shape accepted when building a policy for one customer. */
export type BackupPolicyOverrides = {
  resources?: Partial<ResourceFlags>;
  schedule?: Partial<ScheduleConfig>;
  retention?: Partial<RetentionConfig>;
  verification?: Partial<VerificationConfig>;
  costTracking?: Partial<CostTrackingConfig>;
};

export type BackupJobType = 'full' | 'incremental' | 'wal';

export interface LastRunInfo {
  lastFullAt: Date | null;
  lastIncrementalAt: Date | null;
}

export interface DueResult {
  due: boolean;
  type: BackupJobType | null;
  reason: string;
}

export interface BackupRecord {
  id: string;
  customerId: string;
  type: BackupJobType;
  createdAt: Date;
  legalHold?: boolean;
}

export interface ObjectManifestEntry {
  key: string;
  etag: string;
  size: number;
  mtimeMs: number;
}

export interface DeltaResult {
  added: string[];
  changed: string[];
  removed: string[];
  unchanged: string[];
}

import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';

/**
 * Real AES-256-GCM encrypt/decrypt. The customer key itself is NOT sourced
 * here — per the S3 prompt, keys come from the customer's Oracle Vault
 * (S2 scope). Callers pass in a 32-byte key; this module only handles the
 * cipher mechanics and is exercised in tests with a locally generated
 * throwaway key, never a real vault key.
 */

export interface EncryptedPayload {
  ciphertext: Buffer;
  iv: Buffer;
  authTag: Buffer;
}

const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH_BYTES = 32;
const IV_LENGTH_BYTES = 12;

export function assertValidKey(key: Buffer): void {
  if (key.length !== KEY_LENGTH_BYTES) {
    throw new Error(`encryption key must be ${KEY_LENGTH_BYTES} bytes, got ${key.length}`);
  }
}

export function generateThrowawayKey(): Buffer {
  // Only for local/dev/test use — production keys come from customer Vault (S2).
  return randomBytes(KEY_LENGTH_BYTES);
}

export function encryptBuffer(plaintext: Buffer, key: Buffer): EncryptedPayload {
  assertValidKey(key);
  const iv = randomBytes(IV_LENGTH_BYTES);
  const cipher = createCipheriv(ALGORITHM, key, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return { ciphertext, iv, authTag };
}

export function decryptBuffer(payload: EncryptedPayload, key: Buffer): Buffer {
  assertValidKey(key);
  const decipher = createDecipheriv(ALGORITHM, key, payload.iv);
  decipher.setAuthTag(payload.authTag);
  return Buffer.concat([decipher.update(payload.ciphertext), decipher.final()]);
}

import { createHash } from 'node:crypto';

/** SHA-256 hex digest of a buffer or string. */
export function computeChecksum(data: Buffer | string): string {
  return createHash('sha256').update(data).digest('hex');
}

/** Constant-shape comparison is unnecessary here (checksums aren't secrets), but we
 * still avoid `===` on attacker-influenced strings out of habit; length-check first. */
export function verifyChecksum(data: Buffer | string, expected: string): boolean {
  const actual = computeChecksum(data);
  return actual.length === expected.length && actual === expected;
}

import test from 'node:test';
import assert from 'node:assert/strict';
import { computeChecksum, verifyChecksum } from '../checksum.js';

test('computeChecksum is deterministic for identical input', () => {
  const a = computeChecksum('hello world');
  const b = computeChecksum('hello world');
  assert.equal(a, b);
});

test('computeChecksum differs for different input', () => {
  const a = computeChecksum('hello world');
  const b = computeChecksum('hello world!');
  assert.notEqual(a, b);
});

test('verifyChecksum passes for matching data', () => {
  const data = Buffer.from('backup payload contents');
  const sum = computeChecksum(data);
  assert.equal(verifyChecksum(data, sum), true);
});

test('verifyChecksum fails for corrupted data (simulated bit-flip)', () => {
  const original = Buffer.from('backup payload contents');
  const sum = computeChecksum(original);
  const corrupted = Buffer.from(original);
  corrupted[0] ^= 0xff; // flip bits in the first byte
  assert.equal(verifyChecksum(corrupted, sum), false);
});

test('known SHA-256 vector (empty string)', () => {
  assert.equal(
    computeChecksum(''),
    'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
  );
});

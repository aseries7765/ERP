import test from 'node:test';
import assert from 'node:assert/strict';
import { computeDelta, deltaTransferBytes } from '../incremental.js';
import type { ObjectManifestEntry } from '../types.js';

function entry(key: string, etag: string, size = 100): ObjectManifestEntry {
  return { key, etag, size, mtimeMs: Date.now() };
}

test('identical manifests produce no added/changed/removed', () => {
  const manifest: ObjectManifestEntry[] = [entry('a.txt', 'e1'), entry('b.txt', 'e2')];
  const delta = computeDelta(manifest, manifest);
  assert.deepEqual(delta.added, []);
  assert.deepEqual(delta.changed, []);
  assert.deepEqual(delta.removed, []);
  assert.deepEqual(delta.unchanged.sort(), ['a.txt', 'b.txt']);
});

test('new key in current manifest is "added"', () => {
  const previous = [entry('a.txt', 'e1')];
  const current = [entry('a.txt', 'e1'), entry('new.txt', 'e9')];
  const delta = computeDelta(previous, current);
  assert.deepEqual(delta.added, ['new.txt']);
  assert.deepEqual(delta.removed, []);
});

test('key with a different ETag is "changed", not "added" or "removed"', () => {
  const previous = [entry('a.txt', 'e1')];
  const current = [entry('a.txt', 'e2')];
  const delta = computeDelta(previous, current);
  assert.deepEqual(delta.changed, ['a.txt']);
  assert.deepEqual(delta.added, []);
  assert.deepEqual(delta.unchanged, []);
});

test('key missing from current manifest is "removed"', () => {
  const previous = [entry('a.txt', 'e1'), entry('gone.txt', 'e3')];
  const current = [entry('a.txt', 'e1')];
  const delta = computeDelta(previous, current);
  assert.deepEqual(delta.removed, ['gone.txt']);
});

test('empty previous manifest treats everything as added (first full sync)', () => {
  const current = [entry('a.txt', 'e1'), entry('b.txt', 'e2')];
  const delta = computeDelta([], current);
  assert.deepEqual(delta.added.sort(), ['a.txt', 'b.txt']);
  assert.deepEqual(delta.removed, []);
});

test('deltaTransferBytes only counts added + changed object sizes', () => {
  const previous = [entry('unchanged.txt', 'e1', 500), entry('will-change.txt', 'e2', 200)];
  const current = [
    entry('unchanged.txt', 'e1', 500), // same etag, not transferred
    entry('will-change.txt', 'e3', 300), // changed, transferred at NEW size
    entry('brand-new.txt', 'e4', 150), // added, transferred
  ];
  assert.equal(deltaTransferBytes(previous, current), 300 + 150);
});

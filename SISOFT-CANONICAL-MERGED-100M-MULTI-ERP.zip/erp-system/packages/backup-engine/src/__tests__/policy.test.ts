import test from 'node:test';
import assert from 'node:assert/strict';
import { buildPolicy, planDefaults } from '../policy.js';

test('free plan has no scheduled cadence and no active resources', () => {
  const p = planDefaults('free');
  assert.equal(p.schedule.full, 'never');
  assert.equal(p.schedule.incremental, 'never');
  assert.equal(p.resources.database, false);
});

test('starter plan matches spec: daily full, 7-day retention, no PITR', () => {
  const p = planDefaults('starter');
  assert.equal(p.schedule.full, 'daily');
  assert.equal(p.schedule.incremental, 'never');
  assert.equal(p.schedule.pitrWindowDays, 0);
  assert.equal(p.retention.dailyKeep, 7);
});

test('business plan matches spec: daily+hourly, 30-day retention, 7-day PITR', () => {
  const p = planDefaults('business');
  assert.equal(p.schedule.full, 'daily');
  assert.equal(p.schedule.incremental, 'hourly');
  assert.equal(p.retention.dailyKeep, 30);
  assert.equal(p.schedule.pitrWindowDays, 7);
});

test('enterprise plan matches spec: hourly full, 90-day retention, 30-day PITR', () => {
  const p = planDefaults('enterprise');
  assert.equal(p.schedule.full, 'hourly');
  assert.equal(p.retention.dailyKeep, 90);
  assert.equal(p.schedule.pitrWindowDays, 30);
});

test('all paid plans encrypt with AES-256-GCM from the customer vault', () => {
  for (const plan of ['starter', 'business', 'enterprise'] as const) {
    const p = planDefaults(plan);
    assert.equal(p.encryption.algorithm, 'AES-256-GCM');
    assert.equal(p.encryption.keySource, 'customer-vault');
  }
});

test('buildPolicy attaches customerId and applies partial overrides per section', () => {
  const policy = buildPolicy('cust_123', 'business', {
    retention: { dailyKeep: 45 },
    resources: { cache: true },
  });

  assert.equal(policy.customerId, 'cust_123');
  assert.equal(policy.retention.dailyKeep, 45);
  // untouched retention fields still come from the business default
  assert.equal(policy.retention.weeklyKeep, 8);
  assert.equal(policy.resources.cache, true);
  // untouched resource fields still come from the default
  assert.equal(policy.resources.database, true);
});

test('buildPolicy with no overrides equals plan defaults plus customerId', () => {
  const policy = buildPolicy('cust_456', 'starter');
  const defaults = planDefaults('starter');
  assert.deepEqual(policy.schedule, defaults.schedule);
  assert.deepEqual(policy.retention, defaults.retention);
});

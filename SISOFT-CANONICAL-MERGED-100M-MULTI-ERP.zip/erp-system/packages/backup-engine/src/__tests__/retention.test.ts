import test from 'node:test';
import assert from 'node:assert/strict';
import { selectBackupsForDeletion } from '../retention.js';
import type { BackupRecord, RetentionConfig } from '../types.js';

function daily(id: string, daysAgo: number, now: Date, type: BackupRecord['type'] = 'full'): BackupRecord {
  const createdAt = new Date(now.getTime() - daysAgo * 24 * 60 * 60 * 1000);
  return { id, customerId: 'c1', type, createdAt };
}

test('keeps exactly dailyKeep most recent daily backups, deletes the rest', () => {
  const now = new Date('2026-09-15T00:00:00Z');
  const backups: BackupRecord[] = Array.from({ length: 10 }, (_, i) => daily(`d${i}`, i, now));
  const retention: RetentionConfig = { dailyKeep: 3, weeklyKeep: 0, monthlyKeep: 0, yearlyKeep: 0 };

  const toDelete = selectBackupsForDeletion(backups, retention, now);
  const deletedIds = new Set(toDelete.map((b) => b.id));

  // d0, d1, d2 are the 3 most recent -> kept
  assert.equal(deletedIds.has('d0'), false);
  assert.equal(deletedIds.has('d1'), false);
  assert.equal(deletedIds.has('d2'), false);
  // everything older -> deleted
  assert.equal(deletedIds.has('d3'), true);
  assert.equal(deletedIds.has('d9'), true);
  assert.equal(toDelete.length, 7);
});

test('legal hold records are never selected for deletion, even if very old', () => {
  const now = new Date('2026-09-15T00:00:00Z');
  const backups: BackupRecord[] = [
    daily('old-hold', 400, now),
    daily('old-no-hold', 400, now),
  ];
  backups[0].legalHold = true;
  const retention: RetentionConfig = { dailyKeep: 0, weeklyKeep: 0, monthlyKeep: 0, yearlyKeep: 0 };

  const toDelete = selectBackupsForDeletion(backups, retention, now);
  const deletedIds = new Set(toDelete.map((b) => b.id));
  assert.equal(deletedIds.has('old-hold'), false);
  assert.equal(deletedIds.has('old-no-hold'), true);
});

test('a full backup can simultaneously satisfy daily, weekly and monthly retention', () => {
  const now = new Date('2026-09-15T00:00:00Z');
  // A single full backup from yesterday is the most recent in its day, week, and month buckets.
  const backups: BackupRecord[] = [daily('only-one', 1, now)];
  const retention: RetentionConfig = { dailyKeep: 1, weeklyKeep: 1, monthlyKeep: 1, yearlyKeep: 1 };

  const toDelete = selectBackupsForDeletion(backups, retention, now);
  assert.equal(toDelete.length, 0);
});

test('incrementals are not eligible for weekly/monthly/yearly retention buckets', () => {
  const now = new Date('2026-09-15T00:00:00Z');
  const backups: BackupRecord[] = [daily('inc1', 40, now, 'incremental')];
  // dailyKeep 0 -> not kept by daily bucket. weekly/monthly/yearly only consider 'full' type,
  // so this incremental has no bucket that can save it.
  const retention: RetentionConfig = { dailyKeep: 0, weeklyKeep: 5, monthlyKeep: 5, yearlyKeep: 5 };

  const toDelete = selectBackupsForDeletion(backups, retention, now);
  assert.equal(toDelete.some((b) => b.id === 'inc1'), true);
});

test('future-dated records are defensively ignored (not deleted, not counted as recent)', () => {
  const now = new Date('2026-09-15T00:00:00Z');
  const futureRecord = daily('future', -5, now); // 5 days in the future
  const retention: RetentionConfig = { dailyKeep: 1, weeklyKeep: 0, monthlyKeep: 0, yearlyKeep: 0 };
  const toDelete = selectBackupsForDeletion([futureRecord], retention, now);
  assert.equal(toDelete.length, 0);
});

test('30-day daily retention on a year of daily fulls deletes everything past day 30', () => {
  const now = new Date('2026-09-15T00:00:00Z');
  const backups: BackupRecord[] = Array.from({ length: 365 }, (_, i) => daily(`y${i}`, i, now));
  const retention: RetentionConfig = { dailyKeep: 30, weeklyKeep: 8, monthlyKeep: 3, yearlyKeep: 0 };

  const toDelete = selectBackupsForDeletion(backups, retention, now);
  const kept = backups.length - toDelete.length;
  // 30 daily + up to 8 additional weekly reps outside the daily window + up to 3 monthly reps
  // outside those — kept count must be within a sane bound, never the full 365.
  assert.ok(kept >= 30);
  assert.ok(kept < 45);
  assert.ok(toDelete.length > 300);
});

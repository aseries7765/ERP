import test from 'node:test';
import assert from 'node:assert/strict';
import { encryptBuffer, decryptBuffer, generateThrowawayKey, assertValidKey } from '../encryption.js';

test('encrypt then decrypt round-trips to the original plaintext', () => {
  const key = generateThrowawayKey();
  const plaintext = Buffer.from('this is sensitive backup content');
  const payload = encryptBuffer(plaintext, key);
  const decrypted = decryptBuffer(payload, key);
  assert.deepEqual(decrypted, plaintext);
});

test('ciphertext does not contain the plaintext bytes', () => {
  const key = generateThrowawayKey();
  const plaintext = Buffer.from('a very identifiable secret marker XYZ123');
  const { ciphertext } = encryptBuffer(plaintext, key);
  assert.equal(ciphertext.includes('XYZ123'), false);
});

test('decrypting with the wrong key fails (GCM auth tag check)', () => {
  const key = generateThrowawayKey();
  const wrongKey = generateThrowawayKey();
  const payload = encryptBuffer(Buffer.from('data'), key);
  assert.throws(() => decryptBuffer(payload, wrongKey));
});

test('tampering with ciphertext is detected by the auth tag', () => {
  const key = generateThrowawayKey();
  const payload = encryptBuffer(Buffer.from('important backup bytes'), key);
  payload.ciphertext[0] ^= 0xff;
  assert.throws(() => decryptBuffer(payload, key));
});

test('rejects keys that are not 32 bytes', () => {
  assert.throws(() => assertValidKey(Buffer.alloc(16)));
  assert.doesNotThrow(() => assertValidKey(Buffer.alloc(32)));
});

test('two encryptions of the same plaintext produce different ciphertext (random IV)', () => {
  const key = generateThrowawayKey();
  const plaintext = Buffer.from('same content twice');
  const a = encryptBuffer(plaintext, key);
  const b = encryptBuffer(plaintext, key);
  assert.notDeepEqual(a.ciphertext, b.ciphertext);
});

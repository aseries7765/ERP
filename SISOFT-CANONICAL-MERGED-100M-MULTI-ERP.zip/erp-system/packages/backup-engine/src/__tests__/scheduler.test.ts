import test from 'node:test';
import assert from 'node:assert/strict';
import { isDue, msUntilDue, computeDueJob } from '../scheduler.js';
import { buildPolicy } from '../policy.js';
import type { LastRunInfo } from '../types.js';

test('isDue: never-cadence is never due', () => {
  assert.equal(isDue('never', null, new Date()), false);
  assert.equal(isDue('never', new Date(0), new Date()), false);
});

test('isDue: null lastRunAt with a real cadence is immediately due (first run)', () => {
  assert.equal(isDue('daily', null, new Date()), true);
});

test('isDue: daily cadence respects the 24h boundary', () => {
  const now = new Date('2026-09-15T12:00:00Z');
  const twentyThreeHoursAgo = new Date('2026-09-14T13:00:00Z');
  const twentyFiveHoursAgo = new Date('2026-09-14T11:00:00Z');
  assert.equal(isDue('daily', twentyThreeHoursAgo, now), false);
  assert.equal(isDue('daily', twentyFiveHoursAgo, now), true);
});

test('msUntilDue counts down correctly and is 0 on first run', () => {
  const now = new Date('2026-09-15T12:00:00Z');
  assert.equal(msUntilDue('hourly', null, now), 0);
  const fortyMinAgo = new Date('2026-09-15T11:20:00Z');
  assert.equal(msUntilDue('hourly', fortyMinAgo, now), 20 * 60 * 1000);
});

test('computeDueJob: free plan is never due regardless of last-run state', () => {
  const policy = buildPolicy('c1', 'free');
  const result = computeDueJob(policy, { lastFullAt: null, lastIncrementalAt: null }, new Date());
  assert.equal(result.due, false);
  assert.equal(result.type, null);
});

test('computeDueJob: full backup takes priority over incremental when both are due', () => {
  const policy = buildPolicy('c2', 'business'); // full: daily, incremental: hourly
  const now = new Date('2026-09-15T12:00:00Z');
  const lastRuns: LastRunInfo = {
    lastFullAt: new Date('2026-09-13T00:00:00Z'), // > 1 day ago -> full due
    lastIncrementalAt: new Date('2026-09-15T11:00:00Z'), // 1h ago -> incremental also due
  };
  const result = computeDueJob(policy, lastRuns, now);
  assert.equal(result.due, true);
  assert.equal(result.type, 'full');
});

test('computeDueJob: falls back to incremental when only incremental cadence elapsed', () => {
  const policy = buildPolicy('c3', 'business');
  const now = new Date('2026-09-15T12:00:00Z');
  const lastRuns: LastRunInfo = {
    lastFullAt: new Date('2026-09-15T01:00:00Z'), // 11h ago, daily cadence not elapsed
    lastIncrementalAt: new Date('2026-09-15T10:00:00Z'), // 2h ago, hourly cadence elapsed
  };
  const result = computeDueJob(policy, lastRuns, now);
  assert.equal(result.due, true);
  assert.equal(result.type, 'incremental');
});

test('computeDueJob: nothing due when both cadences are fresh', () => {
  const policy = buildPolicy('c4', 'business');
  const now = new Date('2026-09-15T12:00:00Z');
  const lastRuns: LastRunInfo = {
    lastFullAt: new Date('2026-09-15T01:00:00Z'),
    lastIncrementalAt: new Date('2026-09-15T11:45:00Z'),
  };
  const result = computeDueJob(policy, lastRuns, now);
  assert.equal(result.due, false);
});

import type { BackupPolicy, Cadence, DueResult, LastRunInfo } from './types.js';

const CADENCE_MS: Record<Exclude<Cadence, 'never'>, number> = {
  hourly: 60 * 60 * 1000,
  daily: 24 * 60 * 60 * 1000,
  weekly: 7 * 24 * 60 * 60 * 1000,
  monthly: 30 * 24 * 60 * 60 * 1000, // approximate month; documented simplification
};

/**
 * Elapsed-time due check for a single cadence. `never` and a null last-run
 * with `never` cadence are both "not due". A null last-run with any real
 * cadence is immediately due (first run).
 */
export function isDue(cadence: Cadence, lastRunAt: Date | null, now: Date): boolean {
  if (cadence === 'never') return false;
  if (lastRunAt === null) return true;
  const elapsed = now.getTime() - lastRunAt.getTime();
  return elapsed >= CADENCE_MS[cadence];
}

export function msUntilDue(cadence: Cadence, lastRunAt: Date | null, now: Date): number {
  if (cadence === 'never') return Number.POSITIVE_INFINITY;
  if (lastRunAt === null) return 0;
  const elapsed = now.getTime() - lastRunAt.getTime();
  return Math.max(0, CADENCE_MS[cadence] - elapsed);
}

/**
 * Decides what (if anything) is due for a customer right now. A full
 * backup takes priority over an incremental — running a full backup
 * satisfies the incremental cadence too, since incrementals are deltas
 * against the most recent full/incremental chain.
 */
export function computeDueJob(policy: BackupPolicy, lastRuns: LastRunInfo, now: Date): DueResult {
  if (policy.plan === 'free') {
    return { due: false, type: null, reason: 'free plan is customer-managed; no scheduled backups' };
  }

  const fullDue = isDue(policy.schedule.full, lastRuns.lastFullAt, now);
  if (fullDue) {
    return { due: true, type: 'full', reason: `full backup cadence (${policy.schedule.full}) elapsed` };
  }

  const incrementalDue = isDue(policy.schedule.incremental, lastRuns.lastIncrementalAt, now);
  if (incrementalDue) {
    return { due: true, type: 'incremental', reason: `incremental cadence (${policy.schedule.incremental}) elapsed` };
  }

  return { due: false, type: null, reason: 'no cadence elapsed' };
}

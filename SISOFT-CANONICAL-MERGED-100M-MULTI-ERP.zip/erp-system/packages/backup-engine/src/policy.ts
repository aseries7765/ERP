import type {
  BackupPolicy,
  BackupPolicyOverrides,
  Plan,
  ResourceFlags,
  ScheduleConfig,
  RetentionConfig,
  VerificationConfig,
  CostTrackingConfig,
} from './types.js';

const BASE_RESOURCES: ResourceFlags = {
  database: true,
  objectStorage: true,
  k8sResources: true,
  search: true,
  cache: false, // cache is rebuildable; skipped by default per spec
  config: true,
  encryptionKeys: true,
};

/**
 * Defaults per plan tier, per the S3 prompt's "Defaults per plan" table.
 * `free` is customer-managed / documented-only: we still return a policy
 * object so callers have a consistent shape, but schedule cadences are
 * 'never' and this should never be picked up by the scheduler.
 */
const PLAN_SCHEDULE: Record<Plan, ScheduleConfig> = {
  free: { full: 'never', incremental: 'never', walArchive: false, pitrWindowDays: 0 },
  starter: { full: 'daily', incremental: 'never', walArchive: false, pitrWindowDays: 0 },
  business: { full: 'daily', incremental: 'hourly', walArchive: true, pitrWindowDays: 7 },
  enterprise: { full: 'hourly', incremental: 'hourly', walArchive: true, pitrWindowDays: 30 },
};

const PLAN_RETENTION: Record<Plan, RetentionConfig> = {
  free: { dailyKeep: 0, weeklyKeep: 0, monthlyKeep: 0, yearlyKeep: 0 },
  starter: { dailyKeep: 7, weeklyKeep: 0, monthlyKeep: 0, yearlyKeep: 0 },
  business: { dailyKeep: 30, weeklyKeep: 8, monthlyKeep: 3, yearlyKeep: 0 },
  enterprise: { dailyKeep: 90, weeklyKeep: 12, monthlyKeep: 12, yearlyKeep: 1 },
};

const PLAN_VERIFICATION: Record<Plan, VerificationConfig> = {
  free: { checksumOnWrite: true, restoreTestFrequency: 'none' },
  starter: { checksumOnWrite: true, restoreTestFrequency: 'monthly' },
  business: { checksumOnWrite: true, restoreTestFrequency: 'monthly' },
  enterprise: { checksumOnWrite: true, restoreTestFrequency: 'quarterly' },
};

const PLAN_COST: Record<Plan, CostTrackingConfig> = {
  free: { estimatePerGB: 0, alertThresholdPct: 80 },
  starter: { estimatePerGB: 0.02, alertThresholdPct: 80 },
  business: { estimatePerGB: 0.02, alertThresholdPct: 80 },
  enterprise: { estimatePerGB: 0.02, alertThresholdPct: 90 },
};

/**
 * NOTE on "restore test frequency" vs the prose defaults table in the S3
 * prompt ("weekly restore test" for business, "daily restore test" for
 * enterprise): VerificationConfig as specified only models
 * 'monthly' | 'quarterly' | 'none'. Rather than silently inventing a
 * 'weekly' / 'daily' value the rest of this codebase doesn't define, this
 * is called out honestly in MANIFEST.md as a scope gap between the prose
 * table and the typed interface given in the prompt.
 */

export function planDefaults(plan: Plan): Omit<BackupPolicy, 'customerId'> {
  return {
    plan,
    resources: plan === 'free' ? { ...BASE_RESOURCES, database: false, objectStorage: false, k8sResources: false, search: false, config: false, encryptionKeys: false } : { ...BASE_RESOURCES },
    schedule: { ...PLAN_SCHEDULE[plan] },
    retention: { ...PLAN_RETENTION[plan] },
    encryption: { algorithm: 'AES-256-GCM', keySource: 'customer-vault' },
    verification: { ...PLAN_VERIFICATION[plan] },
    costTracking: { ...PLAN_COST[plan] },
  };
}

/**
 * Builds a concrete policy for one customer: plan defaults with optional
 * per-tenant overrides shallow-merged one level deep per section.
 */
export function buildPolicy(
  customerId: string,
  plan: Plan,
  overrides: BackupPolicyOverrides = {},
): BackupPolicy {
  const base = planDefaults(plan);
  return {
    customerId,
    plan,
    resources: { ...base.resources, ...overrides.resources },
    schedule: { ...base.schedule, ...overrides.schedule },
    retention: { ...base.retention, ...overrides.retention },
    encryption: base.encryption,
    verification: { ...base.verification, ...overrides.verification },
    costTracking: { ...base.costTracking, ...overrides.costTracking },
  };
}

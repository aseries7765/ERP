import type { BackupRecord, RetentionConfig } from './types.js';

function dayKey(d: Date): string {
  return d.toISOString().slice(0, 10); // YYYY-MM-DD (UTC)
}

function monthKey(d: Date): string {
  return d.toISOString().slice(0, 7); // YYYY-MM (UTC)
}

function yearKey(d: Date): string {
  return d.toISOString().slice(0, 4); // YYYY (UTC)
}

/** ISO week key, e.g. "2026-W03". Used to pick one representative backup per week. */
function isoWeekKey(d: Date): string {
  const date = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const dayNum = date.getUTCDay() === 0 ? 7 : date.getUTCDay();
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((date.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${date.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
}

/** Picks the most-recent backup per bucket (day/week/month/year), then keeps the top N buckets. */
function keepMostRecentPerBucket(
  backups: BackupRecord[],
  bucketFn: (d: Date) => string,
  keepCount: number,
): Set<string> {
  const keep = new Set<string>();
  if (keepCount <= 0) return keep;

  const latestPerBucket = new Map<string, BackupRecord>();
  for (const b of backups) {
    const key = bucketFn(b.createdAt);
    const existing = latestPerBucket.get(key);
    if (!existing || b.createdAt.getTime() > existing.createdAt.getTime()) {
      latestPerBucket.set(key, b);
    }
  }

  const sortedBuckets = [...latestPerBucket.entries()].sort(
    (a, b) => b[1].createdAt.getTime() - a[1].createdAt.getTime(),
  );

  for (const [, record] of sortedBuckets.slice(0, keepCount)) {
    keep.add(record.id);
  }
  return keep;
}

/**
 * Grandfather-Father-Son retention: for each customer's backups, keeps the
 * most recent N per day, N per week, N per month, N per year (as configured),
 * and marks everything else for deletion — except records flagged
 * `legalHold`, which are never returned for deletion regardless of age.
 *
 * Only `full` backups participate in weekly/monthly/yearly bucketing
 * (incrementals/WAL segments are daily-retention-only, since they're not
 * independently restorable snapshots).
 */
export function selectBackupsForDeletion(
  backups: BackupRecord[],
  retention: RetentionConfig,
  now: Date,
): BackupRecord[] {
  const fulls = backups.filter((b) => b.type === 'full');

  const keepIds = new Set<string>([
    ...keepMostRecentPerBucket(backups, dayKey, retention.dailyKeep),
    ...keepMostRecentPerBucket(fulls, isoWeekKey, retention.weeklyKeep),
    ...keepMostRecentPerBucket(fulls, monthKey, retention.monthlyKeep),
    ...keepMostRecentPerBucket(fulls, yearKey, retention.yearlyKeep),
  ]);

  return backups.filter((b) => {
    if (b.legalHold) return false; // never auto-delete a legal hold
    if (b.createdAt.getTime() > now.getTime()) return false; // defensive: ignore future-dated records
    return !keepIds.has(b.id);
  });
}

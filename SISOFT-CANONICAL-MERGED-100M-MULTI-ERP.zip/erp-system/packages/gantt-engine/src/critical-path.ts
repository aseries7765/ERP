import { TaskInput, DependencyInput, TaskSchedule, CriticalPathResult } from './types';
import { forwardPass } from './forward-pass';
import { backwardPass } from './backward-pass';
import { computeFloat } from './float';

/**
 * Computes the full CPM (Critical Path Method) schedule for a project's
 * tasks: forward pass, backward pass, float, and the critical path (the set
 * of tasks with zero total float).
 *
 * Deterministic and pure — same input always yields the same schedule (G19,
 * verified against hand-calculated fixtures in critical-path.spec.ts).
 */
export function computeCriticalPath(
  tasks: TaskInput[],
  deps: DependencyInput[],
): CriticalPathResult {
  if (tasks.length === 0) {
    return { schedule: [], criticalPath: [], projectDuration: 0 };
  }

  const { earlyStart, earlyFinish, projectDuration } = forwardPass(tasks, deps);
  const { lateStart, lateFinish } = backwardPass(tasks, deps, projectDuration);
  const taskIds = tasks.map((t) => t.taskId);
  const { totalFloat, freeFloat } = computeFloat(taskIds, earlyStart, earlyFinish, lateStart, deps);

  const schedule: TaskSchedule[] = taskIds.map((taskId) => {
    const tf = totalFloat.get(taskId) ?? 0;
    return {
      taskId,
      earlyStart: earlyStart.get(taskId) ?? 0,
      earlyFinish: earlyFinish.get(taskId) ?? 0,
      lateStart: lateStart.get(taskId) ?? 0,
      lateFinish: lateFinish.get(taskId) ?? 0,
      totalFloat: tf,
      freeFloat: freeFloat.get(taskId) ?? 0,
      // Floating point safety margin for "zero" float.
      isCritical: Math.abs(tf) < 1e-9,
    };
  });

  const criticalPath = schedule.filter((s) => s.isCritical).map((s) => s.taskId);

  return { schedule, criticalPath, projectDuration };
}

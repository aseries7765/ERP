import { BaselineTask, TaskSchedule, TaskId } from './types';

export interface BaselineVariance {
  taskId: TaskId;
  startVarianceDays: number;
  finishVarianceDays: number;
}

/** Captures a baseline snapshot from a computed schedule (to be persisted by the caller). */
export function captureBaseline(schedule: TaskSchedule[]): BaselineTask[] {
  return schedule.map((s) => ({
    taskId: s.taskId,
    baselineStart: s.earlyStart,
    baselineFinish: s.earlyFinish,
  }));
}

/** Compares a current schedule against a previously captured baseline. */
export function compareToBaseline(
  current: TaskSchedule[],
  baseline: BaselineTask[],
): BaselineVariance[] {
  const baselineById = new Map(baseline.map((b) => [b.taskId, b]));
  return current
    .filter((s) => baselineById.has(s.taskId))
    .map((s) => {
      const b = baselineById.get(s.taskId) as BaselineTask;
      return {
        taskId: s.taskId,
        startVarianceDays: s.earlyStart - b.baselineStart,
        finishVarianceDays: s.earlyFinish - b.baselineFinish,
      };
    });
}

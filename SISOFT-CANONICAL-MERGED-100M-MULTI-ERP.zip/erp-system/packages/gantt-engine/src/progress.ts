import { ProgressTask, TaskSchedule, TaskId } from './types';

export interface PlannedVsActual {
  taskId: TaskId;
  plannedPercentComplete: number;
  actualPercentComplete: number;
  varianceDays: number;
}

/**
 * Computes the "should be X% complete by now" figure for a task given the
 * as-of day, based on its planned schedule (linear progress assumption
 * between early start and early finish), and compares to reported actual
 * percent complete.
 */
export function plannedVsActual(
  schedule: TaskSchedule[],
  progress: ProgressTask[],
  asOfDay: number,
): PlannedVsActual[] {
  const progressById = new Map(progress.map((p) => [p.taskId, p]));

  return schedule.map((s) => {
    const duration = s.earlyFinish - s.earlyStart;
    let plannedPct: number;
    if (asOfDay <= s.earlyStart) plannedPct = 0;
    else if (asOfDay >= s.earlyFinish) plannedPct = 100;
    else if (duration === 0) plannedPct = 100;
    else plannedPct = ((asOfDay - s.earlyStart) / duration) * 100;

    const actual = progressById.get(s.taskId);
    const actualPct = actual?.percentComplete ?? 0;

    // Rough schedule variance in days: how far actual progress is from planned,
    // expressed in equivalent days of the task's duration.
    const varianceDays = duration === 0 ? 0 : ((actualPct - plannedPct) / 100) * duration;

    return {
      taskId: s.taskId,
      plannedPercentComplete: plannedPct,
      actualPercentComplete: actualPct,
      varianceDays,
    };
  });
}

import { ResourceAssignment, TaskId } from './types';

export interface OverallocationWindow {
  resourceId: string;
  day: number;
  totalAllocationPct: number;
  taskIds: TaskId[];
}

export interface LevelingSuggestion {
  resourceId: string;
  taskId: TaskId;
  /** Suggested number of days to delay this task's start to resolve the overallocation. */
  suggestedDelayDays: number;
  reason: string;
}

/**
 * Detects resource overallocation: any resource assigned more than 100%
 * (aggregate across concurrent tasks) on any given day.
 */
export function detectOverallocation(assignments: ResourceAssignment[]): OverallocationWindow[] {
  const byResource = new Map<string, ResourceAssignment[]>();
  for (const a of assignments) {
    const list = byResource.get(a.resourceId) ?? [];
    list.push(a);
    byResource.set(a.resourceId, list);
  }

  const windows: OverallocationWindow[] = [];

  for (const [resourceId, resAssignments] of byResource.entries()) {
    const lastDay = Math.max(...resAssignments.map((a) => a.endDay));
    for (let day = 0; day <= lastDay; day++) {
      const activeToday = resAssignments.filter((a) => a.startDay <= day && day < a.endDay);
      const total = activeToday.reduce((sum, a) => sum + a.allocationPct, 0);
      if (total > 100) {
        windows.push({
          resourceId,
          day,
          totalAllocationPct: total,
          taskIds: activeToday.map((a) => a.taskId),
        });
      }
    }
  }

  return windows;
}

/**
 * Produces naive leveling suggestions: for each overallocation window, delay
 * the task(s) with the most total float first (lowest priority to keep on
 * schedule). Since float isn't known to this pure resource module, the
 * caller supplies a priority order (e.g. tasks already off the critical path
 * first); this function delays all but the first (highest-priority) task in
 * each conflicting window by one day per conflicting unit, as a starting
 * point for manual review — full automatic re-leveling with cascading
 * schedule updates is a documented manual-override step (see
 * RESOURCE_LEVELING.md), not fully automated here.
 */
export function suggestLeveling(
  windows: OverallocationWindow[],
  taskPriorityOrder: TaskId[],
): LevelingSuggestion[] {
  const priorityIndex = new Map(taskPriorityOrder.map((id, idx) => [id, idx]));
  const suggestions: LevelingSuggestion[] = [];

  for (const window of windows) {
    const sorted = [...window.taskIds].sort(
      (a, b) => (priorityIndex.get(a) ?? Infinity) - (priorityIndex.get(b) ?? Infinity),
    );
    // Keep the first (highest priority) task on schedule; suggest delaying the rest.
    for (let i = 1; i < sorted.length; i++) {
      const taskId = sorted[i];
      if (taskId === undefined) continue; // unreachable given the loop bound, but keeps strict indexing honest
      suggestions.push({
        resourceId: window.resourceId,
        taskId,
        suggestedDelayDays: 1,
        reason: `Overallocated on day ${window.day} (${window.totalAllocationPct}% of capacity) alongside ${sorted.slice(0, i).join(', ')}`,
      });
    }
  }

  return suggestions;
}

import { TaskId, DependencyInput } from './types';
import { buildSuccessorMap } from './dependencies';

export interface FloatResult {
  totalFloat: Map<TaskId, number>;
  freeFloat: Map<TaskId, number>;
}

/**
 * Computes total float (latestStart - earlyStart) and free float (the amount
 * a task can slip without delaying the early start of ANY successor) for
 * every task.
 */
export function computeFloat(
  taskIds: TaskId[],
  earlyStart: Map<TaskId, number>,
  earlyFinish: Map<TaskId, number>,
  lateStart: Map<TaskId, number>,
  deps: DependencyInput[],
): FloatResult {
  const totalFloat = new Map<TaskId, number>();
  const freeFloat = new Map<TaskId, number>();
  const succMap = buildSuccessorMap(deps);

  for (const taskId of taskIds) {
    const es = earlyStart.get(taskId);
    const ls = lateStart.get(taskId);
    const ef = earlyFinish.get(taskId);
    if (es === undefined || ls === undefined || ef === undefined) {
      throw new Error(`Missing schedule data for task ${taskId}`);
    }
    totalFloat.set(taskId, ls - es);

    const successors = succMap.get(taskId) ?? [];
    if (successors.length === 0) {
      // No successors: free float equals total float (limited only by project end).
      freeFloat.set(taskId, ls - es);
      continue;
    }

    // Free float = min over successors of (successor's early start - this task's early finish),
    // for FS dependencies. For non-FS types we conservatively fall back to total float,
    // since free float is classically defined for FS chains — documented limitation.
    const allFs = successors.every((d) => d.type === 'FS');
    if (!allFs) {
      freeFloat.set(taskId, ls - es);
      continue;
    }

    const minSuccessorStart = Math.min(
      ...successors.map((dep) => earlyStart.get(dep.successorId) ?? Infinity),
    );
    freeFloat.set(taskId, Math.max(0, minSuccessorStart - ef));
  }

  return { totalFloat, freeFloat };
}

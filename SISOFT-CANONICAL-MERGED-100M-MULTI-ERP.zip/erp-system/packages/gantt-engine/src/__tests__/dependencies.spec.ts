import { describe, it, expect } from 'vitest';
import { earliestStartFromDependency } from '../dependencies';
import { DependencyInput } from '../types';

describe('earliestStartFromDependency', () => {
  const base = { predecessorId: 'P', successorId: 'S' };

  it('FS: successor starts at predecessor finish + lag', () => {
    const dep: DependencyInput = { ...base, type: 'FS', lagDays: 2 };
    expect(earliestStartFromDependency(dep, 0, 10, 5)).toBe(12);
  });

  it('SS: successor starts at predecessor start + lag', () => {
    const dep: DependencyInput = { ...base, type: 'SS', lagDays: 1 };
    expect(earliestStartFromDependency(dep, 3, 10, 5)).toBe(4);
  });

  it('FF: successor start is derived so its finish is no earlier than predecessor finish + lag', () => {
    const dep: DependencyInput = { ...base, type: 'FF', lagDays: 0 };
    // successor duration 5, predecessor finish 10 -> successor must start by 10-5=5 at earliest
    expect(earliestStartFromDependency(dep, 0, 10, 5)).toBe(5);
  });

  it('SF: successor start is derived so its finish is no earlier than predecessor start + lag', () => {
    const dep: DependencyInput = { ...base, type: 'SF', lagDays: 0 };
    expect(earliestStartFromDependency(dep, 8, 10, 3)).toBe(5);
  });

  it('supports negative lag (lead time)', () => {
    const dep: DependencyInput = { ...base, type: 'FS', lagDays: -2 };
    expect(earliestStartFromDependency(dep, 0, 10, 5)).toBe(8);
  });

  it('throws on an unknown dependency type', () => {
    const dep = { ...base, type: 'XX' as any, lagDays: 0 };
    expect(() => earliestStartFromDependency(dep, 0, 10, 5)).toThrow();
  });
});

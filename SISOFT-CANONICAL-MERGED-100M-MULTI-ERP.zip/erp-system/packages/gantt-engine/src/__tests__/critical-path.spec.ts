import { describe, it, expect } from 'vitest';
import { computeCriticalPath } from '../critical-path';
import { TaskInput, DependencyInput } from '../types';

/**
 * Classic textbook CPM fixture (hand-calculated, G19):
 *
 *   A(3) -> B(4) -> D(2)
 *   A(3) -> C(2) -> D(2)
 *
 * Forward pass:
 *   A: ES=0 EF=3
 *   B: ES=3 EF=7   (depends on A via FS)
 *   C: ES=3 EF=5   (depends on A via FS)
 *   D: ES=max(7,5)=7 EF=9  (depends on B and C via FS)
 *
 * Project duration = 9
 *
 * Backward pass (from 9):
 *   D: LF=9 LS=7
 *   B: LF=7 LS=3     (D's only path forcing constraint on B)
 *   C: LF=7 LS=5     (C has slack: LF = min over successors -> D's LS = 7)
 *   A: LF=min(B.LS, C.LS)=min(3,5)=3 LS=0
 *
 * Total float:
 *   A: 0-0=0 (critical)
 *   B: 3-3=0 (critical)
 *   C: 5-3=2 (not critical)
 *   D: 7-7=0 (critical)
 *
 * Critical path: A -> B -> D, duration 9.
 */
describe('computeCriticalPath', () => {
  const tasks: TaskInput[] = [
    { taskId: 'A', durationDays: 3 },
    { taskId: 'B', durationDays: 4 },
    { taskId: 'C', durationDays: 2 },
    { taskId: 'D', durationDays: 2 },
  ];
  const deps: DependencyInput[] = [
    { predecessorId: 'A', successorId: 'B', type: 'FS', lagDays: 0 },
    { predecessorId: 'A', successorId: 'C', type: 'FS', lagDays: 0 },
    { predecessorId: 'B', successorId: 'D', type: 'FS', lagDays: 0 },
    { predecessorId: 'C', successorId: 'D', type: 'FS', lagDays: 0 },
  ];

  it('matches the hand-calculated forward pass', () => {
    const result = computeCriticalPath(tasks, deps);
    const byId = Object.fromEntries(result.schedule.map((s) => [s.taskId, s]));

    expect(byId.A!.earlyStart).toBe(0);
    expect(byId.A!.earlyFinish).toBe(3);
    expect(byId.B!.earlyStart).toBe(3);
    expect(byId.B!.earlyFinish).toBe(7);
    expect(byId.C!.earlyStart).toBe(3);
    expect(byId.C!.earlyFinish).toBe(5);
    expect(byId.D!.earlyStart).toBe(7);
    expect(byId.D!.earlyFinish).toBe(9);
    expect(result.projectDuration).toBe(9);
  });

  it('matches the hand-calculated backward pass and float', () => {
    const result = computeCriticalPath(tasks, deps);
    const byId = Object.fromEntries(result.schedule.map((s) => [s.taskId, s]));

    expect(byId.D!.lateStart).toBe(7);
    expect(byId.D!.lateFinish).toBe(9);
    expect(byId.B!.lateStart).toBe(3);
    expect(byId.B!.lateFinish).toBe(7);
    expect(byId.C!.lateStart).toBe(5);
    expect(byId.C!.lateFinish).toBe(7);
    expect(byId.A!.lateStart).toBe(0);
    expect(byId.A!.lateFinish).toBe(3);

    expect(byId.A!.totalFloat).toBe(0);
    expect(byId.B!.totalFloat).toBe(0);
    expect(byId.C!.totalFloat).toBe(2);
    expect(byId.D!.totalFloat).toBe(0);
  });

  it('identifies the correct critical path', () => {
    const result = computeCriticalPath(tasks, deps);
    expect(result.criticalPath.sort()).toEqual(['A', 'B', 'D'].sort());
    expect(result.criticalPath).not.toContain('C');
  });

  it('is deterministic across repeated calls', () => {
    const a = computeCriticalPath(tasks, deps);
    const b = computeCriticalPath(tasks, deps);
    expect(a).toEqual(b);
  });

  it('handles an empty task list', () => {
    const result = computeCriticalPath([], []);
    expect(result.criticalPath).toEqual([]);
    expect(result.projectDuration).toBe(0);
  });

  it('throws on a dependency cycle instead of infinite-looping', () => {
    const cyclicDeps: DependencyInput[] = [
      { predecessorId: 'A', successorId: 'B', type: 'FS', lagDays: 0 },
      { predecessorId: 'B', successorId: 'A', type: 'FS', lagDays: 0 },
    ];
    expect(() =>
      computeCriticalPath(
        [
          { taskId: 'A', durationDays: 1 },
          { taskId: 'B', durationDays: 1 },
        ],
        cyclicDeps,
      ),
    ).toThrow(/Cycle/);
  });

  it('respects positive lag on FS dependencies', () => {
    const laggedDeps: DependencyInput[] = [
      { predecessorId: 'A', successorId: 'B', type: 'FS', lagDays: 5 },
    ];
    const result = computeCriticalPath(
      [
        { taskId: 'A', durationDays: 2 },
        { taskId: 'B', durationDays: 3 },
      ],
      laggedDeps,
    );
    const byId = Object.fromEntries(result.schedule.map((s) => [s.taskId, s]));
    expect(byId.B!.earlyStart).toBe(2 + 5);
  });
});

import { describe, it, expect } from 'vitest';
import { calculateEvm } from '../evm';

/**
 * Reference example verified against the PMI Practice Standard for Earned
 * Value Management worked example style (G24):
 *   BAC = 100,000
 *   Planned % complete = 50%  -> PV = 50,000
 *   Actual % complete  = 40%  -> EV = 40,000
 *   AC = 45,000
 *
 * Expected:
 *   SV  = EV - PV = -10,000        (behind schedule)
 *   CV  = EV - AC = -5,000         (over budget)
 *   SPI = EV / PV = 0.8
 *   CPI = EV / AC = 0.8889 (approx)
 *   EAC = BAC / CPI = 112,500
 *   ETC = EAC - AC = 67,500
 *   VAC = BAC - EAC = -12,500
 */
describe('calculateEvm', () => {
  it('matches the PMI reference worked example', () => {
    const result = calculateEvm({
      bac: 100000,
      plannedPercentComplete: 50,
      actualPercentComplete: 40,
      actualCost: 45000,
    });

    expect(result.pv).toBe(50000);
    expect(result.ev).toBe(40000);
    expect(result.ac).toBe(45000);
    expect(result.sv).toBe(-10000);
    expect(result.cv).toBe(-5000);
    expect(result.spi).toBeCloseTo(0.8, 5);
    expect(result.cpi).toBeCloseTo(0.888889, 5);
    expect(result.eac).toBeCloseTo(112500, 2);
    expect(result.etc).toBeCloseTo(67500, 2);
    expect(result.vac).toBeCloseTo(-12500, 2);
  });

  it('a project exactly on schedule and on budget has SPI=CPI=1 and EAC=BAC', () => {
    const result = calculateEvm({
      bac: 50000,
      plannedPercentComplete: 30,
      actualPercentComplete: 30,
      actualCost: 15000,
    });
    expect(result.spi).toBeCloseTo(1, 5);
    expect(result.cpi).toBeCloseTo(1, 5);
    expect(result.eac).toBeCloseTo(50000, 2);
    expect(result.vac).toBeCloseTo(0, 2);
  });

  it('rejects out-of-range percentages', () => {
    expect(() =>
      calculateEvm({ bac: 100, plannedPercentComplete: 150, actualPercentComplete: 10, actualCost: 5 }),
    ).toThrow();
    expect(() =>
      calculateEvm({ bac: 100, plannedPercentComplete: 10, actualPercentComplete: -1, actualCost: 5 }),
    ).toThrow();
  });

  it('handles zero actual cost with zero earned value as a neutral CPI of 1', () => {
    const result = calculateEvm({ bac: 100, plannedPercentComplete: 0, actualPercentComplete: 0, actualCost: 0 });
    expect(result.cpi).toBe(1);
    expect(result.spi).toBe(1);
  });
});

import { describe, it, expect } from 'vitest';
import { detectOverallocation, suggestLeveling } from '../resource-leveling';
import { ResourceAssignment } from '../types';

describe('detectOverallocation', () => {
  it('flags a resource assigned over 100% on overlapping days', () => {
    const assignments: ResourceAssignment[] = [
      { taskId: 'T1', resourceId: 'ALICE', allocationPct: 60, startDay: 0, endDay: 5 },
      { taskId: 'T2', resourceId: 'ALICE', allocationPct: 60, startDay: 2, endDay: 7 },
    ];
    const windows = detectOverallocation(assignments);
    expect(windows.length).toBeGreaterThan(0);
    expect(windows.every((w) => w.resourceId === 'ALICE')).toBe(true);
    expect(windows.every((w) => w.totalAllocationPct === 120)).toBe(true);
    // Overlap is days 2,3,4 (T1 ends at day 5 exclusive)
    expect(windows.map((w) => w.day).sort((a, b) => a - b)).toEqual([2, 3, 4]);
  });

  it('does not flag non-overlapping or under-100% assignments', () => {
    const assignments: ResourceAssignment[] = [
      { taskId: 'T1', resourceId: 'BOB', allocationPct: 50, startDay: 0, endDay: 5 },
      { taskId: 'T2', resourceId: 'BOB', allocationPct: 50, startDay: 5, endDay: 10 },
    ];
    expect(detectOverallocation(assignments)).toHaveLength(0);
  });
});

describe('suggestLeveling', () => {
  it('suggests delaying the lower-priority task in a conflict window', () => {
    const windows = [
      { resourceId: 'ALICE', day: 2, totalAllocationPct: 120, taskIds: ['T1', 'T2'] },
    ];
    const suggestions = suggestLeveling(windows, ['T1', 'T2']); // T1 is higher priority
    expect(suggestions).toHaveLength(1);
    expect(suggestions[0]!.taskId).toBe('T2');
  });
});

import { TaskInput, DependencyInput, TaskId } from './types';
import { buildSuccessorMap, latestFinishFromDependency, topologicalSort } from './dependencies';

export interface BackwardPassResult {
  lateStart: Map<TaskId, number>;
  lateFinish: Map<TaskId, number>;
}

/**
 * CPM backward pass: computes latest start/finish for every task, walking the
 * dependency graph in reverse topological order, anchored to the overall
 * project duration computed by the forward pass (all leaf/sink tasks may
 * finish no later than the project duration).
 */
export function backwardPass(
  tasks: TaskInput[],
  deps: DependencyInput[],
  projectDuration: number,
): BackwardPassResult {
  const durationById = new Map(tasks.map((t) => [t.taskId, t.durationDays]));
  const taskIds = tasks.map((t) => t.taskId);
  const order = topologicalSort(taskIds, deps).reverse();
  const succMap = buildSuccessorMap(deps);

  const lateStart = new Map<TaskId, number>();
  const lateFinish = new Map<TaskId, number>();

  for (const taskId of order) {
    const duration = durationById.get(taskId);
    if (duration === undefined) throw new Error(`Unknown task in dependency graph: ${taskId}`);

    const successors = succMap.get(taskId) ?? [];
    let finish = projectDuration;

    if (successors.length > 0) {
      finish = Math.min(
        ...successors.map((dep) => {
          const succLateStart = lateStart.get(dep.successorId);
          const succLateFinish = lateFinish.get(dep.successorId);
          if (succLateStart === undefined || succLateFinish === undefined) {
            throw new Error(`Successor ${dep.successorId} not yet scheduled (graph order bug)`);
          }
          return latestFinishFromDependency(dep, succLateStart, succLateFinish, duration);
        }),
      );
    }

    lateFinish.set(taskId, finish);
    lateStart.set(taskId, finish - duration);
  }

  return { lateStart, lateFinish };
}

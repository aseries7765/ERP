import { DependencyInput, TaskId } from './types';

/**
 * Given a dependency, computes the earliest allowed start day for the
 * successor based on the predecessor's computed early start/finish, per the
 * dependency type and lag.
 *
 *   FS (Finish-to-Start): successor starts no earlier than predecessor finish + lag
 *   SS (Start-to-Start):   successor starts no earlier than predecessor start + lag
 *   FF (Finish-to-Finish): successor finishes no earlier than predecessor finish + lag
 *                          (translated to a start constraint via successor duration)
 *   SF (Start-to-Finish):  successor finishes no earlier than predecessor start + lag
 *                          (translated to a start constraint via successor duration)
 */
export function earliestStartFromDependency(
  dep: DependencyInput,
  predecessorEarlyStart: number,
  predecessorEarlyFinish: number,
  successorDurationDays: number,
): number {
  switch (dep.type) {
    case 'FS':
      return predecessorEarlyFinish + dep.lagDays;
    case 'SS':
      return predecessorEarlyStart + dep.lagDays;
    case 'FF':
      return predecessorEarlyFinish + dep.lagDays - successorDurationDays;
    case 'SF':
      return predecessorEarlyStart + dep.lagDays - successorDurationDays;
    default:
      throw new Error(`Unknown dependency type: ${dep.type}`);
  }
}

/** Similarly for the backward pass: latest allowed finish for the predecessor given the successor's late dates. */
export function latestFinishFromDependency(
  dep: DependencyInput,
  successorLateStart: number,
  successorLateFinish: number,
  predecessorDurationDays: number,
): number {
  switch (dep.type) {
    case 'FS':
      return successorLateStart - dep.lagDays;
    case 'SS':
      return successorLateStart - dep.lagDays + predecessorDurationDays;
    case 'FF':
      return successorLateFinish - dep.lagDays;
    case 'SF':
      return successorLateFinish - dep.lagDays + predecessorDurationDays;
    default:
      throw new Error(`Unknown dependency type: ${dep.type}`);
  }
}

export function buildPredecessorMap(
  deps: DependencyInput[],
): Map<TaskId, DependencyInput[]> {
  const map = new Map<TaskId, DependencyInput[]>();
  for (const d of deps) {
    const list = map.get(d.successorId) ?? [];
    list.push(d);
    map.set(d.successorId, list);
  }
  return map;
}

export function buildSuccessorMap(deps: DependencyInput[]): Map<TaskId, DependencyInput[]> {
  const map = new Map<TaskId, DependencyInput[]>();
  for (const d of deps) {
    const list = map.get(d.predecessorId) ?? [];
    list.push(d);
    map.set(d.predecessorId, list);
  }
  return map;
}

/** Topologically sorts tasks by dependency order. Throws on cycles. */
export function topologicalSort(taskIds: TaskId[], deps: DependencyInput[]): TaskId[] {
  const predMap = buildPredecessorMap(deps);
  const inDegree = new Map<TaskId, number>();
  for (const id of taskIds) inDegree.set(id, predMap.get(id)?.length ?? 0);

  const succMap = buildSuccessorMap(deps);
  const queue: TaskId[] = taskIds.filter((id) => inDegree.get(id) === 0);
  const order: TaskId[] = [];

  while (queue.length > 0) {
    const current = queue.shift() as TaskId;
    order.push(current);
    for (const dep of succMap.get(current) ?? []) {
      const remaining = (inDegree.get(dep.successorId) ?? 0) - 1;
      inDegree.set(dep.successorId, remaining);
      if (remaining === 0) queue.push(dep.successorId);
    }
  }

  if (order.length !== taskIds.length) {
    throw new Error('Cycle detected in task dependency graph');
  }
  return order;
}

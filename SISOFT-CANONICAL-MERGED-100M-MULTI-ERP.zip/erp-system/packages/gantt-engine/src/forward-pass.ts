import { TaskInput, DependencyInput, TaskId } from './types';
import { buildPredecessorMap, earliestStartFromDependency, topologicalSort } from './dependencies';

export interface ForwardPassResult {
  earlyStart: Map<TaskId, number>;
  earlyFinish: Map<TaskId, number>;
  projectDuration: number;
}

/**
 * CPM forward pass: computes earliest start/finish for every task, walking
 * the dependency graph in topological order starting all root tasks at day 0.
 */
export function forwardPass(tasks: TaskInput[], deps: DependencyInput[]): ForwardPassResult {
  const durationById = new Map(tasks.map((t) => [t.taskId, t.durationDays]));
  const taskIds = tasks.map((t) => t.taskId);
  const order = topologicalSort(taskIds, deps);
  const predMap = buildPredecessorMap(deps);

  const earlyStart = new Map<TaskId, number>();
  const earlyFinish = new Map<TaskId, number>();

  for (const taskId of order) {
    const duration = durationById.get(taskId);
    if (duration === undefined) throw new Error(`Unknown task in dependency graph: ${taskId}`);

    const predecessors = predMap.get(taskId) ?? [];
    let start = 0;
    for (const dep of predecessors) {
      const predEarlyStart = earlyStart.get(dep.predecessorId);
      const predEarlyFinish = earlyFinish.get(dep.predecessorId);
      if (predEarlyStart === undefined || predEarlyFinish === undefined) {
        throw new Error(`Predecessor ${dep.predecessorId} not yet scheduled (graph order bug)`);
      }
      const candidate = earliestStartFromDependency(dep, predEarlyStart, predEarlyFinish, duration);
      start = Math.max(start, candidate);
    }

    earlyStart.set(taskId, start);
    earlyFinish.set(taskId, start + duration);
  }

  const projectDuration = Math.max(0, ...Array.from(earlyFinish.values()));

  return { earlyStart, earlyFinish, projectDuration };
}

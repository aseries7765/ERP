export type TaskId = string;

export type DependencyType = 'FS' | 'SS' | 'FF' | 'SF';

export interface TaskInput {
  taskId: TaskId;
  /** Duration in whole days (working-day calendars are a documented future item — see GANTT.md). */
  durationDays: number;
}

export interface DependencyInput {
  predecessorId: TaskId;
  successorId: TaskId;
  type: DependencyType;
  /** Lag in days; positive = delay, negative = lead. */
  lagDays: number;
}

export interface TaskSchedule {
  taskId: TaskId;
  earlyStart: number;
  earlyFinish: number;
  lateStart: number;
  lateFinish: number;
  totalFloat: number;
  freeFloat: number;
  isCritical: boolean;
}

export interface CriticalPathResult {
  schedule: TaskSchedule[];
  criticalPath: TaskId[];
  projectDuration: number;
}

export interface BaselineTask {
  taskId: TaskId;
  baselineStart: number;
  baselineFinish: number;
}

export interface ProgressTask {
  taskId: TaskId;
  percentComplete: number;
  actualStart: number | null;
  actualFinish: number | null;
}

export interface ResourceAssignment {
  taskId: TaskId;
  resourceId: string;
  /** Allocation percentage (0-100+) for the duration of the task. */
  allocationPct: number;
  startDay: number;
  endDay: number;
}

export interface EvmInput {
  /** Budget at Completion. */
  bac: number;
  plannedPercentComplete: number;
  actualPercentComplete: number;
  actualCost: number;
}

export interface EvmResult {
  pv: number;
  ev: number;
  ac: number;
  bac: number;
  sv: number;
  cv: number;
  spi: number;
  cpi: number;
  eac: number;
  etc: number;
  vac: number;
}

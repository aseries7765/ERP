import { EvmInput, EvmResult } from './types';

/**
 * Earned Value Management calculations per PMI's Practice Standard for
 * Earned Value Management:
 *
 *   PV  = BAC × plannedPercentComplete
 *   EV  = BAC × actualPercentComplete
 *   AC  = actual cost incurred (given)
 *   SV  = EV - PV
 *   CV  = EV - AC
 *   SPI = EV / PV
 *   CPI = EV / AC
 *   EAC = BAC / CPI   (standard "CPI will continue" forecasting assumption)
 *   ETC = EAC - AC
 *   VAC = BAC - EAC
 *
 * Verified against PMI reference examples in evm.spec.ts (G24).
 */
export function calculateEvm(input: EvmInput): EvmResult {
  const { bac, plannedPercentComplete, actualPercentComplete, actualCost } = input;

  if (bac < 0) throw new Error('BAC must be >= 0');
  if (plannedPercentComplete < 0 || plannedPercentComplete > 100) {
    throw new Error('plannedPercentComplete must be between 0 and 100');
  }
  if (actualPercentComplete < 0 || actualPercentComplete > 100) {
    throw new Error('actualPercentComplete must be between 0 and 100');
  }

  const pv = bac * (plannedPercentComplete / 100);
  const ev = bac * (actualPercentComplete / 100);
  const ac = actualCost;

  const sv = ev - pv;
  const cv = ev - ac;

  // Guard divide-by-zero: if PV or AC is 0, the index is conventionally
  // undefined; we return Infinity/0 sentinel via NaN-safe handling and let
  // the caller decide how to present it (e.g. "N/A" in the UI).
  const spi = pv === 0 ? (ev === 0 ? 1 : Infinity) : ev / pv;
  const cpi = ac === 0 ? (ev === 0 ? 1 : Infinity) : ev / ac;

  const eac = cpi === 0 ? Infinity : bac / cpi;
  const etc = eac - ac;
  const vac = bac - eac;

  return { pv, ev, ac, bac, sv, cv, spi, cpi, eac, etc, vac };
}

export type InvoiceState =
  | 'draft'
  | 'pending_approval'
  | 'approved'
  | 'issued'
  | 'sent'
  | 'partially_paid'
  | 'paid'
  | 'overdue'
  | 'written_off'
  | 'closed'
  | 'cancelled';

export type InvoiceEvent =
  | 'submit_for_approval'
  | 'approve'
  | 'issue'
  | 'send'
  | 'apply_partial_payment'
  | 'apply_full_payment'
  | 'mark_overdue'
  | 'write_off'
  | 'cancel'
  | 'close';

/**
 * Explicit transition table. Any (state, event) pair not listed here is
 * illegal and `transition()` throws rather than silently no-op-ing, so bugs
 * surface immediately instead of leaving an invoice in an inconsistent
 * state.
 *
 * Business rules encoded here (per spec):
 *  - `issue` locks the invoice (immutability is enforced by
 *    InvoiceLockService, not here, but this state machine is what that
 *    service checks against).
 *  - `cancel` is only reachable from states before `issued`. Once issued,
 *    the only way to reverse a charge is a credit note against it — this
 *    state machine intentionally has no issued -> cancelled edge.
 *  - `mark_overdue` is reachable from `issued`, `sent`, or `partially_paid`
 *    (any state where money is still owed and the invoice is live).
 */
const TRANSITIONS: Record<InvoiceState, Partial<Record<InvoiceEvent, InvoiceState>>> = {
  draft: {
    submit_for_approval: 'pending_approval',
    issue: 'issued', // small orgs may skip approval if under threshold
    cancel: 'cancelled',
  },
  pending_approval: {
    approve: 'approved',
    cancel: 'cancelled',
  },
  approved: {
    issue: 'issued',
    cancel: 'cancelled',
  },
  issued: {
    send: 'sent',
    apply_partial_payment: 'partially_paid',
    apply_full_payment: 'paid',
    mark_overdue: 'overdue',
  },
  sent: {
    apply_partial_payment: 'partially_paid',
    apply_full_payment: 'paid',
    mark_overdue: 'overdue',
  },
  partially_paid: {
    apply_partial_payment: 'partially_paid',
    apply_full_payment: 'paid',
    mark_overdue: 'overdue',
    write_off: 'written_off',
  },
  overdue: {
    apply_partial_payment: 'partially_paid',
    apply_full_payment: 'paid',
    write_off: 'written_off',
  },
  paid: {
    close: 'closed',
  },
  written_off: {},
  closed: {},
  cancelled: {},
};

export class IllegalInvoiceTransitionError extends Error {
  constructor(
    public readonly from: InvoiceState,
    public readonly event: InvoiceEvent,
  ) {
    super(`Illegal invoice transition: cannot apply "${event}" from state "${from}"`);
    this.name = 'IllegalInvoiceTransitionError';
  }
}

export class InvoiceLifecycleService {
  /** Pure function: given current state + event, returns the next state. */
  transition(from: InvoiceState, event: InvoiceEvent): InvoiceState {
    const next = TRANSITIONS[from]?.[event];
    if (!next) {
      throw new IllegalInvoiceTransitionError(from, event);
    }
    return next;
  }

  canTransition(from: InvoiceState, event: InvoiceEvent): boolean {
    return TRANSITIONS[from]?.[event] !== undefined;
  }

  /** States in which the invoice must be treated as immutable (see G17). */
  isLocked(state: InvoiceState): boolean {
    return state !== 'draft' && state !== 'pending_approval' && state !== 'approved';
  }
}

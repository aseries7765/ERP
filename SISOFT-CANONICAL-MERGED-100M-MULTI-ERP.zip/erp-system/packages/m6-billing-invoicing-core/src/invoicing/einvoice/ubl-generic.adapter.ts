import { EInvoiceAdapter, EInvoiceBuildResult, EInvoicePayloadInput } from './adapter.interface';

function escapeXml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function minorToDecimal(minorUnits: number): string {
  return (minorUnits / 100).toFixed(2);
}

/**
 * Generic UBL 2.1 Invoice export. This is the fallback adapter that always
 * works — per spec, "UBL generic export for others" — and does not require
 * any country-specific authority submission or signing. It is a plain,
 * well-formed UBL 2.1 document suitable for manual download / manual
 * submission to whatever local system the buyer requires.
 *
 * This is the only adapter marked `production`; every country-specific
 * adapter (ZATCA, PEPPOL, GST, etc.) is out of scope for this slice and
 * must be treated as `not_implemented` until built against real specs and
 * tested against sandbox/validator tooling — see MANIFEST.md.
 */
export class UblGenericAdapter implements EInvoiceAdapter {
  readonly country = 'GENERIC';

  build(input: EInvoicePayloadInput): EInvoiceBuildResult {
    const lines = input.lines
      .map(
        (line, idx) => `
  <cac:InvoiceLine>
    <cbc:ID>${idx + 1}</cbc:ID>
    <cbc:InvoicedQuantity>${line.quantity}</cbc:InvoicedQuantity>
    <cbc:LineExtensionAmount currencyID="${escapeXml(input.currency)}">${minorToDecimal(
          line.lineTotalMinorUnits,
        )}</cbc:LineExtensionAmount>
    <cac:Item>
      <cbc:Description>${escapeXml(line.description)}</cbc:Description>
    </cac:Item>
    <cac:Price>
      <cbc:PriceAmount currencyID="${escapeXml(input.currency)}">${minorToDecimal(
          line.unitPriceMinorUnits,
        )}</cbc:PriceAmount>
    </cac:Price>
    <cac:TaxTotal>
      <cbc:TaxAmount currencyID="${escapeXml(input.currency)}">${minorToDecimal(
          Math.round((line.lineTotalMinorUnits * line.taxRatePercent) / 100),
        )}</cbc:TaxAmount>
    </cac:TaxTotal>
  </cac:InvoiceLine>`,
      )
      .join('');

    const content = `<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
         xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
         xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
  <cbc:CustomizationID>urn:cen.eu:en16931:2017</cbc:CustomizationID>
  <cbc:ID>${escapeXml(input.invoiceNumber)}</cbc:ID>
  <cbc:IssueDate>${input.issueDate.toISOString().slice(0, 10)}</cbc:IssueDate>
  <cbc:DocumentCurrencyCode>${escapeXml(input.currency)}</cbc:DocumentCurrencyCode>
  <cac:AccountingSupplierParty>
    <cac:Party>
      <cbc:EndpointID>${escapeXml(input.supplier.taxId)}</cbc:EndpointID>
      <cac:PartyName><cbc:Name>${escapeXml(input.supplier.name)}</cbc:Name></cac:PartyName>
      <cac:PartyTaxScheme><cbc:CompanyID>${escapeXml(
        input.supplier.taxId,
      )}</cbc:CompanyID></cac:PartyTaxScheme>
      <cac:PostalAddress><cac:Country><cbc:IdentificationCode>${escapeXml(
        input.supplier.country,
      )}</cbc:IdentificationCode></cac:Country></cac:PostalAddress>
    </cac:Party>
  </cac:AccountingSupplierParty>
  <cac:AccountingCustomerParty>
    <cac:Party>
      <cac:PartyName><cbc:Name>${escapeXml(input.customer.name)}</cbc:Name></cac:PartyName>
      <cac:PostalAddress><cac:Country><cbc:IdentificationCode>${escapeXml(
        input.customer.country,
      )}</cbc:IdentificationCode></cac:Country></cac:PostalAddress>
    </cac:Party>
  </cac:AccountingCustomerParty>
  <cac:TaxTotal>
    <cbc:TaxAmount currencyID="${escapeXml(input.currency)}">${minorToDecimal(
      input.totalTaxMinorUnits,
    )}</cbc:TaxAmount>
  </cac:TaxTotal>
  <cac:LegalMonetaryTotal>
    <cbc:LineExtensionAmount currencyID="${escapeXml(input.currency)}">${minorToDecimal(
      input.totalExTaxMinorUnits,
    )}</cbc:LineExtensionAmount>
    <cbc:TaxExclusiveAmount currencyID="${escapeXml(input.currency)}">${minorToDecimal(
      input.totalExTaxMinorUnits,
    )}</cbc:TaxExclusiveAmount>
    <cbc:TaxInclusiveAmount currencyID="${escapeXml(input.currency)}">${minorToDecimal(
      input.totalIncTaxMinorUnits,
    )}</cbc:TaxInclusiveAmount>
    <cbc:PayableAmount currencyID="${escapeXml(input.currency)}">${minorToDecimal(
      input.totalIncTaxMinorUnits,
    )}</cbc:PayableAmount>
  </cac:LegalMonetaryTotal>${lines}
</Invoice>`;

    return { format: 'UBL-2.1', content, readiness: 'production' };
  }
}

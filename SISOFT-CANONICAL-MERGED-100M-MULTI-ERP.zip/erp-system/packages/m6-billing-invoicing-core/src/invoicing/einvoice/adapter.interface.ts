export interface EInvoiceLine {
  description: string;
  quantity: number;
  unitPriceMinorUnits: number;
  taxRatePercent: number;
  lineTotalMinorUnits: number; // quantity * unitPrice, pre-tax
}

export interface EInvoicePayloadInput {
  invoiceNumber: string;
  issueDate: Date;
  currency: string;
  supplier: { name: string; taxId: string; country: string };
  customer: { name: string; taxId?: string; country: string };
  lines: EInvoiceLine[];
  totalExTaxMinorUnits: number;
  totalTaxMinorUnits: number;
  totalIncTaxMinorUnits: number;
}

export interface EInvoiceBuildResult {
  format: string; // e.g. "UBL-2.1", "ZATCA-XML", "GST-JSON"
  content: string; // serialized payload (XML/JSON string)
  readiness: 'production' | 'sandbox' | 'not_implemented';
}

export interface EInvoiceAdapter {
  readonly country: string;
  build(input: EInvoicePayloadInput): EInvoiceBuildResult;
}

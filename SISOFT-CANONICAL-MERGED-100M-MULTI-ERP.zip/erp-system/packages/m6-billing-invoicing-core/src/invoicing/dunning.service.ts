export type DunningAction = 'reminder' | 'late_fee' | 'suspend';

export interface DunningRule {
  daysOverdue: number;
  action: DunningAction;
  template: string;
  lateFeeMinorUnits?: number; // required when action === 'late_fee'
}

export interface DunningRuleSet {
  companyId: string;
  rules: DunningRule[]; // arbitrary order as configured
}

export interface DunningDecision {
  rule: DunningRule;
}

/**
 * Selects which configured dunning rule applies for a given number of days
 * overdue. Policy: the rule with the HIGHEST `daysOverdue` threshold that
 * is still <= actual days overdue wins — i.e. as an invoice ages past
 * multiple thresholds, only the most severe applicable action fires that
 * day, on the assumption the daily cron already fired the earlier rules on
 * their own days. `pickAll` is also exposed for a "catch-up" run that needs
 * every rule the invoice has become eligible for.
 */
export class DunningService {
  pickRule(daysOverdue: number, rules: DunningRule[]): DunningDecision | null {
    const eligible = rules
      .filter((r) => r.daysOverdue <= daysOverdue)
      .sort((a, b) => b.daysOverdue - a.daysOverdue);
    return eligible.length > 0 ? { rule: eligible[0] } : null;
  }

  pickExactRule(daysOverdue: number, rules: DunningRule[]): DunningDecision | null {
    const match = rules.find((r) => r.daysOverdue === daysOverdue);
    return match ? { rule: match } : null;
  }

  validateRule(rule: DunningRule): string[] {
    const errors: string[] = [];
    if (rule.daysOverdue < 0) errors.push('daysOverdue must be >= 0');
    if (rule.action === 'late_fee' && !(rule.lateFeeMinorUnits! > 0)) {
      errors.push('lateFeeMinorUnits must be > 0 for action "late_fee"');
    }
    if (!rule.template) errors.push('template is required');
    return errors;
  }
}

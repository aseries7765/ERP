/**
 * Storage abstraction for invoice/credit-note/debit-note sequence counters.
 *
 * In production this MUST be backed by a DB sequence or a row locked with
 * `SELECT ... FOR UPDATE` inside the same transaction that persists the
 * document, so that the increment and the document write commit atomically.
 * This file only defines the contract; `InMemoryNumberingStore` below is a
 * test double, NOT a production implementation (see MANIFEST.md).
 */
export interface NumberingKey {
  companyId: string;
  fiscalYear: number;
  documentType: 'invoice' | 'credit_note' | 'debit_note';
}

export interface NumberingStore {
  /**
   * Atomically increments and returns the next sequence value for `key`.
   * Must serialize concurrent callers for the same key (no two callers may
   * ever observe the same returned value for the same key).
   */
  nextValue(key: NumberingKey): Promise<number>;
}

function keyOf(key: NumberingKey): string {
  return `${key.companyId}::${key.fiscalYear}::${key.documentType}`;
}

/**
 * In-memory reference implementation used for unit tests. Serializes access
 * per key with a promise-chain mutex so concurrent async callers still get
 * gapless, strictly increasing values. This demonstrates the *algorithm*
 * only — a real deployment needs the DB-level guarantee described above,
 * because multiple API process instances share nothing in-memory.
 */
export class InMemoryNumberingStore implements NumberingStore {
  private counters = new Map<string, number>();
  private locks = new Map<string, Promise<unknown>>();

  async nextValue(key: NumberingKey): Promise<number> {
    const k = keyOf(key);
    const prior = this.locks.get(k) ?? Promise.resolve();
    let release!: () => void;
    const mine = new Promise((res) => (release = res as () => void));
    this.locks.set(
      k,
      prior.then(() => mine),
    );
    await prior;
    try {
      const current = this.counters.get(k) ?? 0;
      const next = current + 1;
      this.counters.set(k, next);
      return next;
    } finally {
      release();
    }
  }
}

import { NumberingKey, NumberingStore } from './numbering-store.interface';

export interface NumberingPattern {
  /** e.g. "INV-{YYYY}-{NNNNNN}" */
  pattern: string;
}

export interface AllocatedNumber {
  value: number;
  formatted: string;
  key: NumberingKey;
}

/**
 * Generates gapless, per-(company, fiscalYear, documentType) document
 * numbers. Concurrency safety is delegated entirely to the injected
 * `NumberingStore` (see numbering-store.interface.ts for what a production
 * store must guarantee).
 *
 * Gap policy: once `nextValue` returns a number, that number is considered
 * consumed permanently — even if the caller's surrounding transaction later
 * fails, the number is NOT reused. Per the spec this is intentional: the
 * caller must instead record a "number voided" audit event and the invoice
 * that would have used it is simply never created. This class only exposes
 * `allocate`; recording the void-audit-event on rollback is the caller's
 * (InvoiceLifecycleService's) responsibility, since only it knows about the
 * transaction outcome.
 */
export class InvoiceNumberingService {
  constructor(private readonly store: NumberingStore) {}

  async allocate(
    key: NumberingKey,
    pattern: NumberingPattern,
  ): Promise<AllocatedNumber> {
    const value = await this.store.nextValue(key);
    return {
      value,
      formatted: this.format(pattern.pattern, key, value),
      key,
    };
  }

  private format(pattern: string, key: NumberingKey, value: number): string {
    const padded = (n: number, width: number) =>
      String(n).padStart(width, '0');

    // Support any run of N's as a zero-padded width, e.g. {NNNNNN} -> 6.
    return pattern
      .replace('{YYYY}', String(key.fiscalYear))
      .replace(/\{(N+)\}/, (_match, ns: string) => padded(value, ns.length));
  }
}

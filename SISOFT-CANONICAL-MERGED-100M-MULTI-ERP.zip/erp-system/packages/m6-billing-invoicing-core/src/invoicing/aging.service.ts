export interface OpenInvoiceForAging {
  invoiceId: string;
  customerId: string;
  currency: string;
  balanceMinorUnits: number; // amount still owed
  dueDate: Date;
}

export type AgingBucketName = 'current' | '1-30' | '31-60' | '61-90' | '90+';

export interface AgingBucketTotals {
  current: number;
  '1-30': number;
  '31-60': number;
  '61-90': number;
  '90+': number;
}

export interface AgingRow {
  customerId: string;
  currency: string;
  buckets: AgingBucketTotals;
  totalMinorUnits: number;
}

const MS_PER_DAY = 24 * 60 * 60 * 1000;

function emptyBuckets(): AgingBucketTotals {
  return { current: 0, '1-30': 0, '31-60': 0, '61-90': 0, '90+': 0 };
}

/**
 * Buckets open invoice balances by days-past-due, grouped by
 * (customer, currency) — mixing currencies in one total would be
 * meaningless, so each currency gets its own row per customer, matching
 * the spec's "group by customer, sales rep, currency" (sales-rep grouping
 * is a caller-side concern once invoices carry an ownerId; this service
 * focuses on the bucket math itself).
 */
export class AgingService {
  bucketFor(dueDate: Date, asOf: Date): AgingBucketName {
    const daysPastDue = Math.floor((asOf.getTime() - dueDate.getTime()) / MS_PER_DAY);
    if (daysPastDue <= 0) return 'current';
    if (daysPastDue <= 30) return '1-30';
    if (daysPastDue <= 60) return '31-60';
    if (daysPastDue <= 90) return '61-90';
    return '90+';
  }

  buildReport(invoices: OpenInvoiceForAging[], asOf: Date): AgingRow[] {
    const rows = new Map<string, AgingRow>();

    for (const inv of invoices) {
      const key = `${inv.customerId}::${inv.currency}`;
      let row = rows.get(key);
      if (!row) {
        row = {
          customerId: inv.customerId,
          currency: inv.currency,
          buckets: emptyBuckets(),
          totalMinorUnits: 0,
        };
        rows.set(key, row);
      }
      const bucket = this.bucketFor(inv.dueDate, asOf);
      row.buckets[bucket] += inv.balanceMinorUnits;
      row.totalMinorUnits += inv.balanceMinorUnits;
    }

    return Array.from(rows.values()).sort((a, b) =>
      a.customerId === b.customerId
        ? a.currency.localeCompare(b.currency)
        : a.customerId.localeCompare(b.customerId),
    );
  }
}

/**
 * Day-based proration for mid-cycle subscription plan/quantity changes.
 * Uses a simple daily-rate model: unused days on the old plan are credited,
 * remaining days on the new plan are charged, both computed against the
 * same billing period so day-counting cannot drift between the two legs.
 *
 * Amounts are handled in integer minor units (cents) throughout to avoid
 * floating point drift; callers are responsible for converting from/to
 * decimal currency at the boundary.
 */
export interface BillingPeriod {
  start: Date;
  end: Date; // exclusive
}

export interface ProrationInput {
  period: BillingPeriod;
  changeDate: Date;
  oldAmountMinorUnits: number;
  newAmountMinorUnits: number;
}

export interface ProrationResult {
  totalPeriodDays: number;
  daysUsedOnOldPlan: number;
  daysRemainingOnNewPlan: number;
  creditMinorUnits: number; // unused portion of old plan, as a positive credit
  chargeMinorUnits: number; // remaining portion of new plan
  netMinorUnits: number; // chargeMinorUnits - creditMinorUnits (can be negative)
}

const MS_PER_DAY = 24 * 60 * 60 * 1000;

export class ProrationService {
  compute(input: ProrationInput): ProrationResult {
    const { period, changeDate, oldAmountMinorUnits, newAmountMinorUnits } = input;

    if (period.end <= period.start) {
      throw new Error('Billing period end must be after start');
    }
    if (changeDate < period.start || changeDate > period.end) {
      throw new Error('changeDate must fall within the billing period');
    }

    const totalPeriodDays = this.diffDays(period.start, period.end);
    const daysUsedOnOldPlan = this.diffDays(period.start, changeDate);
    const daysRemainingOnNewPlan = totalPeriodDays - daysUsedOnOldPlan;

    const dailyOld = oldAmountMinorUnits / totalPeriodDays;
    const dailyNew = newAmountMinorUnits / totalPeriodDays;

    // Round each leg independently, then derive net — matches how most
    // billing systems show "credit" and "charge" as separate invoice lines.
    const creditMinorUnits = Math.round(dailyOld * daysRemainingOnNewPlan);
    const chargeMinorUnits = Math.round(dailyNew * daysRemainingOnNewPlan);

    return {
      totalPeriodDays,
      daysUsedOnOldPlan,
      daysRemainingOnNewPlan,
      creditMinorUnits,
      chargeMinorUnits,
      netMinorUnits: chargeMinorUnits - creditMinorUnits,
    };
  }

  private diffDays(a: Date, b: Date): number {
    return Math.round((b.getTime() - a.getTime()) / MS_PER_DAY);
  }
}

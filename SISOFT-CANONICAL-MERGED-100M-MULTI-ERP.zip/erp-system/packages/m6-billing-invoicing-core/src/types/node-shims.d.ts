// This project intentionally has zero external dependencies (see MANIFEST.md
// for why: no network access in this environment, so no @types/node could be
// installed). These are minimal, hand-written ambient declarations for the
// handful of Node.js built-ins actually used (node:crypto's createHmac /
// timingSafeEqual / randomUUID, and Buffer). In a real monorepo this file
// would be deleted and @types/node used instead.

declare module 'node:crypto' {
  export function createHmac(algorithm: string, key: string): {
    update(data: string): { digest(encoding: 'hex'): string };
  };
  export function timingSafeEqual(a: Uint8Array, b: Uint8Array): boolean;
  export function randomUUID(): string;
}

declare class Buffer extends Uint8Array {
  static from(input: string, encoding?: string): Buffer;
  readonly length: number;
}

declare module 'node:test' {
  type TestFn = () => void | Promise<void>;
  function test(name: string, fn: TestFn): void;
  function test(name: string, options: unknown, fn: TestFn): void;
  export default test;
}

declare module 'node:assert/strict' {
  interface Assert {
    equal(actual: unknown, expected: unknown, message?: string): void;
    notEqual(actual: unknown, expected: unknown, message?: string): void;
    deepEqual(actual: unknown, expected: unknown, message?: string): void;
    throws(fn: () => unknown, expected?: unknown, message?: string): void;
    match(actual: string, expected: RegExp, message?: string): void;
    doesNotMatch(actual: string, expected: RegExp, message?: string): void;
  }
  const assert: Assert;
  export default assert;
}


import { createHmac, timingSafeEqual, randomUUID } from 'node:crypto';
import { ChargeRequest, ChargeResult, PaymentGateway, RefundResult } from './gateway.interface';

/**
 * "Gateway" for manually recorded payments (cash, cheque, bank transfer
 * confirmed by staff). There is no external API to call — `createCharge`
 * just records the manual payment as immediately succeeded, since the
 * money has already physically arrived by the time someone enters it.
 *
 * Included here because it requires no external dependency and no network
 * access, so it is the one gateway in this slice that is genuinely
 * `production`-ready rather than a documented stub. Its webhook verifier
 * is still implemented for symmetry (e.g. a bank-file-import pipeline that
 * posts back into this same API via a signed webhook) and is unit tested
 * for both accept and tamper-reject paths, since HMAC webhook verification
 * (G18) is a hard requirement regardless of gateway.
 */
export class ManualGateway implements PaymentGateway {
  readonly name = 'manual';
  readonly readiness = 'production' as const;

  async createCharge(req: ChargeRequest): Promise<ChargeResult> {
    return {
      gatewayRef: `manual_${randomUUID()}`,
      status: 'succeeded',
      raw: { invoiceId: req.invoiceId, recordedManually: true },
    };
  }

  async refund(chargeGatewayRef: string, _amountMinorUnits: number): Promise<RefundResult> {
    return {
      gatewayRefundRef: `manual_refund_${randomUUID()}`,
      status: 'succeeded',
      raw: { originalRef: chargeGatewayRef },
    };
  }

  verifyWebhook(rawBody: string, signatureHeader: string, secret: string): boolean {
    const expected = createHmac('sha256', secret).update(rawBody).digest('hex');
    const expectedBuf = Buffer.from(expected, 'utf8');
    const givenBuf = Buffer.from(signatureHeader, 'utf8');
    if (expectedBuf.length !== givenBuf.length) return false;
    return timingSafeEqual(expectedBuf, givenBuf);
  }
}

export interface OpenInvoiceForMatch {
  invoiceId: string;
  currency: string;
  balanceMinorUnits: number;
  reference?: string; // e.g. invoice number, PO number
  issuedAt: Date;
}

export interface IncomingPayment {
  paymentId: string;
  currency: string;
  amountMinorUnits: number;
  reference?: string;
  receivedAt: Date;
}

export interface MatchTolerance {
  amountToleranceMinorUnits: number; // absolute
  dateWindowDays: number; // payment must land within N days of invoice issue for a fuzzy match
}

export type MatchOutcome =
  | { status: 'matched_exact'; invoice: OpenInvoiceForMatch }
  | { status: 'matched_reference'; invoice: OpenInvoiceForMatch }
  | { status: 'matched_fuzzy'; invoice: OpenInvoiceForMatch }
  | { status: 'unmatched' };

const MS_PER_DAY = 24 * 60 * 60 * 1000;

/**
 * Auto-matches an incoming payment to exactly one open invoice, trying
 * progressively looser strategies and stopping at the first hit:
 *   1. exact reference + exact amount + same currency
 *   2. exact reference match alone (amount mismatch logged, still linked —
 *      caller decides full vs partial application)
 *   3. fuzzy: same currency, amount within tolerance, received within the
 *      configured date window of the invoice being issued
 * If more than one invoice qualifies at a given strategy, the match is
 * refused (`unmatched`) rather than guessing — ambiguous matches must go to
 * a human, per spec ("Auto-match thresholds configurable").
 */
export class ReconciliationService {
  match(
    payment: IncomingPayment,
    candidates: OpenInvoiceForMatch[],
    tolerance: MatchTolerance,
  ): MatchOutcome {
    const sameCurrency = candidates.filter((c) => c.currency === payment.currency);

    if (payment.reference) {
      const byRef = sameCurrency.filter((c) => c.reference === payment.reference);
      if (byRef.length === 1) {
        const exact = byRef[0].balanceMinorUnits === payment.amountMinorUnits;
        return {
          status: exact ? 'matched_exact' : 'matched_reference',
          invoice: byRef[0],
        };
      }
      if (byRef.length > 1) {
        return { status: 'unmatched' };
      }
    }

    const fuzzy = sameCurrency.filter((c) => {
      const amountOk =
        Math.abs(c.balanceMinorUnits - payment.amountMinorUnits) <=
        tolerance.amountToleranceMinorUnits;
      const daysApart = Math.abs(
        (payment.receivedAt.getTime() - c.issuedAt.getTime()) / MS_PER_DAY,
      );
      return amountOk && daysApart <= tolerance.dateWindowDays;
    });

    if (fuzzy.length === 1) {
      return { status: 'matched_fuzzy', invoice: fuzzy[0] };
    }
    return { status: 'unmatched' };
  }
}

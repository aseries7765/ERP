export interface ChargeRequest {
  invoiceId: string;
  amountMinorUnits: number;
  currency: string;
  methodRef: string; // e.g. saved card token, bank account id
}

export interface ChargeResult {
  gatewayRef: string;
  status: 'succeeded' | 'pending' | 'failed';
  raw?: unknown;
}

export interface RefundResult {
  gatewayRefundRef: string;
  status: 'succeeded' | 'pending' | 'failed';
  raw?: unknown;
}

export interface PaymentGateway {
  readonly name: string;
  readonly readiness: 'production' | 'sandbox' | 'not_implemented';
  createCharge(req: ChargeRequest): Promise<ChargeResult>;
  refund(chargeGatewayRef: string, amountMinorUnits: number): Promise<RefundResult>;
  /** Verifies an inbound webhook's HMAC signature. Must be constant-time. */
  verifyWebhook(rawBody: string, signatureHeader: string, secret: string): boolean;
}

import test from 'node:test';
import assert from 'node:assert/strict';
import { DunningService, DunningRule } from '../src/invoicing/dunning.service';

const RULES: DunningRule[] = [
  { daysOverdue: 1, action: 'reminder', template: 'friendly' },
  { daysOverdue: 7, action: 'reminder', template: 'firm' },
  { daysOverdue: 14, action: 'late_fee', template: 'late-fee', lateFeeMinorUnits: 2500 },
  { daysOverdue: 30, action: 'suspend', template: 'suspension' },
];

test('pickRule returns the most severe applicable rule (daily cron scenario)', () => {
  const svc = new DunningService();
  assert.equal(svc.pickRule(0, RULES), null);
  assert.equal(svc.pickRule(1, RULES)!.rule.action, 'reminder');
  assert.equal(svc.pickRule(5, RULES)!.rule.template, 'friendly'); // still day-1 rule
  assert.equal(svc.pickRule(7, RULES)!.rule.template, 'firm');
  assert.equal(svc.pickRule(20, RULES)!.rule.action, 'late_fee'); // most recent threshold crossed
  assert.equal(svc.pickRule(45, RULES)!.rule.action, 'suspend');
});

test('pickExactRule only matches the exact configured day (for a strict daily cron)', () => {
  const svc = new DunningService();
  assert.equal(svc.pickExactRule(14, RULES)!.rule.action, 'late_fee');
  assert.equal(svc.pickExactRule(15, RULES), null);
});

test('validateRule catches missing late fee amount and negative threshold', () => {
  const svc = new DunningService();
  assert.deepEqual(
    svc.validateRule({ daysOverdue: -1, action: 'late_fee', template: 't' }),
    ['daysOverdue must be >= 0', 'lateFeeMinorUnits must be > 0 for action "late_fee"'],
  );
  assert.deepEqual(svc.validateRule({ daysOverdue: 1, action: 'reminder', template: 't' }), []);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { AgingService } from '../src/invoicing/aging.service';

test('bucketFor classifies days past due correctly at boundaries', () => {
  const svc = new AgingService();
  const asOf = new Date('2026-06-30');
  assert.equal(svc.bucketFor(new Date('2026-06-30'), asOf), 'current'); // due today
  assert.equal(svc.bucketFor(new Date('2026-07-01'), asOf), 'current'); // not yet due
  assert.equal(svc.bucketFor(new Date('2026-06-29'), asOf), '1-30'); // 1 day past due
  assert.equal(svc.bucketFor(new Date('2026-05-31'), asOf), '1-30'); // 30 days past due
  assert.equal(svc.bucketFor(new Date('2026-05-30'), asOf), '31-60'); // 31 days
  assert.equal(svc.bucketFor(new Date('2026-05-01'), asOf), '31-60'); // 60 days
  assert.equal(svc.bucketFor(new Date('2026-04-30'), asOf), '61-90'); // 61 days
  assert.equal(svc.bucketFor(new Date('2026-04-01'), asOf), '61-90'); // 90 days
  assert.equal(svc.bucketFor(new Date('2026-03-31'), asOf), '90+'); // 91 days
});

test('buildReport groups by customer + currency and sums buckets', () => {
  const svc = new AgingService();
  const asOf = new Date('2026-06-30');
  const report = svc.buildReport(
    [
      { invoiceId: 'i1', customerId: 'cust-a', currency: 'USD', balanceMinorUnits: 1000, dueDate: new Date('2026-06-30') },
      { invoiceId: 'i2', customerId: 'cust-a', currency: 'USD', balanceMinorUnits: 500, dueDate: new Date('2026-06-01') },
      { invoiceId: 'i3', customerId: 'cust-a', currency: 'EUR', balanceMinorUnits: 200, dueDate: new Date('2026-06-01') },
      { invoiceId: 'i4', customerId: 'cust-b', currency: 'USD', balanceMinorUnits: 999, dueDate: new Date('2026-01-01') },
    ],
    asOf,
  );

  assert.equal(report.length, 3);
  const custAUsd = report.find((r) => r.customerId === 'cust-a' && r.currency === 'USD')!;
  assert.equal(custAUsd.buckets.current, 1000);
  assert.equal(custAUsd.buckets['1-30'], 500);
  assert.equal(custAUsd.totalMinorUnits, 1500);

  const custB = report.find((r) => r.customerId === 'cust-b')!;
  assert.equal(custB.buckets['90+'], 999);
});

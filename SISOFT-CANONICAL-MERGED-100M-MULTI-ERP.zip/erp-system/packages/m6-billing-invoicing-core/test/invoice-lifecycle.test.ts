import test from 'node:test';
import assert from 'node:assert/strict';
import {
  InvoiceLifecycleService,
  IllegalInvoiceTransitionError,
} from '../src/invoicing/invoice-lifecycle.service';

test('happy path: draft -> pending_approval -> approved -> issued -> sent -> paid -> closed', () => {
  const svc = new InvoiceLifecycleService();
  let s = svc.transition('draft', 'submit_for_approval');
  s = svc.transition(s, 'approve');
  s = svc.transition(s, 'issue');
  s = svc.transition(s, 'send');
  s = svc.transition(s, 'apply_full_payment');
  s = svc.transition(s, 'close');
  assert.equal(s, 'closed');
});

test('draft can skip approval and go straight to issued', () => {
  const svc = new InvoiceLifecycleService();
  assert.equal(svc.transition('draft', 'issue'), 'issued');
});

test('cannot cancel an issued invoice (must use credit note instead)', () => {
  const svc = new InvoiceLifecycleService();
  assert.throws(
    () => svc.transition('issued', 'cancel'),
    IllegalInvoiceTransitionError,
  );
});

test('partial payment then full payment reaches paid', () => {
  const svc = new InvoiceLifecycleService();
  let s = svc.transition('issued', 'apply_partial_payment');
  assert.equal(s, 'partially_paid');
  s = svc.transition(s, 'apply_full_payment');
  assert.equal(s, 'paid');
});

test('overdue invoice can still be paid or written off', () => {
  const svc = new InvoiceLifecycleService();
  const overdue = svc.transition('sent', 'mark_overdue');
  assert.equal(svc.transition(overdue, 'apply_full_payment'), 'paid');
  assert.equal(svc.transition(overdue, 'write_off'), 'written_off');
});

test('canTransition reports illegal moves without throwing', () => {
  const svc = new InvoiceLifecycleService();
  assert.equal(svc.canTransition('closed', 'issue'), false);
  assert.equal(svc.canTransition('draft', 'issue'), true);
});

test('isLocked: only draft/pending_approval/approved are editable', () => {
  const svc = new InvoiceLifecycleService();
  assert.equal(svc.isLocked('draft'), false);
  assert.equal(svc.isLocked('pending_approval'), false);
  assert.equal(svc.isLocked('approved'), false);
  assert.equal(svc.isLocked('issued'), true);
  assert.equal(svc.isLocked('paid'), true);
  assert.equal(svc.isLocked('overdue'), true);
});

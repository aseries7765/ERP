import test from 'node:test';
import assert from 'node:assert/strict';
import { ReconciliationService } from '../src/payments/reconciliation.service';

const TOLERANCE = { amountToleranceMinorUnits: 100, dateWindowDays: 5 };

test('exact reference + exact amount => matched_exact', () => {
  const svc = new ReconciliationService();
  const invoices = [
    { invoiceId: 'inv-1', currency: 'USD', balanceMinorUnits: 5000, reference: 'INV-2026-000001', issuedAt: new Date('2026-01-01') },
  ];
  const payment = { paymentId: 'p1', currency: 'USD', amountMinorUnits: 5000, reference: 'INV-2026-000001', receivedAt: new Date('2026-01-10') };
  const result = svc.match(payment, invoices, TOLERANCE);
  assert.equal(result.status, 'matched_exact');
});

test('reference matches but amount differs => matched_reference (partial payment case)', () => {
  const svc = new ReconciliationService();
  const invoices = [
    { invoiceId: 'inv-1', currency: 'USD', balanceMinorUnits: 5000, reference: 'INV-1', issuedAt: new Date('2026-01-01') },
  ];
  const payment = { paymentId: 'p1', currency: 'USD', amountMinorUnits: 2000, reference: 'INV-1', receivedAt: new Date('2026-01-10') };
  const result = svc.match(payment, invoices, TOLERANCE);
  assert.equal(result.status, 'matched_reference');
});

test('no reference: fuzzy match by amount tolerance + date window', () => {
  const svc = new ReconciliationService();
  const invoices = [
    { invoiceId: 'inv-1', currency: 'USD', balanceMinorUnits: 5000, issuedAt: new Date('2026-01-01') },
  ];
  const payment = { paymentId: 'p1', currency: 'USD', amountMinorUnits: 5050, receivedAt: new Date('2026-01-03') };
  const result = svc.match(payment, invoices, TOLERANCE);
  assert.equal(result.status, 'matched_fuzzy');
});

test('ambiguous fuzzy match across multiple invoices => unmatched, requires human review', () => {
  const svc = new ReconciliationService();
  const invoices = [
    { invoiceId: 'inv-1', currency: 'USD', balanceMinorUnits: 5000, issuedAt: new Date('2026-01-01') },
    { invoiceId: 'inv-2', currency: 'USD', balanceMinorUnits: 5010, issuedAt: new Date('2026-01-02') },
  ];
  const payment = { paymentId: 'p1', currency: 'USD', amountMinorUnits: 5005, receivedAt: new Date('2026-01-03') };
  const result = svc.match(payment, invoices, TOLERANCE);
  assert.equal(result.status, 'unmatched');
});

test('different currency never matches even with identical amount', () => {
  const svc = new ReconciliationService();
  const invoices = [
    { invoiceId: 'inv-1', currency: 'EUR', balanceMinorUnits: 5000, issuedAt: new Date('2026-01-01') },
  ];
  const payment = { paymentId: 'p1', currency: 'USD', amountMinorUnits: 5000, receivedAt: new Date('2026-01-02') };
  const result = svc.match(payment, invoices, TOLERANCE);
  assert.equal(result.status, 'unmatched');
});

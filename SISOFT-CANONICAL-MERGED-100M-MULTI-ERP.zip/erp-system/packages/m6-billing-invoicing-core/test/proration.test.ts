import test from 'node:test';
import assert from 'node:assert/strict';
import { ProrationService } from '../src/billing/proration.service';

test('no-op change at period start: full credit and full new-plan charge', () => {
  const svc = new ProrationService();
  const period = { start: new Date('2026-01-01'), end: new Date('2026-02-01') }; // 31 days
  const r = svc.compute({
    period,
    changeDate: period.start,
    oldAmountMinorUnits: 3100, // $31.00
    newAmountMinorUnits: 6200, // $62.00
  });
  assert.equal(r.totalPeriodDays, 31);
  assert.equal(r.daysUsedOnOldPlan, 0);
  assert.equal(r.daysRemainingOnNewPlan, 31);
  assert.equal(r.creditMinorUnits, 3100);
  assert.equal(r.chargeMinorUnits, 6200);
  assert.equal(r.netMinorUnits, 3100);
});

test('change exactly at period end: zero credit, zero charge', () => {
  const svc = new ProrationService();
  const period = { start: new Date('2026-01-01'), end: new Date('2026-02-01') };
  const r = svc.compute({
    period,
    changeDate: period.end,
    oldAmountMinorUnits: 3100,
    newAmountMinorUnits: 6200,
  });
  assert.equal(r.daysRemainingOnNewPlan, 0);
  assert.equal(r.creditMinorUnits, 0);
  assert.equal(r.chargeMinorUnits, 0);
});

test('mid-cycle upgrade: 10 days used of 30, upgrade for remaining 20', () => {
  const svc = new ProrationService();
  const period = { start: new Date('2026-03-01'), end: new Date('2026-03-31') }; // 30 days
  const r = svc.compute({
    period,
    changeDate: new Date('2026-03-11'), // 10 days used
    oldAmountMinorUnits: 3000, // $1/day
    newAmountMinorUnits: 6000, // $2/day
  });
  assert.equal(r.totalPeriodDays, 30);
  assert.equal(r.daysUsedOnOldPlan, 10);
  assert.equal(r.daysRemainingOnNewPlan, 20);
  assert.equal(r.creditMinorUnits, 2000); // 20 unused days * $1
  assert.equal(r.chargeMinorUnits, 4000); // 20 days * $2
  assert.equal(r.netMinorUnits, 2000); // customer owes $20 more
});

test('rejects changeDate outside the billing period', () => {
  const svc = new ProrationService();
  const period = { start: new Date('2026-01-01'), end: new Date('2026-02-01') };
  assert.throws(() =>
    svc.compute({
      period,
      changeDate: new Date('2026-02-15'),
      oldAmountMinorUnits: 100,
      newAmountMinorUnits: 200,
    }),
  );
});

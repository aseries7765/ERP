import test from 'node:test';
import assert from 'node:assert/strict';
import { InvoiceNumberingService } from '../src/invoicing/invoice-numbering.service';
import { InMemoryNumberingStore } from '../src/invoicing/numbering-store.interface';

test('formats pattern with year and zero-padded width', async () => {
  const svc = new InvoiceNumberingService(new InMemoryNumberingStore());
  const key = { companyId: 'c1', fiscalYear: 2026, documentType: 'invoice' as const };
  const a1 = await svc.allocate(key, { pattern: 'INV-{YYYY}-{NNNNNN}' });
  assert.equal(a1.formatted, 'INV-2026-000001');
  const a2 = await svc.allocate(key, { pattern: 'INV-{YYYY}-{NNNNNN}' });
  assert.equal(a2.formatted, 'INV-2026-000002');
});

test('sequences are independent per (company, fiscalYear, documentType)', async () => {
  const svc = new InvoiceNumberingService(new InMemoryNumberingStore());
  const invKey = { companyId: 'c1', fiscalYear: 2026, documentType: 'invoice' as const };
  const cnKey = { companyId: 'c1', fiscalYear: 2026, documentType: 'credit_note' as const };
  const otherCompany = { companyId: 'c2', fiscalYear: 2026, documentType: 'invoice' as const };
  const otherYear = { companyId: 'c1', fiscalYear: 2027, documentType: 'invoice' as const };

  const inv1 = await svc.allocate(invKey, { pattern: 'INV-{YYYY}-{NNNNNN}' });
  const cn1 = await svc.allocate(cnKey, { pattern: 'CN-{YYYY}-{NNNNNN}' });
  const c2inv1 = await svc.allocate(otherCompany, { pattern: 'INV-{YYYY}-{NNNNNN}' });
  const y2027inv1 = await svc.allocate(otherYear, { pattern: 'INV-{YYYY}-{NNNNNN}' });

  assert.equal(inv1.value, 1);
  assert.equal(cn1.value, 1); // separate sequence, not affected by invoice sequence
  assert.equal(c2inv1.value, 1); // separate company
  assert.equal(y2027inv1.value, 1); // separate fiscal year
});

test('1000 concurrent allocations for the same key yield 1000 unique, sequential, gapless values', async () => {
  const svc = new InvoiceNumberingService(new InMemoryNumberingStore());
  const key = { companyId: 'c1', fiscalYear: 2026, documentType: 'invoice' as const };

  const results = await Promise.all(
    Array.from({ length: 1000 }, () =>
      svc.allocate(key, { pattern: 'INV-{YYYY}-{NNNNNN}' }),
    ),
  );

  const values = results.map((r) => r.value).sort((a, b) => a - b);
  const unique = new Set(values);
  assert.equal(unique.size, 1000, 'all 1000 values must be unique');
  assert.equal(values[0], 1);
  assert.equal(values[999], 1000);
  for (let i = 0; i < 1000; i++) {
    assert.equal(values[i], i + 1, `no gap at index ${i}`);
  }
});

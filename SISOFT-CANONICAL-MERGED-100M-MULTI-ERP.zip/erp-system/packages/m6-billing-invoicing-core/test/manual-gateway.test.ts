import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { ManualGateway } from '../src/payments/manual.gateway';

test('createCharge immediately succeeds with a unique gateway ref', async () => {
  const gw = new ManualGateway();
  const r1 = await gw.createCharge({ invoiceId: 'inv-1', amountMinorUnits: 1000, currency: 'USD', methodRef: 'cash' });
  const r2 = await gw.createCharge({ invoiceId: 'inv-2', amountMinorUnits: 500, currency: 'USD', methodRef: 'cheque' });
  assert.equal(r1.status, 'succeeded');
  assert.notEqual(r1.gatewayRef, r2.gatewayRef);
});

test('refund succeeds and references the original charge', async () => {
  const gw = new ManualGateway();
  const refund = await gw.refund('manual_abc123', 500);
  assert.equal(refund.status, 'succeeded');
  assert.equal((refund.raw as any).originalRef, 'manual_abc123');
});

test('verifyWebhook accepts a correctly signed payload', () => {
  const gw = new ManualGateway();
  const secret = 'whsec_test';
  const body = JSON.stringify({ event: 'payment.confirmed', invoiceId: 'inv-1' });
  const sig = createHmac('sha256', secret).update(body).digest('hex');
  assert.equal(gw.verifyWebhook(body, sig, secret), true);
});

test('verifyWebhook rejects a tampered body', () => {
  const gw = new ManualGateway();
  const secret = 'whsec_test';
  const body = JSON.stringify({ event: 'payment.confirmed', invoiceId: 'inv-1' });
  const sig = createHmac('sha256', secret).update(body).digest('hex');
  const tamperedBody = JSON.stringify({ event: 'payment.confirmed', invoiceId: 'inv-2' });
  assert.equal(gw.verifyWebhook(tamperedBody, sig, secret), false);
});

test('verifyWebhook rejects a wrong secret', () => {
  const gw = new ManualGateway();
  const body = JSON.stringify({ event: 'payment.confirmed' });
  const sig = createHmac('sha256', 'right-secret').update(body).digest('hex');
  assert.equal(gw.verifyWebhook(body, sig, 'wrong-secret'), false);
});

test('verifyWebhook rejects a malformed/short signature without throwing', () => {
  const gw = new ManualGateway();
  assert.equal(gw.verifyWebhook('{}', 'not-a-real-signature', 'secret'), false);
});

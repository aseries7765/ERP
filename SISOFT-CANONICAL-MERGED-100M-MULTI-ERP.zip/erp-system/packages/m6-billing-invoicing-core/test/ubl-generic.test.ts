import test from 'node:test';
import assert from 'node:assert/strict';
import { UblGenericAdapter } from '../src/invoicing/einvoice/ubl-generic.adapter';
import type { EInvoicePayloadInput } from '../src/invoicing/einvoice/adapter.interface';

const SAMPLE: EInvoicePayloadInput = {
  invoiceNumber: 'INV-2026-000001',
  issueDate: new Date('2026-03-15'),
  currency: 'USD',
  supplier: { name: 'Acme & Co', taxId: 'US-123', country: 'US' },
  customer: { name: 'Widgets <Ltd>', country: 'CA' },
  lines: [
    { description: 'Widget "A"', quantity: 2, unitPriceMinorUnits: 5000, taxRatePercent: 10, lineTotalMinorUnits: 10000 },
  ],
  totalExTaxMinorUnits: 10000,
  totalTaxMinorUnits: 1000,
  totalIncTaxMinorUnits: 11000,
};

test('build() returns a production-ready UBL-2.1 result', () => {
  const adapter = new UblGenericAdapter();
  const result = adapter.build(SAMPLE);
  assert.equal(result.format, 'UBL-2.1');
  assert.equal(result.readiness, 'production');
  assert.match(result.content, /<Invoice/);
  assert.match(result.content, /<\/Invoice>/);
});

test('XML-unsafe characters in names/descriptions are escaped', () => {
  const adapter = new UblGenericAdapter();
  const result = adapter.build(SAMPLE);
  assert.match(result.content, /Acme &amp; Co/);
  assert.match(result.content, /Widgets &lt;Ltd&gt;/);
  assert.match(result.content, /Widget &quot;A&quot;/);
  assert.doesNotMatch(result.content, /Acme & Co/); // raw & must never appear
});

test('monetary totals are rendered as decimal strings from minor units', () => {
  const adapter = new UblGenericAdapter();
  const result = adapter.build(SAMPLE);
  assert.match(result.content, /<cbc:PayableAmount currencyID="USD">110\.00<\/cbc:PayableAmount>/);
  assert.match(result.content, /<cbc:TaxAmount currencyID="USD">10\.00<\/cbc:TaxAmount>/);
});

test('document is well-formed XML (parseable, balanced tags)', () => {
  const adapter = new UblGenericAdapter();
  const result = adapter.build(SAMPLE);
  // Lightweight well-formedness check without pulling in an XML parser
  // dependency: every opening tag has a matching closing tag in order.
  const tagPattern = /<\/?([a-zA-Z0-9:]+)(?:\s[^>]*)?\/?>/g;
  const stack: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = tagPattern.exec(result.content))) {
    const full = m[0];
    const name = m[1];
    if (full.startsWith('<?')) continue;
    if (full.endsWith('/>')) continue; // self-closing
    if (full.startsWith('</')) {
      const top = stack.pop();
      assert.equal(top, name, `mismatched closing tag </${name}>`);
    } else {
      stack.push(name);
    }
  }
  assert.equal(stack.length, 0, 'all tags must be closed');
});

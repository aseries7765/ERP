# M6 — Billing + Invoicing (PARTIAL delivery — core logic slice)

**Read MANIFEST.md first.** This zip does NOT implement the full M6 prompt
(NestJS module tree, Prisma models, 8 country e-invoice adapters, 6 payment
gateways, controllers/guards/DTOs, seed scripts, ~90 files of docs/ADRs).
It implements a small, dependency-free set of the highest-risk **business
logic** pieces from that spec, as real TypeScript with real passing unit
tests, plus an honest account of everything else.

## Why scoped down

This was produced in an environment with no network access (no `pnpm
install`, no Prisma, no NestJS, no `@types/node` even), and without the
actual foundation code (M1–M3.10, M2's 83-model schema) that M6 is supposed
to build on top of. Writing the full ~150-file module tree against
frameworks/schemas that aren't present, and claiming untested code meets
G1–G22 (85% coverage, RLS, HMAC, IFRS15, schema-valid XML for 8 countries,
etc.), would mean shipping fiction dressed as a mergeable zip. Instead this
delivers less, but everything delivered actually runs.

## What's here

```
src/
  billing/
    proration.service.ts
  invoicing/
    numbering-store.interface.ts
    invoice-numbering.service.ts
    invoice-lifecycle.service.ts
    aging.service.ts
    dunning.service.ts
    einvoice/
      adapter.interface.ts
      ubl-generic.adapter.ts
  payments/
    gateway.interface.ts
    manual.gateway.ts
    reconciliation.service.ts
  types/
    node-shims.d.ts       (see note below)
test/
  *.test.ts                (34 tests, all passing)
```

## Commands

```
npm run test
```

This compiles `src/` + `test/` with `tsc` and runs the compiled tests with
Node's built-in test runner (`node --test`). No install step is required —
there are zero runtime dependencies. Verified in this environment:

```
# tests 34
# pass 34
# fail 0
```

## Note on `src/types/node-shims.d.ts`

This environment had no `@types/node` available and no network to install
it. That file hand-declares the tiny slice of `node:crypto` and the test
runner's ambient module shape actually used here. In the real monorepo,
delete this file and depend on `@types/node` normally — do not merge these
shims into a codebase that already has real Node types, they will conflict.

## What to actually do with this

Treat this as a spec/design + reference implementation for the pieces it
covers (numbering, lifecycle, proration math, aging buckets, dunning rule
selection, reconciliation matching, one real e-invoice export, one real
payment path with HMAC-verified webhooks) — port the logic into the real
NestJS services once the actual monorepo, Prisma schema, and other M6
dependencies are available, wiring in DB-backed persistence per the
callouts in each file (especially `numbering-store.interface.ts`, which is
explicit that the in-memory store is a test double, not production).

See **MANIFEST.md** for the full gap list against the original prompt.

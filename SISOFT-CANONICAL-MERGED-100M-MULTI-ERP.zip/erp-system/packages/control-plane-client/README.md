# @erp/control-plane-client

SDK for customer ERP environments to report status back to the SaaS control
plane (S1). Runs **inside** each customer's Oracle Cloud environment, not in
the control plane itself.

## Install

```bash
pnpm add @erp/control-plane-client
```

## Usage

```ts
import { ControlPlaneClient, HeartbeatReporter, UsageReporter } from '@erp/control-plane-client';

const client = new ControlPlaneClient({
  baseUrl: process.env.CONTROL_PLANE_URL!,
  apiKey: process.env.CONTROL_PLANE_API_KEY!,
});

const heartbeat = new HeartbeatReporter(client);
heartbeat.startInterval(() => ({
  environmentId: process.env.ENVIRONMENT_ID!,
  cpu: getCpuPercent(),
  memory: getMemoryPercent(),
  uptimeSeconds: process.uptime(),
  activeUsers: await countActiveSessions(),
}), 60_000);

const usage = new UsageReporter(client);
await usage.report({ customerId: process.env.CUSTOMER_ID!, resourceKey: 'users', value: 42 });
```

## API key provisioning

Each environment's API key is issued server-side via
`ApiCredentialService.issue(environmentId)` (control plane admin only) and
should be injected into the customer environment as a secret during
provisioning (S2). Keys are hashed at rest and rotatable via
`ApiCredentialService.rotate()`.

## What this SDK does NOT do

- It does not handle SSO/login (see `SSO_HANDSHAKE.md` — the portal issues a
  HandoffToken, and the customer environment validates it separately).
- It does not sync business data. This SDK only ever sends operational
  metadata (health, usage, version, security events) — never customer
  records.

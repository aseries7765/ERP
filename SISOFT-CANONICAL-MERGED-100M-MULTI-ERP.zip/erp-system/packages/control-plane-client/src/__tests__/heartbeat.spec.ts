import { ControlPlaneClient } from '../client';
import { HeartbeatReporter } from '../heartbeat';

describe('HeartbeatReporter', () => {
  it('posts to /v1/control-plane/heartbeat', async () => {
    const fetchImpl = jest.fn().mockResolvedValue({ ok: true, json: async () => ({ acknowledged: true }) });
    const client = new ControlPlaneClient({ baseUrl: 'https://cp.example.com', apiKey: 'k', fetchImpl: fetchImpl as any });
    const reporter = new HeartbeatReporter(client);

    const result = await reporter.send({ environmentId: 'env-1', cpu: 12.5, activeUsers: 3 });

    expect(fetchImpl).toHaveBeenCalledWith('https://cp.example.com/v1/control-plane/heartbeat', expect.anything());
    expect(result).toEqual({ acknowledged: true });
  });

  it('startInterval invokes send() on the given cadence and does not throw on failure', () => {
    jest.useFakeTimers();
    const fetchImpl = jest.fn().mockRejectedValue(new Error('network down'));
    const client = new ControlPlaneClient({ baseUrl: 'https://cp.example.com', apiKey: 'k', fetchImpl: fetchImpl as any });
    const reporter = new HeartbeatReporter(client);

    const handle = reporter.startInterval(() => ({ environmentId: 'env-1' }), 1000);
    jest.advanceTimersByTime(3000);
    clearInterval(handle);

    expect(fetchImpl).toHaveBeenCalledTimes(3);
    jest.useRealTimers();
  });
});

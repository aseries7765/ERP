import { ControlPlaneClient, ControlPlaneApiError } from '../client';

describe('ControlPlaneClient', () => {
  it('throws if baseUrl is missing', () => {
    expect(() => new ControlPlaneClient({ baseUrl: '', apiKey: 'k' })).toThrow('baseUrl');
  });

  it('throws if apiKey is missing', () => {
    expect(() => new ControlPlaneClient({ baseUrl: 'https://x', apiKey: '' })).toThrow('apiKey');
  });

  it('sends X-Api-Key header and JSON body on post()', async () => {
    const fetchImpl = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ acknowledged: true }),
    });
    const client = new ControlPlaneClient({ baseUrl: 'https://cp.example.com', apiKey: 'secret-key', fetchImpl: fetchImpl as any });

    const result = await client.post('/v1/control-plane/heartbeat', { environmentId: 'env-1' });

    expect(fetchImpl).toHaveBeenCalledWith(
      'https://cp.example.com/v1/control-plane/heartbeat',
      expect.objectContaining({
        method: 'POST',
        headers: expect.objectContaining({ 'X-Api-Key': 'secret-key', 'Content-Type': 'application/json' }),
        body: JSON.stringify({ environmentId: 'env-1' }),
      }),
    );
    expect(result).toEqual({ acknowledged: true });
  });

  it('throws ControlPlaneApiError on non-2xx response', async () => {
    const fetchImpl = jest.fn().mockResolvedValue({
      ok: false,
      status: 401,
      json: async () => ({ message: 'invalid api key' }),
    });
    const client = new ControlPlaneClient({ baseUrl: 'https://cp.example.com', apiKey: 'bad-key', fetchImpl: fetchImpl as any });

    await expect(client.post('/v1/control-plane/heartbeat', {})).rejects.toBeInstanceOf(ControlPlaneApiError);
  });
});

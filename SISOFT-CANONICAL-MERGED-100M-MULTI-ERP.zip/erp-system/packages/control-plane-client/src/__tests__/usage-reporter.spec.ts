import { ControlPlaneClient } from '../client';
import { UsageReporter } from '../usage-reporter';

describe('UsageReporter', () => {
  it('posts usage payload to /v1/control-plane/usage', async () => {
    const fetchImpl = jest.fn().mockResolvedValue({ ok: true, json: async () => ({ resourceKey: 'users', used: 10 }) });
    const client = new ControlPlaneClient({ baseUrl: 'https://cp.example.com', apiKey: 'k', fetchImpl: fetchImpl as any });
    const reporter = new UsageReporter(client);

    await reporter.report({ customerId: 'cust-1', resourceKey: 'users', value: 10 });

    expect(fetchImpl).toHaveBeenCalledWith(
      'https://cp.example.com/v1/control-plane/usage',
      expect.objectContaining({ body: JSON.stringify({ customerId: 'cust-1', resourceKey: 'users', value: 10 }) }),
    );
  });
});

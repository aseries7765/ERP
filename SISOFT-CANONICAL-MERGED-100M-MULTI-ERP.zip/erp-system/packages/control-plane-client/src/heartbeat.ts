import { ControlPlaneClient } from './client';
import { HeartbeatPayload } from './types';

/** Sends a heartbeat to POST /v1/control-plane/heartbeat. Intended to be called on an interval (default 60s) from the customer environment. */
export class HeartbeatReporter {
  constructor(private readonly client: ControlPlaneClient) {}

  async send(payload: HeartbeatPayload): Promise<{ acknowledged: boolean }> {
    return this.client.post('/v1/control-plane/heartbeat', payload);
  }

  /** Convenience helper: starts a setInterval loop. Caller owns the returned handle and must clearInterval on shutdown. */
  startInterval(getPayload: () => HeartbeatPayload, intervalMs = 60_000): ReturnType<typeof setInterval> {
    return setInterval(() => {
      this.send(getPayload()).catch((err) => {
        // Intentionally swallow network errors here — a missed heartbeat is
        // expected to be handled by the control plane's staleness sweep,
        // not by crashing the customer environment's process.
        // eslint-disable-next-line no-console
        console.error('[control-plane-client] heartbeat failed:', err);
      });
    }, intervalMs);
  }
}

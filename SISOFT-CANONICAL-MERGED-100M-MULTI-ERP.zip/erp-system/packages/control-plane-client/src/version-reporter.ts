import { ControlPlaneClient } from './client';
import { VersionReportPayload } from './types';

/**
 * NOTE: version reporting is folded into the heartbeat payload's `version`
 * field server-side (EnvironmentHealth.version) rather than having its own
 * endpoint — S1 didn't stand up a separate version-report route. This
 * reporter is kept as its own class per the SDK's file layout, and posts to
 * the heartbeat endpoint with only the version-relevant fields populated.
 * Prefer using HeartbeatReporter directly if you're already sending full
 * heartbeat payloads; use this only for out-of-band version pings.
 */
export class VersionReporter {
  constructor(private readonly client: ControlPlaneClient) {}

  async report(payload: VersionReportPayload): Promise<unknown> {
    return this.client.post('/v1/control-plane/heartbeat', {
      environmentId: payload.environmentId,
      version: payload.semver,
    });
  }
}

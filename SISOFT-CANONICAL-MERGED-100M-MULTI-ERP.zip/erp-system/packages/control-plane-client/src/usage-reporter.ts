import { ControlPlaneClient } from './client';
import { UsageReportPayload } from './types';

/** Reports resource usage (users, storage_gb, etc.) to POST /v1/control-plane/usage. */
export class UsageReporter {
  constructor(private readonly client: ControlPlaneClient) {}

  async report(payload: UsageReportPayload): Promise<unknown> {
    return this.client.post('/v1/control-plane/usage', payload);
  }
}

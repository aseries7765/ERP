export interface ControlPlaneClientOptions {
  /** Base URL of the control plane API, e.g. https://control.example.com */
  baseUrl: string;
  /** Per-environment API key (issued by ApiCredentialService.issue()). */
  apiKey: string;
  /** Optional fetch override, mainly for tests. */
  fetchImpl?: typeof fetch;
}

export interface HeartbeatPayload {
  environmentId: string;
  cpu?: number;
  memory?: number;
  disk?: number;
  dbSizeMB?: number;
  uptimeSeconds?: number;
  version?: string;
  activeUsers?: number;
  apiLatencyMs?: number;
}

export interface UsageReportPayload {
  customerId: string;
  resourceKey: string;
  value: number;
}

export interface VersionReportPayload {
  environmentId: string;
  semver: string;
}

export interface SecurityEventReportPayload {
  customerId?: string;
  type: 'suspicious_login' | 'rate_limit' | 'quota_exceeded' | 'permission_denied';
  severity?: 'low' | 'medium' | 'high' | 'critical';
  details?: Record<string, unknown>;
}

import { ControlPlaneClient } from './client';
import { SecurityEventReportPayload } from './types';

/** Reports a security-relevant event detected in the customer environment (e.g. repeated failed logins) to the control plane's security dashboard. */
export class SecurityEventReporter {
  constructor(private readonly client: ControlPlaneClient) {}

  async report(payload: SecurityEventReportPayload): Promise<unknown> {
    return this.client.post('/v1/control-plane/security-events-report', payload);
  }
}

import { ControlPlaneClientOptions } from './types';

export class ControlPlaneApiError extends Error {
  constructor(message: string, public readonly status: number, public readonly body?: unknown) {
    super(message);
    this.name = 'ControlPlaneApiError';
  }
}

/**
 * Minimal HTTP client used by every reporter in this package. Sends the
 * per-environment API key as `X-Api-Key`, matching EnvironmentApiKeyGuard
 * server-side.
 */
export class ControlPlaneClient {
  private readonly fetchImpl: typeof fetch;

  constructor(private readonly options: ControlPlaneClientOptions) {
    this.fetchImpl = options.fetchImpl ?? fetch;
    if (!options.baseUrl) throw new Error('ControlPlaneClient requires baseUrl');
    if (!options.apiKey) throw new Error('ControlPlaneClient requires apiKey');
  }

  async post<T>(path: string, body: unknown): Promise<T> {
    const response = await this.fetchImpl(`${this.options.baseUrl}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Api-Key': this.options.apiKey,
      },
      body: JSON.stringify(body),
    });

    const payload = await response.json().catch(() => undefined);
    if (!response.ok) {
      throw new ControlPlaneApiError(`Control plane request to ${path} failed (${response.status})`, response.status, payload);
    }
    return payload as T;
  }
}

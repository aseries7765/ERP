# @erp/query-builder

Dependency-free, AST-only reporting query compiler. It enforces an explicit table/column allow-list, injects the tenant predicate independently of the caller AST, parameterizes values, clamps row limits, and rejects raw SQL/unsafe identifiers.

`compileSafeQuery(ast, tenantId)` is the only supported AST-to-SQL entry point. `QueryAstBuilder` constructs ASTs without accepting SQL fragments.

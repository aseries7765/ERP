import { QueryAstBuilder, compileSafeQuery } from '..';
describe('query-builder safety',()=>{
 it('requires tenant scope',()=>{const ast=QueryAstBuilder.from('invoices').select({table:'invoices',column:'id'}).build(); expect(()=>compileSafeQuery(ast,'')).toThrow();});
 it('rejects unregistered identifiers',()=>{const ast:any={table:'invoices',select:[{table:'invoices',column:'id'}],where:{column:{table:'invoices',column:'id; DROP TABLE x'},operator:'=' ,value:1}}; expect(()=>compileSafeQuery(ast,'t')).toThrow();});
 it('parameterizes values',()=>{const ast=QueryAstBuilder.from('invoices').select({table:'invoices',column:'id'}).where({table:'invoices',column:'status'},'=',"x' OR 1=1 --").build(); const q=compileSafeQuery(ast,'t'); expect(q.sql).not.toContain("OR 1=1"); expect(q.params).toContain("x' OR 1=1 --");});
 it('always adds tenant predicate and clamps limit',()=>{const ast=QueryAstBuilder.from('invoices').select({table:'invoices',column:'id'}).limit(999999).build(); const q=compileSafeQuery(ast,'tenant-a'); expect(q.sql).toContain('"invoices"."tenant_id" = $1'); expect(q.sql).toContain('LIMIT 10000');});
});

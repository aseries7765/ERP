export type Scalar = string | number | boolean | Date | null;
export type ColumnRef = { table: string; column: string; alias?: string };
export type ValueExpr = { value: Scalar } | { param: string } | ColumnRef;
export type Operator = '=' | '!=' | '<>' | '<' | '<=' | '>' | '>=' | 'IN' | 'NOT IN' | 'LIKE' | 'ILIKE' | 'IS NULL' | 'IS NOT NULL' | 'BETWEEN';
export type Predicate = { column: ColumnRef; operator: Operator; value?: Scalar | Scalar[] | ValueExpr | ValueExpr[] };
export type WhereExpr = Predicate | { and: WhereExpr[] } | { or: WhereExpr[] };
export type Join = { type?: 'INNER'|'LEFT'|'RIGHT'; table: string; alias: string; on: Array<{ left: ColumnRef; right: ColumnRef }> };
export type OrderBy = { column: ColumnRef; direction?: 'ASC'|'DESC' } | { alias: string; direction?: 'ASC'|'DESC' };
export type Aggregate = { function: 'COUNT'|'SUM'|'AVG'|'MIN'|'MAX'; column: ColumnRef; alias?: string };
export interface QueryAst {
  table: string; alias?: string; select: Array<ColumnRef | Aggregate>; joins?: Join[]; where?: WhereExpr; groupBy?: ColumnRef[]; orderBy?: OrderBy[]; limit?: number; offset?: number; tenantId?: string;
}
export interface CompiledQuery { sql: string; params: unknown[]; }

import { CompiledQuery, QueryAst, WhereExpr, ColumnRef, Aggregate } from './types';
import { assertColumn, assertIdentifier, assertJoin, assertTable, MAX_ROW_LIMIT } from './safety';

export function compileSafeQuery(ast: QueryAst, tenantId: string): CompiledQuery {
  if (!tenantId || typeof tenantId !== 'string') throw new Error('Tenant scope is required');
  assertTable(ast.table); if (ast.alias) assertIdentifier(ast.alias, 'alias');
  const params: unknown[] = [tenantId];
  const baseAlias = ast.alias ?? ast.table;
  const select = ast.select.map(s => 'function' in s ? compileAggregate(s, params) : compileColumn(s)).join(', ');
  const joins = (ast.joins ?? []).map(j => { assertJoin(j); const on=j.on.map(p=>`${qualified(p.left)} = ${qualified(p.right)}`).join(' AND '); return `${j.type ?? 'INNER'} JOIN ${quote(j.table)} ${quote(j.alias)} ON ${on}`; }).join(' ');
  const clauses = [`${qualified({table:ast.table,column:'tenant_id'})} = $1`];
  if (ast.where) clauses.push(compileWhere(ast.where, params));
  const group = ast.groupBy?.length ? ` GROUP BY ${ast.groupBy.map(compileColumn).join(', ')}` : '';
  const order = ast.orderBy?.length ? ` ORDER BY ${ast.orderBy.map(o => 'alias' in o ? `${quote(o.alias)} ${o.direction ?? 'ASC'}` : `${compileColumn(o.column)} ${o.direction ?? 'ASC'}`).join(', ')}` : '';
  const limit = Math.min(Math.max(Math.trunc(ast.limit ?? MAX_ROW_LIMIT),1),MAX_ROW_LIMIT);
  const offset = Math.max(Math.trunc(ast.offset ?? 0),0);
  const from = `FROM ${quote(ast.table)} ${quote(baseAlias)}`;
  return { sql:`SELECT ${select} ${from}${joins ? ` ${joins}`:''} WHERE ${clauses.join(' AND ')}${group}${order} LIMIT ${limit} OFFSET ${offset}`, params };
}
function compileAggregate(a: Aggregate, params: unknown[]): string { assertColumn(a.column); const sql=`${a.function}(${qualified(a.column)})`; return a.alias ? `${sql} AS ${quote(a.alias)}` : sql; }
function compileColumn(c: ColumnRef): string { assertColumn(c); return c.alias ? `${qualified(c)} AS ${quote(c.alias)}` : qualified(c); }
function compileWhere(w: WhereExpr, params: unknown[]): string {
  if ('and' in w) return `(${w.and.map(x=>compileWhere(x,params)).join(' AND ')})`;
  if ('or' in w) return `(${w.or.map(x=>compileWhere(x,params)).join(' OR ')})`;
  assertColumn(w.column); const left=qualified(w.column);
  if (w.operator==='IS NULL'||w.operator==='IS NOT NULL') return `${left} ${w.operator}`;
  if (w.operator==='IN'||w.operator==='NOT IN') { const vals=Array.isArray(w.value)?w.value:[]; if(!vals.length) throw new Error(`${w.operator} requires values`); return `${left} ${w.operator} (${vals.map(v=>bind(v,params)).join(', ')})`; }
  if (w.operator==='BETWEEN') { if(!Array.isArray(w.value)||w.value.length!==2) throw new Error('BETWEEN requires two values'); return `${left} BETWEEN ${bind(w.value[0],params)} AND ${bind(w.value[1],params)}`; }
  return `${left} ${w.operator} ${bind(w.value,params)}`;
}
function bind(value: unknown, params: unknown[]): string { if (value && typeof value==='object' && 'value' in (value as any)) value=(value as any).value; if (value && typeof value==='object' && 'param' in (value as any)) throw new Error('Unresolved runtime parameter'); params.push(value); return `$${params.length}`; }
function qualified(c: ColumnRef): string { assertColumn(c); return `${quote(c.table)}.${quote(c.column)}`; }
function quote(s:string):string { assertIdentifier(s); return `"${s}"`; }

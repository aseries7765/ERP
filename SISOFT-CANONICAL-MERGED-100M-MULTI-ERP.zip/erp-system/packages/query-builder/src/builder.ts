import { Aggregate, ColumnRef, Join, Operator, QueryAst, Scalar, WhereExpr } from './types';

export class QueryAstBuilder {
  private ast: QueryAst;
  private constructor(table: string) { this.ast = { table, select: [] }; }
  static from(table: string): QueryAstBuilder { return new QueryAstBuilder(table); }
  as(alias: string): this { this.ast.alias = alias; return this; }
  select(...columns: ColumnRef[]): this { this.ast.select.push(...columns); return this; }
  aggregate(fn: Aggregate['function'], column: ColumnRef, alias?: string): this { this.ast.select.push({ function: fn, column, alias }); return this; }
  join(table: string, alias: string, on: Array<{left: ColumnRef; right: ColumnRef}>, type: Join['type']='INNER'): this { (this.ast.joins ??= []).push({table,alias,on,type}); return this; }
  where(column: ColumnRef, operator: Operator, value?: Scalar | Scalar[]): this { this.ast.where = { column, operator, value }; return this; }
  and(...conditions: WhereExpr[]): this { this.ast.where = this.ast.where ? {and:[this.ast.where,...conditions]} : {and:conditions}; return this; }
  or(...conditions: WhereExpr[]): this { this.ast.where = {or:conditions}; return this; }
  groupBy(...columns: ColumnRef[]): this { this.ast.groupBy = columns; return this; }
  orderBy(...orders: NonNullable<QueryAst['orderBy']>): this { this.ast.orderBy = orders; return this; }
  limit(limit: number): this { this.ast.limit = limit; return this; }
  offset(offset: number): this { this.ast.offset = offset; return this; }
  build(): QueryAst { if (!this.ast.select.length) throw new Error('Query must select at least one field'); return structuredClone(this.ast); }
}

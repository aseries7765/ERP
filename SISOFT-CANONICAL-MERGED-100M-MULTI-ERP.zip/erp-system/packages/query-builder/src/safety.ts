import { ColumnRef, Join } from './types';

const IDENT = /^[a-zA-Z_][a-zA-Z0-9_]*$/;
export const MAX_ROW_LIMIT = 10_000;
export const QUERY_TIMEOUT_MS = 10_000;

// Explicit identifier allow-list. The registry is intentionally conservative:
// callers may extend it at build time for newly exposed reporting tables.
const TABLES = new Set<string>([
  'invoices','invoice_lines','customers','vendors','products','warehouses','sales_orders','sales_order_lines',
  'purchase_orders','purchase_order_lines','purchase_invoices','purchase_requisitions','purchase_rfq','purchase_vendor_quotes',
  'hr_employees','hr_attendance','hr_leave_applications','hr_shifts','payroll_runs','payslips','payslip_lines',
  'finance_ledger_accounts','finance_journal_entries','finance_journal_lines','finance_vendor_bills','finance_vendor_payments',
  'finance_bank_accounts','finance_bank_transactions','finance_tax_rates','finance_budgets','finance_budget_lines',
  'projects','project_tasks','project_time_entries','stock_movements','stock_reservations','stock_transfers',
  'audit_events','activity_logs','report_definitions'
]);
const COMMON_COLUMNS = new Set(['id','tenant_id','created_at','updated_at','deleted_at','code','name','status','type','currency','amount','total','subtotal','tax','quantity','price','date','description','employee_id','customer_id','vendor_id','project_id','product_id','warehouse_id','user_id','account_id','invoice_id','order_id','period','year','month']);

export function assertIdentifier(value: string, kind = 'identifier'): void {
  if (!IDENT.test(value)) throw new Error(`Unsafe ${kind}: ${value}`);
}
export function assertTable(table: string): void {
  assertIdentifier(table, 'table');
  if (!TABLES.has(table)) throw new Error(`Table is not registered: ${table}`);
}
export function assertColumn(ref: ColumnRef): void {
  assertTable(ref.table); assertIdentifier(ref.column, 'column');
  if (!COMMON_COLUMNS.has(ref.column)) throw new Error(`Column is not registered: ${ref.table}.${ref.column}`);
  if (ref.alias) assertIdentifier(ref.alias, 'alias');
}
export function assertJoin(join: Join): void {
  assertTable(join.table); assertIdentifier(join.alias, 'join alias');
  if (!join.on.length) throw new Error('Join must contain at least one ON predicate');
  for (const pair of join.on) { assertColumn(pair.left); assertColumn(pair.right); }
}
export function registerTable(table: string, columns: string[]): void {
  assertIdentifier(table, 'table');
  TABLES.add(table);
  for (const c of columns) { assertIdentifier(c, 'column'); COMMON_COLUMNS.add(c); }
}
export function isRegisteredTable(table: string): boolean { return TABLES.has(table); }

/**
 * Triage scale support for ESI (US), CTAS (Canada), and Manchester (UK).
 * Facility picks one scale in config; this module normalizes all three
 * to a common internal urgency + target-time-to-doctor model so the ER
 * queue/dashboard logic (er-queue.ts) doesn't need to know which scale
 * is active.
 *
 * IMPORTANT — scope honesty: this module implements the *scale
 * structures, level validation, and target-time lookup* for all three
 * scales. It does NOT implement full clinical decision-support logic
 * (e.g. the complete ESI algorithm's resource-prediction branching for
 * level 2 vs 3, which in real ESI requires a trained triage nurse's
 * judgment plus vital-sign danger-zone checks). That clinical judgment
 * step is intentionally left to the triage nurse; this module validates
 * and records their assigned level, tracks the derived target time, and
 * flags G19 compliance (level assigned within 5 minutes of arrival).
 */

export type TriageScaleName = 'ESI' | 'CTAS' | 'MANCHESTER';

export class InvalidTriageInputError extends Error {}

export interface TriageLevelDefinition {
  level: string; // e.g. "1", "2", ... or "RED", "ORANGE", ... for Manchester
  label: string;
  targetMinutesToDoctor: number;
  rank: number; // 1 = most urgent, ascending = less urgent
}

const ESI_LEVELS: TriageLevelDefinition[] = [
  { level: '1', label: 'Resuscitation', targetMinutesToDoctor: 0, rank: 1 },
  { level: '2', label: 'Emergent', targetMinutesToDoctor: 10, rank: 2 },
  { level: '3', label: 'Urgent', targetMinutesToDoctor: 30, rank: 3 },
  { level: '4', label: 'Less Urgent', targetMinutesToDoctor: 60, rank: 4 },
  { level: '5', label: 'Non-Urgent', targetMinutesToDoctor: 120, rank: 5 },
];

const CTAS_LEVELS: TriageLevelDefinition[] = [
  { level: '1', label: 'Resuscitation', targetMinutesToDoctor: 0, rank: 1 },
  { level: '2', label: 'Emergent', targetMinutesToDoctor: 15, rank: 2 },
  { level: '3', label: 'Urgent', targetMinutesToDoctor: 30, rank: 3 },
  { level: '4', label: 'Less Urgent', targetMinutesToDoctor: 60, rank: 4 },
  { level: '5', label: 'Non-Urgent', targetMinutesToDoctor: 120, rank: 5 },
];

const MANCHESTER_LEVELS: TriageLevelDefinition[] = [
  { level: 'RED', label: 'Immediate', targetMinutesToDoctor: 0, rank: 1 },
  { level: 'ORANGE', label: 'Very Urgent', targetMinutesToDoctor: 10, rank: 2 },
  { level: 'YELLOW', label: 'Urgent', targetMinutesToDoctor: 60, rank: 3 },
  { level: 'GREEN', label: 'Standard', targetMinutesToDoctor: 120, rank: 4 },
  { level: 'BLUE', label: 'Non-Urgent', targetMinutesToDoctor: 240, rank: 5 },
];

const SCALES: Record<TriageScaleName, TriageLevelDefinition[]> = {
  ESI: ESI_LEVELS,
  CTAS: CTAS_LEVELS,
  MANCHESTER: MANCHESTER_LEVELS,
};

/** Max minutes from arrival to triage-level assignment (spec G19). */
export const MAX_MINUTES_TO_TRIAGE = 5;

export interface AssignTriageInput {
  scale: TriageScaleName;
  level: string;
  arrivalTime: Date;
  triageTime: Date;
}

export interface TriageAssignment {
  scale: TriageScaleName;
  definition: TriageLevelDefinition;
  arrivalTime: Date;
  triageTime: Date;
  minutesToTriage: number;
  withinTargetTime: boolean; // G19 compliance flag
  targetDoctorByTime: Date;
}

/** Returns the ordered level definitions for a scale, most urgent first. */
export function getScaleLevels(scale: TriageScaleName): TriageLevelDefinition[] {
  const levels = SCALES[scale];
  if (!levels) {
    throw new InvalidTriageInputError(`Unknown triage scale: ${scale}`);
  }
  return levels;
}

/**
 * Validates and records a triage assignment. Throws if the level is not
 * valid for the given scale, or if triageTime precedes arrivalTime.
 * Does not throw on late triage (>5 min) — that is a quality metric
 * (G19), not a hard validation failure, since the patient must still be
 * triaged even if it happened late; callers should surface
 * `withinTargetTime === false` as an SLA breach for the dashboard/job
 * (er-sla.service / er-wait-time-monitor.job) rather than blocking on it.
 */
export function assignTriageLevel(input: AssignTriageInput): TriageAssignment {
  const levels = getScaleLevels(input.scale);
  const definition = levels.find((l) => l.level === input.level);
  if (!definition) {
    throw new InvalidTriageInputError(
      `Level "${input.level}" is not valid for scale ${input.scale}. Valid levels: ${levels.map((l) => l.level).join(', ')}`,
    );
  }
  if (input.triageTime.getTime() < input.arrivalTime.getTime()) {
    throw new InvalidTriageInputError('triageTime cannot precede arrivalTime.');
  }

  const minutesToTriage = (input.triageTime.getTime() - input.arrivalTime.getTime()) / 60000;
  const targetDoctorByTime = new Date(
    input.triageTime.getTime() + definition.targetMinutesToDoctor * 60000,
  );

  return {
    scale: input.scale,
    definition,
    arrivalTime: input.arrivalTime,
    triageTime: input.triageTime,
    minutesToTriage: Math.round(minutesToTriage * 100) / 100,
    withinTargetTime: minutesToTriage <= MAX_MINUTES_TO_TRIAGE,
    targetDoctorByTime,
  };
}

/**
 * Compares urgency across two assignments on possibly different scales,
 * using each scale's rank (1 = most urgent). Used by er-queue.ts to
 * order the waiting room even if a facility somehow has mixed-scale
 * historical data (e.g. mid-migration between scales).
 */
export function compareUrgency(a: TriageAssignment, b: TriageAssignment): number {
  return a.definition.rank - b.definition.rank;
}

/**
 * Code blue activation and event timeline. Per spec G20 ("Code blue
 * response MUST be < 2 min"), this tracks activation time and the
 * first responder's arrival time, and flags whether the 2-minute
 * target was met — it does not (and cannot) enforce staff to actually
 * arrive in time; it is the measurement/audit mechanism the SLA is
 * checked against, per ADR-0387.
 */

export class CodeBlueError extends Error {}

export type CodeBlueEventType =
  | 'ACTIVATED'
  | 'FIRST_RESPONDER_ARRIVED'
  | 'CPR_STARTED'
  | 'CPR_STOPPED'
  | 'MEDICATION_GIVEN'
  | 'DEFIBRILLATION'
  | 'ROSC' // return of spontaneous circulation
  | 'DECEASED_PRONOUNCED'
  | 'TRANSFERRED'
  | 'DEBRIEF_NOTE';

export interface CodeBlueEvent {
  type: CodeBlueEventType;
  at: Date;
  recordedBy: { userId: string; name: string };
  detail?: string; // e.g. medication name+dose, defib joules, debrief text
}

export type CodeBlueOutcome = 'ROSC' | 'DECEASED' | 'TRANSFERRED';

export interface CodeBlueActivation {
  id: string;
  patientId: string;
  location: string;
  activatedAt: Date;
  activatedBy: { userId: string; name: string };
  events: CodeBlueEvent[];
  outcome?: CodeBlueOutcome;
  endedAt?: Date;
  /** Minutes from activation to the first responder's arrival, once recorded. */
  responseTimeMinutes?: number;
  /** True once responseTimeMinutes is known and is < 2 min (G20). */
  metResponseTarget?: boolean;
}

const RESPONSE_TARGET_MINUTES = 2;

let idCounter = 0;
function nextId(prefix: string): string {
  idCounter += 1;
  return `${prefix}_${idCounter}`;
}

export class CodeBlueService {
  private activations = new Map<string, CodeBlueActivation>();

  activate(
    patientId: string,
    location: string,
    activatedBy: { userId: string; name: string },
    now: Date = new Date(),
  ): CodeBlueActivation {
    if (!patientId) throw new CodeBlueError('patientId is required.');
    if (!location) throw new CodeBlueError('location is required.');

    const activation: CodeBlueActivation = {
      id: nextId('codeblue'),
      patientId,
      location,
      activatedAt: now,
      activatedBy,
      events: [{ type: 'ACTIVATED', at: now, recordedBy: activatedBy }],
    };
    this.activations.set(activation.id, activation);
    return activation;
  }

  /**
   * Records the first responder's arrival, computing response time
   * against the activation timestamp and flagging G20 compliance.
   * Can only be called once per activation — the *first* responder is
   * what the SLA measures, not every subsequent arrival.
   */
  recordFirstResponderArrival(
    activationId: string,
    respondedBy: { userId: string; name: string },
    now: Date = new Date(),
  ): CodeBlueActivation {
    const activation = this.getOrThrow(activationId);
    if (activation.responseTimeMinutes !== undefined) {
      throw new CodeBlueError(`First responder arrival already recorded for activation ${activationId}.`);
    }
    if (now.getTime() < activation.activatedAt.getTime()) {
      throw new CodeBlueError('Responder arrival time cannot precede activation time.');
    }

    const responseTimeMinutes = round2((now.getTime() - activation.activatedAt.getTime()) / 60000);
    activation.responseTimeMinutes = responseTimeMinutes;
    activation.metResponseTarget = responseTimeMinutes < RESPONSE_TARGET_MINUTES;
    activation.events.push({ type: 'FIRST_RESPONDER_ARRIVED', at: now, recordedBy: respondedBy });

    return activation;
  }

  logEvent(
    activationId: string,
    type: Exclude<CodeBlueEventType, 'ACTIVATED' | 'FIRST_RESPONDER_ARRIVED'>,
    recordedBy: { userId: string; name: string },
    now: Date = new Date(),
    detail?: string,
  ): CodeBlueActivation {
    const activation = this.getOrThrow(activationId);
    if (activation.outcome) {
      throw new CodeBlueError(`Cannot log further events: activation ${activationId} already ended with outcome ${activation.outcome}.`);
    }
    activation.events.push({ type, at: now, recordedBy, detail });
    return activation;
  }

  /** Ends the activation with a required outcome, closing the timeline. */
  end(
    activationId: string,
    outcome: CodeBlueOutcome,
    recordedBy: { userId: string; name: string },
    now: Date = new Date(),
  ): CodeBlueActivation {
    const activation = this.getOrThrow(activationId);
    if (activation.outcome) {
      throw new CodeBlueError(`Activation ${activationId} already ended with outcome ${activation.outcome}.`);
    }
    const eventType: CodeBlueEventType = outcome === 'ROSC' ? 'ROSC' : outcome === 'DECEASED' ? 'DECEASED_PRONOUNCED' : 'TRANSFERRED';
    activation.events.push({ type: eventType, at: now, recordedBy });
    activation.outcome = outcome;
    activation.endedAt = now;
    return activation;
  }

  getActivation(activationId: string): CodeBlueActivation {
    return this.getOrThrow(activationId);
  }

  private getOrThrow(activationId: string): CodeBlueActivation {
    const activation = this.activations.get(activationId);
    if (!activation) throw new CodeBlueError(`No code blue activation found with id ${activationId}.`);
    return activation;
  }
}

function round2(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/**
 * ER queue management: tracks patients waiting to be seen, computes
 * wait times, and detects LWBS (left without being seen) per
 * ADR-0389. Ordering within the queue follows triage urgency first,
 * then arrival time (FIFO within the same urgency level) — it does
 * NOT reorder by wait time alone, since a lower-acuity patient waiting
 * longer must still not jump ahead of a higher-acuity patient who just
 * arrived.
 */

export class ErQueueError extends Error {}

export type QueueEntryStatus = 'WAITING' | 'IN_TREATMENT' | 'LWBS' | 'COMPLETED';

export interface QueueEntry {
  patientId: string;
  arrivalTime: Date;
  urgencyRank: number;
  status: QueueEntryStatus;
  calledAt?: Date;
  lwbsAt?: Date;
}

export class ErQueue {
  private entries = new Map<string, QueueEntry>();

  addPatient(patientId: string, arrivalTime: Date, urgencyRank: number): QueueEntry {
    if (this.entries.has(patientId)) {
      throw new ErQueueError(`Patient ${patientId} is already in the queue.`);
    }
    const entry: QueueEntry = { patientId, arrivalTime, urgencyRank, status: 'WAITING' };
    this.entries.set(patientId, entry);
    return entry;
  }

  getOrderedQueue(): QueueEntry[] {
    return [...this.entries.values()]
      .filter((e) => e.status === 'WAITING')
      .sort((a, b) => {
        if (a.urgencyRank !== b.urgencyRank) return a.urgencyRank - b.urgencyRank;
        return a.arrivalTime.getTime() - b.arrivalTime.getTime();
      });
  }

  callPatient(patientId: string, now: Date = new Date()): QueueEntry {
    const entry = this.getOrThrow(patientId);
    if (entry.status !== 'WAITING') {
      throw new ErQueueError(`Patient ${patientId} is not WAITING (status: ${entry.status}).`);
    }
    entry.status = 'IN_TREATMENT';
    entry.calledAt = now;
    return entry;
  }

  complete(patientId: string): QueueEntry {
    const entry = this.getOrThrow(patientId);
    if (entry.status !== 'IN_TREATMENT') {
      throw new ErQueueError(`Patient ${patientId} is not IN_TREATMENT (status: ${entry.status}).`);
    }
    entry.status = 'COMPLETED';
    return entry;
  }

  markLwbs(patientId: string, now: Date = new Date()): QueueEntry {
    const entry = this.getOrThrow(patientId);
    if (entry.status !== 'WAITING') {
      throw new ErQueueError(`Patient ${patientId} cannot be marked LWBS: status is ${entry.status}, not WAITING.`);
    }
    entry.status = 'LWBS';
    entry.lwbsAt = now;
    return entry;
  }

  getWaitTimeMinutes(patientId: string, now: Date = new Date()): number {
    const entry = this.getOrThrow(patientId);
    const endTime = entry.calledAt ?? entry.lwbsAt ?? now;
    return round2((endTime.getTime() - entry.arrivalTime.getTime()) / 60000);
  }

  getOverdueWaiting(thresholdMinutes: number, now: Date = new Date()): QueueEntry[] {
    return this.getOrderedQueue().filter((e) => this.getWaitTimeMinutes(e.patientId, now) > thresholdMinutes);
  }

  getEntry(patientId: string): QueueEntry {
    return this.getOrThrow(patientId);
  }

  private getOrThrow(patientId: string): QueueEntry {
    const entry = this.entries.get(patientId);
    if (!entry) throw new ErQueueError(`Patient ${patientId} is not in the queue.`);
    return entry;
  }
}

function round2(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

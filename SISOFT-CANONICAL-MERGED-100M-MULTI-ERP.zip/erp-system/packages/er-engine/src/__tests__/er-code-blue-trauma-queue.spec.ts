import { CodeBlueService, CodeBlueError } from '../code-blue';
import {
  determineTraumaLevel,
  activateTraumaTeam,
  recordTeamMemberArrival,
  isTeamFullyAssembled,
  TraumaActivationError,
  TraumaCriteria,
} from '../trauma-activation';
import { ErQueue, ErQueueError } from '../er-queue';

function baseCriteria(): TraumaCriteria {
  return {
    systolicBpBelow90: false,
    respiratoryRateAbnormal: false,
    glasgowComaScaleBelow9: false,
    penetratingInjuryToTorsoHeadNeck: false,
    flailChest: false,
    twoOrMoreProximalLongBoneFractures: false,
    amputationProximalToWristOrAnkle: false,
    fallGreaterThan20Feet: false,
    highRiskMechanism: false,
    ageOver65WithSignificantMechanism: false,
  };
}

describe('CodeBlueService', () => {
  const STAFF_A = { userId: 'staff-1', name: 'RN A' };
  const STAFF_B = { userId: 'staff-2', name: 'MD B' };

  it('activates and logs the ACTIVATED event', () => {
    const service = new CodeBlueService();
    const activation = service.activate('pat-1', 'Ward 3 Room 12', STAFF_A, new Date('2026-09-18T10:00:00Z'));
    expect(activation.events[0].type).toBe('ACTIVATED');
    expect(activation.responseTimeMinutes).toBeUndefined();
  });

  it('flags G20 compliance when first responder arrives within 2 minutes', () => {
    const service = new CodeBlueService();
    const activation = service.activate('pat-1', 'Ward 3', STAFF_A, new Date('2026-09-18T10:00:00Z'));
    const updated = service.recordFirstResponderArrival(activation.id, STAFF_B, new Date('2026-09-18T10:01:30Z'));
    expect(updated.responseTimeMinutes).toBe(1.5);
    expect(updated.metResponseTarget).toBe(true);
  });

  it('flags a G20 breach when first responder arrives after 2 minutes', () => {
    const service = new CodeBlueService();
    const activation = service.activate('pat-1', 'Ward 3', STAFF_A, new Date('2026-09-18T10:00:00Z'));
    const updated = service.recordFirstResponderArrival(activation.id, STAFF_B, new Date('2026-09-18T10:03:00Z'));
    expect(updated.responseTimeMinutes).toBe(3);
    expect(updated.metResponseTarget).toBe(false);
  });

  it('rejects a second first-responder recording', () => {
    const service = new CodeBlueService();
    const activation = service.activate('pat-1', 'Ward 3', STAFF_A);
    service.recordFirstResponderArrival(activation.id, STAFF_B);
    expect(() => service.recordFirstResponderArrival(activation.id, STAFF_B)).toThrow(/already recorded/);
  });

  it('rejects arrival time before activation time', () => {
    const service = new CodeBlueService();
    const activation = service.activate('pat-1', 'Ward 3', STAFF_A, new Date('2026-09-18T10:00:00Z'));
    expect(() =>
      service.recordFirstResponderArrival(activation.id, STAFF_B, new Date('2026-09-18T09:59:00Z')),
    ).toThrow(/cannot precede/);
  });

  it('logs the full clinical timeline and ends with an outcome', () => {
    const service = new CodeBlueService();
    const activation = service.activate('pat-1', 'Ward 3', STAFF_A);
    service.logEvent(activation.id, 'CPR_STARTED', STAFF_B);
    service.logEvent(activation.id, 'DEFIBRILLATION', STAFF_B, new Date(), '200J');
    const ended = service.end(activation.id, 'ROSC', STAFF_B);
    expect(ended.outcome).toBe('ROSC');
    expect(ended.events.map((e) => e.type)).toContain('ROSC');
  });

  it('rejects logging further events after the activation has ended', () => {
    const service = new CodeBlueService();
    const activation = service.activate('pat-1', 'Ward 3', STAFF_A);
    service.end(activation.id, 'DECEASED', STAFF_B);
    expect(() => service.logEvent(activation.id, 'DEBRIEF_NOTE', STAFF_B)).toThrow(/already ended/);
  });

  it('throws for an unknown activation id', () => {
    const service = new CodeBlueService();
    expect(() => service.getActivation('nope')).toThrow(CodeBlueError);
  });
});

describe('determineTraumaLevel', () => {
  it('returns NONE when no criteria are met', () => {
    expect(determineTraumaLevel(baseCriteria()).level).toBe('NONE');
  });

  it('returns LEVEL_1 for a physiologic criterion', () => {
    const result = determineTraumaLevel({ ...baseCriteria(), systolicBpBelow90: true });
    expect(result.level).toBe('LEVEL_1');
    expect(result.triggeredCriteria).toContain('Systolic BP < 90 mmHg');
  });

  it('returns LEVEL_1 for an anatomic criterion', () => {
    const result = determineTraumaLevel({ ...baseCriteria(), flailChest: true });
    expect(result.level).toBe('LEVEL_1');
  });

  it('returns LEVEL_2 when only a Level 2 criterion is met', () => {
    const result = determineTraumaLevel({ ...baseCriteria(), fallGreaterThan20Feet: true });
    expect(result.level).toBe('LEVEL_2');
  });

  it('Level 1 takes priority even if Level 2 criteria also present', () => {
    const result = determineTraumaLevel({ ...baseCriteria(), fallGreaterThan20Feet: true, glasgowComaScaleBelow9: true });
    expect(result.level).toBe('LEVEL_1');
  });

  it('collects multiple triggered criteria', () => {
    const result = determineTraumaLevel({ ...baseCriteria(), systolicBpBelow90: true, flailChest: true });
    expect(result.triggeredCriteria).toHaveLength(2);
  });
});

describe('trauma team activation', () => {
  it('pages the full 7-role team for LEVEL_1', () => {
    const activation = activateTraumaTeam('pat-1', 'LEVEL_1');
    expect(activation.pagedRoles).toHaveLength(7);
    expect(activation.pagedRoles).toContain('TRAUMA_SURGEON');
  });

  it('pages a smaller 3-role team for LEVEL_2', () => {
    const activation = activateTraumaTeam('pat-1', 'LEVEL_2');
    expect(activation.pagedRoles).toHaveLength(3);
  });

  it('records arrivals and detects full assembly', () => {
    let activation = activateTraumaTeam('pat-1', 'LEVEL_2');
    expect(isTeamFullyAssembled(activation)).toBe(false);
    activation = recordTeamMemberArrival(activation, 'TRAUMA_SURGEON', { userId: 'u1', name: 'Dr A' });
    activation = recordTeamMemberArrival(activation, 'EMERGENCY_PHYSICIAN', { userId: 'u2', name: 'Dr B' });
    expect(isTeamFullyAssembled(activation)).toBe(false);
    activation = recordTeamMemberArrival(activation, 'TRAUMA_NURSE', { userId: 'u3', name: 'RN C' });
    expect(isTeamFullyAssembled(activation)).toBe(true);
  });

  it('rejects arrival of a role that was not paged', () => {
    const activation = activateTraumaTeam('pat-1', 'LEVEL_2');
    expect(() => recordTeamMemberArrival(activation, 'RADIOLOGY_TECH', { userId: 'u1', name: 'Tech' })).toThrow(
      TraumaActivationError,
    );
  });

  it('rejects a duplicate arrival for the same role', () => {
    let activation = activateTraumaTeam('pat-1', 'LEVEL_2');
    activation = recordTeamMemberArrival(activation, 'TRAUMA_SURGEON', { userId: 'u1', name: 'Dr A' });
    expect(() => recordTeamMemberArrival(activation, 'TRAUMA_SURGEON', { userId: 'u1', name: 'Dr A' })).toThrow(
      /already been recorded/,
    );
  });
});

describe('ErQueue', () => {
  const t0 = new Date('2026-09-18T10:00:00Z');
  const t5 = new Date('2026-09-18T10:05:00Z');
  const t10 = new Date('2026-09-18T10:10:00Z');

  it('orders by urgency first, then arrival time (FIFO within same urgency)', () => {
    const queue = new ErQueue();
    queue.addPatient('p-low-early', t0, 5);
    queue.addPatient('p-high-late', t5, 1);
    queue.addPatient('p-high-early', t0, 1);

    const ordered = queue.getOrderedQueue().map((e) => e.patientId);
    expect(ordered).toEqual(['p-high-early', 'p-high-late', 'p-low-early']);
  });

  it('rejects adding the same patient twice', () => {
    const queue = new ErQueue();
    queue.addPatient('p1', t0, 1);
    expect(() => queue.addPatient('p1', t0, 1)).toThrow(ErQueueError);
  });

  it('computes wait time and transitions through call/complete', () => {
    const queue = new ErQueue();
    queue.addPatient('p1', t0, 1);
    expect(queue.getWaitTimeMinutes('p1', t5)).toBe(5);

    const called = queue.callPatient('p1', t10);
    expect(called.status).toBe('IN_TREATMENT');
    expect(queue.getWaitTimeMinutes('p1')).toBe(10); // fixed once called, regardless of "now"

    const completed = queue.complete('p1');
    expect(completed.status).toBe('COMPLETED');
  });

  it('rejects calling a patient not in WAITING status', () => {
    const queue = new ErQueue();
    queue.addPatient('p1', t0, 1);
    queue.callPatient('p1', t5);
    expect(() => queue.callPatient('p1', t10)).toThrow(/not WAITING/);
  });

  it('marks LWBS only from WAITING, and freezes wait time at LWBS moment', () => {
    const queue = new ErQueue();
    queue.addPatient('p1', t0, 3);
    const lwbs = queue.markLwbs('p1', t10);
    expect(lwbs.status).toBe('LWBS');
    expect(queue.getWaitTimeMinutes('p1', new Date('2026-09-18T11:00:00Z'))).toBe(10);
  });

  it('rejects marking LWBS on a patient already in treatment', () => {
    const queue = new ErQueue();
    queue.addPatient('p1', t0, 1);
    queue.callPatient('p1', t5);
    expect(() => queue.markLwbs('p1', t10)).toThrow(/not WAITING/);
  });

  it('identifies overdue-waiting patients past a threshold', () => {
    const queue = new ErQueue();
    queue.addPatient('p-fast', t0, 1);
    queue.addPatient('p-slow', new Date('2026-09-18T09:00:00Z'), 1);
    const overdue = queue.getOverdueWaiting(30, t10);
    expect(overdue.map((e) => e.patientId)).toEqual(['p-slow']);
  });

  it('throws for an unknown patient', () => {
    const queue = new ErQueue();
    expect(() => queue.getEntry('nope')).toThrow(ErQueueError);
  });
});

import {
  assignTriageLevel,
  getScaleLevels,
  compareUrgency,
  InvalidTriageInputError,
  MAX_MINUTES_TO_TRIAGE,
} from '../triage-scales';

describe('getScaleLevels', () => {
  it('returns 5 levels for ESI, CTAS, and Manchester', () => {
    expect(getScaleLevels('ESI')).toHaveLength(5);
    expect(getScaleLevels('CTAS')).toHaveLength(5);
    expect(getScaleLevels('MANCHESTER')).toHaveLength(5);
  });

  it('throws on an unknown scale', () => {
    expect(() => getScaleLevels('FOO' as any)).toThrow(InvalidTriageInputError);
  });
});

describe('assignTriageLevel', () => {
  const arrival = new Date('2026-09-18T10:00:00Z');

  it('assigns ESI level 1 with immediate (0 min) target', () => {
    const result = assignTriageLevel({
      scale: 'ESI',
      level: '1',
      arrivalTime: arrival,
      triageTime: new Date('2026-09-18T10:01:00Z'),
    });
    expect(result.definition.label).toBe('Resuscitation');
    expect(result.definition.targetMinutesToDoctor).toBe(0);
    expect(result.withinTargetTime).toBe(true); // 1 min <= 5 min target-to-triage
  });

  it('flags G19 breach when triage happens more than 5 minutes after arrival', () => {
    const result = assignTriageLevel({
      scale: 'ESI',
      level: '3',
      arrivalTime: arrival,
      triageTime: new Date('2026-09-18T10:12:00Z'), // 12 min later
    });
    expect(result.minutesToTriage).toBe(12);
    expect(result.withinTargetTime).toBe(false);
    expect(MAX_MINUTES_TO_TRIAGE).toBe(5);
  });

  it('supports Manchester color levels', () => {
    const result = assignTriageLevel({
      scale: 'MANCHESTER',
      level: 'ORANGE',
      arrivalTime: arrival,
      triageTime: new Date('2026-09-18T10:02:00Z'),
    });
    expect(result.definition.label).toBe('Very Urgent');
    expect(result.definition.targetMinutesToDoctor).toBe(10);
  });

  it('supports CTAS numeric levels distinct from ESI target times', () => {
    const ctas2 = assignTriageLevel({
      scale: 'CTAS',
      level: '2',
      arrivalTime: arrival,
      triageTime: new Date('2026-09-18T10:02:00Z'),
    });
    expect(ctas2.definition.targetMinutesToDoctor).toBe(15); // CTAS-2 differs from ESI-2 (10)
  });

  it('rejects an invalid level for a given scale', () => {
    expect(() =>
      assignTriageLevel({ scale: 'ESI', level: 'RED', arrivalTime: arrival, triageTime: arrival }),
    ).toThrow(/not valid for scale ESI/);
  });

  it('rejects triageTime before arrivalTime', () => {
    expect(() =>
      assignTriageLevel({
        scale: 'ESI',
        level: '2',
        arrivalTime: arrival,
        triageTime: new Date('2026-09-18T09:59:00Z'),
      }),
    ).toThrow(/cannot precede/);
  });

  it('computes targetDoctorByTime as triageTime + target minutes', () => {
    const result = assignTriageLevel({
      scale: 'ESI',
      level: '2',
      arrivalTime: arrival,
      triageTime: new Date('2026-09-18T10:03:00Z'),
    });
    expect(result.targetDoctorByTime.toISOString()).toBe('2026-09-18T10:13:00.000Z'); // +10 min
  });
});

describe('compareUrgency', () => {
  const arrival = new Date('2026-09-18T10:00:00Z');
  const t = (level: string, scale: 'ESI' | 'CTAS' | 'MANCHESTER' = 'ESI') =>
    assignTriageLevel({ scale, level, arrivalTime: arrival, triageTime: arrival });

  it('orders more urgent levels first regardless of scale', () => {
    const esi1 = t('1');
    const esi5 = t('5');
    expect(compareUrgency(esi1, esi5)).toBeLessThan(0);
    expect(compareUrgency(esi5, esi1)).toBeGreaterThan(0);
    expect(compareUrgency(esi1, esi1)).toBe(0);
  });

  it('compares across scales via rank', () => {
    const manchesterRed = t('RED', 'MANCHESTER'); // rank 1
    const esi5 = t('5'); // rank 5
    expect(compareUrgency(manchesterRed, esi5)).toBeLessThan(0);
  });
});

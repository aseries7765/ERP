/**
 * Trauma activation: determines the trauma team activation level from
 * documented physiologic/mechanism criteria (a simplified but real
 * subset of standard trauma triage criteria, e.g. ACS-COT field
 * triage guidelines), and tracks the team members paged for a given
 * activation, per ADR-0388.
 *
 * Scope honesty: this implements the common "Level 1 (full activation)
 * vs Level 2 (partial/limited activation)" two-tier model widely used
 * in US trauma centers, driven by a documented checklist of physiologic
 * and anatomic criteria. It does not implement a full ACS-COT-compliant
 * decision algorithm (which also weighs mechanism-of-injury and special
 * patient/system considerations more elaborately) — see MANIFEST.
 */

export class TraumaActivationError extends Error {}

export type TraumaLevel = 'LEVEL_1' | 'LEVEL_2' | 'NONE';

export interface TraumaCriteria {
  systolicBpBelow90: boolean;
  respiratoryRateAbnormal: boolean;
  glasgowComaScaleBelow9: boolean;
  penetratingInjuryToTorsoHeadNeck: boolean;
  flailChest: boolean;
  twoOrMoreProximalLongBoneFractures: boolean;
  amputationProximalToWristOrAnkle: boolean;
  fallGreaterThan20Feet: boolean;
  highRiskMechanism: boolean;
  ageOver65WithSignificantMechanism: boolean;
}

export interface TraumaActivationResult {
  level: TraumaLevel;
  triggeredCriteria: string[];
}

/**
 * Determines the trauma activation level from documented criteria.
 * Level 1 (full team activation) takes priority over Level 2: if any
 * Level 1 criterion is present, the result is LEVEL_1 regardless of
 * which Level 2 criteria are also present.
 */
export function determineTraumaLevel(criteria: TraumaCriteria): TraumaActivationResult {
  const level1Triggers: Array<[keyof TraumaCriteria, string]> = [
    ['systolicBpBelow90', 'Systolic BP < 90 mmHg'],
    ['respiratoryRateAbnormal', 'Respiratory rate < 10 or > 29/min'],
    ['glasgowComaScaleBelow9', 'GCS < 9'],
    ['penetratingInjuryToTorsoHeadNeck', 'Penetrating injury to torso/head/neck'],
    ['flailChest', 'Flail chest'],
    ['twoOrMoreProximalLongBoneFractures', 'Two or more proximal long-bone fractures'],
    ['amputationProximalToWristOrAnkle', 'Amputation proximal to wrist or ankle'],
  ];
  const level2Triggers: Array<[keyof TraumaCriteria, string]> = [
    ['fallGreaterThan20Feet', 'Fall > 20 feet'],
    ['highRiskMechanism', 'High-risk mechanism of injury'],
    ['ageOver65WithSignificantMechanism', 'Age > 65 with significant mechanism'],
  ];

  const level1Hits = level1Triggers.filter(([key]) => criteria[key]).map(([, label]) => label);
  if (level1Hits.length > 0) {
    return { level: 'LEVEL_1', triggeredCriteria: level1Hits };
  }

  const level2Hits = level2Triggers.filter(([key]) => criteria[key]).map(([, label]) => label);
  if (level2Hits.length > 0) {
    return { level: 'LEVEL_2', triggeredCriteria: level2Hits };
  }

  return { level: 'NONE', triggeredCriteria: [] };
}

export type TraumaTeamRole =
  | 'TRAUMA_SURGEON'
  | 'EMERGENCY_PHYSICIAN'
  | 'ANESTHESIOLOGIST'
  | 'TRAUMA_NURSE'
  | 'RADIOLOGY_TECH'
  | 'BLOOD_BANK_LIAISON'
  | 'RESPIRATORY_THERAPIST';

const TEAM_COMPOSITION: Record<Exclude<TraumaLevel, 'NONE'>, TraumaTeamRole[]> = {
  LEVEL_1: [
    'TRAUMA_SURGEON',
    'EMERGENCY_PHYSICIAN',
    'ANESTHESIOLOGIST',
    'TRAUMA_NURSE',
    'RADIOLOGY_TECH',
    'BLOOD_BANK_LIAISON',
    'RESPIRATORY_THERAPIST',
  ],
  LEVEL_2: ['TRAUMA_SURGEON', 'EMERGENCY_PHYSICIAN', 'TRAUMA_NURSE'],
};

export interface TraumaActivation {
  id: string;
  patientId: string;
  level: Exclude<TraumaLevel, 'NONE'>;
  activatedAt: Date;
  pagedRoles: TraumaTeamRole[];
  arrivals: Array<{ role: TraumaTeamRole; userId: string; name: string; arrivedAt: Date }>;
}

let idCounter = 0;
function nextId(prefix: string): string {
  idCounter += 1;
  return `${prefix}_${idCounter}`;
}

export function activateTraumaTeam(
  patientId: string,
  level: Exclude<TraumaLevel, 'NONE'>,
  now: Date = new Date(),
): TraumaActivation {
  if (!patientId) throw new TraumaActivationError('patientId is required.');
  return {
    id: nextId('trauma'),
    patientId,
    level,
    activatedAt: now,
    pagedRoles: [...TEAM_COMPOSITION[level]],
    arrivals: [],
  };
}

export function recordTeamMemberArrival(
  activation: TraumaActivation,
  role: TraumaTeamRole,
  member: { userId: string; name: string },
  now: Date = new Date(),
): TraumaActivation {
  if (!activation.pagedRoles.includes(role)) {
    throw new TraumaActivationError(`Role ${role} was not paged for this ${activation.level} activation.`);
  }
  if (activation.arrivals.some((a) => a.role === role)) {
    throw new TraumaActivationError(`Role ${role} has already been recorded as arrived.`);
  }
  return {
    ...activation,
    arrivals: [...activation.arrivals, { role, ...member, arrivedAt: now }],
  };
}

export function isTeamFullyAssembled(activation: TraumaActivation): boolean {
  return activation.pagedRoles.every((role) => activation.arrivals.some((a) => a.role === role));
}

# Stage 29 — `@erp/security` Source Reconstruction

Implemented the missing `@erp/security` workspace package from the existing API imports and security documentation contracts. The package provides password/input validators, HIBP response matching helper, CSRF token issue/verification with session-bound HMAC, trusted-origin checking, security headers/CSP nonce support, SQLi anomaly heuristic, and the documented in-process brute-force detector/progressive delay.

## Verification

- Package TypeScript static typecheck: PASS.
- API contract imports now have concrete package exports.
- CSRF token is bound to session ID and secret; comparison is timing-safe.
- Security header unit contract is covered.
- Brute-force thresholds and delay cap are covered.
- Runtime Nest/PostgreSQL/Redis verification: NOT RUN; environment lacks the required dependency/runtime services.

## Important limitation

The brute-force detector remains in-memory by design, matching the existing documentation. Multi-instance production deployment must use a shared Redis-backed implementation before production claims are made.

The HIBP helper does not perform network calls; callers must perform the HIBP k-anonymity request and pass the response suffixes to the pure function.

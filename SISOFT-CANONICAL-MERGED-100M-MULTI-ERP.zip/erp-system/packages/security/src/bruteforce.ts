type Failure={at:number};
export interface FailureOutcome{locked:boolean;lockedUntilMs?:number;}
export class BruteForceDetector{private accounts=new Map<string,Failure[]>();private ips=new Map<string,Failure[]>();private locked=new Map<string,number>();private readonly windowMs=15*60_000;private readonly accountLimit=5;private readonly ipLimit=20;private prune(a:Failure[],now:number){return a.filter(x=>x.at>now-this.windowMs)}
recordFailure(accountKey:string,ip:string,now=Date.now()):FailureOutcome{let aa=this.prune(this.accounts.get(accountKey)??[],now);aa.push({at:now});this.accounts.set(accountKey,aa);let ii=this.prune(this.ips.get(ip)??[],now);ii.push({at:now});this.ips.set(ip,ii);if(aa.length>=this.accountLimit){const until=now+this.windowMs;this.locked.set(accountKey,until);return {locked:true,lockedUntilMs:until};}return {locked:false};}
isIpBlocked(ip:string,now=Date.now()){const ii=this.prune(this.ips.get(ip)??[],now);this.ips.set(ip,ii);return ii.length>=this.ipLimit;}
clearOnSuccess(accountKey:string){this.accounts.delete(accountKey);this.locked.delete(accountKey);}
isAccountLocked(accountKey:string,now=Date.now()){const until=this.locked.get(accountKey)??0;if(until<=now){this.locked.delete(accountKey);return false;}return true;}}
export function progressiveDelayMs(failures:number):number{return Math.min(30_000,1000*2**Math.max(0,Math.min(5,failures-1)));}

const SQLI=/(?:\bunion\s+(?:all\s+)?select\b|;\s*(?:drop|alter|truncate|delete|update|insert)\b|--\s*(?:$|\S)|\/\*|\*\/)/i;
export function looksLikeSqlInjection(value:unknown):boolean{return typeof value==='string'&&SQLI.test(value);}

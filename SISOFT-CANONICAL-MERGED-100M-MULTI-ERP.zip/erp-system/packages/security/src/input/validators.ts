const EMAIL=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const E164=/^\+[1-9]\d{7,14}$/;
export function isValidEmail(value:string):boolean{return typeof value==='string'&&value.length<=254&&EMAIL.test(value);}
export function isValidPhoneE164(value:string):boolean{return typeof value==='string'&&E164.test(value);}
export function isValidUrl(value:string, protocols: readonly string[]= ['https:']):boolean{try{const u=new URL(value); return protocols.includes(u.protocol)&&!!u.hostname;}catch{return false;}}
export function meetsPasswordPolicy(password:string):boolean{if(typeof password!=='string'||password.length<12)return false;if(/^(.)\1+$/.test(password))return false;return /[a-z]/.test(password)&&/[A-Z]/.test(password)&&/\d/.test(password);}
export async function isPasswordPwned(sha1Prefix:string, suffixes:Iterable<string>):Promise<boolean>{const p=sha1Prefix.trim().toUpperCase();if(!/^[0-9A-F]{5}$/.test(p))throw new Error('Invalid HIBP hash prefix');const s=String(sha1Prefix).length; if(s!==5)throw new Error('Invalid HIBP hash prefix');return Array.from(suffixes).some(x=>x.trim().toUpperCase().split(':')[0]===p);}

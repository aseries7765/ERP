export type CountryCode = 'PK'|'SA'|'IN'|'US';
export type ImplementationStatus = 'FULL'|'PARTIAL';
export interface EmployeeTaxProfile { employeeId:string; countryCode:CountryCode; isNational:boolean; isResident:boolean; stateCode?:string; taxRegime?:string; dateOfJoining:string; annualBasic:number; }
export interface TaxCalculationInput { profile:EmployeeTaxProfile; monthlyTaxableGross:number; ytdTaxableGross:number; ytdTaxWithheld:number; taxYear:number; }
export interface TaxCalculationResult { periodTax:number; annualizedTax:number; approximate:boolean; notes?:string[]; }
export interface StatutoryContributionInput { profile:EmployeeTaxProfile; monthlyGross:number; monthlyBasic:number; options?:Record<string,unknown>; }
export interface StatutoryLine { schemeCode:string; schemeName:string; employeeAmount:number; employerAmount:number; taxableBase:number; }
export interface StatutoryContributionResult { lines:StatutoryLine[]; approximate:boolean; notes?:string[]; }
export interface StatutoryReportInput { periodStart:string; periodEnd:string; employerRegistrationNumber:string; lines:Array<{employee:EmployeeTaxProfile; grossPay:number; taxWithheld:number; statutory:StatutoryLine[]}>; }
export interface StatutoryReportOutput { reportCode:string; fileName:string; content:string; generatedAt:string; }
export interface LaborLawRules { countryCode:CountryCode; standardWeeklyHours:number; maxWeeklyHoursWithOvertime?:number; minAnnualLeaveDays:number; noticePeriodDaysDefault?:number; gratuityApplicable:boolean; calculateGratuity?: (years:number, monthlyBasic:number)=>number; }
export interface CountryPayrollPlugin { countryCode:CountryCode; displayName:string; implementationStatus:ImplementationStatus; calculateTax(i:TaxCalculationInput):TaxCalculationResult; calculateStatutoryContributions(i:StatutoryContributionInput):StatutoryContributionResult; generateStatutoryReport(i:StatutoryReportInput):StatutoryReportOutput; getLaborLawRules():LaborLawRules; }
export function money(n:number):number { if(!Number.isFinite(n)||n<0) throw new Error('Payroll plugin monetary input must be a finite non-negative number'); return Math.round((n+Number.EPSILON)*100)/100; }
export function assertProfile(p:EmployeeTaxProfile, code:CountryCode):void { if(p.countryCode!==code) throw new Error(`Plugin ${code} cannot calculate profile for ${p.countryCode}`); }
export function report(code:string,i:StatutoryReportInput):StatutoryReportOutput { const payload={reportCode:code,periodStart:i.periodStart,periodEnd:i.periodEnd,employerRegistrationNumber:i.employerRegistrationNumber,lines:i.lines}; return {reportCode:code,fileName:`${code}-${i.periodStart}-${i.periodEnd}.json`,content:JSON.stringify(payload),generatedAt:new Date().toISOString()}; }

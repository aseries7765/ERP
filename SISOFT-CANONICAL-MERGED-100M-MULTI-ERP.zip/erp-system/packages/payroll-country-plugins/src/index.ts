export * from './types'; export * from './pk'; export * from './sa'; export * from './in'; export * from './us';
export type SupportedCountry='PK'|'SA'|'IN'|'US';
export function getCountryPlugin(code:SupportedCountry){switch(code){case 'PK':return pkPlugin;case 'SA':return saPlugin;case 'IN':return inPlugin;case 'US':return usPlugin;default:throw new Error(`Unsupported payroll country: ${code}`);}}
import {pkPlugin} from './pk'; import {saPlugin} from './sa'; import {inPlugin} from './in'; import {usPlugin} from './us';

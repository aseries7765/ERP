/**
 * UK 2026/27 standard non-savings employment income bands for England,
 * Wales and Northern Ireland. Scotland uses separate income-tax bands.
 * Source: HMRC rates and allowances, updated 6 April 2026.
 */
export const UK_EWNI_BANDS_2026_27 = [
  { code: 'PERSONAL_ALLOWANCE', from: 0, to: 12570, rate: 0 },
  { code: 'BASIC', from: 12570.01, to: 50270, rate: 0.20 },
  { code: 'HIGHER', from: 50270.01, to: 125140, rate: 0.40 },
  { code: 'ADDITIONAL', from: 125140.01, to: null, rate: 0.45 },
] as const;

# UK tax reference data

This directory supplies the 2026/27 England, Wales and Northern Ireland standard PAYE income-tax slab table consumed by the existing tax-slab seed. It is reference data only; a full UK payroll plugin (including Scotland, NIC, tax codes and PAYE edge cases) is not claimed by this stage.

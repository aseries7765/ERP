export const PK_SALARIED_TAX_SLABS_FY2026_27 = [
 {from:0,to:600000,rate:0}, {from:600000,to:1200000,rate:1}, {from:1200000,to:2200000,rate:11}, {from:2200000,to:3200000,rate:23}, {from:3200000,to:4100000,rate:30}, {from:4100000,to:7000000,rate:35}, {from:7000000,to:Infinity,rate:35}
] as const;
export function computeAnnualTaxPK(income:number):number { if(income<=600000)return 0; if(income<=1200000)return (income-600000)*.01; if(income<=2400000)return 6000+(income-1200000)*.125; if(income<=3200000)return 156000+(income-2400000)*.23; if(income<=4100000)return 340000+(income-3200000)*.30; if(income<=7000000)return 610000+(income-4100000)*.35; return 1_625_000+(income-7000000)*.35; }
export function marginalRatePK(income:number):number { if(income<=600000)return 0; if(income<=1200000)return 1; if(income<=2400000)return 12.5; if(income<=3200000)return 23; if(income<=4100000)return 30; return 35; }

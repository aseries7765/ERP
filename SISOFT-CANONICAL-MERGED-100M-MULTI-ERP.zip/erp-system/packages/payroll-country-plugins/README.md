# @erp/payroll-country-plugins

Country-specific payroll contracts used by Sisoft payroll. The package intentionally distinguishes FULL from PARTIAL implementations. A PARTIAL plugin must surface `approximate: true` and document its unsupported scope rather than silently presenting an estimate as statutory-complete.

Currently supported: PK, SA, IN, US.


## Stage 34 integration note
The existing API tax-slab seed also imports `UK_EWNI_BANDS_2026_27`; the 2026/27 England/Wales/Northern Ireland reference table is now present under `src/uk/tax-slabs.ts`. This is reference data only and does not make the UK a full payroll plugin.

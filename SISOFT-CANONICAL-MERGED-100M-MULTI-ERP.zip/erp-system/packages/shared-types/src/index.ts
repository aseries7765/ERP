export * from './reports.js';

/** UUID-like identifier used across service boundaries without runtime coupling. */
export type EntityId = string;

/** Tenant boundary carried by application services and workers. */
export interface TenantContext {
  tenantId: EntityId;
}

/** Authenticated actor boundary; roles remain opaque to shared packages. */
export interface ActorContext extends TenantContext {
  userId: EntityId;
  roles?: readonly string[];
}

/** Cursor pagination contract used by list APIs. */
export interface CursorPageRequest {
  limit?: number;
  cursor?: string;
}

export interface CursorPage<T> {
  data: readonly T[];
  nextCursor?: string | null;
}

/** Stable cross-package DTO contract for report execution results. */
export type ReportExecutionStatus = 'succeeded' | 'failed';

export type ReportRow = Record<string, unknown>;

export interface ReportExecutionResultDto {
  executionId: string;
  reportId: string;
  status: ReportExecutionStatus;
  rowCount?: number;
  columns?: string[];
  rows?: ReportRow[];
  cached: boolean;
  durationMs: number;
  executedAt: string;
  error?: string;
}

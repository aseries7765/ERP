import { DicomElement } from './types';
import {
  TAG_PATIENT_NAME,
  TAG_PATIENT_ID,
  TAG_PATIENT_BIRTH_DATE,
  TAG_PATIENT_SEX,
  TAG_REFERRING_PHYSICIAN_NAME,
  TAG_INSTITUTION_NAME,
  TAG_PATIENT_ADDRESS,
  TAG_ACCESSION_NUMBER,
} from './types';

/**
 * Default anonymization policy: tags that directly identify a patient
 * or referring clinician, per the DICOM PS3.15 "Basic Application
 * Level Confidentiality Profile" (a well-known subset, not the full
 * profile — see MANIFEST for exactly which tags are covered vs the
 * ~50+ tags in the full DICOM standard profile).
 *
 * - REMOVE: dropped from the output entirely.
 * - BLANK: replaced with an empty value of the same VR (keeps the
 *   element present, which some downstream consumers expect, but with
 *   no identifying content).
 * - REPLACE_WITH: replaced with a fixed research-safe placeholder.
 */
export type AnonymizationAction =
  | { type: 'REMOVE' }
  | { type: 'BLANK' }
  | { type: 'REPLACE_WITH'; value: string };

export type AnonymizationPolicy = Map<number, AnonymizationAction>;

export function defaultAnonymizationPolicy(): AnonymizationPolicy {
  return new Map<number, AnonymizationAction>([
    [TAG_PATIENT_NAME, { type: 'REPLACE_WITH', value: 'ANONYMOUS' }],
    [TAG_PATIENT_ID, { type: 'REPLACE_WITH', value: 'ANON-ID' }],
    [TAG_PATIENT_BIRTH_DATE, { type: 'BLANK' }],
    [TAG_PATIENT_SEX, { type: 'BLANK' }],
    [TAG_REFERRING_PHYSICIAN_NAME, { type: 'REMOVE' }],
    [TAG_INSTITUTION_NAME, { type: 'REMOVE' }],
    [TAG_PATIENT_ADDRESS, { type: 'REMOVE' }],
    [TAG_ACCESSION_NUMBER, { type: 'REMOVE' }],
  ]);
}

/**
 * Applies an anonymization policy to a dataset, returning a NEW array
 * (does not mutate the input) with identifying elements removed,
 * blanked, or replaced. Elements not covered by the policy pass
 * through unchanged — this is a deliberate default-allow design since
 * a default-deny (only pass explicitly-approved tags) would drop
 * clinically necessary data this HIS hasn't classified yet; the policy
 * map is the enforcement point, and expanding its coverage is a config
 * change, not a code change.
 */
export function anonymize(
  elements: DicomElement[],
  policy: AnonymizationPolicy = defaultAnonymizationPolicy(),
): DicomElement[] {
  const result: DicomElement[] = [];

  for (const el of elements) {
    const action = policy.get(el.tag);
    if (!action) {
      result.push(el);
      continue;
    }

    if (action.type === 'REMOVE') {
      continue;
    }
    if (action.type === 'BLANK') {
      result.push({ ...el, rawValue: Buffer.alloc(0) });
      continue;
    }
    // REPLACE_WITH: DICOM string values must stay even-length (pad with a space if odd).
    const padded = action.value.length % 2 === 0 ? action.value : action.value + ' ';
    result.push({ ...el, rawValue: Buffer.from(padded, 'ascii') });
  }

  return result;
}

/**
 * Convenience audit check: true if the dataset still contains
 * elements that the policy says should have been removed or blanked.
 * (REPLACE_WITH tags are expected to still be present by design, so
 * they are not flagged here.)
 */
export function containsIdentifyingData(
  elements: DicomElement[],
  policy: AnonymizationPolicy = defaultAnonymizationPolicy(),
): boolean {
  for (const el of elements) {
    const action = policy.get(el.tag);
    if (!action) continue;
    if (action.type === 'REMOVE') return true; // should have been dropped, not present
    if (action.type === 'BLANK' && el.rawValue.length > 0) return true; // should have been emptied
  }
  return false;
}

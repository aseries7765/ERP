import {
  parseDataset,
  parseDicomFile,
  findElement,
  decodeString,
  getString,
} from '../dicom-parser';
import { anonymize, containsIdentifyingData, defaultAnonymizationPolicy } from '../anonymizer';
import {
  DicomTag,
  ValueRepresentation,
  SHORT_LENGTH_VRS,
  TAG_PATIENT_NAME,
  TAG_PATIENT_ID,
  DicomParseError,
  TAG_PATIENT_BIRTH_DATE,
  TAG_MODALITY,
  TAG_STUDY_INSTANCE_UID,
} from '../types';

/**
 * Test helper: encodes one Explicit VR Little Endian data element into
 * bytes, mirroring the real DICOM wire format this parser reads. This
 * is test scaffolding, not a shipped encoder (the package does not yet
 * include a general DICOM encoder — see MANIFEST).
 */
function encodeElement(group: number, element: number, vr: ValueRepresentation, value: string | Buffer): Buffer {
  const raw = Buffer.isBuffer(value) ? value : Buffer.from(value, 'ascii');
  const padded = raw.length % 2 === 0 ? raw : Buffer.concat([raw, Buffer.from(vr === 'PN' || vr === 'LO' || vr === 'SH' || vr === 'UI' || vr === 'CS' || vr === 'DA' ? ' ' : '\x00')]);

  const tagBuf = Buffer.alloc(4);
  tagBuf.writeUInt16LE(group, 0);
  tagBuf.writeUInt16LE(element, 2);
  const vrBuf = Buffer.from(vr, 'ascii');

  if (SHORT_LENGTH_VRS.has(vr)) {
    const lenBuf = Buffer.alloc(2);
    lenBuf.writeUInt16LE(padded.length, 0);
    return Buffer.concat([tagBuf, vrBuf, lenBuf, padded]);
  }
  const reservedBuf = Buffer.alloc(2); // 0x0000
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32LE(padded.length, 0);
  return Buffer.concat([tagBuf, vrBuf, reservedBuf, lenBuf, padded]);
}

function buildDataset(elements: Array<[number, number, ValueRepresentation, string]>): Buffer {
  return Buffer.concat(elements.map(([g, e, vr, v]) => encodeElement(g, e, vr, v)));
}

describe('parseDataset', () => {
  it('parses a simple dataset with short-length VRs', () => {
    const buf = buildDataset([
      [0x0010, 0x0010, 'PN', 'Doe^John'],
      [0x0010, 0x0020, 'LO', 'MRN12345'],
      [0x0008, 0x0060, 'CS', 'CT'],
    ]);
    const elements = parseDataset(buf);
    expect(elements).toHaveLength(3);
    expect(getString(elements, TAG_PATIENT_NAME)).toBe('Doe^John');
    expect(getString(elements, TAG_PATIENT_ID)).toBe('MRN12345');
    expect(getString(elements, TAG_MODALITY)).toBe('CT');
  });

  it('parses long-form (OB) elements without decoding them as text', () => {
    const pixelData = Buffer.from([0x01, 0x02, 0x03, 0x04]);
    const buf = buildDataset([[0x0008, 0x0060, 'CS', 'CT']]);
    const withPixels = Buffer.concat([buf, encodeElement(0x7fe0, 0x0010, 'OB', pixelData)]);
    const elements = parseDataset(withPixels);
    const pixelElement = findElement(elements, (0x7fe0 << 16) | 0x0010);
    expect(pixelElement).toBeDefined();
    expect(pixelElement!.vr).toBe('OB');
    expect(pixelElement!.rawValue).toEqual(pixelData);
    expect(() => decodeString(pixelElement)).toThrow(/Cannot decode VR OB/);
  });

  it('handles an odd-length value correctly since encodeElement pads to even length', () => {
    const buf = buildDataset([[0x0008, 0x0060, 'CS', 'CT']]); // 'CT' is already even length
    const elements = parseDataset(buf);
    expect(getString(elements, TAG_MODALITY)).toBe('CT');
  });

  it('throws on a truncated element (not enough bytes for tag+VR+length)', () => {
    const buf = buildDataset([[0x0010, 0x0010, 'PN', 'Doe']]);
    expect(() => parseDataset(buf.subarray(0, 5))).toThrow(DicomParseError);
  });

  it('throws on an unrecognized VR', () => {
    const tagBuf = Buffer.alloc(4);
    tagBuf.writeUInt16LE(0x0010, 0); // group
    tagBuf.writeUInt16LE(0x0010, 2); // element
    const bogus = Buffer.concat([tagBuf, Buffer.from('ZZ', 'ascii'), Buffer.from([0x02, 0x00]), Buffer.from('AB')]);
    expect(() => parseDataset(bogus)).toThrow(/Unrecognized or unsupported VR "ZZ"/);
  });

  it('throws when declared length exceeds remaining buffer', () => {
    const el = encodeElement(0x0010, 0x0010, 'LO', 'MRN12345');
    const truncated = el.subarray(0, el.length - 2); // chop off part of the value
    expect(() => parseDataset(truncated)).toThrow(/claims length/);
  });

  it('rejects undefined length (0xFFFFFFFF) as out of scope', () => {
    const tagBuf = Buffer.alloc(4);
    tagBuf.writeUInt16LE(0x0008, 0);
    tagBuf.writeUInt16LE(0x0000, 2);
    const reserved = Buffer.alloc(2);
    const lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32LE(0xffffffff, 0);
    const el = Buffer.concat([tagBuf, Buffer.from('SQ', 'ascii'), reserved, lenBuf]);
    expect(() => parseDataset(el)).toThrow(/Undefined length/);
  });
});

describe('parseDicomFile', () => {
  function buildFile(datasetElements: Array<[number, number, ValueRepresentation, string]>): Buffer {
    const preamble = Buffer.alloc(128, 0);
    const magic = Buffer.from('DICM', 'ascii');
    const metaGroup = Buffer.concat([
      encodeElement(0x0002, 0x0010, 'UI', '1.2.840.10008.1.2.1'), // Explicit VR LE
    ]);
    const dataset = buildDataset(datasetElements);
    return Buffer.concat([preamble, magic, metaGroup, dataset]);
  }

  it('parses a well-formed file: preamble, magic, meta group, and dataset', () => {
    const file = buildFile([
      [0x0010, 0x0010, 'PN', 'Doe^John'],
      [0x0020, 0x000d, 'UI', '1.2.3.4.5'],
      [0x0008, 0x0060, 'CS', 'MR'],
    ]);
    const parsed = parseDicomFile(file);
    expect(parsed.transferSyntaxUid).toBe('1.2.840.10008.1.2.1');
    expect(getString(parsed.datasetElements, TAG_PATIENT_NAME)).toBe('Doe^John');
    expect(getString(parsed.datasetElements, TAG_STUDY_INSTANCE_UID)).toBe('1.2.3.4.5');
    expect(getString(parsed.datasetElements, TAG_MODALITY)).toBe('MR');
  });

  it('rejects a file missing the DICM magic', () => {
    const bad = Buffer.concat([Buffer.alloc(128, 0), Buffer.from('NOPE', 'ascii')]);
    expect(() => parseDicomFile(bad)).toThrow(/Missing "DICM" magic/);
  });

  it('rejects an unsupported transfer syntax', () => {
    const preamble = Buffer.alloc(128, 0);
    const magic = Buffer.from('DICM', 'ascii');
    const metaGroup = encodeElement(0x0002, 0x0010, 'UI', '1.2.840.10008.1.2'); // Implicit VR LE — unsupported
    const file = Buffer.concat([preamble, magic, metaGroup]);
    expect(() => parseDicomFile(file)).toThrow(/Unsupported transfer syntax/);
  });

  it('rejects a buffer too short to be a DICOM file', () => {
    expect(() => parseDicomFile(Buffer.alloc(10))).toThrow(/too short/);
  });
});

describe('anonymize', () => {
  const original = buildDataset([
    [0x0010, 0x0010, 'PN', 'Doe^John'],
    [0x0010, 0x0020, 'LO', 'MRN12345'],
    [0x0010, 0x0030, 'DA', '19800115'],
    [0x0008, 0x0060, 'CS', 'CT'], // not identifying, should pass through
    [0x0008, 0x0090, 'PN', 'Smith^Jane'], // referring physician
  ]);

  it('replaces, blanks, and removes tags per the default policy, leaving clinical tags untouched', () => {
    const elements = parseDataset(original);
    const anonymized = anonymize(elements);

    expect(getString(anonymized, TAG_PATIENT_NAME)).toBe('ANONYMOUS');
    expect(getString(anonymized, TAG_PATIENT_ID)).toBe('ANON-ID');
    expect(findElement(anonymized, TAG_PATIENT_BIRTH_DATE)?.rawValue.length).toBe(0);
    expect(getString(anonymized, TAG_MODALITY)).toBe('CT'); // untouched
    expect(findElement(anonymized, (0x0008 << 16) | 0x0090)).toBeUndefined(); // referring physician removed
  });

  it('does not mutate the input array', () => {
    const elements = parseDataset(original);
    const before = JSON.stringify(elements.map((e) => [e.tag, e.rawValue.toString('hex')]));
    anonymize(elements);
    const after = JSON.stringify(elements.map((e) => [e.tag, e.rawValue.toString('hex')]));
    expect(after).toBe(before);
  });

  it('containsIdentifyingData correctly flags an unanonymized dataset and clears after anonymizing', () => {
    const elements = parseDataset(original);
    expect(containsIdentifyingData(elements)).toBe(true); // referring physician present = should-be-removed tag present
    const anonymized = anonymize(elements);
    expect(containsIdentifyingData(anonymized)).toBe(false);
  });

  it('keeps DICOM value length even after REPLACE_WITH substitution', () => {
    const elements = parseDataset(buildDataset([[0x0010, 0x0010, 'PN', 'X']]));
    const policy = defaultAnonymizationPolicy();
    policy.set(TAG_PATIENT_NAME, { type: 'REPLACE_WITH', value: 'ODD' }); // 3 chars, odd length
    const anonymized = anonymize(elements, policy);
    const el = findElement(anonymized, TAG_PATIENT_NAME)!;
    expect(el.rawValue.length % 2).toBe(0);
  });
});

import {
  DicomElement,
  DicomParseError,
  DicomTag,
  SHORT_LENGTH_VRS,
  ValueRepresentation,
  makeTag,
  tagToString,
} from './types';

const RECOGNIZED_VRS: ReadonlySet<string> = new Set([
  'UI', 'SH', 'LO', 'PN', 'DA', 'TM', 'CS', 'IS', 'US', 'UL', 'SQ', 'OB', 'UN',
]);

/**
 * Parses a DICOM dataset (a sequence of data elements) encoded in
 * Explicit VR Little Endian — by far the most common transfer syntax
 * in practice and the one this parser supports.
 *
 * Scope honesty: this does NOT support Implicit VR Little Endian,
 * Big Endian, or compressed transfer syntaxes (JPEG, RLE, etc.) — see
 * MANIFEST. SQ (sequence) elements are recognized structurally (their
 * length is read correctly so parsing doesn't desync) but their nested
 * contents are not recursively decoded; SQ values are kept as raw
 * bytes. OB (e.g. pixel data) is likewise kept raw, never decoded as
 * text.
 */
export function parseDataset(buffer: Buffer): DicomElement[] {
  const elements: DicomElement[] = [];
  let offset = 0;

  while (offset < buffer.length) {
    if (offset + 8 > buffer.length) {
      throw new DicomParseError(`Truncated data element at offset ${offset}: not enough bytes for tag+VR+length.`);
    }

    const group = buffer.readUInt16LE(offset);
    const element = buffer.readUInt16LE(offset + 2);
    const tag: DicomTag = makeTag(group, element);
    const vrString = buffer.toString('ascii', offset + 4, offset + 6);

    if (!RECOGNIZED_VRS.has(vrString)) {
      throw new DicomParseError(
        `Unrecognized or unsupported VR "${vrString}" for tag (${tagToString(tag)}) at offset ${offset}.`,
      );
    }
    const vr = vrString as ValueRepresentation;

    let length: number;
    let valueStart: number;

    if (SHORT_LENGTH_VRS.has(vr)) {
      length = buffer.readUInt16LE(offset + 6);
      valueStart = offset + 8;
    } else {
      // OB, SQ, UN: 2 reserved bytes then a 4-byte length.
      if (offset + 12 > buffer.length) {
        throw new DicomParseError(`Truncated long-form length header at offset ${offset} for VR ${vr}.`);
      }
      length = buffer.readUInt32LE(offset + 8);
      valueStart = offset + 12;
    }

    if (length === 0xffffffff) {
      throw new DicomParseError(
        `Undefined length (0xFFFFFFFF) at tag (${tagToString(tag)}) is not supported — requires sequence delimiter scanning, out of scope for this parser.`,
      );
    }

    const valueEnd = valueStart + length;
    if (valueEnd > buffer.length) {
      throw new DicomParseError(
        `Element value for tag (${tagToString(tag)}) claims length ${length} but only ${buffer.length - valueStart} bytes remain.`,
      );
    }

    elements.push({ tag, vr, rawValue: buffer.subarray(valueStart, valueEnd) });
    offset = valueEnd;
  }

  return elements;
}

/** Finds the first element with the given tag, or undefined. */
export function findElement(elements: DicomElement[], tag: DicomTag): DicomElement | undefined {
  return elements.find((e) => e.tag === tag);
}

/**
 * Decodes a text-valued element (UI/SH/LO/PN/DA/TM/CS/IS) as an ASCII
 * string, trimming the trailing padding space/null DICOM uses to keep
 * values at even byte length.
 */
export function decodeString(element: DicomElement | undefined): string | undefined {
  if (!element) return undefined;
  if (element.vr === 'OB' || element.vr === 'SQ') {
    throw new DicomParseError(`Cannot decode VR ${element.vr} as a string.`);
  }
  return element.rawValue.toString('ascii').replace(/[\x00 ]+$/, '');
}

export function getString(elements: DicomElement[], tag: DicomTag): string | undefined {
  return decodeString(findElement(elements, tag));
}

/** File Meta Information group (0002,xxxx) is always Explicit VR Little Endian regardless of the dataset's own transfer syntax. */
const TRANSFER_SYNTAX_UID_TAG = makeTag(0x0002, 0x0010);
const EXPLICIT_VR_LITTLE_ENDIAN_UID = '1.2.840.10008.1.2.1';

export interface DicomFile {
  metaElements: DicomElement[];
  datasetElements: DicomElement[];
  transferSyntaxUid: string;
}

/**
 * Parses a full DICOM Part 10 file: 128-byte preamble, "DICM" magic,
 * the File Meta Information group, then the main dataset.
 *
 * Only datasets encoded in Explicit VR Little Endian are supported for
 * the main dataset (checked against the meta group's declared transfer
 * syntax UID); anything else throws a clear, honest error rather than
 * silently misparsing.
 */
export function parseDicomFile(buffer: Buffer): DicomFile {
  if (buffer.length < 132) {
    throw new DicomParseError('Buffer too short to be a DICOM Part 10 file (needs 128-byte preamble + "DICM").');
  }
  const magic = buffer.toString('ascii', 128, 132);
  if (magic !== 'DICM') {
    throw new DicomParseError(`Missing "DICM" magic at offset 128 (got "${magic}"). Not a valid DICOM Part 10 file.`);
  }

  // Meta group length is at (0002,0000), UL, immediately after the magic.
  // We parse forward from offset 132 and simply keep consuming elements
  // from group 0002 until we hit a non-0002 group, which marks the
  // start of the main dataset.
  let offset = 132;
  const metaElements: DicomElement[] = [];

  while (offset < buffer.length) {
    const group = buffer.readUInt16LE(offset);
    if (group !== 0x0002) break;

    const remaining = buffer.subarray(offset);
    const [element, consumed] = parseOneElement(remaining);
    metaElements.push(element);
    offset += consumed;
  }

  const transferSyntaxUid = getString(metaElements, TRANSFER_SYNTAX_UID_TAG);
  if (!transferSyntaxUid) {
    throw new DicomParseError('File Meta group is missing TransferSyntaxUID (0002,0010).');
  }
  if (transferSyntaxUid !== EXPLICIT_VR_LITTLE_ENDIAN_UID) {
    throw new DicomParseError(
      `Unsupported transfer syntax "${transferSyntaxUid}". Only Explicit VR Little Endian (${EXPLICIT_VR_LITTLE_ENDIAN_UID}) is supported by this parser.`,
    );
  }

  const datasetElements = parseDataset(buffer.subarray(offset));

  return { metaElements, datasetElements, transferSyntaxUid };
}

/** Parses exactly one element from the start of `buffer`, returning it plus how many bytes it consumed. Used for the meta-group scan, which must stop at the first non-0002 group rather than parsing the whole rest of the file in one pass. */
function parseOneElement(buffer: Buffer): [DicomElement, number] {
  const all = parseDataset(buffer.subarray(0, findFirstElementEnd(buffer)));
  return [all[0], findFirstElementEnd(buffer)];
}

/** Determines the byte length of the single data element starting at offset 0 of `buffer`, without parsing the rest of the buffer. */
function findFirstElementEnd(buffer: Buffer): number {
  if (buffer.length < 8) {
    throw new DicomParseError('Truncated data element while scanning file meta group.');
  }
  const vrString = buffer.toString('ascii', 4, 6);
  if (!RECOGNIZED_VRS.has(vrString)) {
    throw new DicomParseError(`Unrecognized VR "${vrString}" while scanning file meta group.`);
  }
  const vr = vrString as ValueRepresentation;
  if (SHORT_LENGTH_VRS.has(vr)) {
    const length = buffer.readUInt16LE(6);
    return 8 + length;
  }
  const length = buffer.readUInt32LE(8);
  return 12 + length;
}

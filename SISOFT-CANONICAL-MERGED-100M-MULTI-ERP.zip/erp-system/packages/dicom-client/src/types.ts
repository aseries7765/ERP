/**
 * DICOM tag = (group, element), conventionally written as "GGGG,EEEE" in
 * hex. We represent it internally as a single number (group << 16 |
 * element) for fast comparison/lookup, with helpers to go to/from the
 * hex string form.
 */
export type DicomTag = number;

export function makeTag(group: number, element: number): DicomTag {
  return (group << 16) | element;
}

export function tagToString(tag: DicomTag): string {
  const group = (tag >>> 16) & 0xffff;
  const element = tag & 0xffff;
  return `${group.toString(16).padStart(4, '0')},${element.toString(16).padStart(4, '0')}`;
}

/** Value Representations this parser understands (the common ones for the tags this HIS actually reads). */
export type ValueRepresentation =
  | 'UI' // Unique Identifier
  | 'SH' // Short String
  | 'LO' // Long String
  | 'PN' // Person Name
  | 'DA' // Date
  | 'TM' // Time
  | 'CS' // Code String
  | 'IS' // Integer String
  | 'US' // Unsigned Short
  | 'UL' // Unsigned Long
  | 'SQ' // Sequence (not decoded — see parser scope note)
  | 'OB' // Other Byte (pixel data etc. — not decoded, kept raw)
  | 'UN'; // Unknown

/** VRs that use a 2-byte length field (short form). All others in this parser use the 4-byte (long) form. */
export const SHORT_LENGTH_VRS: ReadonlySet<ValueRepresentation> = new Set([
  'UI', 'SH', 'LO', 'PN', 'DA', 'TM', 'CS', 'IS', 'US', 'UL',
]);

export interface DicomElement {
  tag: DicomTag;
  vr: ValueRepresentation;
  /** Raw bytes of the value, before string decoding. */
  rawValue: Buffer;
}

export class DicomParseError extends Error {}

// Well-known tags this HIS actually needs (spec: C-STORE header fields, anonymization).
export const TAG_PATIENT_NAME = makeTag(0x0010, 0x0010);
export const TAG_PATIENT_ID = makeTag(0x0010, 0x0020);
export const TAG_PATIENT_BIRTH_DATE = makeTag(0x0010, 0x0030);
export const TAG_PATIENT_SEX = makeTag(0x0010, 0x0040);
export const TAG_STUDY_INSTANCE_UID = makeTag(0x0020, 0x000d);
export const TAG_SERIES_INSTANCE_UID = makeTag(0x0020, 0x000e);
export const TAG_SOP_INSTANCE_UID = makeTag(0x0008, 0x0018);
export const TAG_SOP_CLASS_UID = makeTag(0x0008, 0x0016);
export const TAG_MODALITY = makeTag(0x0008, 0x0060);
export const TAG_STUDY_DATE = makeTag(0x0008, 0x0020);
export const TAG_ACCESSION_NUMBER = makeTag(0x0008, 0x0050);
export const TAG_REFERRING_PHYSICIAN_NAME = makeTag(0x0008, 0x0090);
export const TAG_INSTITUTION_NAME = makeTag(0x0008, 0x0080);
export const TAG_PATIENT_ADDRESS = makeTag(0x0010, 0x1040);

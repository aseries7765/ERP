import { parseMessage, findSegment, getField } from '../parser';
import { parseMsh } from '../segments/msh';
import { parsePid } from '../segments/pid';
import { classifyAdt } from '../messages/adt';
import { frameMllp, unframeMllp, MllpStreamReader, MllpFramingError } from '../mllp';
import { buildAck } from '../ack';
import { Hl7ParseError } from '../types';

// A representative ADT^A01 message, CR-delimited as on the wire.
const ADT_A01 =
  'MSH|^~\\&|REGSYS|HOSPITAL|HIS|HOSPITAL|20260918120000||ADT^A01|MSG00001|P|2.5.1\r' +
  'EVN|A01|20260918120000\r' +
  'PID|1||MRN12345^^^HOSPITAL^MR||Doe^John^Middle||19800115|M|||123 Main St^^Springfield^IL^62704^USA\r' +
  'PV1|1|I|WARD1^101^A|||||1234^Smith^Jane|||||||||||V001\r';

describe('parseMessage', () => {
  it('parses segments and self-declared delimiters', () => {
    const msg = parseMessage(ADT_A01);
    expect(msg.delimiters.field).toBe('|');
    expect(msg.delimiters.component).toBe('^');
    expect(msg.segments.map((s) => s.segmentId)).toEqual(['MSH', 'EVN', 'PID', 'PV1']);
  });

  it('accepts \\n and \\r\\n as segment terminators, not just \\r', () => {
    const withLF = ADT_A01.replace(/\r/g, '\n');
    const msg = parseMessage(withLF);
    expect(msg.segments).toHaveLength(4);

    const withCRLF = ADT_A01.replace(/\r/g, '\r\n');
    const msg2 = parseMessage(withCRLF);
    expect(msg2.segments).toHaveLength(4);
  });

  it('rejects empty input', () => {
    expect(() => parseMessage('')).toThrow(Hl7ParseError);
    expect(() => parseMessage('   ')).toThrow(Hl7ParseError);
  });

  it('rejects a message not starting with MSH', () => {
    expect(() => parseMessage('PID|1||MRN123\r')).toThrow(/must start with MSH/);
  });

  it('MSH field indices line up with the HL7 spec (MSH-9 = message type)', () => {
    const msg = parseMessage(ADT_A01);
    const msh = findSegment(msg, 'MSH')!;
    expect(getField(msh, 1)).toBe('|'); // MSH-1 is the field separator itself
    expect(getField(msh, 2)).toBe('^~\\&'); // MSH-2 encoding characters
    expect(getField(msh, 9)).toBe('ADT^A01');
    expect(getField(msh, 10)).toBe('MSG00001');
  });

  it('finds a segment that appears once and returns undefined for absent segments', () => {
    const msg = parseMessage(ADT_A01);
    expect(findSegment(msg, 'PID')).toBeDefined();
    expect(findSegment(msg, 'OBX')).toBeUndefined();
  });
});

describe('parseMsh', () => {
  it('extracts message type, trigger, routing, and control id', () => {
    const msg = parseMessage(ADT_A01);
    const msh = parseMsh(msg);
    expect(msh.messageType).toBe('ADT');
    expect(msh.triggerEvent).toBe('A01');
    expect(msh.sendingApplication).toBe('REGSYS');
    expect(msh.sendingFacility).toBe('HOSPITAL');
    expect(msh.messageControlId).toBe('MSG00001');
    expect(msh.processingId).toBe('P');
    expect(msh.versionId).toBe('2.5.1');
  });

  it('throws when MSH-9 is missing', () => {
    const bad = 'MSH|^~\\&|REGSYS|HOSPITAL|HIS|HOSPITAL|20260918120000|||MSG00001|P|2.5.1\r';
    const msg = parseMessage(bad);
    expect(() => parseMsh(msg)).toThrow(/MSH-9/);
  });
});

describe('parsePid', () => {
  it('extracts patient id, name, DOB, sex, and address', () => {
    const msg = parseMessage(ADT_A01);
    const pid = parsePid(msg);
    expect(pid.patientId).toBe('MRN12345');
    expect(pid.patientIdAssigningAuthority).toBe('HOSPITAL');
    expect(pid.lastName).toBe('Doe');
    expect(pid.firstName).toBe('John');
    expect(pid.middleName).toBe('Middle');
    expect(pid.dateOfBirth).toBe('19800115');
    expect(pid.sex).toBe('M');
    expect(pid.address).toEqual({
      street: '123 Main St',
      city: 'Springfield',
      state: 'IL',
      zip: '62704',
      country: 'USA',
    });
  });

  it('takes the first repetition when PID-3 repeats', () => {
    const withRepeat = ADT_A01.replace(
      'PID|1||MRN12345^^^HOSPITAL^MR||',
      'PID|1||MRN12345^^^HOSPITAL^MR~SSN999^^^SSA^SS||',
    );
    const msg = parseMessage(withRepeat);
    const pid = parsePid(msg);
    expect(pid.patientId).toBe('MRN12345');
  });

  it('throws when PID-5 has no last name', () => {
    const bad = ADT_A01.replace('Doe^John^Middle', '');
    const msg = parseMessage(bad);
    expect(() => parsePid(msg)).toThrow(/last name/);
  });

  it('throws when PID segment is missing entirely', () => {
    const noPid = 'MSH|^~\\&|REGSYS|HOSPITAL|HIS|HOSPITAL|20260918120000||ADT^A01|MSG00001|P|2.5.1\r';
    const msg = parseMessage(noPid);
    expect(() => parsePid(msg)).toThrow(/no PID segment/);
  });
});

describe('classifyAdt', () => {
  it('classifies A01 correctly with its meaning', () => {
    const msg = parseMessage(ADT_A01);
    const result = classifyAdt(msg);
    expect(result.trigger).toBe('A01');
    expect(result.meaning).toMatch(/Admit/);
  });

  it('rejects non-ADT message types', () => {
    const orm = ADT_A01.replace('ADT^A01', 'ORM^O01');
    const msg = parseMessage(orm);
    expect(() => classifyAdt(msg)).toThrow(/Not an ADT message/);
  });

  it('rejects unsupported ADT triggers (e.g. A09 merge events, out of scope)', () => {
    const a09 = ADT_A01.replace('ADT^A01', 'ADT^A09');
    const msg = parseMessage(a09);
    expect(() => classifyAdt(msg)).toThrow(/Unsupported ADT trigger/);
  });

  it('accepts all of A01 through A08', () => {
    for (const trigger of ['A01', 'A02', 'A03', 'A04', 'A05', 'A06', 'A07', 'A08']) {
      const variant = ADT_A01.replace('ADT^A01', `ADT^${trigger}`);
      const msg = parseMessage(variant);
      expect(classifyAdt(msg).trigger).toBe(trigger);
    }
  });
});

describe('MLLP framing', () => {
  it('round-trips frame/unframe', () => {
    const framed = frameMllp(ADT_A01);
    expect(framed[0]).toBe(0x0b);
    expect(framed[framed.length - 2]).toBe(0x1c);
    expect(framed[framed.length - 1]).toBe(0x0d);
    expect(unframeMllp(framed)).toBe(ADT_A01);
  });

  it('rejects a buffer missing proper framing', () => {
    expect(() => unframeMllp(Buffer.from('not framed'))).toThrow(MllpFramingError);
  });

  it('reassembles a message split across multiple TCP chunks', () => {
    const framed = frameMllp(ADT_A01);
    const received: string[] = [];
    const reader = new MllpStreamReader((m) => received.push(m));

    const mid = Math.floor(framed.length / 2);
    reader.push(framed.subarray(0, mid));
    expect(received).toHaveLength(0); // not complete yet
    expect(reader.hasPendingData()).toBe(true);

    reader.push(framed.subarray(mid));
    expect(received).toHaveLength(1);
    expect(received[0]).toBe(ADT_A01);
  });

  it('handles two full frames arriving in a single chunk', () => {
    const framed1 = frameMllp(ADT_A01);
    const framed2 = frameMllp(ADT_A01.replace('A01', 'A03'));
    const combined = Buffer.concat([framed1, framed2]);

    const received: string[] = [];
    const reader = new MllpStreamReader((m) => received.push(m));
    reader.push(combined);

    expect(received).toHaveLength(2);
    expect(received[1]).toContain('A03');
  });
});

describe('buildAck', () => {
  it('builds a structurally valid AA ack referencing the original control id', () => {
    const msg = parseMessage(ADT_A01);
    const msh = parseMsh(msg);
    const ack = buildAck({
      originalMsh: msh,
      ackCode: 'AA',
      respondingApplication: 'HIS',
      respondingFacility: 'HOSPITAL',
      ackControlId: 'ACK00001',
      now: new Date('2026-09-18T12:00:05Z'),
    });

    const ackMsg = parseMessage(ack);
    const ackMsh = parseMsh(ackMsg);
    expect(ackMsh.messageType).toBe('ACK');
    // The responding app becomes the sender of the ACK; original sender becomes receiver.
    expect(ackMsh.sendingApplication).toBe('HIS');
    expect(ackMsh.receivingApplication).toBe('REGSYS');

    const msa = findSegment(ackMsg, 'MSA')!;
    expect(getField(msa, 1)).toBe('AA');
    expect(getField(msa, 2)).toBe('MSG00001'); // references original control id
  });

  it('builds an AE (nak) with an error text message', () => {
    const msg = parseMessage(ADT_A01);
    const msh = parseMsh(msg);
    const nak = buildAck({
      originalMsh: msh,
      ackCode: 'AE',
      respondingApplication: 'HIS',
      respondingFacility: 'HOSPITAL',
      ackControlId: 'ACK00002',
      textMessage: 'Unknown patient facility',
    });
    const nakMsg = parseMessage(nak);
    const msa = findSegment(nakMsg, 'MSA')!;
    expect(getField(msa, 1)).toBe('AE');
    expect(getField(msa, 3)).toBe('Unknown patient facility');
  });
});

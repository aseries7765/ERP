/**
 * HL7 v2.x delimiters. HL7 messages declare their own encoding
 * characters in MSH-1 (field separator) and MSH-2 (the four encoding
 * characters: component, repetition, escape, subcomponent), so these
 * must always be read from the message itself rather than assumed —
 * this parser does that in parser.ts rather than hardcoding '|^~\&'.
 */
export interface Hl7Delimiters {
  field: string; // MSH-1, e.g. '|'
  component: string; // first char of MSH-2, e.g. '^'
  repetition: string; // second char of MSH-2, e.g. '~'
  escape: string; // third char of MSH-2, e.g. '\'
  subcomponent: string; // fourth char of MSH-2, e.g. '&'
}

export const DEFAULT_DELIMITERS: Hl7Delimiters = {
  field: '|',
  component: '^',
  repetition: '~',
  escape: '\\',
  subcomponent: '&',
};

/** A single HL7 segment: its 3-letter ID plus raw field strings (field 0 is the segment ID itself, per HL7 convention field indices start at 1 for the first data field). */
export interface Hl7Segment {
  segmentId: string;
  /** rawFields[0] is always the segment ID; data fields start at index 1, matching HL7 field-numbering convention (SEG-1, SEG-2, ...). */
  rawFields: string[];
}

export class Hl7ParseError extends Error {}

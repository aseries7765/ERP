import { DEFAULT_DELIMITERS, Hl7Delimiters, Hl7ParseError, Hl7Segment } from './types';

/** A fully parsed HL7 message: its delimiters plus ordered segments. */
export interface Hl7Message {
  delimiters: Hl7Delimiters;
  segments: Hl7Segment[];
}

/**
 * Parses a raw HL7 v2 message string into segments and fields.
 *
 * HL7 segments are separated by carriage return (\r); real-world
 * traffic sometimes uses \n or \r\n due to transport quirks, so all
 * three are accepted as segment terminators.
 *
 * The message's own MSH segment declares delimiters: MSH-1 is the
 * field separator (the character immediately after "MSH"), and MSH-2
 * is the four encoding characters (component, repetition, escape,
 * subcomponent) in that fixed order. This parser reads those from the
 * message rather than assuming the common '|^~\&' — though that is by
 * far the most common set in practice and is used if MSH is malformed.
 *
 * Field splitting only: this parser does not split components/
 * subcomponents (that is done lazily by segment-specific accessors in
 * msh.ts/pid.ts/pv1.ts, since only some fields are componentized).
 */
export function parseMessage(raw: string): Hl7Message {
  if (!raw || raw.trim().length === 0) {
    throw new Hl7ParseError('Empty HL7 message.');
  }

  const normalized = raw.replace(/\r\n/g, '\r').replace(/\n/g, '\r');
  const segmentStrings = normalized.split('\r').filter((s) => s.length > 0);

  if (segmentStrings.length === 0) {
    throw new Hl7ParseError('No segments found in HL7 message.');
  }
  if (!segmentStrings[0].startsWith('MSH')) {
    throw new Hl7ParseError(`Message must start with MSH segment, got: ${segmentStrings[0].slice(0, 10)}`);
  }

  const delimiters = extractDelimiters(segmentStrings[0]);
  const segments = segmentStrings.map((s) => parseSegment(s, delimiters));

  return { delimiters, segments };
}

function extractDelimiters(mshLine: string): Hl7Delimiters {
  if (mshLine.length < 8) {
    throw new Hl7ParseError('MSH segment too short to contain delimiter declaration.');
  }
  const field = mshLine.charAt(3); // char after "MSH"
  const encodingChars = mshLine.substring(4, 8); // next 4 chars: component, repetition, escape, subcomponent

  if (encodingChars.length !== 4) {
    return DEFAULT_DELIMITERS;
  }

  return {
    field,
    component: encodingChars.charAt(0),
    repetition: encodingChars.charAt(1),
    escape: encodingChars.charAt(2),
    subcomponent: encodingChars.charAt(3),
  };
}

function parseSegment(line: string, delimiters: Hl7Delimiters): Hl7Segment {
  const segmentId = line.substring(0, 3);

  if (segmentId === 'MSH') {
    // MSH is special: the field separator itself is MSH-1, so a plain
    // split would misplace it. We reconstruct fields so that
    // rawFields[1] === the field separator character, and rawFields[2]
    // is the encoding characters block — matching how every other
    // segment's field indices line up with the HL7 spec's numbering.
    // Skip past "MSH" (3) + field-sep (1) + 4 encoding chars (4) + the
    // field-sep that follows them (1) = 9 chars, landing exactly on the
    // start of MSH-3's value. (Using 8 here is an off-by-one: it leaves
    // that trailing separator in `rest`, producing a spurious leading
    // empty field and shifting every subsequent MSH field index by one.)
    const rest = line.substring(9);
    const restFields = rest.length > 0 ? rest.split(delimiters.field) : [];
    return {
      segmentId,
      rawFields: [segmentId, delimiters.field, line.substring(4, 8), ...restFields],
    };
  }

  const fields = line.split(delimiters.field);
  return { segmentId, rawFields: fields };
}

/**
 * Returns the raw (un-componentized) value of field number `fieldNumber`
 * (1-based, per HL7 convention) for a segment, or undefined if absent.
 */
export function getField(segment: Hl7Segment, fieldNumber: number): string | undefined {
  return segment.rawFields[fieldNumber];
}

/** Splits a field's raw value into components using the message's component delimiter. */
export function getComponents(fieldValue: string | undefined, delimiters: Hl7Delimiters): string[] {
  if (fieldValue === undefined) return [];
  return fieldValue.split(delimiters.component);
}

/** Finds the first segment with the given segment ID, or undefined. */
export function findSegment(message: Hl7Message, segmentId: string): Hl7Segment | undefined {
  return message.segments.find((s) => s.segmentId === segmentId);
}

/** Finds all segments with the given segment ID (e.g. multiple OBX per OBR). */
export function findSegments(message: Hl7Message, segmentId: string): Hl7Segment[] {
  return message.segments.filter((s) => s.segmentId === segmentId);
}

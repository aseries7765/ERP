import { Hl7Message, findSegment, getComponents, getField } from '../parser';
import { Hl7ParseError } from '../types';

export interface MshFields {
  sendingApplication: string;
  sendingFacility: string;
  receivingApplication: string;
  receivingFacility: string;
  dateTimeOfMessage: string;
  messageType: string; // e.g. "ADT"
  triggerEvent: string; // e.g. "A01"
  messageControlId: string;
  processingId: string;
  versionId: string;
}

/**
 * Extracts the fields most consumers need from MSH: message type,
 * trigger event, routing info, and the control ID needed to correlate
 * an ACK/NAK back to this message.
 *
 * MSH-9 (message type) is componentized as "TYPE^TRIGGER^STRUCTURE" in
 * HL7 2.4+, or just "TYPE^TRIGGER" in older versions; both are handled.
 */
export function parseMsh(message: Hl7Message): MshFields {
  const msh = findSegment(message, 'MSH');
  if (!msh) {
    throw new Hl7ParseError('Message has no MSH segment.');
  }

  const messageTypeField = getField(msh, 9);
  if (!messageTypeField) {
    throw new Hl7ParseError('MSH-9 (message type) is required but missing.');
  }
  const [messageType, triggerEvent] = getComponents(messageTypeField, message.delimiters);
  if (!messageType || !triggerEvent) {
    throw new Hl7ParseError(`MSH-9 must contain type and trigger event (got: "${messageTypeField}").`);
  }

  const messageControlId = getField(msh, 10);
  if (!messageControlId) {
    throw new Hl7ParseError('MSH-10 (message control ID) is required but missing.');
  }

  return {
    sendingApplication: getField(msh, 3) ?? '',
    sendingFacility: getField(msh, 4) ?? '',
    receivingApplication: getField(msh, 5) ?? '',
    receivingFacility: getField(msh, 6) ?? '',
    dateTimeOfMessage: getField(msh, 7) ?? '',
    messageType,
    triggerEvent,
    messageControlId,
    processingId: getField(msh, 11) ?? 'P',
    versionId: getField(msh, 12) ?? '2.5.1',
  };
}

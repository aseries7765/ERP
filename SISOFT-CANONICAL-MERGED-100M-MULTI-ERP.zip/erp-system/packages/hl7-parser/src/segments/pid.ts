import { Hl7Message, findSegment, getComponents, getField } from '../parser';
import { Hl7ParseError } from '../types';

export interface PidFields {
  patientId: string; // PID-3, first component of the first repetition (MRN typically)
  patientIdAssigningAuthority?: string;
  lastName: string;
  firstName: string;
  middleName?: string;
  dateOfBirth?: string; // raw HL7 TS (YYYYMMDD[HHMMSS])
  sex?: string; // PID-8: M, F, O, U, A, N
  address?: {
    street?: string;
    city?: string;
    state?: string;
    zip?: string;
    country?: string;
  };
}

/**
 * Extracts the fields most consumers need from PID for matching to an
 * internal patient record (by MRN) and basic demographics.
 *
 * PID-3 (patient identifier list) can repeat (multiple ID types); this
 * extracts the first repetition's ID component, which is the common
 * convention for "the" patient identifier in ADT feeds. Full multi-ID
 * reconciliation (matching against MRN vs SSN vs other ID types
 * simultaneously) is out of scope here and belongs to the MPI logic in
 * HIS-1, which this parser feeds.
 */
export function parsePid(message: Hl7Message): PidFields {
  const pid = findSegment(message, 'PID');
  if (!pid) {
    throw new Hl7ParseError('Message has no PID segment.');
  }

  const idField = getField(pid, 3);
  if (!idField) {
    throw new Hl7ParseError('PID-3 (patient identifier list) is required but missing.');
  }
  // PID-3 can repeat with '~'; take the first repetition, then split its components.
  const firstRepetition = idField.split(message.delimiters.repetition)[0];
  const idComponents = getComponents(firstRepetition, message.delimiters);
  const patientId = idComponents[0];
  if (!patientId) {
    throw new Hl7ParseError('PID-3 first repetition has no identifier value.');
  }

  const nameField = getField(pid, 5);
  const nameComponents = getComponents(nameField, message.delimiters);
  const lastName = nameComponents[0] ?? '';
  const firstName = nameComponents[1] ?? '';
  const middleName = nameComponents[2];
  if (!lastName) {
    throw new Hl7ParseError('PID-5 (patient name) is required but missing a last name component.');
  }

  const addressField = getField(pid, 11);
  const addressComponents = getComponents(addressField, message.delimiters);
  const address = addressField
    ? {
        street: addressComponents[0] || undefined,
        city: addressComponents[2] || undefined,
        state: addressComponents[3] || undefined,
        zip: addressComponents[4] || undefined,
        country: addressComponents[5] || undefined,
      }
    : undefined;

  return {
    patientId,
    patientIdAssigningAuthority: idComponents[3] || undefined,
    lastName,
    firstName,
    middleName: middleName || undefined,
    dateOfBirth: getField(pid, 7) || undefined,
    sex: getField(pid, 8) || undefined,
    address,
  };
}

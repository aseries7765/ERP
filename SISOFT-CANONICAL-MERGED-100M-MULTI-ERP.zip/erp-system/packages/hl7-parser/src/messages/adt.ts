import { Hl7Message } from '../parser';
import { parseMsh } from '../segments/msh';
import { Hl7ParseError } from '../types';

/** ADT trigger events this parser recognizes and routes, per spec scope (A01-A08). */
export const SUPPORTED_ADT_TRIGGERS = ['A01', 'A02', 'A03', 'A04', 'A05', 'A06', 'A07', 'A08'] as const;
export type AdtTrigger = (typeof SUPPORTED_ADT_TRIGGERS)[number];

export const ADT_TRIGGER_MEANING: Record<AdtTrigger, string> = {
  A01: 'Admit/visit notification',
  A02: 'Transfer a patient',
  A03: 'Discharge/end visit',
  A04: 'Register a patient',
  A05: 'Pre-admit a patient',
  A06: 'Change an outpatient to an inpatient',
  A07: 'Change an inpatient to an outpatient',
  A08: 'Update patient information',
};

export interface ClassifiedAdt {
  trigger: AdtTrigger;
  meaning: string;
}

/**
 * Confirms a message is ADT and its trigger is one of the supported
 * A01-A08 events, returning the trigger and its plain-English meaning.
 * Throws for non-ADT messages or ADT triggers outside A01-A08 (e.g.
 * A09-A13 merge/cancel events are intentionally out of scope for this
 * slice — see MANIFEST for what's not yet implemented).
 */
export function classifyAdt(message: Hl7Message): ClassifiedAdt {
  const msh = parseMsh(message);
  if (msh.messageType !== 'ADT') {
    throw new Hl7ParseError(`Not an ADT message (MSH-9.1 = "${msh.messageType}").`);
  }
  if (!SUPPORTED_ADT_TRIGGERS.includes(msh.triggerEvent as AdtTrigger)) {
    throw new Hl7ParseError(
      `Unsupported ADT trigger event "${msh.triggerEvent}". Supported: ${SUPPORTED_ADT_TRIGGERS.join(', ')}.`,
    );
  }
  const trigger = msh.triggerEvent as AdtTrigger;
  return { trigger, meaning: ADT_TRIGGER_MEANING[trigger] };
}

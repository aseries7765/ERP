import { MshFields } from './segments/msh';

export type AckCode = 'AA' | 'AE' | 'AR'; // Application Accept, Error, Reject

export interface BuildAckOptions {
  /** The MSH of the message being acknowledged. */
  originalMsh: MshFields;
  ackCode: AckCode;
  /** Our own application/facility identity, to populate the ACK's own MSH-3/4. */
  respondingApplication: string;
  respondingFacility: string;
  /** Control ID for the ACK message itself (distinct from the original's). */
  ackControlId: string;
  textMessage?: string; // MSA-3, human-readable detail, especially for AE/AR
  now?: Date;
}

/**
 * Builds a minimal, spec-valid HL7 ACK (or NAK, using ackCode AE/AR)
 * message responding to a received message. Per spec G24, the caller
 * (hl7-ack.service in the his-hl7 module) is responsible for sending
 * this within 5 seconds of receipt — that timing guarantee lives at
 * the transport/service layer, not here; this function only builds a
 * structurally correct response.
 *
 * NAK is not a distinct message type in HL7 v2 — it's the same ACK
 * message structure with MSA-1 set to AE (application error) or AR
 * (application reject) instead of AA (application accept).
 */
export function buildAck(options: BuildAckOptions): string {
  const now = options.now ?? new Date();
  const timestamp = formatHl7Timestamp(now);

  // MSH is not a plain '|'-joined field list: MSH-1 *is* the field
  // separator character and MSH-2 is the encoding-characters block, so
  // naively joining them as array elements with '|' inserts spurious
  // extra separators (this was caught by execution, not review — see
  // the analogous off-by-one in parser.ts). Build the fixed MSH-1/2
  // prefix literally, then join the remaining, genuinely '|'-delimited
  // fields (MSH-3 onward) separately.
  const restFields = [
    options.respondingApplication,
    options.respondingFacility,
    options.originalMsh.sendingApplication,
    options.originalMsh.sendingFacility,
    timestamp,
    '',
    `ACK^${options.originalMsh.triggerEvent}`,
    options.ackControlId,
    options.originalMsh.processingId,
    options.originalMsh.versionId,
  ].join('|');
  const msh = `MSH|^~\\&|${restFields}`;

  const msa = ['MSA', options.ackCode, options.originalMsh.messageControlId, options.textMessage ?? ''].join('|');

  return [msh, msa].join('\r') + '\r';
}

function formatHl7Timestamp(date: Date): string {
  const pad = (n: number, len = 2) => String(n).padStart(len, '0');
  return (
    `${date.getUTCFullYear()}${pad(date.getUTCMonth() + 1)}${pad(date.getUTCDate())}` +
    `${pad(date.getUTCHours())}${pad(date.getUTCMinutes())}${pad(date.getUTCSeconds())}`
  );
}

/**
 * MLLP (Minimal Lower Layer Protocol) framing, per HL7's standard TCP
 * transport wrapper. Every HL7 v2 message on the wire (port 2575 by
 * convention, configurable per spec) is wrapped as:
 *
 *   <VT> message <FS><CR>
 *
 * Where VT = 0x0B, FS = 0x1C, CR = 0x0D.
 */
export const MLLP_START_BLOCK = 0x0b;
export const MLLP_END_BLOCK = 0x1c;
export const MLLP_CARRIAGE_RETURN = 0x0d;

export class MllpFramingError extends Error {}

/** Wraps a raw HL7 message string in MLLP framing bytes for transmission. */
export function frameMllp(message: string): Buffer {
  const messageBuffer = Buffer.from(message, 'utf8');
  return Buffer.concat([
    Buffer.from([MLLP_START_BLOCK]),
    messageBuffer,
    Buffer.from([MLLP_END_BLOCK, MLLP_CARRIAGE_RETURN]),
  ]);
}

/**
 * Extracts the raw HL7 message from a single, complete MLLP-framed
 * buffer. Throws if the start/end markers are missing or malformed.
 * Does not handle partial/split TCP reads — that's the responsibility
 * of the streaming reassembler (`MllpStreamReader`) below, which a real
 * MLLP server needs because HL7 messages can arrive across multiple
 * TCP packets.
 */
export function unframeMllp(buffer: Buffer): string {
  if (buffer.length < 3) {
    throw new MllpFramingError('Buffer too short to contain MLLP framing.');
  }
  if (buffer[0] !== MLLP_START_BLOCK) {
    throw new MllpFramingError(`Expected MLLP start block 0x0B, got 0x${buffer[0].toString(16)}.`);
  }
  const last = buffer.length - 1;
  const secondToLast = buffer.length - 2;
  if (buffer[secondToLast] !== MLLP_END_BLOCK || buffer[last] !== MLLP_CARRIAGE_RETURN) {
    throw new MllpFramingError('Buffer does not end with MLLP end block (0x1C 0x0D).');
  }
  return buffer.subarray(1, secondToLast).toString('utf8');
}

/**
 * Reassembles MLLP frames from a stream of arbitrarily-chunked TCP
 * data. Feed it bytes as they arrive via `push()`; it emits complete,
 * unframed HL7 message strings via the `onMessage` callback as soon as
 * each is fully received. Handles: a frame split across multiple
 * chunks, and multiple frames arriving in a single chunk.
 */
export class MllpStreamReader {
  private buffer: Buffer = Buffer.alloc(0);

  constructor(private readonly onMessage: (message: string) => void) {}

  push(chunk: Buffer): void {
    this.buffer = Buffer.concat([this.buffer, chunk]);

    // eslint-disable-next-line no-constant-condition
    while (true) {
      const startIdx = this.buffer.indexOf(MLLP_START_BLOCK);
      if (startIdx === -1) {
        // No start block yet; discard any stray bytes preceding a future frame.
        this.buffer = Buffer.alloc(0);
        return;
      }
      // Look for FS CR pair after the start block.
      const endIdx = this.findEndBlock(startIdx + 1);
      if (endIdx === -1) {
        // Incomplete frame; keep from startIdx onward and wait for more data.
        this.buffer = this.buffer.subarray(startIdx);
        return;
      }

      const frame = this.buffer.subarray(startIdx, endIdx + 2); // include FS CR
      this.onMessage(unframeMllp(frame));
      this.buffer = this.buffer.subarray(endIdx + 2);
    }
  }

  private findEndBlock(from: number): number {
    for (let i = from; i < this.buffer.length - 1; i++) {
      if (this.buffer[i] === MLLP_END_BLOCK && this.buffer[i + 1] === MLLP_CARRIAGE_RETURN) {
        return i;
      }
    }
    return -1;
  }

  /** True if there is an incomplete, buffered frame awaiting more data. */
  hasPendingData(): boolean {
    return this.buffer.length > 0;
  }
}

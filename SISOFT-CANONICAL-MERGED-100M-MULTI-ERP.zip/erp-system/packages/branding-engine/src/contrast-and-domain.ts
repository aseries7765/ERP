/**
 * ContrastChecker
 *
 * Implements the WCAG 2.1 relative-luminance and contrast-ratio formulas
 * exactly as specified (https://www.w3.org/TR/WCAG21/#dfn-contrast-ratio),
 * so branding colors chosen by a customer can be validated against the
 * G19 quality gate (WCAG 2.1 AA) before being saved.
 */

export interface RgbColor {
  r: number; // 0-255
  g: number;
  b: number;
}

export function hexToRgb(hex: string): RgbColor {
  const clean = hex.replace("#", "");
  if (!/^[0-9a-fA-F]{6}$/.test(clean)) {
    throw new Error(`Invalid hex color: ${hex}`);
  }
  return {
    r: parseInt(clean.slice(0, 2), 16),
    g: parseInt(clean.slice(2, 4), 16),
    b: parseInt(clean.slice(4, 6), 16),
  };
}

function srgbChannelToLinear(c: number): number {
  const cs = c / 255;
  return cs <= 0.03928 ? cs / 12.92 : Math.pow((cs + 0.055) / 1.055, 2.4);
}

export function relativeLuminance(color: RgbColor): number {
  const r = srgbChannelToLinear(color.r);
  const g = srgbChannelToLinear(color.g);
  const b = srgbChannelToLinear(color.b);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function contrastRatio(fg: RgbColor, bg: RgbColor): number {
  const l1 = relativeLuminance(fg);
  const l2 = relativeLuminance(bg);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

export type WcagLevel = "fail" | "AA" | "AAA";

export interface ContrastResult {
  ratio: number;
  normalTextLevel: WcagLevel; // AA >= 4.5, AAA >= 7
  largeTextLevel: WcagLevel; // AA >= 3, AAA >= 4.5
}

export function evaluateContrast(fgHex: string, bgHex: string): ContrastResult {
  const ratio = contrastRatio(hexToRgb(fgHex), hexToRgb(bgHex));
  return {
    ratio: Math.round(ratio * 100) / 100,
    normalTextLevel: ratio >= 7 ? "AAA" : ratio >= 4.5 ? "AA" : "fail",
    largeTextLevel: ratio >= 4.5 ? "AAA" : ratio >= 3 ? "AA" : "fail",
  };
}

/**
 * Per S6 spec: "Primary color must pass WCAG AA (4.5:1) on white + black.
 * If fails -> warning + suggestion."
 */
export interface PrimaryColorValidation {
  onWhite: ContrastResult;
  onBlack: ContrastResult;
  passesAA: boolean;
  suggestion?: string;
}

export function validatePrimaryBrandColor(primaryHex: string): PrimaryColorValidation {
  const onWhite = evaluateContrast(primaryHex, "#FFFFFF");
  const onBlack = evaluateContrast(primaryHex, "#000000");
  const passesAA = onWhite.normalTextLevel !== "fail" || onBlack.normalTextLevel !== "fail";

  let suggestion: string | undefined;
  if (!passesAA) {
    const rgb = hexToRgb(primaryHex);
    const darkened = darkenTowardBlack(rgb, 0.25);
    suggestion = `#${componentToHex(darkened.r)}${componentToHex(darkened.g)}${componentToHex(darkened.b)}`;
  }

  return { onWhite, onBlack, passesAA, suggestion };
}

function darkenTowardBlack(c: RgbColor, amount: number): RgbColor {
  return {
    r: Math.round(c.r * (1 - amount)),
    g: Math.round(c.g * (1 - amount)),
    b: Math.round(c.b * (1 - amount)),
  };
}

function componentToHex(n: number): string {
  return Math.max(0, Math.min(255, n)).toString(16).padStart(2, "0");
}

/**
 * DomainVerificationService
 *
 * Verifies that a customer has pointed a CNAME at us before we provision
 * a custom domain + SSL for white-label. Pure logic here; the actual DNS
 * lookup (dns.resolveCname) is injected so this is testable without a
 * real network call.
 */
export type DnsLookup = (hostname: string) => Promise<string[]>;

export interface DomainVerificationResult {
  verified: boolean;
  reason?: string;
}

export async function verifyCustomDomain(
  customerDomain: string,
  expectedTarget: string,
  dnsLookup: DnsLookup,
): Promise<DomainVerificationResult> {
  if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(customerDomain)) {
    return { verified: false, reason: "Domain is not a syntactically valid hostname" };
  }

  let records: string[];
  try {
    records = await dnsLookup(customerDomain);
  } catch {
    return { verified: false, reason: "DNS lookup failed — no CNAME record found" };
  }

  const normalizedTarget = expectedTarget.replace(/\.$/, "").toLowerCase();
  const matches = records.some((r) => r.replace(/\.$/, "").toLowerCase() === normalizedTarget);

  if (!matches) {
    return { verified: false, reason: `CNAME does not point to ${expectedTarget}` };
  }
  return { verified: true };
}

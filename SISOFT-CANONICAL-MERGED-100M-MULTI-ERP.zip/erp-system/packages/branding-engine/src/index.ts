/**
 * @erp/branding-engine
 * Placeholder entry point created during integration pass.
 * Real branding logic should be implemented here.
 */
export const BRANDING_ENGINE_VERSION = '0.1.0';

export function getBrandingPlaceholder() {
  return {
    version: BRANDING_ENGINE_VERSION,
    status: 'stub',
  };
}

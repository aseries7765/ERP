export { getPromptTemplate, renderTemplate } from './registry';
export type { PromptTemplate } from './registry';

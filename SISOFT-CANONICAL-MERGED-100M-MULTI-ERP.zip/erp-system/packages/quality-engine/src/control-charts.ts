import { ControlChartPoint, ControlChartResult, ControlLimits } from './types';

/**
 * X-bar / R style control chart with 3-sigma control limits computed from the
 * sample data itself (centerLine = mean, limits = mean +/- 3*stdDev), which
 * is the standard approach when subgroup constants (A2/D3/D4 tables) aren't
 * supplied. If the caller has subgroup size and wants classical A2/D3/D4
 * factors, they should compute limits separately and pass them via
 * `overrideLimits` — this function still flags out-of-control points against
 * whichever limits are in effect.
 */
export function buildControlChart(
  values: number[],
  overrideLimits?: ControlLimits,
): ControlChartResult {
  if (values.length === 0) throw new Error('values must not be empty');

  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((sum, v) => sum + (v - mean) ** 2, 0) / values.length;
  const stdDev = Math.sqrt(variance);

  const limits: ControlLimits = overrideLimits ?? {
    centerLine: mean,
    upperControlLimit: mean + 3 * stdDev,
    lowerControlLimit: mean - 3 * stdDev,
  };

  const points: (ControlChartPoint & { outOfControl: boolean })[] = values.map((value, idx) => ({
    sampleIndex: idx,
    value,
    outOfControl: value > limits.upperControlLimit || value < limits.lowerControlLimit,
  }));

  return { ...limits, points };
}

/** p-chart (proportion nonconforming) control limits, varying by subgroup size. */
export function buildPChart(
  defectiveCounts: number[],
  subgroupSizes: number[],
): ControlChartResult {
  if (defectiveCounts.length !== subgroupSizes.length) {
    throw new Error('defectiveCounts and subgroupSizes must be the same length');
  }
  if (defectiveCounts.length === 0) throw new Error('input must not be empty');

  const proportions = defectiveCounts.map((d, i) => {
    const n = subgroupSizes[i];
    if (n === undefined) throw new Error(`Missing subgroup size at index ${i}`);
    return d / n;
  });
  const totalDefective = defectiveCounts.reduce((a, b) => a + b, 0);
  const totalInspected = subgroupSizes.reduce((a, b) => a + b, 0);
  const pBar = totalDefective / totalInspected;

  const avgN = totalInspected / subgroupSizes.length;
  const sigmaP = Math.sqrt((pBar * (1 - pBar)) / avgN);

  const ucl = Math.min(1, pBar + 3 * sigmaP);
  const lcl = Math.max(0, pBar - 3 * sigmaP);

  const points = proportions.map((p, idx) => ({
    sampleIndex: idx,
    value: p,
    outOfControl: p > ucl || p < lcl,
  }));

  return { centerLine: pBar, upperControlLimit: ucl, lowerControlLimit: lcl, points };
}

export type AqlLevel = 0.065 | 0.1 | 0.15 | 0.25 | 0.4 | 0.65 | 1.0 | 1.5 | 2.5 | 4.0 | 6.5;
export type InspectionLevel = 'S-1' | 'S-2' | 'S-3' | 'S-4' | 'I' | 'II' | 'III';

export interface SamplingPlanResult {
  lotSizeMin: number;
  lotSizeMax: number;
  codeLetter: string;
  sampleSize: number;
  acceptNumber: number;
  rejectNumber: number;
}

export interface ControlChartPoint {
  sampleIndex: number;
  value: number;
}

export interface ControlLimits {
  centerLine: number;
  upperControlLimit: number;
  lowerControlLimit: number;
}

export interface ControlChartResult extends ControlLimits {
  points: (ControlChartPoint & { outOfControl: boolean })[];
}

export interface FmeaLine {
  failureMode: string;
  severity: number; // 1-10
  occurrence: number; // 1-10
  detection: number; // 1-10
}

export interface FmeaResult extends FmeaLine {
  rpn: number; // Risk Priority Number = S x O x D
}

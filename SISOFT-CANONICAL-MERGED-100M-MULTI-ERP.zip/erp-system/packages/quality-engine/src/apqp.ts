/**
 * APQP (Advanced Product Quality Planning) support.
 *
 * NOT IMPLEMENTED IN THIS DELIVERY — documented gap, not a silent stub.
 *
 * APQP is a 5-phase program-management framework (Plan & Define, Product
 * Design & Development, Process Design & Development, Product & Process
 * Validation, Feedback/Assessment/Corrective Action) that maps naturally
 * onto the Projects module (Project + ProjectPhase + Milestone) rather than
 * onto this pure-calculation quality-engine package. Modeling APQP as a
 * Project Template (see apps/api/prisma/seed/projects/seed-project-templates.ts)
 * is the intended approach but was out of scope for this delivery — flagged
 * here rather than hidden. See docs/modules/manufacturing/ISO_9001.md.
 */
export const APQP_STATUS = 'not-implemented' as const;

import { AqlLevel, SamplingPlanResult } from './types';

/**
 * Simplified MIL-STD-105E / ISO 2859-1 sampling plan lookup.
 *
 * HONEST LIMITATION: this implements a representative subset of the standard
 * — General Inspection Level II, Normal severity, single sampling plans only
 * — covering the most commonly used AQL values (0.65, 1.0, 1.5, 2.5, 4.0, 6.5)
 * and code letters A through R (lot sizes up to 500,000). It does NOT
 * implement: Special Inspection Levels S-1 to S-4, tightened/reduced
 * inspection switching rules, double/multiple sampling plans, or AQLs outside
 * the list above. See docs/modules/manufacturing/SAMPLING.md for the full
 * gap list. This is sufficient for standard incoming/in-process/final
 * inspection under normal conditions but should not be relied on for
 * contractual MIL-STD-105E compliance without extending the table.
 */

interface CodeLetterRange {
  min: number;
  max: number;
  letter: string;
}

// General Inspection Level II lot-size-to-code-letter table (MIL-STD-105E Table I).
const CODE_LETTER_TABLE: CodeLetterRange[] = [
  { min: 2, max: 8, letter: 'A' },
  { min: 9, max: 15, letter: 'B' },
  { min: 16, max: 25, letter: 'C' },
  { min: 26, max: 50, letter: 'D' },
  { min: 51, max: 90, letter: 'E' },
  { min: 91, max: 150, letter: 'F' },
  { min: 151, max: 280, letter: 'G' },
  { min: 281, max: 500, letter: 'H' },
  { min: 501, max: 1200, letter: 'J' },
  { min: 1201, max: 3200, letter: 'K' },
  { min: 3201, max: 10000, letter: 'L' },
  { min: 10001, max: 35000, letter: 'M' },
  { min: 35001, max: 150000, letter: 'N' },
  { min: 150001, max: 500000, letter: 'P' },
  { min: 500001, max: Infinity, letter: 'Q' },
];

// Sample sizes per code letter (Table II-A, Normal single sampling).
const SAMPLE_SIZE_BY_LETTER: Record<string, number> = {
  A: 2,
  B: 3,
  C: 5,
  D: 8,
  E: 13,
  F: 20,
  G: 32,
  H: 50,
  J: 80,
  K: 125,
  L: 200,
  M: 315,
  N: 500,
  P: 800,
  Q: 1250,
};

// Accept/Reject numbers per (code letter, AQL). Subset covering common AQLs.
// Format: [Ac, Re]. `null` means "not applicable at this code letter for this AQL"
// (would require plan substitution per the standard, not implemented here).
const AC_RE_TABLE: Record<string, Partial<Record<AqlLevel, [number, number]>>> = {
  A: { 6.5: [0, 1] },
  B: { 4.0: [0, 1], 6.5: [1, 2] },
  C: { 2.5: [0, 1], 4.0: [1, 2], 6.5: [1, 2] },
  D: { 1.5: [0, 1], 2.5: [1, 2], 4.0: [1, 2], 6.5: [2, 3] },
  E: { 1.0: [0, 1], 1.5: [1, 2], 2.5: [1, 2], 4.0: [2, 3], 6.5: [3, 4] },
  F: { 0.65: [0, 1], 1.0: [1, 2], 1.5: [1, 2], 2.5: [2, 3], 4.0: [3, 4], 6.5: [5, 6] },
  G: { 0.65: [1, 2], 1.0: [1, 2], 1.5: [2, 3], 2.5: [3, 4], 4.0: [5, 6], 6.5: [7, 8] },
  H: { 0.65: [1, 2], 1.0: [2, 3], 1.5: [3, 4], 2.5: [5, 6], 4.0: [7, 8], 6.5: [10, 11] },
  J: { 0.65: [2, 3], 1.0: [3, 4], 1.5: [5, 6], 2.5: [7, 8], 4.0: [10, 11], 6.5: [14, 15] },
  K: { 0.65: [3, 4], 1.0: [5, 6], 1.5: [7, 8], 2.5: [10, 11], 4.0: [14, 15], 6.5: [21, 22] },
  L: { 0.65: [5, 6], 1.0: [7, 8], 1.5: [10, 11], 2.5: [14, 15], 4.0: [21, 22], 6.5: [21, 22] },
  M: { 0.65: [7, 8], 1.0: [10, 11], 1.5: [14, 15], 2.5: [21, 22], 4.0: [21, 22], 6.5: [21, 22] },
  N: { 0.65: [10, 11], 1.0: [14, 15], 1.5: [21, 22], 2.5: [21, 22], 4.0: [21, 22], 6.5: [21, 22] },
};

export function codeLetterForLotSize(lotSize: number): CodeLetterRange {
  const found = CODE_LETTER_TABLE.find((r) => lotSize >= r.min && lotSize <= r.max);
  if (!found) throw new Error(`No code letter defined for lot size ${lotSize}`);
  return found;
}

/**
 * Returns the sampling plan (sample size, accept/reject numbers) for a given
 * lot size and AQL, under General Inspection Level II, Normal severity,
 * single sampling — see module-level limitation note.
 */
export function getSamplingPlan(lotSize: number, aql: AqlLevel): SamplingPlanResult {
  if (lotSize < 2) throw new Error('lotSize must be >= 2');

  const range = codeLetterForLotSize(lotSize);
  const sampleSize = SAMPLE_SIZE_BY_LETTER[range.letter];
  const plan = AC_RE_TABLE[range.letter]?.[aql];

  if (sampleSize === undefined) {
    throw new Error(`No sample size defined for code letter ${range.letter} (table gap)`);
  }

  if (!plan) {
    throw new Error(
      `No plan defined for code letter ${range.letter} at AQL ${aql}. This subset of the ` +
        `MIL-STD-105E table does not cover this combination — extend AC_RE_TABLE or select ` +
        `a supported AQL (see SAMPLING.md limitations).`,
    );
  }

  const [acceptNumber, rejectNumber] = plan;

  return {
    lotSizeMin: range.min,
    lotSizeMax: range.max,
    codeLetter: range.letter,
    sampleSize,
    acceptNumber,
    rejectNumber,
  };
}

/** Applies a sampling plan's decision rule to an observed defect count. */
export function evaluateSample(plan: SamplingPlanResult, defectsFound: number): 'accept' | 'reject' {
  return defectsFound <= plan.acceptNumber ? 'accept' : 'reject';
}

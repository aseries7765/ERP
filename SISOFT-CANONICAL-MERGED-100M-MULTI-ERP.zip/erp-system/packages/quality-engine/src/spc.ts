export interface ProcessCapabilityInput {
  values: number[];
  upperSpecLimit: number;
  lowerSpecLimit: number;
}

export interface ProcessCapabilityResult {
  mean: number;
  stdDev: number;
  cp: number;
  cpk: number;
}

/**
 * Process capability indices Cp and Cpk:
 *   Cp  = (USL - LSL) / (6 * stdDev)          — potential capability
 *   Cpk = min(USL - mean, mean - LSL) / (3 * stdDev)  — actual (centering-aware) capability
 */
export function calculateProcessCapability(input: ProcessCapabilityInput): ProcessCapabilityResult {
  const { values, upperSpecLimit, lowerSpecLimit } = input;
  if (values.length < 2) throw new Error('Need at least 2 data points for process capability');
  if (upperSpecLimit <= lowerSpecLimit) throw new Error('upperSpecLimit must be > lowerSpecLimit');

  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance =
    values.reduce((sum, v) => sum + (v - mean) ** 2, 0) / (values.length - 1); // sample variance
  const stdDev = Math.sqrt(variance);

  if (stdDev === 0) {
    return { mean, stdDev: 0, cp: Infinity, cpk: Infinity };
  }

  const cp = (upperSpecLimit - lowerSpecLimit) / (6 * stdDev);
  const cpk = Math.min(upperSpecLimit - mean, mean - lowerSpecLimit) / (3 * stdDev);

  return { mean, stdDev, cp, cpk };
}

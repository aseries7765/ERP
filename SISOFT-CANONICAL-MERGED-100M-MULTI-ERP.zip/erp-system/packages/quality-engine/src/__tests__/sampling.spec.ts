import { describe, it, expect } from 'vitest';
import { codeLetterForLotSize, getSamplingPlan, evaluateSample } from '../sampling';

describe('codeLetterForLotSize', () => {
  it('maps lot sizes to the correct MIL-STD-105E General Level II code letter', () => {
    expect(codeLetterForLotSize(5).letter).toBe('A');
    expect(codeLetterForLotSize(100).letter).toBe('F');
    expect(codeLetterForLotSize(2000).letter).toBe('K');
  });

  it('throws for lot sizes below the minimum', () => {
    expect(() => codeLetterForLotSize(1)).toThrow();
  });
});

describe('getSamplingPlan', () => {
  it('returns sample size and accept/reject numbers for a supported lot size + AQL', () => {
    const plan = getSamplingPlan(100, 1.0);
    expect(plan.codeLetter).toBe('F');
    expect(plan.sampleSize).toBe(20);
    expect(plan.acceptNumber).toBe(1);
    expect(plan.rejectNumber).toBe(2);
  });

  it('throws a clear error for an unsupported code-letter/AQL combination', () => {
    expect(() => getSamplingPlan(5, 1.0)).toThrow(/No plan defined/);
  });
});

describe('evaluateSample', () => {
  it('accepts when defects are at or below the accept number', () => {
    const plan = getSamplingPlan(100, 1.0);
    expect(evaluateSample(plan, 0)).toBe('accept');
    expect(evaluateSample(plan, 1)).toBe('accept');
  });

  it('rejects when defects exceed the accept number', () => {
    const plan = getSamplingPlan(100, 1.0);
    expect(evaluateSample(plan, 2)).toBe('reject');
  });
});

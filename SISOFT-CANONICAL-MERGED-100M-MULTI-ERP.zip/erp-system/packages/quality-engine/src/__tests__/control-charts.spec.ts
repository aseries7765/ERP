import { describe, it, expect } from 'vitest';
import { buildControlChart, buildPChart } from '../control-charts';

describe('buildControlChart', () => {
  it('computes mean-centered 3-sigma limits and flags a clear out-of-control point', () => {
    // 19 points at the nominal value plus small natural noise, and one
    // sharp outlier. Using enough "normal" points matters here: with too
    // few points, a single large outlier can dominate the computed mean and
    // stdDev enough to inflate the UCL until it masks the very point it
    // should flag (a real, known characteristic of computing control limits
    // from data that includes the point under test, not a bug — see
    // control-charts.ts's docstring). This fixture keeps the outlier's
    // leverage low enough that it's still flagged.
    const values = [10, 9, 11, 10, 10, 9, 11, 10, 10, 9, 11, 10, 10, 9, 11, 10, 10, 9, 11, 50];
    const result = buildControlChart(values);
    expect(result.points[19]!.outOfControl).toBe(true);
    expect(result.points.slice(0, 19).every((p) => !p.outOfControl)).toBe(true);
  });

  it('uses override limits when supplied', () => {
    const values = [5, 6, 7];
    const result = buildControlChart(values, { centerLine: 6, upperControlLimit: 6.5, lowerControlLimit: 5.5 });
    expect(result.centerLine).toBe(6);
    expect(result.points[0]!.outOfControl).toBe(true); // 5 < 5.5
    expect(result.points[2]!.outOfControl).toBe(true); // 7 > 6.5
    expect(result.points[1]!.outOfControl).toBe(false);
  });

  it('throws on empty input', () => {
    expect(() => buildControlChart([])).toThrow();
  });
});

describe('buildPChart', () => {
  it('computes p-bar and flags proportions outside 3-sigma limits', () => {
    const defective = [2, 3, 2, 20, 1];
    const sizes = [100, 100, 100, 100, 100];
    const result = buildPChart(defective, sizes);
    expect(result.centerLine).toBeCloseTo(28 / 500, 5);
    expect(result.points[3]!.outOfControl).toBe(true);
  });

  it('throws when input arrays mismatch in length', () => {
    expect(() => buildPChart([1, 2], [100])).toThrow();
  });
});

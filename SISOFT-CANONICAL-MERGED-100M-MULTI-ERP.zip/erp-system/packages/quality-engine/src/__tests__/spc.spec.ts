import { describe, it, expect } from 'vitest';
import { calculateProcessCapability } from '../spc';
import { calculateFmea } from '../fmea';

describe('calculateProcessCapability', () => {
  it('computes Cp and Cpk for a centered, capable process', () => {
    const values = [9.9, 10.0, 10.1, 10.0, 9.95, 10.05, 10.0, 9.98, 10.02, 10.0];
    const result = calculateProcessCapability({ values, upperSpecLimit: 10.5, lowerSpecLimit: 9.5 });
    expect(result.cp).toBeGreaterThan(0);
    expect(result.cpk).toBeGreaterThan(0);
    expect(result.cpk).toBeLessThanOrEqual(result.cp + 1e-9);
  });

  it('throws with fewer than 2 data points', () => {
    expect(() => calculateProcessCapability({ values: [1], upperSpecLimit: 10, lowerSpecLimit: 0 })).toThrow();
  });

  it('throws when spec limits are inverted', () => {
    expect(() =>
      calculateProcessCapability({ values: [1, 2, 3], upperSpecLimit: 0, lowerSpecLimit: 10 }),
    ).toThrow();
  });
});

describe('calculateFmea', () => {
  it('computes RPN and sorts descending by risk', () => {
    const results = calculateFmea([
      { failureMode: 'Low risk', severity: 2, occurrence: 2, detection: 2 }, // RPN 8
      { failureMode: 'High risk', severity: 9, occurrence: 8, detection: 7 }, // RPN 504
    ]);
    expect(results[0]!.failureMode).toBe('High risk');
    expect(results[0]!.rpn).toBe(504);
    expect(results[1]!.rpn).toBe(8);
  });

  it('rejects out-of-range ratings', () => {
    expect(() =>
      calculateFmea([{ failureMode: 'Bad', severity: 11, occurrence: 1, detection: 1 }]),
    ).toThrow();
  });
});

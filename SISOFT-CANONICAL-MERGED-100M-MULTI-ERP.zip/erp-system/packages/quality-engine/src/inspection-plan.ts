export type InspectionType = 'IQC' | 'IPQC' | 'FQC' | 'OQC';

export interface InspectionCheckDefinition {
  characteristic: string;
  /** Nominal/target value, if numeric. */
  nominal?: number;
  /** Allowed tolerance +/- nominal, if numeric. */
  tolerance?: number;
  /** For pass/fail (non-numeric) checks. */
  isPassFail?: boolean;
}

export interface InspectionPlan {
  inspectionType: InspectionType;
  checks: InspectionCheckDefinition[];
}

export interface CheckResult {
  characteristic: string;
  measuredValue?: number;
  passFailResult?: boolean;
  passed: boolean;
}

/**
 * Evaluates a set of recorded measurements/pass-fail results against an
 * inspection plan's tolerances, returning a pass/fail verdict per
 * characteristic checked.
 */
export function evaluateInspectionResults(
  plan: InspectionPlan,
  recorded: { characteristic: string; measuredValue?: number; passFailResult?: boolean }[],
): CheckResult[] {
  return plan.checks.map((check) => {
    const record = recorded.find((r) => r.characteristic === check.characteristic);

    if (!record) {
      return { characteristic: check.characteristic, passed: false };
    }

    if (check.isPassFail) {
      return {
        characteristic: check.characteristic,
        passFailResult: record.passFailResult,
        passed: record.passFailResult === true,
      };
    }

    if (check.nominal === undefined || check.tolerance === undefined) {
      throw new Error(`Numeric check ${check.characteristic} missing nominal/tolerance`);
    }
    if (record.measuredValue === undefined) {
      return { characteristic: check.characteristic, passed: false };
    }

    const withinTolerance =
      Math.abs(record.measuredValue - check.nominal) <= check.tolerance;

    return {
      characteristic: check.characteristic,
      measuredValue: record.measuredValue,
      passed: withinTolerance,
    };
  });
}

export function overallVerdict(results: CheckResult[]): 'pass' | 'fail' {
  return results.every((r) => r.passed) ? 'pass' : 'fail';
}

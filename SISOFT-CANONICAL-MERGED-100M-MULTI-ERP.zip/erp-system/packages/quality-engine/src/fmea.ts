import { FmeaLine, FmeaResult } from './types';

/**
 * Calculates the Risk Priority Number (RPN = Severity x Occurrence x
 * Detection) for a list of FMEA lines, each rated 1-10 on each dimension,
 * and sorts results descending by RPN so the highest-risk failure modes
 * surface first.
 */
export function calculateFmea(lines: FmeaLine[]): FmeaResult[] {
  return lines
    .map((line) => {
      for (const [key, val] of Object.entries({
        severity: line.severity,
        occurrence: line.occurrence,
        detection: line.detection,
      })) {
        if (val < 1 || val > 10) {
          throw new Error(`FMEA ${key} rating must be between 1 and 10, got ${val}`);
        }
      }
      return { ...line, rpn: line.severity * line.occurrence * line.detection };
    })
    .sort((a, b) => b.rpn - a.rpn);
}

/**
 * PPAP (Production Part Approval Process) support.
 *
 * NOT IMPLEMENTED IN THIS DELIVERY — documented gap, not a silent stub.
 *
 * PPAP is fundamentally a document-checklist workflow (18 standard elements:
 * design records, engineering change documents, DFMEA, process flow diagram,
 * PFMEA, control plan, MSA studies, dimensional results, material/performance
 * test results, initial process studies, qualified lab documentation,
 * appearance approval report, sample production parts, master sample,
 * checking aids, customer-specific requirements, part submission warrant)
 * rather than a calculation engine. It belongs on `ProjectDocument` /
 * `QualityInspection` records with a checklist status field, which is a
 * data-modeling + workflow concern for the API layer (M9 manufacturing
 * module + M3.8 Documents), not pure-function logic for this package.
 *
 * This file exists so the gap is visible in the package's file tree and
 * tracked, rather than silently absent. See
 * docs/modules/manufacturing/ISO_9001.md for what's covered vs deferred.
 */
export const PPAP_STATUS = 'not-implemented' as const;

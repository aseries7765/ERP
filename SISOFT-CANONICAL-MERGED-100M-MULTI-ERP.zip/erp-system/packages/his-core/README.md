# @erp/his-core

Shared HIS clinical primitives, framework-agnostic.

## Scope in this slice (HIS-1 / Patient Core)
- `PatientMrnGenerator` — gapless, per-facility MRN generation.
- `PatientValidator` — registration input validation.

## Explicitly NOT in this slice
Encounter/SOAP model, vitals ranges/early-warning-score, appointment slot
algorithm, allergy cross-reactivity, problem-list model. These are real
work items from the full HIS-1 spec, deferred to a later slice — see
project MANIFEST.md for the cut list.

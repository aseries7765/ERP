import { PatientValidator } from '../patient/patient-validator';

describe('PatientValidator', () => {
  const validator = new PatientValidator();
  const now = new Date('2026-09-17T00:00:00Z');

  const base = () => ({
    firstName: 'Jane',
    lastName: 'Doe',
    dateOfBirth: new Date('1990-01-15T00:00:00Z'),
    sex: '2' as const,
  });

  it('accepts valid input', () => {
    const result = validator.validate(base(), now);
    expect(result.valid).toBe(true);
    expect(result.issues).toEqual([]);
  });

  it('rejects missing firstName', () => {
    const result = validator.validate({ ...base(), firstName: '' }, now);
    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual({ field: 'firstName', message: 'firstName is required' });
  });

  it('rejects whitespace-only lastName', () => {
    const result = validator.validate({ ...base(), lastName: '   ' }, now);
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.field === 'lastName')).toBe(true);
  });

  it('rejects a future date of birth', () => {
    const result = validator.validate({ ...base(), dateOfBirth: new Date('2027-01-01') }, now);
    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual({
      field: 'dateOfBirth',
      message: 'dateOfBirth cannot be in the future',
    });
  });

  it('rejects an implausible age over 130 years', () => {
    const result = validator.validate({ ...base(), dateOfBirth: new Date('1880-01-01') }, now);
    expect(result.valid).toBe(false);
    expect(result.issues.some((i) => i.field === 'dateOfBirth')).toBe(true);
  });

  it('rejects an invalid dateOfBirth value', () => {
    const result = validator.validate({ ...base(), dateOfBirth: new Date('not-a-date') }, now);
    expect(result.valid).toBe(false);
  });

  it('rejects an invalid sex code', () => {
    const result = validator.validate({ ...base(), sex: 'X' as any }, now);
    expect(result.valid).toBe(false);
    expect(result.issues).toContainEqual({
      field: 'sex',
      message: 'sex must be one of 0, 1, 2, 9 (ISO 5218)',
    });
  });

  it('accepts a date of birth exactly on today (newborn)', () => {
    const result = validator.validate({ ...base(), dateOfBirth: now }, now);
    expect(result.valid).toBe(true);
  });

  it('reports multiple issues at once', () => {
    const result = validator.validate(
      { firstName: '', lastName: '', dateOfBirth: new Date('bad'), sex: 'X' as any },
      now,
    );
    expect(result.issues.length).toBe(4);
  });
});

import {
  PatientMrnGenerator,
  MrnCounterRepository,
  InvalidMrnFormatOptionsError,
} from '../patient/patient-mrn';

class InMemoryMrnCounterRepository implements MrnCounterRepository {
  private counters = new Map<string, number>();

  async incrementAndGet(facilityId: string): Promise<number> {
    const current = this.counters.get(facilityId) ?? 0;
    const next = current + 1;
    this.counters.set(facilityId, next);
    return next;
  }
}

describe('PatientMrnGenerator', () => {
  it('formats a sequence with zero-padding', () => {
    const gen = new PatientMrnGenerator(new InMemoryMrnCounterRepository());
    expect(gen.format(123, { facilityCode: 'CLN01' })).toBe('MRN-CLN01-000123');
  });

  it('respects a custom sequence width', () => {
    const gen = new PatientMrnGenerator(new InMemoryMrnCounterRepository());
    expect(gen.format(7, { facilityCode: 'CLN01', sequenceWidth: 3 })).toBe('MRN-CLN01-007');
  });

  it('includes the year when requested', () => {
    const gen = new PatientMrnGenerator(new InMemoryMrnCounterRepository());
    expect(
      gen.format(5, { facilityCode: 'CLN01', includeYear: true, year: 2026 }),
    ).toBe('MRN-2026-CLN01-000005');
  });

  it('generates gapless, strictly increasing MRNs per facility', async () => {
    const gen = new PatientMrnGenerator(new InMemoryMrnCounterRepository());
    const first = await gen.generate('fac-1', { facilityCode: 'CLN01' });
    const second = await gen.generate('fac-1', { facilityCode: 'CLN01' });
    const third = await gen.generate('fac-1', { facilityCode: 'CLN01' });
    expect([first, second, third]).toEqual([
      'MRN-CLN01-000001',
      'MRN-CLN01-000002',
      'MRN-CLN01-000003',
    ]);
  });

  it('keeps separate, independent sequences per facility', async () => {
    const gen = new PatientMrnGenerator(new InMemoryMrnCounterRepository());
    const a1 = await gen.generate('fac-A', { facilityCode: 'A' });
    const b1 = await gen.generate('fac-B', { facilityCode: 'B' });
    const a2 = await gen.generate('fac-A', { facilityCode: 'A' });
    expect(a1).toBe('MRN-A-000001');
    expect(b1).toBe('MRN-B-000001');
    expect(a2).toBe('MRN-A-000002');
  });

  it('remains gapless under concurrent generation for one facility', async () => {
    const repo = new InMemoryMrnCounterRepository();
    const gen = new PatientMrnGenerator(repo);
    const results = await Promise.all(
      Array.from({ length: 20 }, () => gen.generate('fac-1', { facilityCode: 'CLN01' })),
    );
    const sequences = results
      .map((mrn) => parseInt(mrn.split('-')[2], 10))
      .sort((a, b) => a - b);
    expect(sequences).toEqual(Array.from({ length: 20 }, (_, i) => i + 1));
  });

  it('rejects a non-alphanumeric facility code', () => {
    const gen = new PatientMrnGenerator(new InMemoryMrnCounterRepository());
    expect(() => gen.format(1, { facilityCode: 'CLN-01' })).toThrow(
      InvalidMrnFormatOptionsError,
    );
  });

  it('rejects a non-positive sequence', () => {
    const gen = new PatientMrnGenerator(new InMemoryMrnCounterRepository());
    expect(() => gen.format(0, { facilityCode: 'CLN01' })).toThrow(
      InvalidMrnFormatOptionsError,
    );
  });
});

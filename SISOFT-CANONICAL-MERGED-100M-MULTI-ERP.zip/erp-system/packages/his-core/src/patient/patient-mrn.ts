/**
 * Medical Record Number (MRN) generation.
 *
 * Format: `MRN-<facilityCode>-<zeroPaddedSequence>` e.g. "MRN-CLN01-000123".
 * Gapless per facility: the counter only advances on a committed patient
 * creation, never pre-reserved and discarded. Concurrency safety is the
 * caller's responsibility (repository implementation must use a row lock /
 * SELECT ... FOR UPDATE or equivalent atomic increment — see
 * MrnCounterRepository below for the contract this generator depends on).
 */

export interface MrnCounterRepository {
  /**
   * Atomically increments and returns the next value for a facility.
   * Implementations MUST guarantee this is safe under concurrent callers
   * (e.g. `UPDATE ... SET next_value = next_value + 1 ... RETURNING`
   * inside a transaction, or SELECT FOR UPDATE + UPDATE).
   */
  incrementAndGet(facilityId: string): Promise<number>;
}

export interface MrnFormatOptions {
  /** Short facility code embedded in the MRN, e.g. "CLN01". */
  facilityCode: string;
  /** Zero-padding width for the sequence portion. Default 6. */
  sequenceWidth?: number;
  /** Optional year segment, e.g. true -> "MRN-2026-CLN01-000123". */
  includeYear?: boolean;
  /** Year to embed if includeYear is true. Defaults to current year. */
  year?: number;
}

export class InvalidMrnFormatOptionsError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidMrnFormatOptionsError';
  }
}

export class PatientMrnGenerator {
  constructor(private readonly repo: MrnCounterRepository) {}

  async generate(facilityId: string, options: MrnFormatOptions): Promise<string> {
    this.validateOptions(options);
    const seq = await this.repo.incrementAndGet(facilityId);
    return this.format(seq, options);
  }

  format(sequence: number, options: MrnFormatOptions): string {
    this.validateOptions(options);
    if (!Number.isInteger(sequence) || sequence < 1) {
      throw new InvalidMrnFormatOptionsError('sequence must be a positive integer');
    }
    const width = options.sequenceWidth ?? 6;
    const padded = String(sequence).padStart(width, '0');
    const parts = ['MRN'];
    if (options.includeYear) {
      parts.push(String(options.year ?? new Date().getFullYear()));
    }
    parts.push(options.facilityCode);
    parts.push(padded);
    return parts.join('-');
  }

  private validateOptions(options: MrnFormatOptions): void {
    if (!options.facilityCode || !/^[A-Za-z0-9]+$/.test(options.facilityCode)) {
      throw new InvalidMrnFormatOptionsError(
        'facilityCode is required and must be alphanumeric',
      );
    }
    if (options.sequenceWidth !== undefined && options.sequenceWidth < 1) {
      throw new InvalidMrnFormatOptionsError('sequenceWidth must be >= 1');
    }
  }
}

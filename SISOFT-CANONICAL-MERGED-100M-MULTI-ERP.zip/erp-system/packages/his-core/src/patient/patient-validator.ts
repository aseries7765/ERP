export interface PatientInput {
  firstName: string;
  lastName: string;
  dateOfBirth: Date;
  sex: '0' | '1' | '2' | '9'; // ISO 5218-style: 0 unknown, 1 male, 2 female, 9 not applicable
}

export interface ValidationIssue {
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
}

const MAX_AGE_YEARS = 130;

export class PatientValidator {
  validate(input: PatientInput, now: Date = new Date()): ValidationResult {
    const issues: ValidationIssue[] = [];

    if (!input.firstName || !input.firstName.trim()) {
      issues.push({ field: 'firstName', message: 'firstName is required' });
    }
    if (!input.lastName || !input.lastName.trim()) {
      issues.push({ field: 'lastName', message: 'lastName is required' });
    }
    if (!(input.dateOfBirth instanceof Date) || isNaN(input.dateOfBirth.getTime())) {
      issues.push({ field: 'dateOfBirth', message: 'dateOfBirth must be a valid date' });
    } else {
      if (input.dateOfBirth.getTime() > now.getTime()) {
        issues.push({ field: 'dateOfBirth', message: 'dateOfBirth cannot be in the future' });
      }
      const ageYears = this.ageInYears(input.dateOfBirth, now);
      if (ageYears > MAX_AGE_YEARS) {
        issues.push({
          field: 'dateOfBirth',
          message: `dateOfBirth implies an age over ${MAX_AGE_YEARS} years`,
        });
      }
    }
    if (!['0', '1', '2', '9'].includes(input.sex)) {
      issues.push({ field: 'sex', message: 'sex must be one of 0, 1, 2, 9 (ISO 5218)' });
    }

    return { valid: issues.length === 0, issues };
  }

  private ageInYears(dob: Date, now: Date): number {
    let age = now.getFullYear() - dob.getFullYear();
    const monthDiff = now.getMonth() - dob.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < dob.getDate())) {
      age--;
    }
    return age;
  }
}

import { useEffect, useState } from 'react';
import type { FormSchemaDefinition } from '../types';

export interface UseFormSchemaResult {
  schema: FormSchemaDefinition | null;
  loading: boolean;
  error: Error | null;
}

/**
 * Fetches a form schema by id, or by entityType (falls back to latest
 * published) from GET /v1/form-schemas/:id/render. `fetcher` is injected
 * so this hook doesn't hardcode the host app's HTTP client/base URL/auth
 * header wiring.
 */
export function useFormSchema(idOrEntityType: string, fetcher: (url: string) => Promise<FormSchemaDefinition>): UseFormSchemaResult {
  const [schema, setSchema] = useState<FormSchemaDefinition | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    fetcher(`/v1/form-schemas/${encodeURIComponent(idOrEntityType)}/render`)
      .then((result) => {
        if (!cancelled) setSchema(result);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err : new Error(String(err)));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [idOrEntityType, fetcher]);

  return { schema, loading, error };
}

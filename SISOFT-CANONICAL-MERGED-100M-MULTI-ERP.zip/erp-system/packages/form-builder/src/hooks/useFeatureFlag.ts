import { useEffect, useState } from 'react';

export interface UseFeatureFlagResult {
  enabled: boolean;
  loading: boolean;
}

/**
 * Evaluates a feature flag client-side by calling GET
 * /v1/feature-flags/:key (server-authoritative — this hook never
 * evaluates rollout/targeting logic itself, it just displays the
 * server's answer). Defaults to `enabled: false` while loading so gated
 * UI doesn't flash on before settling.
 */
export function useFeatureFlag(flagKey: string, fetcher: (url: string) => Promise<{ enabled: boolean }>): UseFeatureFlagResult {
  const [enabled, setEnabled] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    fetcher(`/v1/feature-flags/${encodeURIComponent(flagKey)}`)
      .then((result) => {
        if (!cancelled) setEnabled(result.enabled);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [flagKey, fetcher]);

  return { enabled, loading };
}

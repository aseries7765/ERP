import React from 'react';
import type { FieldComponentProps } from '../types';

/** Handles NUMBER and DECIMAL. */
export function NumberField({ field, value, onChange, error, disabled }: FieldComponentProps) {
  return (
    <div className="form-builder-field">
      <label htmlFor={`field-${field.key}`}>
        {field.label}
        {field.required && <span aria-hidden="true"> *</span>}
      </label>
      <input
        id={`field-${field.key}`}
        type="number"
        step={field.type === 'DECIMAL' ? 'any' : 1}
        value={value === null || value === undefined ? '' : (value as number)}
        onChange={(e) => onChange(e.target.value === '' ? null : Number(e.target.value))}
        disabled={disabled}
        min={field.validation?.min}
        max={field.validation?.max}
        aria-invalid={!!error}
      />
      {error && <p role="alert" className="form-builder-error">{error}</p>}
    </div>
  );
}

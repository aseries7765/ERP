import React from 'react';
import type { FieldComponentProps } from '../types';

/**
 * Handles FILE fields. This is a thin trigger only — actual upload
 * handling belongs to M3.8 (Documents & Files); this component just
 * stores whatever file *reference* (id/URL) the host app's upload flow
 * returns. Hosts should override via DynamicForm's `fieldComponents` prop
 * to wire in M3.8's real uploader; this default is a functional but
 * minimal fallback (a plain file input that reports the file name).
 */
export function FileField({ field, value, onChange, disabled }: FieldComponentProps) {
  return (
    <div className="form-builder-field">
      <label htmlFor={`field-${field.key}`}>{field.label}</label>
      <input
        id={`field-${field.key}`}
        type="file"
        disabled={disabled}
        onChange={(e) => onChange(e.target.files?.[0]?.name ?? null)}
      />
      {typeof value === 'string' && value && <p className="form-builder-help">Current: {value}</p>}
    </div>
  );
}

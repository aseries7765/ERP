import React from 'react';
import type { FieldComponentProps } from '../types';

function optionLabel(opt: string | { value: string; label: string }) {
  return typeof opt === 'string' ? opt : opt.label;
}
function optionValue(opt: string | { value: string; label: string }) {
  return typeof opt === 'string' ? opt : opt.value;
}

/** Handles ENUM (single-select) and MULTIENUM (multi-select). */
export function EnumField({ field, value, onChange, error, disabled }: FieldComponentProps) {
  const options = field.options ?? [];
  const isMulti = field.type === 'MULTIENUM';

  if (isMulti) {
    const selected = new Set(Array.isArray(value) ? (value as string[]) : []);
    return (
      <fieldset className="form-builder-field">
        <legend>
          {field.label}
          {field.required && <span aria-hidden="true"> *</span>}
        </legend>
        {options.map((opt) => {
          const v = optionValue(opt);
          return (
            <label key={v} className="form-builder-checkbox-option">
              <input
                type="checkbox"
                checked={selected.has(v)}
                disabled={disabled}
                onChange={(e) => {
                  const next = new Set(selected);
                  e.target.checked ? next.add(v) : next.delete(v);
                  onChange([...next]);
                }}
              />
              {optionLabel(opt)}
            </label>
          );
        })}
        {error && <p role="alert" className="form-builder-error">{error}</p>}
      </fieldset>
    );
  }

  return (
    <div className="form-builder-field">
      <label htmlFor={`field-${field.key}`}>
        {field.label}
        {field.required && <span aria-hidden="true"> *</span>}
      </label>
      <select id={`field-${field.key}`} value={(value as string) ?? ''} disabled={disabled} onChange={(e) => onChange(e.target.value)} aria-invalid={!!error}>
        <option value="" disabled>
          Select…
        </option>
        {options.map((opt) => (
          <option key={optionValue(opt)} value={optionValue(opt)}>
            {optionLabel(opt)}
          </option>
        ))}
      </select>
      {error && <p role="alert" className="form-builder-error">{error}</p>}
    </div>
  );
}

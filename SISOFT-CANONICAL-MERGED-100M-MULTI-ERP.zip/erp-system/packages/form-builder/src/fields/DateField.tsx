import React from 'react';
import type { FieldComponentProps } from '../types';

/** Handles DATE and DATETIME. */
export function DateField({ field, value, onChange, error, disabled }: FieldComponentProps) {
  return (
    <div className="form-builder-field">
      <label htmlFor={`field-${field.key}`}>
        {field.label}
        {field.required && <span aria-hidden="true"> *</span>}
      </label>
      <input
        id={`field-${field.key}`}
        type={field.type === 'DATETIME' ? 'datetime-local' : 'date'}
        value={(value as string) ?? ''}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        aria-invalid={!!error}
      />
      {error && <p role="alert" className="form-builder-error">{error}</p>}
    </div>
  );
}

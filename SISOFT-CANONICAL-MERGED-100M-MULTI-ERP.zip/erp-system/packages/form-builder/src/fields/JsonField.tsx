import React, { useState } from 'react';
import type { FieldComponentProps } from '../types';

/** Handles JSON fields as a raw-JSON textarea with client-side parse
 * feedback. Structural validation of the JSON's *shape* is left to the
 * consumer (see schema-validator.service.ts's JSON case). */
export function JsonField({ field, value, onChange, error, disabled }: FieldComponentProps) {
  const [text, setText] = useState(() => (value === undefined || value === null ? '' : JSON.stringify(value, null, 2)));
  const [parseError, setParseError] = useState<string | null>(null);

  return (
    <div className="form-builder-field">
      <label htmlFor={`field-${field.key}`}>{field.label}</label>
      <textarea
        id={`field-${field.key}`}
        rows={6}
        value={text}
        disabled={disabled}
        onChange={(e) => {
          setText(e.target.value);
          try {
            onChange(e.target.value.trim() === '' ? null : JSON.parse(e.target.value));
            setParseError(null);
          } catch {
            setParseError('Invalid JSON');
          }
        }}
      />
      {(parseError || error) && <p role="alert" className="form-builder-error">{parseError ?? error}</p>}
    </div>
  );
}

import React from 'react';
import type { FieldComponentProps } from '../types';

/**
 * Handles REFERENCE fields (FK to another entity). Ships as a plain text
 * input for the referenced id/code by default; hosts that want a live
 * lookup/autocomplete should swap this component out via DynamicForm's
 * `fieldComponents` override prop (see DynamicForm.tsx) rather than
 * editing this file, since the right lookup UI is host-app-specific.
 */
export function ReferenceField({ field, value, onChange, error, disabled }: FieldComponentProps) {
  const refEntity = field.validation?.refEntity;
  return (
    <div className="form-builder-field">
      <label htmlFor={`field-${field.key}`}>
        {field.label}
        {field.required && <span aria-hidden="true"> *</span>}
      </label>
      <input
        id={`field-${field.key}`}
        type="text"
        placeholder={refEntity ? `${refEntity} ID…` : field.placeholder}
        value={(value as string) ?? ''}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        aria-invalid={!!error}
      />
      {error && <p role="alert" className="form-builder-error">{error}</p>}
    </div>
  );
}

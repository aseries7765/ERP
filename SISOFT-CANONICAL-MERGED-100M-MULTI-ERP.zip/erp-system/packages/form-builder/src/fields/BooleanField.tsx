import React from 'react';
import type { FieldComponentProps } from '../types';

export function BooleanField({ field, value, onChange, disabled }: FieldComponentProps) {
  return (
    <div className="form-builder-field form-builder-field--boolean">
      <label htmlFor={`field-${field.key}`}>
        <input
          id={`field-${field.key}`}
          type="checkbox"
          checked={!!value}
          onChange={(e) => onChange(e.target.checked)}
          disabled={disabled}
        />
        {field.label}
      </label>
    </div>
  );
}

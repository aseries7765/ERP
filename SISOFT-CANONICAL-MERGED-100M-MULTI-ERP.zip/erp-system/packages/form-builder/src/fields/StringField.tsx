import React from 'react';
import type { FieldComponentProps } from '../types';

/** Handles STRING, TEXT (textarea), EMAIL, PHONE, URL — all plain-text
 * inputs that differ only in HTML input type / element. */
export function StringField({ field, value, onChange, error, disabled }: FieldComponentProps) {
  const inputType = { EMAIL: 'email', URL: 'url', PHONE: 'tel' }[field.type as string] ?? 'text';
  const common = {
    id: `field-${field.key}`,
    value: (value as string) ?? '',
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => onChange(e.target.value),
    disabled,
    placeholder: field.placeholder,
    'aria-invalid': !!error,
    'aria-describedby': error ? `field-${field.key}-error` : undefined,
  };

  return (
    <div className="form-builder-field">
      <label htmlFor={`field-${field.key}`}>
        {field.label}
        {field.required && <span aria-hidden="true"> *</span>}
      </label>
      {field.type === 'TEXT' ? <textarea rows={4} {...common} /> : <input type={inputType} {...common} />}
      {field.helpText && <p className="form-builder-help">{field.helpText}</p>}
      {error && <p id={`field-${field.key}-error`} role="alert" className="form-builder-error">{error}</p>}
    </div>
  );
}

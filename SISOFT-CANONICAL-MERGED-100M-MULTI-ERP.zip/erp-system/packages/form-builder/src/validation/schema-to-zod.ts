import { z, ZodTypeAny } from 'zod';
import type { FormFieldDefinition } from '../types';

/**
 * Converts a FormFieldDefinition into a runtime zod schema, so the exact
 * same field-type rules the backend enforces (schema-validator.service.ts)
 * are also enforced client-side before submission (fast feedback; the
 * backend remains the source of truth and re-validates on submit).
 */
function fieldToZod(field: FormFieldDefinition): ZodTypeAny {
  let schema: ZodTypeAny;

  switch (field.type) {
    case 'STRING':
    case 'TEXT': {
      let s = z.string();
      if (field.validation?.minLength !== undefined) s = s.min(field.validation.minLength);
      if (field.validation?.maxLength !== undefined) s = s.max(field.validation.maxLength);
      if (field.validation?.regex) s = s.regex(new RegExp(field.validation.regex));
      schema = s;
      break;
    }
    case 'NUMBER':
    case 'DECIMAL': {
      let n = z.number();
      if (field.validation?.min !== undefined) n = n.min(field.validation.min);
      if (field.validation?.max !== undefined) n = n.max(field.validation.max);
      schema = n;
      break;
    }
    case 'BOOLEAN':
      schema = z.boolean();
      break;
    case 'DATE':
    case 'DATETIME':
      schema = z.string().refine((v) => !Number.isNaN(new Date(v).getTime()), 'Must be a valid date');
      break;
    case 'EMAIL':
      schema = z.string().email();
      break;
    case 'URL':
      schema = z.string().url();
      break;
    case 'PHONE':
      schema = z.string().regex(/^[+]?[\d\s().-]{6,20}$/, 'Must be a valid phone number');
      break;
    case 'ENUM': {
      const values = (field.options ?? []).map((o) => (typeof o === 'string' ? o : o.value));
      schema = values.length ? z.enum(values as [string, ...string[]]) : z.string();
      break;
    }
    case 'MULTIENUM': {
      const values = (field.options ?? []).map((o) => (typeof o === 'string' ? o : o.value));
      schema = z.array(values.length ? z.enum(values as [string, ...string[]]) : z.string());
      break;
    }
    case 'REFERENCE':
      schema = z.union([z.string(), z.number()]);
      break;
    case 'JSON':
      schema = z.unknown();
      break;
    case 'FILE':
      schema = z.string(); // file id/reference, not raw bytes
      break;
    default:
      schema = z.unknown();
  }

  return field.required ? schema : schema.optional().nullable();
}

/** Builds a zod object schema for an entire form (keyed by field.key). */
export function schemaToZod(fields: FormFieldDefinition[]) {
  const shape: Record<string, ZodTypeAny> = {};
  for (const field of fields) shape[field.key] = fieldToZod(field);
  return z.object(shape);
}

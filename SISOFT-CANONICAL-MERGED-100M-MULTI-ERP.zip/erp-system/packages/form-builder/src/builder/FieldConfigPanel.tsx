import React from 'react';
import type { FormFieldDefinition } from '../types';

export interface FieldConfigPanelProps {
  field: FormFieldDefinition;
  onChange: (next: FormFieldDefinition) => void;
  onRemove: () => void;
}

/** Editor for a single field's label/required/options/validation, shown
 * when a field in the designer canvas is selected. */
export function FieldConfigPanel({ field, onChange, onRemove }: FieldConfigPanelProps) {
  const isChoice = field.type === 'ENUM' || field.type === 'MULTIENUM';
  const optionsText = (field.options ?? []).map((o) => (typeof o === 'string' ? o : `${o.value}:${o.label}`)).join('\n');

  return (
    <div className="form-builder-field-config">
      <h4>Field: {field.key}</h4>
      <label>
        Label
        <input value={field.label} onChange={(e) => onChange({ ...field, label: e.target.value })} />
      </label>
      <label>
        <input type="checkbox" checked={!!field.required} onChange={(e) => onChange({ ...field, required: e.target.checked })} />
        Required
      </label>
      <label>
        Help text
        <input value={field.helpText ?? ''} onChange={(e) => onChange({ ...field, helpText: e.target.value })} />
      </label>
      {isChoice && (
        <label>
          Options (one per line, "value:label" or just "value")
          <textarea
            rows={4}
            value={optionsText}
            onChange={(e) => {
              const options = e.target.value
                .split('\n')
                .map((line) => line.trim())
                .filter(Boolean)
                .map((line) => {
                  const [value, label] = line.split(':');
                  return label ? { value, label } : value;
                });
              onChange({ ...field, options });
            }}
          />
        </label>
      )}
      {field.type === 'REFERENCE' && (
        <label>
          Referenced entity
          <input
            value={field.validation?.refEntity ?? ''}
            onChange={(e) => onChange({ ...field, validation: { ...field.validation, refEntity: e.target.value } })}
          />
        </label>
      )}
      <button type="button" onClick={onRemove} className="form-builder-remove">
        Remove field
      </button>
    </div>
  );
}

import React from 'react';
import type { CustomFieldType } from '../types';

const PALETTE: { type: CustomFieldType; label: string }[] = [
  { type: 'STRING', label: 'Short text' },
  { type: 'TEXT', label: 'Long text' },
  { type: 'NUMBER', label: 'Number' },
  { type: 'DECIMAL', label: 'Decimal' },
  { type: 'BOOLEAN', label: 'Yes / No' },
  { type: 'DATE', label: 'Date' },
  { type: 'DATETIME', label: 'Date & time' },
  { type: 'ENUM', label: 'Dropdown (single)' },
  { type: 'MULTIENUM', label: 'Checkboxes (multi)' },
  { type: 'EMAIL', label: 'Email' },
  { type: 'PHONE', label: 'Phone' },
  { type: 'URL', label: 'URL' },
  { type: 'REFERENCE', label: 'Linked record' },
  { type: 'JSON', label: 'JSON' },
  { type: 'FILE', label: 'File' },
];

export interface FieldPaletteProps {
  onAdd: (type: CustomFieldType) => void;
}

/** Sidebar of addable field types for the form designer. */
export function FieldPalette({ onAdd }: FieldPaletteProps) {
  return (
    <div className="form-builder-palette">
      <h3>Add a field</h3>
      <ul>
        {PALETTE.map((item) => (
          <li key={item.type}>
            <button type="button" onClick={() => onAdd(item.type)}>
              {item.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

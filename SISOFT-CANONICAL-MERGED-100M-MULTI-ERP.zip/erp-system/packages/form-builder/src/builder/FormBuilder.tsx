import React, { useState } from 'react';
import type { FormFieldDefinition, CustomFieldType } from '../types';
import { FieldPalette } from './FieldPalette';
import { FieldConfigPanel } from './FieldConfigPanel';
import { DynamicForm } from '../DynamicForm';

export interface FormBuilderValue {
  entityType: string;
  name: string;
  fields: FormFieldDefinition[];
  layout: string[][];
}

export interface FormBuilderProps {
  entityType: string;
  initialValue?: Partial<FormBuilderValue>;
  onSave: (value: FormBuilderValue) => void | Promise<void>;
  onPublish?: (value: FormBuilderValue) => void | Promise<void>;
}

let autoIdCounter = 0;
function autoKey(type: CustomFieldType) {
  autoIdCounter += 1;
  return `${type.toLowerCase()}_${autoIdCounter}`;
}

/**
 * Admin-facing form designer: add fields from the palette, configure them,
 * and arrange them into rows (layout). One row per field by default —
 * hosts that want drag-to-reorder / multi-field rows can post-process
 * `layout` after onSave, or fork this component; reordering UI itself is
 * out of scope for this initial delivery (see MANIFEST.md "Known
 * limitations").
 */
export function FormBuilder({ entityType, initialValue, onSave, onPublish }: FormBuilderProps) {
  const [name, setName] = useState(initialValue?.name ?? `${entityType} form`);
  const [fields, setFields] = useState<FormFieldDefinition[]>(initialValue?.fields ?? []);
  const [layout, setLayout] = useState<string[][]>(initialValue?.layout ?? []);
  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);

  function addField(type: CustomFieldType) {
    const key = autoKey(type);
    const field: FormFieldDefinition = { key, type, label: `New ${type.toLowerCase()} field`, required: false };
    setFields((prev) => [...prev, field]);
    setLayout((prev) => [...prev, [key]]);
    setSelectedKey(key);
  }

  function updateField(next: FormFieldDefinition) {
    setFields((prev) => prev.map((f) => (f.key === next.key ? next : f)));
  }

  function removeField(key: string) {
    setFields((prev) => prev.filter((f) => f.key !== key));
    setLayout((prev) => prev.map((row) => row.filter((k) => k !== key)).filter((row) => row.length > 0));
    if (selectedKey === key) setSelectedKey(null);
  }

  function currentValue(): FormBuilderValue {
    return { entityType, name, fields, layout };
  }

  const selectedField = fields.find((f) => f.key === selectedKey) ?? null;
  const previewSchema = { id: 'preview', tenantId: 'preview', entityType, name, version: 0, fields, layout, isPublished: false };

  return (
    <div className="form-builder-designer">
      <div className="form-builder-designer-header">
        <label>
          Form name
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <button type="button" onClick={() => setShowPreview((v) => !v)}>
          {showPreview ? 'Back to editing' : 'Preview'}
        </button>
        <button type="button" onClick={() => onSave(currentValue())}>
          Save draft
        </button>
        {onPublish && (
          <button type="button" onClick={() => onPublish(currentValue())}>
            Publish
          </button>
        )}
      </div>

      {showPreview ? (
        <DynamicForm schema={previewSchema} onSubmit={() => {}} submitLabel="(preview only)" disabled />
      ) : (
        <div className="form-builder-designer-body">
          <FieldPalette onAdd={addField} />
          <ul className="form-builder-canvas">
            {fields.map((f) => (
              <li key={f.key} onClick={() => setSelectedKey(f.key)} className={f.key === selectedKey ? 'selected' : ''}>
                {f.label} <small>({f.type})</small>
              </li>
            ))}
          </ul>
          {selectedField && <FieldConfigPanel field={selectedField} onChange={updateField} onRemove={() => removeField(selectedField.key)} />}
        </div>
      )}
    </div>
  );
}

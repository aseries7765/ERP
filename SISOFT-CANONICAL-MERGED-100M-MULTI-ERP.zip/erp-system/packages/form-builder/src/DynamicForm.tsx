import React, { useMemo, useState } from 'react';
import type { FormSchemaDefinition, FormFieldDefinition, FieldComponentProps, FormValues } from './types';
import { schemaToZod } from './validation/schema-to-zod';
import { StringField } from './fields/StringField';
import { NumberField } from './fields/NumberField';
import { BooleanField } from './fields/BooleanField';
import { DateField } from './fields/DateField';
import { EnumField } from './fields/EnumField';
import { ReferenceField } from './fields/ReferenceField';
import { JsonField } from './fields/JsonField';
import { FileField } from './fields/FileField';

type FieldComponent = React.ComponentType<FieldComponentProps>;

const DEFAULT_FIELD_COMPONENTS: Record<string, FieldComponent> = {
  STRING: StringField,
  TEXT: StringField,
  EMAIL: StringField,
  PHONE: StringField,
  URL: StringField,
  NUMBER: NumberField,
  DECIMAL: NumberField,
  BOOLEAN: BooleanField,
  DATE: DateField,
  DATETIME: DateField,
  ENUM: EnumField,
  MULTIENUM: EnumField,
  REFERENCE: ReferenceField,
  JSON: JsonField,
  FILE: FileField,
};

export interface DynamicFormProps {
  schema: FormSchemaDefinition;
  initialValues?: FormValues;
  onSubmit: (values: FormValues) => void | Promise<void>;
  /** Override or extend the field-type -> component mapping (e.g. to plug
   * in a real autocomplete for REFERENCE, or a real uploader for FILE). */
  fieldComponents?: Partial<Record<string, FieldComponent>>;
  submitLabel?: string;
  disabled?: boolean;
}

/**
 * Renders a form from a FormSchema (fields + layout), running the same
 * validation rules as the backend's schema-validator.service.ts (via
 * schema-to-zod.ts) before calling onSubmit. Layout is a grid of rows,
 * each row a list of field keys rendered side-by-side.
 */
export function DynamicForm({ schema, initialValues = {}, onSubmit, fieldComponents, submitLabel = 'Submit', disabled }: DynamicFormProps) {
  const [values, setValues] = useState<FormValues>(initialValues);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const zodSchema = useMemo(() => schemaToZod(schema.fields), [schema.fields]);
  const fieldsByKey = useMemo(() => new Map(schema.fields.map((f) => [f.key, f])), [schema.fields]);
  const components = { ...DEFAULT_FIELD_COMPONENTS, ...fieldComponents };

  function setValue(key: string, value: unknown) {
    setValues((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => (prev[key] ? { ...prev, [key]: '' } : prev));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const result = zodSchema.safeParse(values);
    if (!result.success) {
      const nextErrors: Record<string, string> = {};
      for (const issue of result.error.issues) nextErrors[String(issue.path[0])] = issue.message;
      setErrors(nextErrors);
      return;
    }
    setSubmitting(true);
    try {
      await onSubmit(result.data as FormValues);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form className="form-builder" onSubmit={handleSubmit} noValidate>
      {schema.layout.map((row, i) => (
        <div className="form-builder-row" key={i}>
          {row.map((key) => {
            const field = fieldsByKey.get(key);
            if (!field) return null;
            const Component = components[field.type] ?? StringField;
            return (
              <Component
                key={key}
                field={field as FormFieldDefinition}
                value={values[key]}
                onChange={(v) => setValue(key, v)}
                error={errors[key]}
                disabled={disabled || submitting}
              />
            );
          })}
        </div>
      ))}
      <button type="submit" disabled={disabled || submitting}>
        {submitting ? 'Submitting…' : submitLabel}
      </button>
    </form>
  );
}

import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { FormBuilder } from '../builder/FormBuilder';

describe('FormBuilder', () => {
  it('adding a field from the palette adds it to the canvas', () => {
    render(<FormBuilder entityType="Customer" onSave={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: /short text/i }));
    expect(screen.getByText(/New string field/i)).toBeInTheDocument();
  });

  it('calls onSave with the current entityType, fields, and layout', () => {
    const onSave = vi.fn();
    render(<FormBuilder entityType="Customer" onSave={onSave} />);
    fireEvent.click(screen.getByRole('button', { name: /short text/i }));
    fireEvent.click(screen.getByRole('button', { name: /save draft/i }));

    expect(onSave).toHaveBeenCalledWith(
      expect.objectContaining({
        entityType: 'Customer',
        fields: expect.arrayContaining([expect.objectContaining({ type: 'STRING' })]),
      }),
    );
  });

  it('removing the selected field clears it from both fields and layout', () => {
    const onSave = vi.fn();
    render(<FormBuilder entityType="Customer" onSave={onSave} />);
    fireEvent.click(screen.getByRole('button', { name: /short text/i }));
    fireEvent.click(screen.getByRole('button', { name: /remove field/i }));
    fireEvent.click(screen.getByRole('button', { name: /save draft/i }));

    expect(onSave).toHaveBeenCalledWith(expect.objectContaining({ fields: [], layout: [] }));
  });
});

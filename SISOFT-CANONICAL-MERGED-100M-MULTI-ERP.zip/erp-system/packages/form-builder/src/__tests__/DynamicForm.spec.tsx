import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { DynamicForm } from '../DynamicForm';
import type { FormSchemaDefinition } from '../types';

const schema: FormSchemaDefinition = {
  id: 's1',
  tenantId: 't1',
  entityType: 'Customer',
  name: 'Intake',
  version: 1,
  fields: [
    { key: 'name', type: 'STRING', label: 'Name', required: true },
    { key: 'vip', type: 'BOOLEAN', label: 'VIP' },
  ],
  layout: [['name'], ['vip']],
  isPublished: true,
};

describe('DynamicForm', () => {
  it('renders one input per field in the schema', () => {
    render(<DynamicForm schema={schema} onSubmit={() => {}} />);
    expect(screen.getByLabelText(/Name/)).toBeInTheDocument();
    expect(screen.getByLabelText(/VIP/)).toBeInTheDocument();
  });

  it('blocks submission and shows an error when a required field is empty', async () => {
    const onSubmit = vi.fn();
    render(<DynamicForm schema={schema} onSubmit={onSubmit} />);
    fireEvent.click(screen.getByRole('button', { name: /submit/i }));

    await waitFor(() => expect(screen.getByRole('alert')).toBeInTheDocument());
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it('calls onSubmit with validated values when the form is valid', async () => {
    const onSubmit = vi.fn();
    render(<DynamicForm schema={schema} onSubmit={onSubmit} />);
    fireEvent.change(screen.getByLabelText(/Name/), { target: { value: 'Ada' } });
    fireEvent.click(screen.getByRole('button', { name: /submit/i }));

    await waitFor(() => expect(onSubmit).toHaveBeenCalledWith(expect.objectContaining({ name: 'Ada' })));
  });
});

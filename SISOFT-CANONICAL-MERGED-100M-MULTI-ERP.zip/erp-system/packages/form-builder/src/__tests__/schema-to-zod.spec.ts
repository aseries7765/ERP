import { describe, it, expect } from 'vitest';
import { schemaToZod } from '../validation/schema-to-zod';
import type { FormFieldDefinition } from '../types';

describe('schemaToZod', () => {
  it('marks required fields as required and optional fields as optional', () => {
    const fields: FormFieldDefinition[] = [
      { key: 'name', type: 'STRING', label: 'Name', required: true },
      { key: 'nickname', type: 'STRING', label: 'Nickname', required: false },
    ];
    const schema = schemaToZod(fields);

    expect(schema.safeParse({ name: 'Ada' }).success).toBe(true);
    expect(schema.safeParse({}).success).toBe(false); // name missing
  });

  it('enforces number min/max', () => {
    const fields: FormFieldDefinition[] = [{ key: 'qty', type: 'NUMBER', label: 'Qty', required: true, validation: { min: 1, max: 5 } }];
    const schema = schemaToZod(fields);
    expect(schema.safeParse({ qty: 0 }).success).toBe(false);
    expect(schema.safeParse({ qty: 3 }).success).toBe(true);
  });

  it('enforces ENUM against declared options', () => {
    const fields: FormFieldDefinition[] = [{ key: 'status', type: 'ENUM', label: 'Status', required: true, options: ['open', 'closed'] }];
    const schema = schemaToZod(fields);
    expect(schema.safeParse({ status: 'archived' }).success).toBe(false);
    expect(schema.safeParse({ status: 'open' }).success).toBe(true);
  });

  it('validates EMAIL format', () => {
    const fields: FormFieldDefinition[] = [{ key: 'email', type: 'EMAIL', label: 'Email', required: true }];
    const schema = schemaToZod(fields);
    expect(schema.safeParse({ email: 'nope' }).success).toBe(false);
    expect(schema.safeParse({ email: 'a@b.com' }).success).toBe(true);
  });
});

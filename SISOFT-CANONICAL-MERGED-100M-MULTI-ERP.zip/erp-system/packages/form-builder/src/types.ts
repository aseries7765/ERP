export type {
  CustomFieldType,
  CustomFieldOption,
  CustomFieldValidation,
  FormFieldDefinition,
  FormSchemaDefinition,
  FeatureFlagDefinition,
  FeatureFlagEvalContext,
} from '@erp/shared-types/settings';

export interface FormValues {
  [key: string]: unknown;
}

export interface FieldComponentProps {
  field: import('@erp/shared-types/settings').FormFieldDefinition;
  value: unknown;
  onChange: (value: unknown) => void;
  error?: string;
  disabled?: boolean;
}

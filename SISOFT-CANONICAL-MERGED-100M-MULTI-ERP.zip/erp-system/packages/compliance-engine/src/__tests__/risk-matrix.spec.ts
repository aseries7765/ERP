import { calculateRisk, requiresDpoConsultation } from '../risk-matrix';

describe('calculateRisk', () => {
  it('classifies low scores as low risk', () => {
    const result = calculateRisk({ likelihood: 1, impact: 2 });
    expect(result.score).toBe(2);
    expect(result.level).toBe('low');
  });

  it('classifies mid scores as medium risk', () => {
    const result = calculateRisk({ likelihood: 2, impact: 3 });
    expect(result.score).toBe(6);
    expect(result.level).toBe('medium');
  });

  it('classifies scores of 10-15 as high risk', () => {
    const result = calculateRisk({ likelihood: 3, impact: 4 });
    expect(result.score).toBe(12);
    expect(result.level).toBe('high');
  });

  it('classifies scores of 16+ as critical risk', () => {
    const result = calculateRisk({ likelihood: 5, impact: 5 });
    expect(result.score).toBe(25);
    expect(result.level).toBe('critical');
  });

  it('rejects out-of-range likelihood', () => {
    expect(() => calculateRisk({ likelihood: 6 as any, impact: 3 })).toThrow();
  });

  it('rejects non-integer impact', () => {
    expect(() => calculateRisk({ likelihood: 3, impact: 2.5 as any })).toThrow();
  });
});

describe('requiresDpoConsultation', () => {
  it('requires consultation for high risk', () => {
    expect(requiresDpoConsultation(calculateRisk({ likelihood: 3, impact: 4 }))).toBe(true);
  });

  it('requires consultation for critical risk', () => {
    expect(requiresDpoConsultation(calculateRisk({ likelihood: 5, impact: 5 }))).toBe(true);
  });

  it('does not require consultation for low or medium risk', () => {
    expect(requiresDpoConsultation(calculateRisk({ likelihood: 1, impact: 1 }))).toBe(false);
    expect(requiresDpoConsultation(calculateRisk({ likelihood: 2, impact: 2 }))).toBe(false);
  });
});

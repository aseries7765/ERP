import { analyzeGaps } from '../gap-analysis';
import { ComplianceControl, ComplianceRequirement } from '../types';

function req(id: string): ComplianceRequirement {
  return { id, frameworkId: 'gdpr', code: id, title: id, description: id };
}

function control(id: string, requirementIds: string[], status: ComplianceControl['implementation']['status'] = 'implemented'): ComplianceControl {
  return {
    id,
    frameworkId: 'gdpr',
    requirementIds,
    title: id,
    implementation: { status },
    testing: { result: 'not_tested' },
    effectiveness: { score: 0 },
  };
}

describe('analyzeGaps', () => {
  it('returns zero coverage for a framework with no requirements', () => {
    const result = analyzeGaps('gdpr', [], []);
    expect(result.coveragePct).toBe(0);
    expect(result.requirementsTotal).toBe(0);
  });

  it('treats unmapped requirements as gaps', () => {
    const requirements = [req('r1'), req('r2')];
    const controls = [control('c1', ['r1'])];

    const result = analyzeGaps('gdpr', requirements, controls);

    expect(result.uncoveredRequirements.map((r) => r.id)).toEqual(['r2']);
    expect(result.requirementsCovered).toBe(1);
    expect(result.coveragePct).toBe(50);
  });

  it('treats requirements mapped only to non-implemented controls as gaps', () => {
    const requirements = [req('r1')];
    const controls = [control('c1', ['r1'], 'partial')];

    const result = analyzeGaps('gdpr', requirements, controls);

    expect(result.uncoveredRequirements.map((r) => r.id)).toEqual(['r1']);
    expect(result.coveragePct).toBe(0);
  });

  it('reports full coverage when every requirement has an implemented control', () => {
    const requirements = [req('r1'), req('r2')];
    const controls = [control('c1', ['r1']), control('c2', ['r2'])];

    const result = analyzeGaps('gdpr', requirements, controls);

    expect(result.uncoveredRequirements).toEqual([]);
    expect(result.coveragePct).toBe(100);
  });
});

import { calculateComplianceScore } from '../scoring';
import { ComplianceControl, OpenFinding } from '../types';

function control(overrides: Partial<ComplianceControl> = {}): ComplianceControl {
  return {
    id: 'c1',
    frameworkId: 'gdpr',
    requirementIds: ['r1'],
    title: 'c1',
    implementation: { status: 'implemented' },
    testing: { result: 'pass' },
    effectiveness: { score: 100 },
    ...overrides,
  };
}

describe('calculateComplianceScore', () => {
  it('returns a zero score for a framework with no controls', () => {
    const result = calculateComplianceScore('gdpr', [], []);
    expect(result.score).toBe(0);
    expect(result.controlsTotal).toBe(0);
  });

  it('returns 100 when every control is fully implemented, tested and effective with no findings', () => {
    const controls = [control(), control({ id: 'c2' })];
    const result = calculateComplianceScore('gdpr', controls, []);
    expect(result.score).toBe(100);
    expect(result.controlsImplementedPct).toBe(100);
    expect(result.controlsTestedPct).toBe(100);
    expect(result.controlsEffectivePct).toBe(100);
  });

  it('reduces the score for controls that are not implemented', () => {
    const controls = [
      control(),
      control({ id: 'c2', implementation: { status: 'not_implemented' } }),
    ];
    const result = calculateComplianceScore('gdpr', controls, []);
    expect(result.controlsImplementedPct).toBe(50);
    expect(result.score).toBeLessThan(100);
  });

  it('applies a penalty for open critical findings', () => {
    const controls = [control()];
    const findings: OpenFinding[] = [
      { id: 'f1', controlId: 'c1', severity: 'critical', status: 'open', dueAt: '2099-01-01' },
    ];
    const result = calculateComplianceScore('gdpr', controls, findings);
    expect(result.openFindings).toBe(1);
    expect(result.score).toBeLessThan(100);
  });

  it('does not penalize for resolved findings', () => {
    const controls = [control()];
    const findings: OpenFinding[] = [
      { id: 'f1', controlId: 'c1', severity: 'critical', status: 'resolved', dueAt: '2020-01-01' },
    ];
    const result = calculateComplianceScore('gdpr', controls, findings);
    expect(result.openFindings).toBe(0);
    expect(result.score).toBe(100);
  });

  it('counts findings past their due date as overdue', () => {
    const controls = [control()];
    const findings: OpenFinding[] = [
      { id: 'f1', controlId: 'c1', severity: 'low', status: 'open', dueAt: '2000-01-01' },
    ];
    const result = calculateComplianceScore('gdpr', controls, findings);
    expect(result.overdueFindings).toBe(1);
  });

  it('never returns a score below 0 even with many critical findings', () => {
    const controls = [control({ implementation: { status: 'not_implemented' }, testing: { result: 'fail' }, effectiveness: { score: 0 } })];
    const findings: OpenFinding[] = Array.from({ length: 10 }, (_, i) => ({
      id: `f${i}`,
      controlId: 'c1',
      severity: 'critical' as const,
      status: 'open' as const,
      dueAt: '2000-01-01',
    }));
    const result = calculateComplianceScore('gdpr', controls, findings);
    expect(result.score).toBeGreaterThanOrEqual(0);
  });
});

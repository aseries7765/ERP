import {
  mapRequirementsToControls,
  findUnmappedRequirements,
  findDanglingControlReferences,
} from '../control-mapping';
import { ComplianceControl, ComplianceRequirement } from '../types';

function req(id: string): ComplianceRequirement {
  return { id, frameworkId: 'gdpr', code: id, title: id, description: id };
}

function control(id: string, requirementIds: string[]): ComplianceControl {
  return {
    id,
    frameworkId: 'gdpr',
    requirementIds,
    title: id,
    implementation: { status: 'not_implemented' },
    testing: { result: 'not_tested' },
    effectiveness: { score: 0 },
  };
}

describe('mapRequirementsToControls', () => {
  it('maps each requirement to the controls that reference it', () => {
    const requirements = [req('r1'), req('r2')];
    const controls = [control('c1', ['r1']), control('c2', ['r1', 'r2'])];

    const map = mapRequirementsToControls(requirements, controls);

    expect(map.get('r1')?.map((c) => c.id)).toEqual(['c1', 'c2']);
    expect(map.get('r2')?.map((c) => c.id)).toEqual(['c2']);
  });

  it('returns an empty array for requirements with no controls', () => {
    const requirements = [req('r1')];
    const map = mapRequirementsToControls(requirements, []);
    expect(map.get('r1')).toEqual([]);
  });
});

describe('findUnmappedRequirements', () => {
  it('finds requirements with zero mapped controls', () => {
    const requirements = [req('r1'), req('r2')];
    const controls = [control('c1', ['r1'])];

    const unmapped = findUnmappedRequirements(requirements, controls);

    expect(unmapped.map((r) => r.id)).toEqual(['r2']);
  });

  it('returns empty array when all requirements are mapped', () => {
    const requirements = [req('r1')];
    const controls = [control('c1', ['r1'])];
    expect(findUnmappedRequirements(requirements, controls)).toEqual([]);
  });
});

describe('findDanglingControlReferences', () => {
  it('finds controls referencing a requirement id that does not exist', () => {
    const requirements = [req('r1')];
    const controls = [control('c1', ['r1', 'ghost'])];

    const dangling = findDanglingControlReferences(requirements, controls);

    expect(dangling.map((c) => c.id)).toEqual(['c1']);
  });

  it('returns empty array when every reference is valid', () => {
    const requirements = [req('r1'), req('r2')];
    const controls = [control('c1', ['r1', 'r2'])];
    expect(findDanglingControlReferences(requirements, controls)).toEqual([]);
  });
});

import { ComplianceControl, ComplianceRequirement } from './types';

/**
 * Maps requirements to the controls that implement them.
 * Pure function over in-memory data — no I/O.
 */
export function mapRequirementsToControls(
  requirements: ComplianceRequirement[],
  controls: ComplianceControl[],
): Map<string, ComplianceControl[]> {
  const map = new Map<string, ComplianceControl[]>();

  for (const requirement of requirements) {
    const matches = controls.filter((control) =>
      control.requirementIds.includes(requirement.id),
    );
    map.set(requirement.id, matches);
  }

  return map;
}

/**
 * Returns requirement IDs that have zero mapped controls.
 */
export function findUnmappedRequirements(
  requirements: ComplianceRequirement[],
  controls: ComplianceControl[],
): ComplianceRequirement[] {
  const mapping = mapRequirementsToControls(requirements, controls);
  return requirements.filter((r) => (mapping.get(r.id) ?? []).length === 0);
}

/**
 * Returns controls that reference a requirement ID not present in the
 * supplied requirement list. Used to catch data-integrity issues in
 * framework catalogs (dangling requirement references).
 */
export function findDanglingControlReferences(
  requirements: ComplianceRequirement[],
  controls: ComplianceControl[],
): ComplianceControl[] {
  const requirementIds = new Set(requirements.map((r) => r.id));
  return controls.filter((control) =>
    control.requirementIds.some((id) => !requirementIds.has(id)),
  );
}

import { findUnmappedRequirements } from './control-mapping';
import { ComplianceControl, ComplianceRequirement, GapAnalysisResult } from './types';

/**
 * Identifies requirements with no implemented, effective control coverage.
 * A requirement counts as "covered" only if at least one mapped control
 * is implemented (partial/not_implemented controls do not count).
 */
export function analyzeGaps(
  frameworkId: string,
  requirements: ComplianceRequirement[],
  controls: ComplianceControl[],
): GapAnalysisResult {
  const requirementsTotal = requirements.length;

  if (requirementsTotal === 0) {
    return {
      frameworkId,
      uncoveredRequirements: [],
      requirementsTotal: 0,
      requirementsCovered: 0,
      coveragePct: 0,
    };
  }

  const unmapped = new Set(findUnmappedRequirements(requirements, controls).map((r) => r.id));

  const uncoveredRequirements = requirements.filter((requirement) => {
    if (unmapped.has(requirement.id)) return true;
    const mappedControls = controls.filter((c) =>
      c.requirementIds.includes(requirement.id),
    );
    const hasImplementedControl = mappedControls.some(
      (c) => c.implementation.status === 'implemented',
    );
    return !hasImplementedControl;
  });

  const requirementsCovered = requirementsTotal - uncoveredRequirements.length;
  const coveragePct = Math.round((requirementsCovered / requirementsTotal) * 10000) / 100;

  return {
    frameworkId,
    uncoveredRequirements,
    requirementsTotal,
    requirementsCovered,
    coveragePct,
  };
}

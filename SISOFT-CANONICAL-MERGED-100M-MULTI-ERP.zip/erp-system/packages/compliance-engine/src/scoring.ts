import { ComplianceControl, ComplianceScoreBreakdown, OpenFinding } from './types';

/**
 * Weighted compliance score, per ADR 0169.
 * Weights: implementation 40%, testing 30%, effectiveness 30% (sums to a
 * 0-100 base score). Open findings then apply a separate deduction of up
 * to 10 additional points, so the theoretical floor is 0 not -10.
 */
const WEIGHTS = {
  implementation: 0.4,
  testing: 0.3,
  effectiveness: 0.3,
};
// Findings penalty is a separate deduction from the 0-100 base score,
// capped at 10 points, not part of the implementation/testing/effectiveness budget.
const FINDINGS_PENALTY_MAX_POINTS = 10;

export function calculateComplianceScore(
  frameworkId: string,
  controls: ComplianceControl[],
  findings: OpenFinding[],
): ComplianceScoreBreakdown {
  const controlsTotal = controls.length;

  if (controlsTotal === 0) {
    return {
      frameworkId,
      controlsTotal: 0,
      controlsImplementedPct: 0,
      controlsTestedPct: 0,
      controlsEffectivePct: 0,
      openFindings: 0,
      overdueFindings: 0,
      score: 0,
    };
  }

  const implementedCount = controls.filter(
    (c) => c.implementation.status === 'implemented',
  ).length;
  const testedCount = controls.filter((c) => c.testing.result !== 'not_tested').length;
  const passedCount = controls.filter((c) => c.testing.result === 'pass').length;

  const controlsImplementedPct = round2((implementedCount / controlsTotal) * 100);
  const controlsTestedPct = round2((testedCount / controlsTotal) * 100);

  const avgEffectiveness =
    controls.reduce((sum, c) => sum + clamp(c.effectiveness.score, 0, 100), 0) /
    controlsTotal;
  const controlsEffectivePct = round2(avgEffectiveness);

  const openFindingsList = findings.filter((f) => f.status === 'open');
  const now = Date.now();
  const overdueFindingsList = openFindingsList.filter(
    (f) => new Date(f.dueAt).getTime() < now,
  );

  const severityWeight: Record<string, number> = {
    critical: 4,
    high: 3,
    medium: 2,
    low: 1,
  };
  const findingsSeverityScore = openFindingsList.reduce(
    (sum, f) => sum + (severityWeight[f.severity] ?? 1),
    0,
  );
  // Normalize penalty against a saturation point of 20 severity-weighted points.
  const findingsPenaltyFraction = Math.min(findingsSeverityScore / 20, 1);

  const baseScore =
    (controlsImplementedPct / 100) * WEIGHTS.implementation * 100 +
    (controlsTestedPct / 100) * WEIGHTS.testing * 100 +
    (controlsEffectivePct / 100) * WEIGHTS.effectiveness * 100;

  const penalty = findingsPenaltyFraction * FINDINGS_PENALTY_MAX_POINTS;

  const score = round2(clamp(baseScore - penalty, 0, 100));

  return {
    frameworkId,
    controlsTotal,
    controlsImplementedPct,
    controlsTestedPct,
    controlsEffectivePct,
    openFindings: openFindingsList.length,
    overdueFindings: overdueFindingsList.length,
    score,
  };
}

function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

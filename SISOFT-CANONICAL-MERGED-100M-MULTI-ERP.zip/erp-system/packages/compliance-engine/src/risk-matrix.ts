import { RiskMatrixInput, RiskMatrixResult, RiskLevel } from './types';

/**
 * Standard 5x5 likelihood x impact risk matrix, used by DPIA risk
 * assessment (Article 35) and incident severity classification.
 *
 * Score bands (of 25 max):
 *  1-4   -> low
 *  5-9   -> medium
 *  10-15 -> high
 *  16-25 -> critical
 */
export function calculateRisk(input: RiskMatrixInput): RiskMatrixResult {
  if (
    !Number.isInteger(input.likelihood) ||
    !Number.isInteger(input.impact) ||
    input.likelihood < 1 ||
    input.likelihood > 5 ||
    input.impact < 1 ||
    input.impact > 5
  ) {
    throw new Error('likelihood and impact must be integers between 1 and 5');
  }

  const score = input.likelihood * input.impact;
  const level = scoreToLevel(score);

  return { ...input, score, level };
}

function scoreToLevel(score: number): RiskLevel {
  if (score >= 16) return 'critical';
  if (score >= 10) return 'high';
  if (score >= 5) return 'medium';
  return 'low';
}

/**
 * DPIA is required under Article 35 when residual risk (after mitigation
 * is considered) remains 'high' or 'critical'. Used to gate DPIA sign-off.
 */
export function requiresDpoConsultation(result: RiskMatrixResult): boolean {
  return result.level === 'high' || result.level === 'critical';
}

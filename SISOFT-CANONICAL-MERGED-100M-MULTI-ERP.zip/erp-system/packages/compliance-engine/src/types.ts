/**
 * Shared types for the compliance scoring/mapping engine.
 * Framework-agnostic: frameworks are data, not code (see frameworks/*.ts).
 */

export type ControlStatus = 'implemented' | 'partial' | 'not_implemented';
export type TestResult = 'pass' | 'fail' | 'not_tested';
export type FindingSeverity = 'critical' | 'high' | 'medium' | 'low';

export interface ComplianceRequirement {
  id: string;
  frameworkId: string;
  code: string;
  title: string;
  description: string;
}

export interface ComplianceControl {
  id: string;
  frameworkId: string;
  requirementIds: string[];
  title: string;
  implementation: {
    status: ControlStatus;
    implementedAt?: string;
  };
  testing: {
    lastTested?: string;
    result: TestResult;
    nextTestDue?: string;
  };
  effectiveness: {
    score: number; // 0-100
    lastAssessed?: string;
  };
}

export interface OpenFinding {
  id: string;
  controlId: string;
  severity: FindingSeverity;
  status: 'open' | 'resolved';
  dueAt: string;
}

export interface ComplianceScoreBreakdown {
  frameworkId: string;
  controlsTotal: number;
  controlsImplementedPct: number;
  controlsTestedPct: number;
  controlsEffectivePct: number;
  openFindings: number;
  overdueFindings: number;
  score: number; // 0-100 weighted
}

export interface GapAnalysisResult {
  frameworkId: string;
  uncoveredRequirements: ComplianceRequirement[];
  requirementsTotal: number;
  requirementsCovered: number;
  coveragePct: number;
}

export interface RiskMatrixInput {
  likelihood: 1 | 2 | 3 | 4 | 5;
  impact: 1 | 2 | 3 | 4 | 5;
}

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';

export interface RiskMatrixResult extends RiskMatrixInput {
  score: number; // likelihood * impact, 1-25
  level: RiskLevel;
}

import { ComplianceRequirement } from '../types';

/**
 * PCI-DSS v4.0 requirement catalog (subset — one representative
 * requirement per top-level goal, not the full ~300 sub-requirements).
 * Full catalog is a known gap; see MANIFEST.md.
 */
export const PCI_REQUIREMENTS: ComplianceRequirement[] = [
  { id: 'pci-1', frameworkId: 'pci-dss', code: 'Req 1', title: 'Install and maintain network security controls', description: 'Network security controls protect the cardholder data environment.' },
  { id: 'pci-3', frameworkId: 'pci-dss', code: 'Req 3', title: 'Protect stored account data', description: 'Stored cardholder data must be protected, minimized, and encrypted where retained.' },
  { id: 'pci-8', frameworkId: 'pci-dss', code: 'Req 8', title: 'Identify users and authenticate access', description: 'Unique IDs and strong authentication for all access to system components.' },
  { id: 'pci-10', frameworkId: 'pci-dss', code: 'Req 10', title: 'Log and monitor all access', description: 'Track and monitor all access to network resources and cardholder data.' },
];

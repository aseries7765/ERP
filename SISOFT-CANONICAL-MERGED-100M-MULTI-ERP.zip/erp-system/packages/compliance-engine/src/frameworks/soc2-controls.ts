import { ComplianceRequirement } from '../types';

/**
 * SOC 2 Trust Services Criteria catalog (Security / Common Criteria
 * subset). Availability, Processing Integrity, Confidentiality and
 * Privacy categories are not yet modeled; see MANIFEST.md.
 */
export const SOC2_REQUIREMENTS: ComplianceRequirement[] = [
  { id: 'soc2-cc1.1', frameworkId: 'soc2', code: 'CC1.1', title: 'Commitment to integrity and ethical values', description: 'The entity demonstrates a commitment to integrity and ethical values.' },
  { id: 'soc2-cc6.1', frameworkId: 'soc2', code: 'CC6.1', title: 'Logical access controls', description: 'The entity implements logical access security software and infrastructure to protect information assets.' },
  { id: 'soc2-cc7.2', frameworkId: 'soc2', code: 'CC7.2', title: 'Incident detection and response', description: 'The entity monitors system components for anomalies indicative of security events.' },
  { id: 'soc2-cc9.1', frameworkId: 'soc2', code: 'CC9.1', title: 'Risk mitigation', description: 'The entity identifies, selects, and develops risk mitigation activities for risks from business disruptions.' },
];

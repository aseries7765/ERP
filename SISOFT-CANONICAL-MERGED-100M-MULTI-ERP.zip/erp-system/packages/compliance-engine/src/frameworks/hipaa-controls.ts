import { ComplianceRequirement } from '../types';

/**
 * HIPAA Security & Breach Notification Rule catalog (subset). Privacy
 * Rule (45 CFR 164 Subpart E) minimum-necessary-use detail beyond
 * access logging is a known gap; see MANIFEST.md.
 */
export const HIPAA_REQUIREMENTS: ComplianceRequirement[] = [
  { id: 'hipaa-164.308', frameworkId: 'hipaa', code: '164.308', title: 'Administrative safeguards', description: 'Security management process, workforce security, and information access management for ePHI.' },
  { id: 'hipaa-164.312', frameworkId: 'hipaa', code: '164.312', title: 'Technical safeguards', description: 'Access control, audit controls, integrity controls, and transmission security for ePHI.' },
  { id: 'hipaa-164.314', frameworkId: 'hipaa', code: '164.314', title: 'Business associate agreements', description: 'Contracts with business associates must contain satisfactory assurances re: ePHI safeguards.' },
  { id: 'hipaa-164.404', frameworkId: 'hipaa', code: '164.404', title: 'Breach notification to individuals', description: 'Covered entities must notify affected individuals within 60 days of discovering a breach of unsecured PHI.' },
];

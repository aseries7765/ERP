import { ComplianceRequirement } from '../types';

/**
 * ISO/IEC 27001:2022 Annex A control-family catalog (subset — one
 * representative requirement per clause family, not the full 93
 * Annex A controls). Full catalog is a known gap; see MANIFEST.md.
 */
export const ISO27001_REQUIREMENTS: ComplianceRequirement[] = [
  { id: 'iso27001-5.1', frameworkId: 'iso27001', code: 'A.5.1', title: 'Policies for information security', description: 'Information security policy and topic-specific policies shall be defined, approved, and reviewed.' },
  { id: 'iso27001-5.15', frameworkId: 'iso27001', code: 'A.5.15', title: 'Access control', description: 'Rules to control physical and logical access to information shall be established.' },
  { id: 'iso27001-5.24', frameworkId: 'iso27001', code: 'A.5.24', title: 'Incident management planning', description: 'The organization shall plan and prepare for managing information security incidents.' },
  { id: 'iso27001-8.8', frameworkId: 'iso27001', code: 'A.8.8', title: 'Management of technical vulnerabilities', description: 'Information about technical vulnerabilities shall be obtained and evaluated in a timely manner.' },
  { id: 'iso27001-8.16', frameworkId: 'iso27001', code: 'A.8.16', title: 'Monitoring activities', description: 'Networks, systems and applications shall be monitored for anomalous behaviour.' },
  { id: 'iso27001-8.24', frameworkId: 'iso27001', code: 'A.8.24', title: 'Use of cryptography', description: 'Rules for effective use of cryptography, including key management, shall be defined and implemented.' },
];

import { ComplianceRequirement } from '../types';

/**
 * GDPR requirement catalog (subset — core articles relevant to a
 * general SaaS customer environment). Full 99-article coverage is a
 * known gap; see MANIFEST.md.
 */
export const GDPR_REQUIREMENTS: ComplianceRequirement[] = [
  {
    id: 'gdpr-5',
    frameworkId: 'gdpr',
    code: 'Art. 5',
    title: 'Principles relating to processing of personal data',
    description: 'Lawfulness, fairness, transparency, purpose limitation, data minimization, accuracy, storage limitation, integrity and confidentiality.',
  },
  {
    id: 'gdpr-6',
    frameworkId: 'gdpr',
    code: 'Art. 6',
    title: 'Lawfulness of processing',
    description: 'Processing is lawful only if at least one legal basis applies.',
  },
  {
    id: 'gdpr-7',
    frameworkId: 'gdpr',
    code: 'Art. 7',
    title: 'Conditions for consent',
    description: 'Consent must be freely given, specific, informed, and unambiguous, and withdrawable as easily as given.',
  },
  {
    id: 'gdpr-15',
    frameworkId: 'gdpr',
    code: 'Art. 15',
    title: 'Right of access',
    description: 'Data subjects may request confirmation of processing and a copy of their data.',
  },
  {
    id: 'gdpr-16',
    frameworkId: 'gdpr',
    code: 'Art. 16',
    title: 'Right to rectification',
    description: 'Data subjects may request correction of inaccurate personal data.',
  },
  {
    id: 'gdpr-17',
    frameworkId: 'gdpr',
    code: 'Art. 17',
    title: 'Right to erasure',
    description: 'Data subjects may request erasure subject to statutory exceptions.',
  },
  {
    id: 'gdpr-18',
    frameworkId: 'gdpr',
    code: 'Art. 18',
    title: 'Right to restriction of processing',
    description: 'Data subjects may request restriction rather than deletion.',
  },
  {
    id: 'gdpr-20',
    frameworkId: 'gdpr',
    code: 'Art. 20',
    title: 'Right to data portability',
    description: 'Data subjects may receive their data in a structured, machine-readable format.',
  },
  {
    id: 'gdpr-21',
    frameworkId: 'gdpr',
    code: 'Art. 21',
    title: 'Right to object',
    description: 'Data subjects may object to processing based on legitimate interest or direct marketing.',
  },
  {
    id: 'gdpr-22',
    frameworkId: 'gdpr',
    code: 'Art. 22',
    title: 'Automated individual decision-making',
    description: 'Data subjects have the right not to be subject to a decision based solely on automated processing without safeguards.',
  },
  {
    id: 'gdpr-30',
    frameworkId: 'gdpr',
    code: 'Art. 30',
    title: 'Records of processing activities',
    description: 'Controllers must maintain a record of processing activities.',
  },
  {
    id: 'gdpr-32',
    frameworkId: 'gdpr',
    code: 'Art. 32',
    title: 'Security of processing',
    description: 'Appropriate technical and organizational measures to ensure a level of security appropriate to the risk.',
  },
  {
    id: 'gdpr-33',
    frameworkId: 'gdpr',
    code: 'Art. 33',
    title: 'Notification of a breach to the supervisory authority',
    description: 'Personal data breaches must be notified to the DPA within 72 hours of becoming aware, unless unlikely to result in risk.',
  },
  {
    id: 'gdpr-34',
    frameworkId: 'gdpr',
    code: 'Art. 34',
    title: 'Communication of a breach to the data subject',
    description: 'High-risk breaches must be communicated to affected individuals without undue delay.',
  },
  {
    id: 'gdpr-35',
    frameworkId: 'gdpr',
    code: 'Art. 35',
    title: 'Data protection impact assessment',
    description: 'A DPIA is required where processing is likely to result in high risk to individuals.',
  },
];

import './test-shim';
import { report, runQueuedTests } from './test-shim';

async function main() {
  await import('../src/__tests__/double-entry.spec');
  await import('../src/__tests__/posting.spec');
  await import('../src/__tests__/trial-balance.spec');
  await import('../../../apps/api/test/accounting/journal-posting.service.spec');
  await runQueuedTests();
  report();
}

main();

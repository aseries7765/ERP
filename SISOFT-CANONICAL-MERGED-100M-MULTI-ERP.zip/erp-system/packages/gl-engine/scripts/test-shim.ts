/**
 * Minimal offline test harness.
 *
 * WHY THIS EXISTS: this package's package.json declares jest/ts-jest as
 * devDependencies (the correct, standard choice for the real monorepo).
 * But the sandbox this code was authored in has no npm registry access
 * (verified: `npm install` returns 403 for both npmjs.org packages and
 * scoped packages), so jest cannot actually be installed here to prove
 * the specs pass. Rather than claim "tests pass" without running them
 * (see the M8 prompt's own "HONESTY OVER SPEED" section), this file
 * implements just enough of Jest's describe/it/expect surface to
 * actually execute the real spec files in src/__tests__/ unmodified,
 * using only the TypeScript compiler already available in this sandbox
 * (via `tsx`, which needs no network either).
 *
 * This is a verification shim, not a replacement for jest. When this
 * package is merged into the real monorepo (with real registry access),
 * `pnpm --filter @erp/gl-engine test` should run the same spec files
 * through real jest/ts-jest — this harness is not referenced anywhere
 * outside of `npm run test:offline`.
 */
type Matcher = (actual: unknown) => void;

let currentSuite: string[] = [];
let passCount = 0;
let failCount = 0;
const failures: string[] = [];
const queuedTests: { name: string; fn: () => void | Promise<void> }[] = [];

function fullName(name: string): string {
  return [...currentSuite, name].join(' > ');
}

(global as any).describe = (name: string, fn: () => void) => {
  currentSuite.push(name);
  try {
    fn();
  } finally {
    currentSuite.pop();
  }
};

// Tests are QUEUED at describe-time (matching how `it()` bodies aren't run
// until spec-collection finishes), then run sequentially and awaited in
// runQueuedTests() — this supports both sync and async (`async () => {}`)
// test bodies, which the journal-posting.service.spec.ts (an async
// service) needs.
(global as any).it = (name: string, fn: () => void | Promise<void>) => {
  const label = fullName(name);
  queuedTests.push({ name: label, fn });
};

export async function runQueuedTests(): Promise<void> {
  for (const { name, fn } of queuedTests) {
    try {
      await fn();
      passCount++;
    } catch (err: any) {
      failCount++;
      failures.push(`${name}\n    ${err?.message ?? err}`);
    }
  }
}

function deepEqual(a: unknown, b: unknown): boolean {
  if (Object.is(a, b)) return true;
  if (typeof a !== typeof b) return false;
  if (a && b && typeof a === 'object') {
    const aKeys = Object.keys(a as object);
    const bKeys = Object.keys(b as object);
    if (aKeys.length !== bKeys.length) return false;
    return aKeys.every((k) => deepEqual((a as any)[k], (b as any)[k]));
  }
  return false;
}

function assert(cond: boolean, message: string): void {
  if (!cond) throw new Error(message);
}

(global as any).expect = (actual: unknown) => {
  const api = {
    toBe: (expected: unknown) => assert(Object.is(actual, expected), `expected ${JSON.stringify(actual)} toBe ${JSON.stringify(expected)}`),
    toEqual: (expected: unknown) => assert(deepEqual(actual, expected), `expected ${JSON.stringify(actual)} toEqual ${JSON.stringify(expected)}`),
    toHaveLength: (n: number) => assert((actual as any).length === n, `expected length ${(actual as any).length} toBe ${n}`),
    toContain: (item: unknown) => assert((actual as any[]).includes(item), `expected [${actual}] toContain ${item}`),
    toBeCloseTo: (expected: number, precision = 2) => {
      const diff = Math.abs((actual as number) - expected);
      assert(diff < Math.pow(10, -precision) / 2, `expected ${actual} toBeCloseTo ${expected}`);
    },
    toMatchObject: (expected: Record<string, unknown>) => {
      for (const key of Object.keys(expected)) {
        assert(
          deepEqual((actual as any)[key], expected[key]),
          `expected field "${key}": ${JSON.stringify((actual as any)[key])} toMatchObject value ${JSON.stringify(expected[key])}`,
        );
      }
    },
    toThrow: (matcher?: RegExp | { new (...args: any[]): Error }) => {
      let threw = false;
      let error: any;
      try {
        (actual as () => void)();
      } catch (e) {
        threw = true;
        error = e;
      }
      assert(threw, 'expected function to throw, but it did not');
      if (matcher instanceof RegExp) {
        assert(matcher.test(error?.message ?? ''), `expected thrown error message to match ${matcher}, got "${error?.message}"`);
      } else if (typeof matcher === 'function') {
        assert(error instanceof matcher, `expected thrown error to be instance of ${matcher.name}, got ${error?.constructor?.name}`);
      }
    },
    not: {
      toBe: (expected: unknown) => assert(!Object.is(actual, expected), `expected ${JSON.stringify(actual)} not toBe ${JSON.stringify(expected)}`),
    },
  };
  return api;
};

(global as any).expect.arrayContaining = (items: unknown[]) => ({
  __isArrayContaining: true,
  items,
});

// Patch toEqual to understand arrayContaining wrapper produced above.
const originalExpect = (global as any).expect;
(global as any).expect = (actual: unknown) => {
  const api = originalExpect(actual);
  const originalToEqual = api.toEqual;
  api.toEqual = (expected: any) => {
    if (expected && expected.__isArrayContaining) {
      for (const item of expected.items) {
        assert((actual as any[]).includes(item), `expected [${actual}] to contain (arrayContaining) ${item}`);
      }
      return;
    }
    originalToEqual(expected);
  };
  return api;
};
(global as any).expect.arrayContaining = originalExpect.arrayContaining ?? ((items: unknown[]) => ({ __isArrayContaining: true, items }));

export function report(): void {
  console.log(`\n${passCount} passed, ${failCount} failed`);
  if (failures.length > 0) {
    console.log('\nFAILURES:');
    for (const f of failures) console.log(`  ✗ ${f}`);
    process.exitCode = 1;
  } else {
    console.log('All specs passed.');
  }
}

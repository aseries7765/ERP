import { DecimalString } from './types';

/**
 * Self-contained fixed-point decimal arithmetic for money.
 *
 * IMPLEMENTATION NOTE: an earlier draft of this file depended on
 * `decimal.js`. That dependency was removed — not for licensing or
 * performance reasons, but because the sandbox this package was
 * authored in has no npm registry access, so a third-party dependency
 * could not actually be installed and verified here. Rather than ship
 * code that imports something never proven to resolve, this engine uses
 * native BigInt, which needs nothing from npm. This is arguably a better
 * outcome for the "heart of the ERP" money math regardless: one fewer
 * supply-chain dependency for the single most safety-critical package
 * in M8. If the merge captain prefers decimal.js (e.g. for arbitrary
 * scale beyond 4dp elsewhere in the codebase), swapping the internals of
 * this file is a contained change — nothing outside precision.ts needs
 * to know how Money is implemented internally.
 *
 * Money is stored internally as a BigInt scaled by 10^SCALE. SCALE=4
 * matches BALANCE_COMPARISON_DP, the precision the M8 prompt specifies
 * for balance comparisons ("to 4 decimal places"). Per G19, `number`
 * (Float) is never used for money at any point in this file.
 */

const SCALE = 4;
const SCALE_FACTOR = 10n ** BigInt(SCALE);
export const BALANCE_COMPARISON_DP = SCALE;

const DECIMAL_STRING_RE = /^(-?)(\d+)(?:\.(\d+))?$/;

function parseToRaw(value: string): bigint {
  if (value === undefined || value === null || value.trim() === '') {
    throw new Error('toDecimal: received empty/undefined value');
  }
  const trimmed = value.trim();
  const match = DECIMAL_STRING_RE.exec(trimmed);
  if (!match) {
    throw new Error(`toDecimal: "${value}" is not a valid decimal string`);
  }
  const [, signStr, intPart, fracPartRaw = ''] = match;
  if (fracPartRaw.length > SCALE) {
    throw new Error(
      `toDecimal: "${value}" has more than ${SCALE} decimal places; round upstream before passing money into gl-engine.`,
    );
  }
  const fracPart = fracPartRaw.padEnd(SCALE, '0');
  const magnitude = BigInt(intPart) * SCALE_FACTOR + BigInt(fracPart || '0');
  return signStr === '-' ? -magnitude : magnitude;
}

export class Money {
  private constructor(private readonly raw: bigint) {}

  static fromString(value: DecimalString): Money {
    return new Money(parseToRaw(value));
  }

  static zero(): Money {
    return new Money(0n);
  }

  plus(other: Money): Money {
    return new Money(this.raw + other.raw);
  }

  minus(other: Money): Money {
    return new Money(this.raw - other.raw);
  }

  greaterThan(n: number): boolean {
    return this.raw > BigInt(n) * SCALE_FACTOR;
  }

  isFinite(): boolean {
    // Always true — a BigInt-backed value cannot be NaN/Infinity. Kept as
    // a method (rather than removed) so callers don't need to special-case
    // this implementation vs. a future Decimal.js-backed one.
    return true;
  }

  /** Rounds (half-up, sign-aware) to `dp` decimal places and returns a new Money. */
  toDecimalPlaces(dp: number = SCALE): Money {
    if (dp >= SCALE) return this;
    const divisor = 10n ** BigInt(SCALE - dp);
    const absRaw = this.raw < 0n ? -this.raw : this.raw;
    const remainder = absRaw % divisor;
    let truncated = absRaw - remainder;
    if (remainder * 2n >= divisor) {
      truncated += divisor;
    }
    return new Money(this.raw < 0n ? -truncated : truncated);
  }

  equals(other: Money): boolean {
    return this.raw === other.raw;
  }

  toFixed(dp: number = SCALE): DecimalString {
    const clampedDp = Math.min(dp, SCALE);
    const rounded = this.toDecimalPlaces(clampedDp);
    const absRaw = rounded.raw < 0n ? -rounded.raw : rounded.raw;
    const intPart = absRaw / SCALE_FACTOR;
    const fracFull = (absRaw % SCALE_FACTOR).toString().padStart(SCALE, '0');
    const frac = fracFull.slice(0, clampedDp);
    const isNegative = rounded.raw < 0n && (intPart !== 0n || /[1-9]/.test(frac));
    const sign = isNegative ? '-' : '';
    return clampedDp === 0 ? `${sign}${intPart}` : `${sign}${intPart}.${frac}`;
  }

  toString(): string {
    return this.toFixed(SCALE);
  }
}

export function toDecimal(value: DecimalString): Money {
  return Money.fromString(value);
}

export function toDecimalString(value: Money): DecimalString {
  return value.toFixed(BALANCE_COMPARISON_DP);
}

export function sum(values: DecimalString[]): Money {
  return values.reduce((acc: Money, v) => acc.plus(toDecimal(v)), Money.zero());
}

/** Equality at the 4-decimal-place comparison precision the validator uses. */
export function decimalEquals(a: Money, b: Money, dp: number = BALANCE_COMPARISON_DP): boolean {
  return a.toDecimalPlaces(dp).equals(b.toDecimalPlaces(dp));
}

export function isPositive(value: DecimalString): boolean {
  try {
    return toDecimal(value).greaterThan(0);
  } catch {
    return false;
  }
}

import { validateDoubleEntry } from '../double-entry';
import { AccountPostabilityInfo, JournalEntryInput, JournalLineInput, PeriodStatusInfo } from '../types';

function acct(
  id: string,
  overrides: Partial<AccountPostabilityInfo> = {},
): [string, AccountPostabilityInfo] {
  return [
    id,
    {
      accountId: id,
      isPostable: true,
      isLocked: false,
      normalBalance: 'DEBIT',
      accountType: 'ASSET',
      ...overrides,
    },
  ];
}

const openPeriod: PeriodStatusInfo = { fiscalPeriodId: 'FY26-P01', isClosed: false };
const closedPeriod: PeriodStatusInfo = { fiscalPeriodId: 'FY26-P01', isClosed: true };

function line(partial: Partial<JournalLineInput> & Pick<JournalLineInput, 'lineId' | 'accountId' | 'side' | 'amount'>): JournalLineInput {
  return {
    currency: 'USD',
    baseAmount: partial.amount,
    ...partial,
  };
}

describe('validateDoubleEntry', () => {
  const accounts = new Map<string, AccountPostabilityInfo>([
    acct('cash', { accountType: 'ASSET', normalBalance: 'DEBIT' }),
    acct('revenue', { accountType: 'REVENUE', normalBalance: 'CREDIT' }),
    acct('ap', { accountType: 'LIABILITY', normalBalance: 'CREDIT' }),
    acct('header-expenses', { isPostable: false, accountType: 'EXPENSE', normalBalance: 'DEBIT' }),
    acct('locked-acct', { isLocked: true }),
  ]);

  it('accepts a simple balanced two-line entry', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-1',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        line({ lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '100.00' }),
        line({ lineId: 'l2', accountId: 'revenue', side: 'CREDIT', amount: '100.00' }),
      ],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.valid).toBe(true);
    expect(result.issues).toHaveLength(0);
    expect(result.totalDebitBase).toBe('100.0000');
    expect(result.totalCreditBase).toBe('100.0000');
  });

  it('rejects an unbalanced entry', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-2',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        line({ lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '100.00' }),
        line({ lineId: 'l2', accountId: 'revenue', side: 'CREDIT', amount: '99.99' }),
      ],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.valid).toBe(false);
    expect(result.issues.map((i) => i.code)).toContain('UNBALANCED_BASE_CURRENCY');
  });

  it('accepts balance exact to 4 decimal places, rejects a 5th-decimal drift beyond rounding', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-3',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        line({ lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '100.0001' }),
        line({ lineId: 'l2', accountId: 'revenue', side: 'CREDIT', amount: '100.0001' }),
      ],
    };
    expect(validateDoubleEntry(entry, accounts, openPeriod).valid).toBe(true);
  });

  it('rejects an entry with only one line', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-4',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [line({ lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '100.00' })],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.valid).toBe(false);
    expect(result.issues.map((i) => i.code)).toContain('SINGLE_LINE');
    // A single-line entry is also unbalanced by definition.
    expect(result.issues.map((i) => i.code)).toContain('UNBALANCED_BASE_CURRENCY');
  });

  it('rejects an entry with zero lines', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-5',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.valid).toBe(false);
    expect(result.issues.map((i) => i.code)).toEqual(['EMPTY_ENTRY']);
  });

  it('rejects zero and negative amounts (direction is carried by side, not sign)', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-6',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        line({ lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '0.00' }),
        line({ lineId: 'l2', accountId: 'revenue', side: 'CREDIT', amount: '-5.00' }),
      ],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.valid).toBe(false);
    const codes = result.issues.map((i) => i.code);
    expect(codes.filter((c) => c === 'NON_POSITIVE_AMOUNT')).toHaveLength(2);
  });

  it('rejects posting to a non-postable (header/group) account', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-7',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        line({ lineId: 'l1', accountId: 'header-expenses', side: 'DEBIT', amount: '50.00' }),
        line({ lineId: 'l2', accountId: 'cash', side: 'CREDIT', amount: '50.00' }),
      ],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.valid).toBe(false);
    expect(result.issues.map((i) => i.code)).toContain('ACCOUNT_NOT_POSTABLE');
  });

  it('rejects posting to a locked account', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-8',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        line({ lineId: 'l1', accountId: 'locked-acct', side: 'DEBIT', amount: '50.00' }),
        line({ lineId: 'l2', accountId: 'cash', side: 'CREDIT', amount: '50.00' }),
      ],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.valid).toBe(false);
    expect(result.issues.map((i) => i.code)).toContain('ACCOUNT_LOCKED');
  });

  it('rejects posting into a closed period', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-9',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        line({ lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '50.00' }),
        line({ lineId: 'l2', accountId: 'revenue', side: 'CREDIT', amount: '50.00' }),
      ],
    };
    const result = validateDoubleEntry(entry, accounts, closedPeriod);
    expect(result.valid).toBe(false);
    expect(result.issues.map((i) => i.code)).toContain('PERIOD_CLOSED');
  });

  it('rejects an unknown account id', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-10',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        line({ lineId: 'l1', accountId: 'does-not-exist', side: 'DEBIT', amount: '10.00' }),
        line({ lineId: 'l2', accountId: 'cash', side: 'CREDIT', amount: '10.00' }),
      ],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.valid).toBe(false);
    expect(result.issues.map((i) => i.code)).toContain('ACCOUNT_NOT_POSTABLE');
  });

  it('accepts a balanced 3-currency entry where only the base-currency total balances', () => {
    // 100 USD debit to cash (base USD) vs 90 EUR + 12 GBP credits whose
    // base-currency equivalents happen to sum to 100.00 USD. Per-currency
    // buckets do NOT balance individually, which is expected and fine.
    const entry: JournalEntryInput = {
      journalEntryId: 'je-11',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        { lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '100.00', currency: 'USD', baseAmount: '100.00' },
        { lineId: 'l2', accountId: 'ap', side: 'CREDIT', amount: '90.00', currency: 'EUR', baseAmount: '60.00' },
        { lineId: 'l3', accountId: 'revenue', side: 'CREDIT', amount: '12.00', currency: 'GBP', baseAmount: '40.00' },
      ],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.valid).toBe(true);
  });

  it('still rejects a multi-currency entry if the BASE-currency totals do not balance', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-12',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        { lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '100.00', currency: 'USD', baseAmount: '100.00' },
        { lineId: 'l2', accountId: 'ap', side: 'CREDIT', amount: '90.00', currency: 'EUR', baseAmount: '60.00' },
        { lineId: 'l3', accountId: 'revenue', side: 'CREDIT', amount: '12.00', currency: 'GBP', baseAmount: '39.00' },
      ],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.valid).toBe(false);
    expect(result.issues.map((i) => i.code)).toContain('UNBALANCED_BASE_CURRENCY');
  });

  it('flags an unbalanced single-currency entry via the per-currency check too', () => {
    const entry: JournalEntryInput = {
      journalEntryId: 'je-13',
      companyId: 'co-1',
      fiscalPeriodId: 'FY26-P01',
      lines: [
        line({ lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '10.00' }),
        line({ lineId: 'l2', accountId: 'revenue', side: 'CREDIT', amount: '9.00' }),
      ],
    };
    const result = validateDoubleEntry(entry, accounts, openPeriod);
    expect(result.issues.map((i) => i.code)).toEqual(
      expect.arrayContaining(['UNBALANCED_TRANSACTION_CURRENCY', 'UNBALANCED_BASE_CURRENCY']),
    );
  });

  describe('fuzzing — random entries must never be incorrectly accepted as balanced', () => {
    // Deterministic PRNG so failures are reproducible without a fixed seed lib.
    function mulberry32(seed: number) {
      return function () {
        seed |= 0;
        seed = (seed + 0x6d2b79f5) | 0;
        let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      };
    }
    const rand = mulberry32(42);

    it('runs 2000 random entries; validator verdict always matches independently-computed balance', () => {
      for (let i = 0; i < 2000; i++) {
        const lineCount = 2 + Math.floor(rand() * 5); // 2..6 lines
        const lines: JournalLineInput[] = [];
        let runningDebit = 0;
        let runningCredit = 0;
        for (let j = 0; j < lineCount; j++) {
          const side: 'DEBIT' | 'CREDIT' = rand() > 0.5 ? 'DEBIT' : 'CREDIT';
          // Cents-precision random amount between 0.01 and 999.99
          const cents = 1 + Math.floor(rand() * 99998);
          const amount = (cents / 100).toFixed(2);
          if (side === 'DEBIT') runningDebit += cents;
          else runningCredit += cents;
          lines.push(
            line({
              lineId: `l${j}`,
              accountId: rand() > 0.5 ? 'cash' : 'revenue',
              side,
              amount,
            }),
          );
        }
        // On ~half of iterations, force it into balance by adjusting the
        // last line so we get a healthy mix of balanced/unbalanced cases.
        if (rand() > 0.5) {
          const diff = runningDebit - runningCredit;
          const last = lines[lines.length - 1];
          const lastCents = Math.round(parseFloat(last.amount) * 100);
          const adjustedCents = last.side === 'DEBIT' ? lastCents - diff : lastCents + diff;
          if (adjustedCents > 0) {
            last.amount = (adjustedCents / 100).toFixed(2);
            last.baseAmount = last.amount;
            if (last.side === 'DEBIT') runningDebit = runningDebit - lastCents + adjustedCents;
            else runningCredit = runningCredit - lastCents + adjustedCents;
          }
        }

        const entry: JournalEntryInput = {
          journalEntryId: `fuzz-${i}`,
          companyId: 'co-1',
          fiscalPeriodId: 'FY26-P01',
          lines,
        };
        const result = validateDoubleEntry(entry, accounts, openPeriod);
        const actuallyBalanced = runningDebit === runningCredit;
        expect(result.valid).toBe(actuallyBalanced);
      }
    });
  });
});

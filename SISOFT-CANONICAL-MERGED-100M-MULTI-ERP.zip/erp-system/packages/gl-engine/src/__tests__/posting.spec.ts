import { post, PostingRejectedError } from '../posting';
import { reverseGlEntries } from '../reversal';
import { AccountPostabilityInfo, JournalEntryInput, PeriodStatusInfo } from '../types';

const accounts = new Map<string, AccountPostabilityInfo>([
  ['cash', { accountId: 'cash', isPostable: true, isLocked: false, normalBalance: 'DEBIT', accountType: 'ASSET' }],
  [
    'revenue',
    { accountId: 'revenue', isPostable: true, isLocked: false, normalBalance: 'CREDIT', accountType: 'REVENUE' },
  ],
]);
const openPeriod: PeriodStatusInfo = { fiscalPeriodId: 'FY26-P01', isClosed: false };
const closedPeriod: PeriodStatusInfo = { fiscalPeriodId: 'FY26-P01', isClosed: true };

const balancedEntry: JournalEntryInput = {
  journalEntryId: 'je-100',
  companyId: 'co-1',
  fiscalPeriodId: 'FY26-P01',
  lines: [
    { lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '500.00', currency: 'USD', baseAmount: '500.00' },
    { lineId: 'l2', accountId: 'revenue', side: 'CREDIT', amount: '500.00', currency: 'USD', baseAmount: '500.00' },
  ],
};

describe('post()', () => {
  it('produces one GlEntry per journal line, preserving side/account/amount', () => {
    const result = post(balancedEntry, accounts, openPeriod, new Date('2026-01-15T00:00:00Z'));
    expect(result).toHaveLength(2);
    expect(result[0]).toMatchObject({
      journalEntryId: 'je-100',
      accountId: 'cash',
      side: 'DEBIT',
      baseAmount: '500.00',
    });
    expect(result[1]).toMatchObject({ accountId: 'revenue', side: 'CREDIT' });
    expect(result.every((r) => r.postedAt === '2026-01-15T00:00:00.000Z')).toBe(true);
  });

  it('throws PostingRejectedError and posts NOTHING for an unbalanced entry (all-or-nothing)', () => {
    const unbalanced: JournalEntryInput = {
      ...balancedEntry,
      journalEntryId: 'je-101',
      lines: [
        { lineId: 'l1', accountId: 'cash', side: 'DEBIT', amount: '500.00', currency: 'USD', baseAmount: '500.00' },
        { lineId: 'l2', accountId: 'revenue', side: 'CREDIT', amount: '400.00', currency: 'USD', baseAmount: '400.00' },
      ],
    };
    expect(() => post(unbalanced, accounts, openPeriod)).toThrow(PostingRejectedError);
  });

  it('refuses to post into a closed period — locked periods are immutable (G18)', () => {
    expect(() => post(balancedEntry, accounts, closedPeriod)).toThrow(PostingRejectedError);
  });
});

describe('reverseGlEntries()', () => {
  it('mirrors every line (debit<->credit) and links back to the original JE', () => {
    const posted = post(balancedEntry, accounts, openPeriod, new Date('2026-01-15T00:00:00Z'));
    const reversal = reverseGlEntries(posted, 'je-100-REV', new Date('2026-02-01T00:00:00Z'));

    expect(reversal).toHaveLength(2);
    expect(reversal[0]).toMatchObject({
      journalEntryId: 'je-100-REV',
      accountId: 'cash',
      side: 'CREDIT', // was DEBIT
      reversesJournalEntryId: 'je-100',
    });
    expect(reversal[1]).toMatchObject({ accountId: 'revenue', side: 'DEBIT' });

    // Reversal of a balanced entry is itself balanced.
    const debitTotal = reversal.filter((r) => r.side === 'DEBIT').reduce((a, r) => a + Number(r.baseAmount), 0);
    const creditTotal = reversal.filter((r) => r.side === 'CREDIT').reduce((a, r) => a + Number(r.baseAmount), 0);
    expect(debitTotal).toBeCloseTo(creditTotal, 6);
  });

  it('throws when reversing an empty set of entries', () => {
    expect(() => reverseGlEntries([], 'je-rev')).toThrow();
  });
});

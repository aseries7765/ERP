import { assertLedgerIntegrity, computeTrialBalance } from '../trial-balance';
import { AccountPostabilityInfo, GlEntry } from '../types';

const accounts = new Map<string, AccountPostabilityInfo>([
  ['cash', { accountId: 'cash', isPostable: true, isLocked: false, normalBalance: 'DEBIT', accountType: 'ASSET' }],
  [
    'revenue',
    { accountId: 'revenue', isPostable: true, isLocked: false, normalBalance: 'CREDIT', accountType: 'REVENUE' },
  ],
  ['ap', { accountId: 'ap', isPostable: true, isLocked: false, normalBalance: 'CREDIT', accountType: 'LIABILITY' }],
]);

function entry(partial: Partial<GlEntry> & Pick<GlEntry, 'accountId' | 'side' | 'baseAmount'>): GlEntry {
  return {
    journalEntryId: 'je-x',
    lineId: 'l-x',
    companyId: 'co-1',
    fiscalPeriodId: 'FY26-P01',
    amount: partial.baseAmount,
    currency: 'USD',
    postedAt: '2026-01-01T00:00:00.000Z',
    ...partial,
  };
}

describe('computeTrialBalance()', () => {
  it('sums debits and credits per account and reports a balanced ledger', () => {
    const entries: GlEntry[] = [
      entry({ accountId: 'cash', side: 'DEBIT', baseAmount: '1000.00' }),
      entry({ accountId: 'revenue', side: 'CREDIT', baseAmount: '700.00' }),
      entry({ accountId: 'ap', side: 'CREDIT', baseAmount: '300.00' }),
    ];
    const tb = computeTrialBalance('co-1', 'FY26-P01', entries, accounts);
    expect(tb.isBalanced).toBe(true);
    expect(tb.totalDebitBase).toBe('1000.0000');
    expect(tb.totalCreditBase).toBe('1000.0000');
    expect(tb.rows).toHaveLength(3);

    const cashRow = tb.rows.find((r) => r.accountId === 'cash')!;
    expect(cashRow.netBalance).toBe('1000.0000'); // normal DEBIT balance, all debits

    const revenueRow = tb.rows.find((r) => r.accountId === 'revenue')!;
    expect(revenueRow.netBalance).toBe('700.0000'); // normal CREDIT balance, all credits
  });

  it('ignores entries belonging to a different company (tenant isolation at the data layer)', () => {
    const entries: GlEntry[] = [
      entry({ accountId: 'cash', side: 'DEBIT', baseAmount: '100.00' }),
      entry({ accountId: 'revenue', side: 'CREDIT', baseAmount: '100.00' }),
      entry({ accountId: 'cash', side: 'DEBIT', baseAmount: '999.00', companyId: 'co-OTHER' }),
    ];
    const tb = computeTrialBalance('co-1', 'FY26-P01', entries, accounts);
    expect(tb.totalDebitBase).toBe('100.0000');
  });

  it('flags an out-of-balance ledger as a genuine integrity failure (should be unreachable via post())', () => {
    const entries: GlEntry[] = [
      entry({ accountId: 'cash', side: 'DEBIT', baseAmount: '100.00' }),
      entry({ accountId: 'revenue', side: 'CREDIT', baseAmount: '90.00' }),
    ];
    const tb = computeTrialBalance('co-1', 'FY26-P01', entries, accounts);
    expect(tb.isBalanced).toBe(false);
    expect(() => assertLedgerIntegrity(tb)).toThrow(/GL INTEGRITY FAILURE/);
  });

  it('throws a clear error if a GL entry references an account with no metadata supplied', () => {
    const entries: GlEntry[] = [entry({ accountId: 'unknown-account', side: 'DEBIT', baseAmount: '10.00' })];
    expect(() => computeTrialBalance('co-1', 'FY26-P01', entries, accounts)).toThrow(/unknown-account/);
  });

  it('returns a balanced empty trial balance for a period with no activity', () => {
    const tb = computeTrialBalance('co-1', 'FY26-P02', [], accounts);
    expect(tb.isBalanced).toBe(true);
    expect(tb.rows).toHaveLength(0);
    expect(tb.totalDebitBase).toBe('0.0000');
  });
});

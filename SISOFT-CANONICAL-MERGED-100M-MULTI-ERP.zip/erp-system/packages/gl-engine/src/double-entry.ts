import {
  AccountPostabilityInfo,
  JournalEntryInput,
  PeriodStatusInfo,
  ValidationIssue,
  ValidationResult,
} from './types';
import { decimalEquals, isPositive, sum, toDecimalString } from './precision';

/**
 * DoubleEntryValidator — the single most load-bearing piece of M8.
 *
 * Mirrors the spec in the M8 prompt's "KEY BEHAVIORS > DoubleEntryValidatorService":
 *   - Sum of debits MUST equal sum of credits (to 4 decimal places)
 *   - Every line: exactly one of debit or credit (enforced by the type
 *     system here — `side` is a single discriminant, not two nullable
 *     fields — so "both" and "neither" are unrepresentable, not just
 *     validated against)
 *   - Account must be postable (leaf node in COA)
 *   - Account must not be locked
 *   - Period must not be closed
 *   - Multi-currency: sum of baseAmount debits = sum of baseAmount credits
 *   - Also checks transaction-currency balance PER CURRENCY, since a
 *     multi-currency JE that only balances in base currency but not in
 *     any single transaction currency usually indicates a data-entry bug
 *     upstream, even though base-currency balance is what's ultimately
 *     required for posting.
 *
 * This function is pure and synchronous: given the JE and the account/
 * period metadata the caller looked up via Prisma, it returns a
 * ValidationResult. It never touches a database itself.
 */
export function validateDoubleEntry(
  entry: JournalEntryInput,
  accounts: Map<string, AccountPostabilityInfo>,
  period: PeriodStatusInfo,
): ValidationResult {
  const issues: ValidationIssue[] = [];

  if (!entry.lines || entry.lines.length === 0) {
    issues.push({ code: 'EMPTY_ENTRY', message: 'Journal entry has no lines.' });
    return finish(issues);
  }

  if (entry.lines.length < 2) {
    issues.push({
      code: 'SINGLE_LINE',
      message: 'A journal entry must have at least two lines (double entry).',
    });
  }

  if (period.isClosed) {
    issues.push({
      code: 'PERIOD_CLOSED',
      message: `Fiscal period ${period.fiscalPeriodId} is closed; no journal entries may post into it.`,
    });
  }

  for (const line of entry.lines) {
    if (!isPositive(line.amount) || !isPositive(line.baseAmount)) {
      issues.push({
        code: 'NON_POSITIVE_AMOUNT',
        message: `Line ${line.lineId}: amount and baseAmount must both be > 0. Debit/credit direction is carried by "side", not by sign.`,
        lineId: line.lineId,
      });
      continue;
    }

    const acct = accounts.get(line.accountId);
    if (!acct) {
      issues.push({
        code: 'ACCOUNT_NOT_POSTABLE',
        message: `Line ${line.lineId}: account ${line.accountId} was not found / not resolvable.`,
        lineId: line.lineId,
      });
      continue;
    }
    if (!acct.isPostable) {
      issues.push({
        code: 'ACCOUNT_NOT_POSTABLE',
        message: `Line ${line.lineId}: account ${line.accountId} is a group/header account and cannot be posted to directly.`,
        lineId: line.lineId,
      });
    }
    if (acct.isLocked) {
      issues.push({
        code: 'ACCOUNT_LOCKED',
        message: `Line ${line.lineId}: account ${line.accountId} is locked for posting.`,
        lineId: line.lineId,
      });
    }
  }

  // Base-currency balance — this is the one that actually gates posting.
  const debitBase = sum(entry.lines.filter((l) => l.side === 'DEBIT').map((l) => l.baseAmount));
  const creditBase = sum(entry.lines.filter((l) => l.side === 'CREDIT').map((l) => l.baseAmount));
  if (!decimalEquals(debitBase, creditBase)) {
    issues.push({
      code: 'UNBALANCED_BASE_CURRENCY',
      message: `Base-currency debits (${toDecimalString(debitBase)}) do not equal credits (${toDecimalString(
        creditBase,
      )}).`,
    });
  }

  // Per-transaction-currency balance — advisory-strength check for data
  // quality, grouped by currency code.
  const byCurrency = new Map<string, { debit: string[]; credit: string[] }>();
  for (const l of entry.lines) {
    const bucket = byCurrency.get(l.currency) ?? { debit: [], credit: [] };
    (l.side === 'DEBIT' ? bucket.debit : bucket.credit).push(l.amount);
    byCurrency.set(l.currency, bucket);
  }
  for (const [currency, bucket] of byCurrency) {
    const d = sum(bucket.debit);
    const c = sum(bucket.credit);
    if (!decimalEquals(d, c) && byCurrency.size === 1) {
      // Only flag as a hard issue when the whole JE is single-currency;
      // in a genuine multi-currency JE, individual currencies legitimately
      // need not balance on their own — only the base-currency total must.
      issues.push({
        code: 'UNBALANCED_TRANSACTION_CURRENCY',
        message: `${currency} debits (${toDecimalString(d)}) do not equal ${currency} credits (${toDecimalString(
          c,
        )}).`,
      });
    }
  }

  return finish(issues, debitBase, creditBase);
}

function finish(
  issues: ValidationIssue[],
  debitBase = sum([]),
  creditBase = sum([]),
): ValidationResult {
  return {
    valid: issues.length === 0,
    issues,
    totalDebitBase: toDecimalString(debitBase),
    totalCreditBase: toDecimalString(creditBase),
  };
}

/**
 * Core types for the GL engine.
 *
 * NOTE ON SCOPE: these are deliberately plain TypeScript interfaces, not
 * Prisma models. This package has no dependency on @prisma/client, NestJS,
 * or any monorepo-specific code, so it can be built, tested, and merged
 * without touching M2's schema or any other account's files. The
 * accounting module's services (outside this package) are responsible for
 * mapping Prisma models to/from these shapes.
 */

/** Money is always represented as a decimal STRING at the boundary of this
 * package (never `number`/Float) to avoid silent precision loss when data
 * crosses JSON/DB boundaries. Internally, Decimal.js is used for all math.
 * See G19 in the M8 prompt: "Decimal precision everywhere (no Float for money)."
 */
export type DecimalString = string;

export type DebitCredit = 'DEBIT' | 'CREDIT';

/**
 * A single line of a journal entry, already resolved to base currency.
 * `amount` / `currency` are the transaction-currency values (what was
 * actually entered); `baseAmount` is the company base-currency equivalent
 * computed by the caller using an M3.2 exchange rate. This package never
 * fetches or guesses exchange rates itself — it only validates that the
 * base-currency amounts balance, per G21 of the M8 prompt.
 */
export interface JournalLineInput {
  /** Caller-assigned line id (for error reporting / drill-down; opaque to this package). */
  lineId: string;
  accountId: string;
  side: DebitCredit;
  /** Transaction-currency amount, always positive. */
  amount: DecimalString;
  currency: string;
  /** Base-currency equivalent of `amount`, always positive. */
  baseAmount: DecimalString;
  costCenterId?: string;
}

export interface JournalEntryInput {
  journalEntryId: string;
  companyId: string;
  fiscalPeriodId: string;
  lines: JournalLineInput[];
}

export interface ValidationIssue {
  code:
    | 'EMPTY_ENTRY'
    | 'SINGLE_LINE'
    | 'MISSING_AMOUNT'
    | 'NON_POSITIVE_AMOUNT'
    | 'UNBALANCED_TRANSACTION_CURRENCY'
    | 'UNBALANCED_BASE_CURRENCY'
    | 'ACCOUNT_NOT_POSTABLE'
    | 'ACCOUNT_LOCKED'
    | 'PERIOD_CLOSED';
  message: string;
  lineId?: string;
}

export interface ValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
  /** Sum of all DEBIT baseAmount lines, as a decimal string, for audit logging. */
  totalDebitBase: DecimalString;
  /** Sum of all CREDIT baseAmount lines, as a decimal string, for audit logging. */
  totalCreditBase: DecimalString;
}

/** Metadata the double-entry validator needs about each account, supplied
 * by the caller (accounting module) since only it has access to the COA
 * via Prisma. This keeps the engine free of DB dependencies. */
export interface AccountPostabilityInfo {
  accountId: string;
  /** True only for leaf accounts in the COA tree — group/header accounts are not postable. */
  isPostable: boolean;
  isLocked: boolean;
  normalBalance: DebitCredit;
  accountType: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
}

export interface PeriodStatusInfo {
  fiscalPeriodId: string;
  isClosed: boolean;
}

/** A posted GL entry — the append-only record produced by posting.ts. */
export interface GlEntry {
  journalEntryId: string;
  lineId: string;
  accountId: string;
  companyId: string;
  fiscalPeriodId: string;
  side: DebitCredit;
  amount: DecimalString;
  currency: string;
  baseAmount: DecimalString;
  postedAt: string;
  /** Present only on reversal entries; points at the JE they reverse. */
  reversesJournalEntryId?: string;
}

export interface TrialBalanceRow {
  accountId: string;
  accountType: AccountPostabilityInfo['accountType'];
  totalDebitBase: DecimalString;
  totalCreditBase: DecimalString;
  /** Net balance in the account's normal-balance sign convention. */
  netBalance: DecimalString;
}

export interface TrialBalanceResult {
  companyId: string;
  fiscalPeriodId: string | 'ALL';
  rows: TrialBalanceRow[];
  totalDebitBase: DecimalString;
  totalCreditBase: DecimalString;
  /** Integrity check per G20: must always be true, or something upstream is broken. */
  isBalanced: boolean;
}

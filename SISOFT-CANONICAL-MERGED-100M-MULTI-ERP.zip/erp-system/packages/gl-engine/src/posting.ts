import { AccountPostabilityInfo, GlEntry, JournalEntryInput, PeriodStatusInfo } from './types';
import { validateDoubleEntry } from './double-entry';

export class PostingRejectedError extends Error {
  constructor(public readonly issues: { code: string; message: string }[]) {
    super(
      `Journal entry rejected: ${issues.map((i) => i.message).join('; ')}`,
    );
    this.name = 'PostingRejectedError';
  }
}

/**
 * post() — mirrors JournalPostingService.post() from the M8 prompt, but
 * only the pure, DB-free part of it: validate, then materialize the
 * GL entries that the caller should persist atomically alongside marking
 * the JE as posted.
 *
 * Steps 2 (assign gapless JE number), 5 (update GL materialized view),
 * 6/7 (emit events), and 8 (audit) are the accounting module's
 * responsibility, since they require the DB/event bus. This function
 * only owns step 1 (validate) and produces the step-4 GL entry rows.
 *
 * Throws PostingRejectedError if validation fails — posting is
 * intentionally all-or-nothing, never partial.
 */
export function post(
  entry: JournalEntryInput,
  accounts: Map<string, AccountPostabilityInfo>,
  period: PeriodStatusInfo,
  postedAt: Date = new Date(),
): GlEntry[] {
  const result = validateDoubleEntry(entry, accounts, period);
  if (!result.valid) {
    throw new PostingRejectedError(result.issues);
  }

  return entry.lines.map((line) => ({
    journalEntryId: entry.journalEntryId,
    lineId: line.lineId,
    accountId: line.accountId,
    companyId: entry.companyId,
    fiscalPeriodId: entry.fiscalPeriodId,
    side: line.side,
    amount: line.amount,
    currency: line.currency,
    baseAmount: line.baseAmount,
    postedAt: postedAt.toISOString(),
  }));
}

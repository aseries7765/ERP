import { GlEntry } from './types';

/**
 * reverseGlEntries() — mirrors ReversalService.reverse() from the M8
 * prompt: "Create mirror JE (debits ↔ credits)". Posted JEs are
 * immutable (G17); correction is always reversal + new JE, never an edit.
 *
 * This is pure data transformation — flip DEBIT<->CREDIT on every line of
 * an already-posted entry and stamp the link back to the original. The
 * caller (JournalReversalService) is responsible for creating the new
 * JournalEntry row, running it back through post(), and posting it under
 * the new reversal JE's id.
 */
export function reverseGlEntries(
  original: GlEntry[],
  reversalJournalEntryId: string,
  postedAt: Date = new Date(),
): GlEntry[] {
  if (original.length === 0) {
    throw new Error('reverseGlEntries: cannot reverse an entry with no lines.');
  }
  const originalJournalEntryId = original[0].journalEntryId;
  return original.map((line) => ({
    ...line,
    journalEntryId: reversalJournalEntryId,
    lineId: `${line.lineId}-rev`,
    side: line.side === 'DEBIT' ? 'CREDIT' : 'DEBIT',
    postedAt: postedAt.toISOString(),
    reversesJournalEntryId: originalJournalEntryId,
  }));
}

import { AccountPostabilityInfo, GlEntry, TrialBalanceResult, TrialBalanceRow } from './types';
import { decimalEquals, Money, sum, toDecimal, toDecimalString } from './precision';

/**
 * computeTrialBalance() — mirrors TrialBalanceService from the M8 prompt:
 * real-time sum of debits/credits per account, grouped by account type,
 * with the "debits must equal credits" integrity check (G20) baked in as
 * `isBalanced` on the result rather than left for the caller to
 * remember to check.
 *
 * Pure function over an array of already-posted GL entries (which the
 * caller fetched from the DB / materialized view) plus account metadata.
 * fiscalPeriodId is accepted for labeling only — the caller decides
 * whether entries are already period-filtered or this is a cumulative
 * (ALL) trial balance.
 */
export function computeTrialBalance(
  companyId: string,
  fiscalPeriodId: string | 'ALL',
  entries: GlEntry[],
  accounts: Map<string, AccountPostabilityInfo>,
): TrialBalanceResult {
  const byAccount = new Map<string, { debit: string[]; credit: string[] }>();

  for (const e of entries) {
    if (e.companyId !== companyId) continue;
    const bucket = byAccount.get(e.accountId) ?? { debit: [], credit: [] };
    (e.side === 'DEBIT' ? bucket.debit : bucket.credit).push(e.baseAmount);
    byAccount.set(e.accountId, bucket);
  }

  const rows: TrialBalanceRow[] = [];
  let totalDebit = Money.zero();
  let totalCredit = Money.zero();

  for (const [accountId, bucket] of byAccount) {
    const acct = accounts.get(accountId);
    if (!acct) {
      throw new Error(
        `computeTrialBalance: account ${accountId} appears in GL entries but has no metadata supplied.`,
      );
    }
    const debit = sum(bucket.debit);
    const credit = sum(bucket.credit);
    totalDebit = totalDebit.plus(debit);
    totalCredit = totalCredit.plus(credit);

    const netInNormalConvention =
      acct.normalBalance === 'DEBIT' ? debit.minus(credit) : credit.minus(debit);

    rows.push({
      accountId,
      accountType: acct.accountType,
      totalDebitBase: toDecimalString(debit),
      totalCreditBase: toDecimalString(credit),
      netBalance: toDecimalString(netInNormalConvention),
    });
  }

  rows.sort((a, b) => a.accountId.localeCompare(b.accountId));

  return {
    companyId,
    fiscalPeriodId,
    rows,
    totalDebitBase: toDecimalString(totalDebit),
    totalCreditBase: toDecimalString(totalCredit),
    isBalanced: decimalEquals(totalDebit, totalCredit),
  };
}

/** Convenience export used by the daily gl-integrity-check.job.ts described
 * in the M8 prompt: throws if the ledger is out of balance, since that
 * should never happen if double-entry was enforced at post() time. */
export function assertLedgerIntegrity(tb: TrialBalanceResult): void {
  if (!tb.isBalanced) {
    const diff = toDecimal(tb.totalDebitBase).minus(toDecimal(tb.totalCreditBase));
    throw new Error(
      `GL INTEGRITY FAILURE for company ${tb.companyId}, period ${tb.fiscalPeriodId}: ` +
        `debits (${tb.totalDebitBase}) != credits (${tb.totalCreditBase}), diff ${diff.toString()}. ` +
        `This should be impossible if all posting went through post() — investigate immediately.`,
    );
  }
}

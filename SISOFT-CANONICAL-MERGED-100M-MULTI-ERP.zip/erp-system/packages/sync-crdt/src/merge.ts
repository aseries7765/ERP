import type { LWWMap } from './lww-map.js';
import type { ORSet } from './or-set.js';
import type { PNCounter } from './counter.js';

/**
 * Declares which CRDT strategy governs each field of an entity type.
 * This is the "custom resolver" table referenced by ConflictResolver
 * on the server and by the client SDK's merge-strategies module —
 * both sides must agree on this table for convergence to hold.
 */
export type FieldStrategy = 'lww' | 'or-set' | 'counter';

export type EntityStrategyMap<T> = Partial<Record<keyof T, FieldStrategy>>;

/**
 * Three-way merge of two divergent copies of an entity against a
 * common ancestor, dispatching each field to its declared CRDT.
 * Fields with no declared strategy default to 'lww'.
 *
 * This is the function ServerMergeService and the client SDK's
 * crdt-document module both call — same implementation on both
 * sides guarantees convergence (G16 / G23).
 */
export function mergeEntity<T extends Record<string, unknown>>(
  local: LWWMap<T>,
  remote: LWWMap<T>,
): LWWMap<T> {
  // LWWMap.merge is already commutative/associative/idempotent per
  // field, so entity-level LWW fields merge directly.
  return local.clone().merge(remote);
}

/** Merges two OR-Sets representing the same collection field. */
export function mergeSet<T>(local: ORSet<T>, remote: ORSet<T>): ORSet<T> {
  return local.merge(remote);
}

/** Merges two PN-Counters representing the same numeric field. */
export function mergeCounter(local: PNCounter, remote: PNCounter): PNCounter {
  return local.merge(remote);
}

/**
 * Example custom resolver referenced by CONFLICT_RESOLUTION.md:
 * stock quantity is operation-based (delta), never an absolute LWW
 * write, so concurrent adjustments from two warehouse terminals both
 * apply instead of one clobbering the other.
 */
export function applyStockDelta(counter: PNCounter, delta: number): void {
  if (delta >= 0) counter.increment(delta);
  else counter.decrement(-delta);
}

/**
 * Vector clock and Lamport timestamp utilities used to establish
 * causal ordering between operations produced by different clients
 * (devices) in the offline-sync system.
 */

export type VectorClock = Record<string, number>;

export interface ClockedOp {
  clientId: string;
  clock: VectorClock;
}

/**
 * Comparison result between two vector clocks.
 * - 'before':      a happened-before b
 * - 'after':        a happened-after b
 * - 'equal':        identical clocks
 * - 'concurrent':   neither dominates the other (true conflict)
 */
export type ClockOrder = 'before' | 'after' | 'equal' | 'concurrent';

/** Returns a new clock with clientId's counter incremented by 1. */
export function tick(clock: VectorClock, clientId: string): VectorClock {
  return { ...clock, [clientId]: (clock[clientId] ?? 0) + 1 };
}

/** Merges two vector clocks by taking the element-wise maximum. */
export function mergeClocks(a: VectorClock, b: VectorClock): VectorClock {
  const merged: VectorClock = { ...a };
  for (const key of Object.keys(b)) {
    merged[key] = Math.max(merged[key] ?? 0, b[key] ?? 0);
  }
  return merged;
}

/**
 * Compares two vector clocks to determine causal order.
 * Missing entries are treated as 0.
 */
export function compareClocks(a: VectorClock, b: VectorClock): ClockOrder {
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  let aGreater = false;
  let bGreater = false;

  for (const key of keys) {
    const av = a[key] ?? 0;
    const bv = b[key] ?? 0;
    if (av > bv) aGreater = true;
    if (bv > av) bGreater = true;
  }

  if (aGreater && bGreater) return 'concurrent';
  if (aGreater) return 'after';
  if (bGreater) return 'before';
  return 'equal';
}

/** True if a and b are causally concurrent (a real conflict). */
export function isConcurrent(a: VectorClock, b: VectorClock): boolean {
  return compareClocks(a, b) === 'concurrent';
}

/**
 * Lamport logical clock — a single monotonic counter, used as a
 * tie-breaker for LWW strategies alongside wall-clock timestamps.
 */
export class LamportClock {
  private counter = 0;

  now(): number {
    this.counter += 1;
    return this.counter;
  }

  /** Update local counter on receipt of a remote timestamp. */
  observe(remote: number): number {
    this.counter = Math.max(this.counter, remote) + 1;
    return this.counter;
  }

  value(): number {
    return this.counter;
  }
}

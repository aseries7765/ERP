/**
 * PN-Counter (Positive-Negative Counter).
 * Used for numeric fields that are modified by relative deltas rather
 * than absolute writes — e.g. stock quantity adjustments made
 * concurrently by multiple offline clients. Each client tracks its
 * own increment/decrement totals; the counter value is always the
 * sum of increments minus the sum of decrements across all clients,
 * which makes merges commutative regardless of order.
 */

export class PNCounter {
  private increments: Map<string, number> = new Map();
  private decrements: Map<string, number> = new Map();

  private readonly clientId: string;

  constructor(clientId: string) {
    this.clientId = clientId;
  }

  increment(amount = 1): void {
    if (amount < 0) throw new Error('increment() requires a non-negative amount');
    this.increments.set(this.clientId, (this.increments.get(this.clientId) ?? 0) + amount);
  }

  decrement(amount = 1): void {
    if (amount < 0) throw new Error('decrement() requires a non-negative amount');
    this.decrements.set(this.clientId, (this.decrements.get(this.clientId) ?? 0) + amount);
  }

  value(): number {
    const inc = [...this.increments.values()].reduce((a, b) => a + b, 0);
    const dec = [...this.decrements.values()].reduce((a, b) => a + b, 0);
    return inc - dec;
  }

  /** Merges by taking, per client, the max of each side's increment/decrement totals. */
  merge(other: PNCounter): PNCounter {
    for (const [client, amt] of other.increments.entries()) {
      this.increments.set(client, Math.max(this.increments.get(client) ?? 0, amt));
    }
    for (const [client, amt] of other.decrements.entries()) {
      this.decrements.set(client, Math.max(this.decrements.get(client) ?? 0, amt));
    }
    return this;
  }

  snapshot(): { increments: Record<string, number>; decrements: Record<string, number> } {
    return {
      increments: Object.fromEntries(this.increments),
      decrements: Object.fromEntries(this.decrements),
    };
  }
}

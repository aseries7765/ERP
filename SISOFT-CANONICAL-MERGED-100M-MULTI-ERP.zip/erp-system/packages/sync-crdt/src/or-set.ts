/**
 * Observed-Remove Set (OR-Set).
 * Used for collection-style fields where concurrent add/remove must
 * commute correctly — tags, team members, categories. An element can
 * be re-added after removal (unlike a simple tombstone set), and a
 * concurrent add always "wins" over a concurrent remove of the same
 * add (the remove can only remove tags it observed).
 */

interface Tag {
  id: string; // unique per add operation, e.g. `${clientId}:${lamport}`
}

export class ORSet<T> {
  /** value -> set of add-tags currently live (not yet removed) */
  private adds: Map<string, Map<string, Tag>> = new Map();
  /** value -> set of tombstoned tag ids */
  private removes: Map<string, Set<string>> = new Map();
  private serialize: (v: T) => string;

  constructor(serialize: (v: T) => string = (v) => JSON.stringify(v)) {
    this.serialize = serialize;
  }

  add(value: T, tagId: string): void {
    const key = this.serialize(value);
    const existing = this.adds.get(key) ?? new Map<string, Tag>();
    existing.set(tagId, { id: tagId });
    this.adds.set(key, existing);
  }

  /** Removes a value by tombstoning every add-tag currently observed for it. */
  remove(value: T): void {
    const key = this.serialize(value);
    const liveTags = this.adds.get(key);
    if (!liveTags) return;
    const tombstones = this.removes.get(key) ?? new Set<string>();
    for (const tagId of liveTags.keys()) tombstones.add(tagId);
    this.removes.set(key, tombstones);
  }

  has(value: T): boolean {
    const key = this.serialize(value);
    const liveTags = this.adds.get(key);
    if (!liveTags || liveTags.size === 0) return false;
    const tombstones = this.removes.get(key) ?? new Set<string>();
    return [...liveTags.keys()].some((tag) => !tombstones.has(tag));
  }

  values(): T[] {
    const result: T[] = [];
    for (const [key, liveTags] of this.adds.entries()) {
      const tombstones = this.removes.get(key) ?? new Set<string>();
      const stillLive = [...liveTags.keys()].some((tag) => !tombstones.has(tag));
      if (stillLive) {
        // key round-trips through JSON for the default serializer; callers
        // using custom serializers should track their own reverse mapping.
        result.push(JSON.parse(key) as T);
      }
    }
    return result;
  }

  /** Merges another OR-Set's add/remove sets in. Commutative, associative, idempotent. */
  merge(other: ORSet<T>): ORSet<T> {
    for (const [key, tags] of other.adds.entries()) {
      const mine = this.adds.get(key) ?? new Map<string, Tag>();
      for (const [tagId, tag] of tags.entries()) mine.set(tagId, tag);
      this.adds.set(key, mine);
    }
    for (const [key, tombstones] of other.removes.entries()) {
      const mine = this.removes.get(key) ?? new Set<string>();
      for (const tagId of tombstones) mine.add(tagId);
      this.removes.set(key, mine);
    }
    return this;
  }
}

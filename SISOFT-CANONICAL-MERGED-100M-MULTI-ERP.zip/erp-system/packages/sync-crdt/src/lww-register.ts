/**
 * Last-Write-Wins Register.
 * Used for simple scalar fields (status, priority, single-select fields)
 * where the most recent write should always win deterministically,
 * regardless of the order operations are applied in.
 */

export interface LWWValue<T> {
  value: T;
  /** Wall-clock timestamp (ms since epoch) of the write. */
  timestamp: number;
  /** Lamport counter — tie-breaker when timestamps collide. */
  lamport: number;
  /** Client that produced the write — final tie-breaker for determinism. */
  clientId: string;
}

export class LWWRegister<T> {
  private current: LWWValue<T>;

  constructor(initial: LWWValue<T>) {
    this.current = initial;
  }

  get(): T {
    return this.current.value;
  }

  meta(): LWWValue<T> {
    return this.current;
  }

  /**
   * Merges an incoming value. Deterministic total order:
   * higher timestamp wins; on tie, higher lamport wins;
   * on tie, higher clientId (lexicographic) wins.
   * This guarantees convergence regardless of merge order.
   */
  merge(incoming: LWWValue<T>): LWWRegister<T> {
    if (isLater(incoming, this.current)) {
      this.current = incoming;
    }
    return this;
  }

  static merged<T>(a: LWWValue<T>, b: LWWValue<T>): LWWValue<T> {
    return isLater(b, a) ? b : a;
  }
}

function isLater<T>(candidate: LWWValue<T>, against: LWWValue<T>): boolean {
  if (candidate.timestamp !== against.timestamp) {
    return candidate.timestamp > against.timestamp;
  }
  if (candidate.lamport !== against.lamport) {
    return candidate.lamport > against.lamport;
  }
  return candidate.clientId > against.clientId;
}

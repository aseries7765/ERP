import type { VectorClock } from './clock.js';

export interface CrdtOperation {
  id: string;
  entityType: string;
  entityId: string;
  clientId: string;
  vectorClock: VectorClock;
  timestamp: number;
  lamport: number;
}

export interface EntityMergeResult<T> {
  merged: T;
  hadConflict: boolean;
  resolvedBy: 'lww' | 'or-set' | 'counter' | 'no-conflict';
}

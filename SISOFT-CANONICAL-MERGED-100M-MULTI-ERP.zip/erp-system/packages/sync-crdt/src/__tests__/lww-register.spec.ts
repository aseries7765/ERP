import { describe, it, expect } from 'vitest';
import { LWWRegister } from '../lww-register.js';

describe('LWWRegister', () => {
  it('higher timestamp wins regardless of merge order', () => {
    const older = { value: 'a', timestamp: 100, lamport: 1, clientId: 'c1' };
    const newer = { value: 'b', timestamp: 200, lamport: 1, clientId: 'c1' };

    const r1 = new LWWRegister(older).merge(newer);
    const r2 = new LWWRegister(newer).merge(older);

    expect(r1.get()).toBe('b');
    expect(r2.get()).toBe('b');
  });

  it('breaks timestamp ties using the lamport counter', () => {
    const a = { value: 'a', timestamp: 100, lamport: 1, clientId: 'c1' };
    const b = { value: 'b', timestamp: 100, lamport: 2, clientId: 'c1' };

    const r = new LWWRegister(a).merge(b);
    expect(r.get()).toBe('b');
  });

  it('breaks timestamp+lamport ties using clientId for determinism', () => {
    const a = { value: 'from-a', timestamp: 100, lamport: 1, clientId: 'client-a' };
    const b = { value: 'from-b', timestamp: 100, lamport: 1, clientId: 'client-b' };

    // client-b > client-a lexicographically, so b should win either order.
    expect(new LWWRegister(a).merge(b).get()).toBe('from-b');
    expect(new LWWRegister(b).merge(a).get()).toBe('from-b');
  });

  it('is idempotent — merging the same value twice is a no-op', () => {
    const a = { value: 'a', timestamp: 100, lamport: 1, clientId: 'c1' };
    const r = new LWWRegister(a).merge(a).merge(a);
    expect(r.get()).toBe('a');
  });
});

import { describe, it, expect } from 'vitest';
import { LWWMap } from '../lww-map.js';
import { ORSet } from '../or-set.js';
import { PNCounter } from '../counter.js';

interface Order extends Record<string, unknown> {
  status: string;
  notes: string;
}

/** Deterministic seeded PRNG so failures are reproducible. */
function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle<T>(arr: T[], rand: () => number): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

describe('CRDT convergence (property-based)', () => {
  it('LWWMap: 200 random application orders of 12 ops all converge to the same final state', () => {
    const ops: Array<{ field: keyof Order; value: string; timestamp: number; lamport: number; clientId: string }> = [];
    for (let i = 0; i < 12; i++) {
      ops.push({
        field: i % 2 === 0 ? 'status' : 'notes',
        value: `v${i}`,
        timestamp: 1000 + i * 7,
        lamport: i,
        clientId: `client-${i % 3}`,
      });
    }

    const rand = mulberry32(42);
    const results: Array<Partial<Order>> = [];

    for (let trial = 0; trial < 200; trial++) {
      const order = shuffle(ops, rand);
      const map = LWWMap.fromObject<Order>(
        { status: 'new', notes: '' },
        { timestamp: 0, lamport: -1, clientId: 'init' },
      );
      for (const op of order) {
        map.setField(op.field, {
          value: op.value,
          timestamp: op.timestamp,
          lamport: op.lamport,
          clientId: op.clientId,
        });
      }
      results.push(map.toObject());
    }

    const first = JSON.stringify(results[0]);
    for (const r of results) {
      expect(JSON.stringify(r)).toBe(first);
    }
  });

  it('ORSet: 200 random merge orders of per-replica sets all converge to the same value set', () => {
    const rand = mulberry32(7);

    function buildReplicas(): ORSet<string>[] {
      const r1 = new ORSet<string>();
      r1.add('red', 'r1:1');
      r1.add('blue', 'r1:2');

      const r2 = new ORSet<string>();
      r2.add('red', 'r1:1'); // observed r1's add
      r2.remove('red');
      r2.add('green', 'r2:1');

      const r3 = new ORSet<string>();
      r3.add('blue', 'r1:2'); // observed r1's add
      r3.add('yellow', 'r3:1');

      return [r1, r2, r3];
    }

    const results: string[][] = [];
    for (let trial = 0; trial < 200; trial++) {
      const replicas = shuffle(buildReplicas(), rand);
      const merged = replicas.reduce((acc, r) => acc.merge(r), new ORSet<string>());
      results.push(merged.values().sort());
    }

    const first = JSON.stringify(results[0]);
    for (const r of results) {
      expect(JSON.stringify(r)).toBe(first);
    }
  });

  it('PNCounter: 200 random merge orders of concurrent stock adjustments converge to the same total', () => {
    const rand = mulberry32(99);

    function buildReplicas(): PNCounter[] {
      const a = new PNCounter('a');
      a.increment(10);
      const b = new PNCounter('b');
      b.decrement(3);
      const c = new PNCounter('c');
      c.increment(2);
      c.decrement(1);
      return [a, b, c];
    }

    const results: number[] = [];
    for (let trial = 0; trial < 200; trial++) {
      const replicas = shuffle(buildReplicas(), rand);
      const merged = replicas.reduce((acc, r) => acc.merge(r), new PNCounter('seed'));
      results.push(merged.value());
    }

    expect(new Set(results).size).toBe(1);
    expect(results[0]).toBe(8); // 10 - 3 + 2 - 1
  });
});

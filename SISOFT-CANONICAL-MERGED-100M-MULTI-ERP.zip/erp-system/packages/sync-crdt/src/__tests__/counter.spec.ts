import { describe, it, expect } from 'vitest';
import { PNCounter } from '../counter.js';
import { applyStockDelta } from '../merge.js';

describe('PNCounter', () => {
  it('tracks increments and decrements from a single client', () => {
    const c = new PNCounter('device-1');
    c.increment(5);
    c.decrement(2);
    expect(c.value()).toBe(3);
  });

  it('merges concurrent adjustments from two warehouse terminals without losing either delta', () => {
    // Two terminals independently adjust stock for the same SKU while offline.
    const terminalA = new PNCounter('terminal-a');
    applyStockDelta(terminalA, -3); // sold 3 units

    const terminalB = new PNCounter('terminal-b');
    applyStockDelta(terminalB, +10); // received 10 units

    const merged = terminalA.merge(terminalB);
    expect(merged.value()).toBe(7); // both deltas applied, not clobbered
  });

  it('merge is commutative and idempotent', () => {
    const a = new PNCounter('a');
    a.increment(4);
    const b = new PNCounter('b');
    b.decrement(1);

    const ab = new PNCounter('a').merge(a).merge(b);
    const ba = new PNCounter('a').merge(b).merge(a);
    const abIdempotent = ab.merge(b); // re-merging b again changes nothing

    expect(ab.value()).toBe(ba.value());
    expect(abIdempotent.value()).toBe(ab.value());
  });

  it('rejects negative amounts (deltas must be signed via applyStockDelta)', () => {
    const c = new PNCounter('a');
    expect(() => c.increment(-1)).toThrow();
    expect(() => c.decrement(-1)).toThrow();
  });
});

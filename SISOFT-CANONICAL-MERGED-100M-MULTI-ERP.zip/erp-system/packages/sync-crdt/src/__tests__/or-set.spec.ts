import { describe, it, expect } from 'vitest';
import { ORSet } from '../or-set.js';

describe('ORSet', () => {
  it('adds and removes commute — same result regardless of application order', () => {
    const s1 = new ORSet<string>();
    s1.add('urgent', 'c1:1');
    s1.remove('urgent');
    s1.add('vip', 'c1:2');

    const s2 = new ORSet<string>();
    s2.add('vip', 'c1:2');
    s2.add('urgent', 'c1:1');
    s2.remove('urgent');

    expect(s1.values().sort()).toEqual(s2.values().sort());
    expect(s1.has('urgent')).toBe(false);
    expect(s1.has('vip')).toBe(true);
  });

  it('re-adding after removal (by a fresh tag) makes the value live again', () => {
    const s = new ORSet<string>();
    s.add('tag-a', 'c1:1');
    s.remove('tag-a');
    expect(s.has('tag-a')).toBe(false);

    s.add('tag-a', 'c1:2'); // new add-tag, not observed by the earlier remove
    expect(s.has('tag-a')).toBe(true);
  });

  it('a concurrent add wins over a concurrent remove of the same element (add-bias)', () => {
    // Client A adds "beta" with tag c-a:1. Client B, concurrently and
    // without having observed A's add, removes "beta" (no-op for it,
    // since it has nothing to tombstone). On merge, A's add survives.
    const fromA = new ORSet<string>();
    fromA.add('beta', 'c-a:1');

    const fromB = new ORSet<string>();
    fromB.remove('beta'); // no live tags observed -> no-op

    const merged = fromA.merge(fromB);
    expect(merged.has('beta')).toBe(true);
  });

  it('merge is commutative: merge(A,B) == merge(B,A)', () => {
    const a = new ORSet<string>();
    a.add('x', 'a:1');
    a.remove('x');
    a.add('y', 'a:2');

    const b = new ORSet<string>();
    b.add('x', 'a:1'); // same add-tag observed
    b.add('z', 'b:1');

    const ab = new ORSet<string>().merge(a).merge(b);
    const ba = new ORSet<string>().merge(b).merge(a);

    expect(ab.values().sort()).toEqual(ba.values().sort());
  });
});

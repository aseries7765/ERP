import { describe, it, expect } from 'vitest';
import { LWWMap } from '../lww-map.js';

interface Customer extends Record<string, unknown> {
  name: string;
  status: string;
}

describe('LWWMap', () => {
  it('merges non-conflicting field edits from two clients without loss', () => {
    // Client A edits `name`, Client B concurrently edits `status`.
    const base = LWWMap.fromObject<Customer>(
      { name: 'Acme', status: 'active' },
      { timestamp: 100, lamport: 1, clientId: 'server' },
    );

    const fromA = base.clone();
    fromA.setField('name', { value: 'Acme Corp', timestamp: 200, lamport: 2, clientId: 'device-a' });

    const fromB = base.clone();
    fromB.setField('status', { value: 'suspended', timestamp: 210, lamport: 2, clientId: 'device-b' });

    const merged = fromA.merge(fromB);
    expect(merged.toObject()).toEqual({ name: 'Acme Corp', status: 'suspended' });
  });

  it('resolves same-field concurrent edits deterministically via LWW, converging either merge order', () => {
    const base = LWWMap.fromObject<Customer>(
      { name: 'Acme', status: 'active' },
      { timestamp: 100, lamport: 1, clientId: 'server' },
    );

    const fromA = base.clone();
    fromA.setField('status', { value: 'active-review', timestamp: 300, lamport: 2, clientId: 'device-a' });

    const fromB = base.clone();
    fromB.setField('status', { value: 'suspended', timestamp: 305, lamport: 2, clientId: 'device-b' });

    const mergedAB = fromA.clone().merge(fromB);
    const mergedBA = fromB.clone().merge(fromA);

    // Both orders must converge to the same final state (later timestamp wins).
    expect(mergedAB.toObject().status).toBe('suspended');
    expect(mergedBA.toObject().status).toBe('suspended');
    expect(mergedAB.toObject()).toEqual(mergedBA.toObject());
  });
});

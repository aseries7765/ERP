import { describe, it, expect } from 'vitest';
import { tick, mergeClocks, compareClocks, isConcurrent, LamportClock } from '../clock.js';

describe('vector clock', () => {
  it('tick increments only the given client', () => {
    const c1 = tick({}, 'a');
    expect(c1).toEqual({ a: 1 });
    const c2 = tick(c1, 'a');
    expect(c2).toEqual({ a: 2 });
  });

  it('detects before/after for causally related clocks', () => {
    const a = { x: 1 };
    const b = { x: 2 };
    expect(compareClocks(a, b)).toBe('before');
    expect(compareClocks(b, a)).toBe('after');
  });

  it('detects concurrent (conflicting) clocks', () => {
    const a = { x: 1, y: 0 };
    const b = { x: 0, y: 1 };
    expect(compareClocks(a, b)).toBe('concurrent');
    expect(isConcurrent(a, b)).toBe(true);
  });

  it('treats identical clocks as equal', () => {
    expect(compareClocks({ x: 1 }, { x: 1 })).toBe('equal');
  });

  it('merge takes element-wise max', () => {
    const merged = mergeClocks({ a: 3, b: 1 }, { a: 1, b: 5, c: 2 });
    expect(merged).toEqual({ a: 3, b: 5, c: 2 });
  });
});

describe('LamportClock', () => {
  it('is strictly monotonically increasing', () => {
    const clock = new LamportClock();
    const t1 = clock.now();
    const t2 = clock.now();
    expect(t2).toBeGreaterThan(t1);
  });

  it('observe() jumps ahead of a larger remote value', () => {
    const clock = new LamportClock();
    clock.now(); // 1
    const next = clock.observe(10);
    expect(next).toBe(11);
    expect(clock.value()).toBe(11);
  });
});

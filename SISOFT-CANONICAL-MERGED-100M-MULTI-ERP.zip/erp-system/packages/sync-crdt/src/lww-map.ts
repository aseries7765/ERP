import type { LWWValue } from './lww-register.js';

/**
 * Field-level Last-Write-Wins Map.
 * Each field of an entity (e.g. a Customer record) is its own LWW
 * register, so two clients editing *different* fields concurrently
 * merge without conflict, while edits to the *same* field resolve
 * via LWW ordering.
 */
export class LWWMap<T extends Record<string, unknown>> {
  private fields: Map<keyof T, LWWValue<T[keyof T]>> = new Map();

  static fromObject<T extends Record<string, unknown>>(
    obj: T,
    meta: { timestamp: number; lamport: number; clientId: string },
  ): LWWMap<T> {
    const map = new LWWMap<T>();
    for (const key of Object.keys(obj) as (keyof T)[]) {
      map.fields.set(key, { value: obj[key], ...meta });
    }
    return map;
  }

  setField<K extends keyof T>(key: K, entry: LWWValue<T[K]>): void {
    const existing = this.fields.get(key);
    if (!existing || isLater(entry as LWWValue<T[keyof T]>, existing)) {
      this.fields.set(key, entry as LWWValue<T[keyof T]>);
    }
  }

  toObject(): Partial<T> {
    const out: Partial<T> = {};
    for (const [key, entry] of this.fields.entries()) {
      out[key] = entry.value as T[typeof key];
    }
    return out;
  }

  /** Merges another map's fields in, field by field. Commutative & idempotent. */
  merge(other: LWWMap<T>): LWWMap<T> {
    for (const [key, entry] of other.fields.entries()) {
      const existing = this.fields.get(key);
      if (!existing || isLater(entry, existing)) {
        this.fields.set(key, entry);
      }
    }
    return this;
  }

  clone(): LWWMap<T> {
    const copy = new LWWMap<T>();
    copy.fields = new Map(this.fields);
    return copy;
  }
}

function isLater<T>(candidate: LWWValue<T>, against: LWWValue<T>): boolean {
  if (candidate.timestamp !== against.timestamp) {
    return candidate.timestamp > against.timestamp;
  }
  if (candidate.lamport !== against.lamport) {
    return candidate.lamport > against.lamport;
  }
  return candidate.clientId > against.clientId;
}

# @erp/sync-crdt

Conflict-free replicated data type primitives shared by the server
(`apps/api/src/modules/sync`) and the client SDK (`packages/sync-engine`).
Both sides import the *same* implementations from this package so that
merges are guaranteed to converge (G16/G23) — there is no separate
"server CRDT" and "client CRDT" to keep in sync.

## What's implemented

| Primitive | File | Use for |
|---|---|---|
| Vector clock + Lamport clock | `clock.ts` | causal ordering, tie-breaking |
| LWW-Register | `lww-register.ts` | a single scalar value |
| LWW-Map | `lww-map.ts` | field-level merge of a record (e.g. a `Customer`) |
| OR-Set | `or-set.ts` | tags, members, categories — add/remove commute |
| PN-Counter | `counter.ts` | quantities modified by concurrent deltas |
| `mergeEntity` / `mergeSet` / `mergeCounter` | `merge.ts` | dispatch helpers, plus the `applyStockDelta` example from the spec |

Determinism: every merge is commutative, associative, and idempotent
— see `src/__tests__/merge.spec.ts` for the property-based convergence
tests (200 random application/merge orders per primitive, seeded PRNG
for reproducibility).

## Not implemented in this package (see root MANIFEST.md)

- `rga.ts` / `text.ts` (RGA / Yjs-backed collaborative text for notes
  fields) — the spec calls for a Yjs integration; pulling in Yjs and
  building the RGA wrapper is a substantial sub-task on its own and is
  cut from this slice. `custom-resolvers.ts` as a *separate* file is
  also not built — its one worked example (stock delta) lives in
  `merge.ts::applyStockDelta` instead of a dedicated file.

## Running the tests

```
pnpm install
pnpm --filter @erp/sync-crdt test
```

This repo could not run `pnpm install` in the environment this package
was authored in (no registry access) — see root `MANIFEST.md` for how
the logic was instead verified directly against the compiled source
using Node's built-in TypeScript stripping and `node:assert`.

declare module 'node:crypto' {
  export function randomBytes(size:number): {toString(encoding:string):string};
  export function createHmac(algorithm:string,key:string): {update(data:string):any;digest(encoding:string):string};
  export function timingSafeEqual(a:any,b:any):boolean;
}
declare const Buffer: {from(value:string): any};

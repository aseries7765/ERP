import assert from 'node:assert/strict';
import test from 'node:test';
import { calculateDsrDeadline, classifyForErasure, pseudonymize, DSR_ARTICLE_WORKFLOW } from './index';

test('standard deadline is 30 days', () => {
  const d = calculateDsrDeadline({ requestType: 'access', receivedAt: '2026-01-01T00:00:00Z' });
  assert.equal(d.dueAt.toISOString(), '2026-01-31T00:00:00.000Z');
  assert.equal(d.extendedDueAt, undefined);
});

test('complex request exposes 90 day extension', () => {
  const d = calculateDsrDeadline({ requestType: 'erasure', receivedAt: '2026-01-01T00:00:00Z', isComplex: true });
  assert.equal(d.extendedDueAt?.toISOString(), '2026-04-01T00:00:00.000Z');
  assert.equal(d.isOverdue(new Date('2026-04-02T00:00:00Z')), true);
});

test('classification follows accepted ADR', () => {
  assert.equal(classifyForErasure({ legalBasis: 'legal_obligation' }), 'retain');
  assert.equal(classifyForErasure({ retentionRequired: true }), 'retain');
  assert.equal(classifyForErasure({ legalBasis: 'contract' }), 'anonymize');
  assert.equal(classifyForErasure({ legalBasis: 'consent' }), 'erasable');
});

test('pseudonymization is deterministic and key-sensitive', () => {
  const a = pseudonymize('subject-1', '0123456789abcdef');
  assert.equal(a, pseudonymize('subject-1', '0123456789abcdef'));
  assert.notEqual(a, pseudonymize('subject-1', 'fedcba9876543210'));
  assert.throws(() => pseudonymize('subject-1', 'short'));
});

test('all seven request types have workflow definitions', () => {
  assert.equal(Object.keys(DSR_ARTICLE_WORKFLOW).length, 7);
});

import { createHmac } from 'node:crypto';

export type DsrRequestType =
  | 'access' | 'rectification' | 'erasure' | 'restriction'
  | 'portability' | 'objection' | 'automated_decision';

export type ErasureDisposition = 'retain' | 'anonymize' | 'erasable';

export interface DsrDeadline {
  receivedAt: Date;
  dueAt: Date;
  extendedDueAt?: Date;
  isComplex: boolean;
  daysRemaining(now?: Date): number;
  isOverdue(now?: Date): boolean;
}

const DAY_MS = 86_400_000;
const STANDARD_DAYS = 30;
const COMPLEX_DAYS = 90;

function asDate(value: Date | string): Date {
  const d = value instanceof Date ? new Date(value.getTime()) : new Date(value);
  if (Number.isNaN(d.getTime())) throw new Error('Invalid date');
  return d;
}

export function calculateDsrDeadline(input: {
  requestType: DsrRequestType;
  receivedAt: Date | string;
  isComplex?: boolean;
}): DsrDeadline {
  const receivedAt = asDate(input.receivedAt);
  const isComplex = input.isComplex === true;
  const dueAt = new Date(receivedAt.getTime() + STANDARD_DAYS * DAY_MS);
  const extendedDueAt = isComplex ? new Date(receivedAt.getTime() + COMPLEX_DAYS * DAY_MS) : undefined;
  const effective = () => extendedDueAt ?? dueAt;
  return {
    receivedAt, dueAt, extendedDueAt, isComplex,
    daysRemaining(now = new Date()) { return Math.ceil((effective().getTime() - asDate(now).getTime()) / DAY_MS); },
    isOverdue(now = new Date()) { return asDate(now).getTime() > effective().getTime(); },
  };
}

export function pseudonymize(value: string, secret: string): string {
  if (!secret || secret.length < 16) throw new Error('DSR pseudonymization key must be at least 16 characters');
  return createHmac('sha256', secret).update(value).digest('hex');
}

export function classifyForErasure(input: { legalBasis?: string; retentionRequired?: boolean }): ErasureDisposition {
  if (input.legalBasis === 'legal_obligation' || input.retentionRequired === true) return 'retain';
  if (input.legalBasis === 'contract') return 'anonymize';
  return 'erasable';
}

export interface DsrRecord {
  id: string;
  tenantId: string;
  subjectId: string;
  entityType: string;
  data: Record<string, unknown>;
  legalBasis?: string;
  retentionRequired?: boolean;
}

export interface DataFinderAdapter {
  findBySubject(tenantId: string, subjectId: string): Promise<DsrRecord[]>;
}

export interface ErasureResult { retained: string[]; anonymized: string[]; erased: string[]; }

export function applyErasureClassification(records: DsrRecord[]): ErasureResult {
  const result: ErasureResult = { retained: [], anonymized: [], erased: [] };
  for (const record of records) {
    const disposition = classifyForErasure(record);
    result[disposition === 'retain' ? 'retained' : disposition === 'anonymize' ? 'anonymized' : 'erased'].push(record.id);
  }
  return result;
}

export function anonymizeRecord(record: DsrRecord, fields: string[]): DsrRecord {
  const data = { ...record.data };
  for (const field of fields) if (field in data) data[field] = null;
  return { ...record, subjectId: `anon:${record.id}`, data };
}

export interface ExportBundle { subjectId: string; generatedAt: string; records: DsrRecord[]; }
export function exportData(subjectId: string, records: DsrRecord[]): ExportBundle {
  return { subjectId, generatedAt: new Date().toISOString(), records: records.map(r => ({ ...r, data: { ...r.data } })) };
}

export const DSR_ARTICLE_WORKFLOW: Readonly<Record<DsrRequestType, readonly string[]>> = {
  access: ['collect', 'review', 'export', 'deliver'],
  rectification: ['collect', 'review', 'correct', 'confirm'],
  erasure: ['collect', 'retention_review', 'erase_or_anonymize', 'confirm'],
  restriction: ['collect', 'review', 'restrict', 'confirm'],
  portability: ['collect', 'normalize', 'export', 'deliver'],
  objection: ['collect', 'review', 'decision', 'confirm'],
  automated_decision: ['collect', 'review', 'explain_or_escalate', 'confirm'],
};

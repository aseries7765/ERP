# @erp/dsr-engine

Contract-driven DSR compliance primitives used by the API DSR deadline job and documented compliance module.

Includes the 30/90-day deadline calculator, HMAC pseudonymization, erasure classification, conservative anonymization/export helpers, and per-request-type workflow definitions.

This package is intentionally framework-free. Database-specific discovery, erasure transactions, identity verification, and Article-specific handlers remain API/module responsibilities.

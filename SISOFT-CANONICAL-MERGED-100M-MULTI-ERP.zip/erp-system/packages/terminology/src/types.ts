export type TerminologyMap = Record<string, string>;

export interface TerminologyClientOptions {
  /** Base URL of the API, e.g. https://api.example.com */
  baseUrl: string;
  /** Function returning the current auth token / headers for fetch calls. */
  getAuthHeaders?: () => Record<string, string> | Promise<Record<string, string>>;
  /** BCP-47 locale, e.g. "en", "ur". Defaults to "en". */
  locale?: string;
}

export interface ResolveBatchRequest {
  keys: string[];
  locale?: string;
}

export interface TerminologyContextValue {
  /** Resolve a key against the currently-loaded map; falls back to the raw key. */
  t: (key: string, params?: Record<string, string | number>) => string;
  /** True while the initial batch preload for this screen/provider is in flight. */
  loading: boolean;
  /** The current locale in use. */
  locale: string;
  /** Imperatively request additional keys not covered by the initial preload. */
  preload: (keys: string[]) => Promise<void>;
}

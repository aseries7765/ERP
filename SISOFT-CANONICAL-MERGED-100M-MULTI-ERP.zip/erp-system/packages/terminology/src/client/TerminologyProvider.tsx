import React, { createContext, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { TerminologyClient } from './terminology-client';
import type { TerminologyClientOptions, TerminologyContextValue } from '../types';

export const TerminologyContext = createContext<TerminologyContextValue | null>(null);

export interface TerminologyProviderProps extends TerminologyClientOptions {
  /** Keys to preload as soon as the provider mounts (a screen's known key set). */
  preloadKeys?: string[];
  children: React.ReactNode;
}

/**
 * Wraps a screen/app in terminology context. Preloads `preloadKeys` in one
 * batch request on mount (see BatchResolverService server-side), then serves
 * `t()` calls from the resulting in-memory map.
 */
export function TerminologyProvider({ preloadKeys = [], children, ...clientOptions }: TerminologyProviderProps) {
  const clientRef = useRef<TerminologyClient>();
  if (!clientRef.current) clientRef.current = new TerminologyClient(clientOptions);

  const [map, setMap] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(preloadKeys.length > 0);

  const preload = useCallback(async (keys: string[]) => {
    const resolved = await clientRef.current!.resolveBatch(keys);
    setMap((prev) => ({ ...prev, ...resolved }));
  }, []);

  useEffect(() => {
    let cancelled = false;
    if (preloadKeys.length === 0) {
      setLoading(false);
      return;
    }
    setLoading(true);
    preload(preloadKeys).finally(() => {
      if (!cancelled) setLoading(false);
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preloadKeys.join('|')]);

  const t = useCallback(
    (key: string, params?: Record<string, string | number>): string => {
      const raw = map[key] ?? key;
      if (!params) return raw;
      return Object.entries(params).reduce(
        (acc, [param, value]) => acc.split(`{${param}}`).join(String(value)),
        raw,
      );
    },
    [map],
  );

  const value = useMemo<TerminologyContextValue>(
    () => ({ t, loading, locale: clientOptions.locale ?? 'en', preload }),
    [t, loading, clientOptions.locale, preload],
  );

  return <TerminologyContext.Provider value={value}>{children}</TerminologyContext.Provider>;
}

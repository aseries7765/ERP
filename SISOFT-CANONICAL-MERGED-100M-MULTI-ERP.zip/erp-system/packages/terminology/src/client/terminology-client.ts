import type { TerminologyClientOptions, TerminologyMap } from '../types';

/**
 * Thin fetch wrapper around the /v1/terminology/resolve endpoints, with an
 * in-memory cache so repeated preloads of the same key within a session
 * don't re-hit the network. Server-side response caching/TTL is handled by
 * the API (Redis); this cache is purely to avoid redundant client requests
 * within a single page session.
 */
export class TerminologyClient {
  private readonly baseUrl: string;
  private readonly getAuthHeaders: TerminologyClientOptions['getAuthHeaders'];
  private readonly locale: string;
  private readonly memoryCache = new Map<string, string>();
  private inFlight: Promise<TerminologyMap> | null = null;

  constructor(options: TerminologyClientOptions) {
    this.baseUrl = options.baseUrl.replace(/\/$/, '');
    this.getAuthHeaders = options.getAuthHeaders;
    this.locale = options.locale ?? 'en';
  }

  /** Resolve a single key, using the in-memory cache if already loaded. */
  async resolve(key: string): Promise<string> {
    if (this.memoryCache.has(key)) return this.memoryCache.get(key)!;

    const map = await this.resolveBatch([key]);
    return map[key] ?? key;
  }

  /** Batch-resolve many keys in one request; merges results into the memory cache. */
  async resolveBatch(keys: string[]): Promise<TerminologyMap> {
    const uncached = keys.filter((k) => !this.memoryCache.has(k));
    if (uncached.length === 0) {
      return Object.fromEntries(keys.map((k) => [k, this.memoryCache.get(k)!]));
    }

    const headers = await this.buildHeaders();

    let response: Response;
    try {
      response = await fetch(`${this.baseUrl}/v1/terminology/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...headers },
        body: JSON.stringify({ keys: uncached, locale: this.locale }),
      });
    } catch (err) {
      // Network failure: degrade to raw keys rather than breaking the UI (G16 mirrored client-side).
      return Object.fromEntries(keys.map((k) => [k, this.memoryCache.get(k) ?? k]));
    }

    if (!response.ok) {
      return Object.fromEntries(keys.map((k) => [k, this.memoryCache.get(k) ?? k]));
    }

    const resolved = (await response.json()) as TerminologyMap;
    for (const [k, v] of Object.entries(resolved)) this.memoryCache.set(k, v);

    return Object.fromEntries(keys.map((k) => [k, this.memoryCache.get(k) ?? k]));
  }

  /** Returns the currently-cached snapshot without triggering a network call. */
  getSnapshot(): TerminologyMap {
    return Object.fromEntries(this.memoryCache.entries());
  }

  private async buildHeaders(): Promise<Record<string, string>> {
    if (!this.getAuthHeaders) return {};
    return this.getAuthHeaders();
  }
}

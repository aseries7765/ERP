import { useContext } from 'react';
import { TerminologyContext } from './TerminologyProvider';
import type { TerminologyContextValue } from '../types';

/**
 * const { t, loading } = useTerminology();
 * const label = t('erp.crm.customer.label');
 * const welcome = t('welcome.message', { name: 'Ahmed' });
 *
 * Must be used within a <TerminologyProvider>.
 */
export function useTerminology(): TerminologyContextValue {
  const ctx = useContext(TerminologyContext);
  if (!ctx) {
    throw new Error('useTerminology() must be used within a <TerminologyProvider>.');
  }
  return ctx;
}

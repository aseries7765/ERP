import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { TerminologyProvider } from '../TerminologyProvider';
import { T } from '../../components/T';
import { useTerminology } from '../use-terminology';

describe('TerminologyProvider / useTerminology / <T />', () => {
  beforeEach(() => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ 'erp.crm.customer.label': 'Patient' }),
    });
  });

  it('throws a clear error when useTerminology is used outside a provider', () => {
    const Broken = () => {
      useTerminology();
      return null;
    };
    // Suppress React's expected error boundary console noise for this case.
    const spy = jest.spyOn(console, 'error').mockImplementation(() => {});
    expect(() => render(<Broken />)).toThrow(/must be used within a <TerminologyProvider>/);
    spy.mockRestore();
  });

  it('preloads keys on mount and renders resolved values via <T />', async () => {
    render(
      <TerminologyProvider baseUrl="https://api.example.com" preloadKeys={['erp.crm.customer.label']}>
        <T k="erp.crm.customer.label" />
      </TerminologyProvider>,
    );

    await waitFor(() => expect(screen.getByText('Patient')).toBeInTheDocument());
  });

  it('renders the fallback while loading, before the preload resolves', () => {
    render(
      <TerminologyProvider baseUrl="https://api.example.com" preloadKeys={['erp.crm.customer.label']}>
        <T k="erp.crm.customer.label" fallback="Loading..." />
      </TerminologyProvider>,
    );

    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('interpolates params passed to t()', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: async () => ({ 'welcome.message': 'Welcome, {name}' }),
    });

    const Consumer = () => {
      const { t, loading } = useTerminology();
      if (loading) return null;
      return <span>{t('welcome.message', { name: 'Ahmed' })}</span>;
    };

    render(
      <TerminologyProvider baseUrl="https://api.example.com" preloadKeys={['welcome.message']}>
        <Consumer />
      </TerminologyProvider>,
    );

    await waitFor(() => expect(screen.getByText('Welcome, Ahmed')).toBeInTheDocument());
  });
});

import { TerminologyClient } from '../terminology-client';

describe('TerminologyClient', () => {
  beforeEach(() => {
    global.fetch = jest.fn();
  });

  it('resolveBatch posts uncached keys and merges the response into the memory cache', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: async () => ({ 'erp.crm.customer.label': 'Patient' }),
    });

    const client = new TerminologyClient({ baseUrl: 'https://api.example.com', locale: 'en' });
    const result = await client.resolveBatch(['erp.crm.customer.label']);

    expect(result['erp.crm.customer.label']).toBe('Patient');
    expect(global.fetch).toHaveBeenCalledWith(
      'https://api.example.com/v1/terminology/resolve',
      expect.objectContaining({ method: 'POST' }),
    );
  });

  it('does not re-fetch keys already in the memory cache', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: async () => ({ 'erp.crm.customer.label': 'Patient' }),
    });

    const client = new TerminologyClient({ baseUrl: 'https://api.example.com' });
    await client.resolveBatch(['erp.crm.customer.label']);
    await client.resolveBatch(['erp.crm.customer.label']);

    expect(global.fetch).toHaveBeenCalledTimes(1);
  });

  it('degrades to raw keys on network failure, never throws', async () => {
    (global.fetch as jest.Mock).mockRejectedValue(new Error('offline'));

    const client = new TerminologyClient({ baseUrl: 'https://api.example.com' });
    const result = await client.resolveBatch(['erp.crm.customer.label']);

    expect(result['erp.crm.customer.label']).toBe('erp.crm.customer.label');
  });

  it('degrades to raw keys on a non-ok response', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({ ok: false, json: async () => ({}) });

    const client = new TerminologyClient({ baseUrl: 'https://api.example.com' });
    const result = await client.resolveBatch(['erp.crm.customer.label']);

    expect(result['erp.crm.customer.label']).toBe('erp.crm.customer.label');
  });
});

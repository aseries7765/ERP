import React from 'react';
import { useTerminology } from '../client/use-terminology';

export interface TProps {
  /** The terminology key to resolve, e.g. "erp.crm.customer.label". */
  k: string;
  /** Optional interpolation params, e.g. {{ name: 'Ahmed' }} for "Welcome, {name}". */
  params?: Record<string, string | number>;
  /** Fallback text to render while the surrounding provider is still loading. */
  fallback?: string;
}

/**
 * <T k="erp.crm.customer.label" />  renders: "Patient" (or "Customer", etc.
 * depending on tenant overrides / installed pack — resolution is invisible
 * to the caller).
 */
export function T({ k, params, fallback }: TProps): JSX.Element {
  const { t, loading } = useTerminology();
  if (loading && fallback !== undefined) return <>{fallback}</>;
  return <>{t(k, params)}</>;
}

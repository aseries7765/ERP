import React from 'react';
import { T, TProps } from './T';

/**
 * Same as <T /> but requires `params`, useful when a lint rule wants to
 * enforce that interpolated keys are always called with their params
 * explicitly (catches "welcome.message" being used with no {name} at
 * review time rather than silently rendering "Welcome, {name}").
 */
export function TWithParams(props: Required<Pick<TProps, 'params'>> & Omit<TProps, 'params'>): JSX.Element {
  return <T {...props} />;
}

import { resolveServer, ResolveServerOptions } from './resolve-server';
import type { TerminologyMap } from '../types';

/**
 * Convenience wrapper for preloading a whole screen's terminology keys
 * server-side, returning a map suitable for hydrating a client
 * <TerminologyProvider> without a second network round trip
 * (e.g. pass as `initialMap` prop if extending the provider for SSR hydration).
 */
export async function preloadScreen(
  screenKeys: string[],
  tenantId: string,
  locale: string,
  options: ResolveServerOptions,
): Promise<TerminologyMap> {
  return resolveServer(screenKeys, tenantId, locale, options);
}

import type { TerminologyMap } from '../types';

export interface ResolveServerOptions {
  baseUrl: string;
  /** Server-side auth: typically forwards the incoming request's cookies/headers. */
  authHeaders?: Record<string, string>;
}

/**
 * const labels = await resolveServer(keys, tenant, locale);
 *
 * Used in SSR contexts (e.g. Next.js getServerSideProps / RSC) to resolve a
 * known set of keys server-side before render, avoiding a client-side
 * loading flash. Calls the same POST /v1/terminology/resolve batch endpoint
 * as the client — server-side and client-side resolution always agree
 * because they hit the same resolution engine.
 */
export async function resolveServer(
  keys: string[],
  tenantId: string,
  locale: string,
  options: ResolveServerOptions,
): Promise<TerminologyMap> {
  if (keys.length === 0) return {};

  try {
    const response = await fetch(`${options.baseUrl.replace(/\/$/, '')}/v1/terminology/resolve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Tenant-Id': tenantId,
        ...(options.authHeaders ?? {}),
      },
      body: JSON.stringify({ keys, locale }),
    });

    if (!response.ok) {
      return Object.fromEntries(keys.map((k) => [k, k]));
    }
    return (await response.json()) as TerminologyMap;
  } catch {
    // SSR must never crash a page render because terminology resolution failed.
    return Object.fromEntries(keys.map((k) => [k, k]));
  }
}

import { resolveServer } from '../resolve-server';

describe('resolveServer', () => {
  beforeEach(() => {
    global.fetch = jest.fn();
  });

  it('returns an empty object for an empty key list without calling fetch', async () => {
    const result = await resolveServer([], 'tenant-A', 'en', { baseUrl: 'https://api.example.com' });
    expect(result).toEqual({});
    expect(global.fetch).not.toHaveBeenCalled();
  });

  it('posts keys, tenant header, and locale, returning the resolved map', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: async () => ({ 'erp.crm.customer.label': 'Patient' }),
    });

    const result = await resolveServer(['erp.crm.customer.label'], 'tenant-A', 'en', {
      baseUrl: 'https://api.example.com',
    });

    expect(result['erp.crm.customer.label']).toBe('Patient');
    expect(global.fetch).toHaveBeenCalledWith(
      'https://api.example.com/v1/terminology/resolve',
      expect.objectContaining({
        method: 'POST',
        headers: expect.objectContaining({ 'X-Tenant-Id': 'tenant-A' }),
      }),
    );
  });

  it('never throws on network failure — falls back to raw keys', async () => {
    (global.fetch as jest.Mock).mockRejectedValue(new Error('DNS failure'));

    const result = await resolveServer(['erp.crm.customer.label'], 'tenant-A', 'en', {
      baseUrl: 'https://api.example.com',
    });

    expect(result['erp.crm.customer.label']).toBe('erp.crm.customer.label');
  });
});

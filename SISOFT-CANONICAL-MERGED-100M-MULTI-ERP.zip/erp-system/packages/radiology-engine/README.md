# @erp/radiology-engine

Pure, framework-free domain logic for radiology operations: modality
registry, contrast contraindication checking, report template rendering,
basic prep instructions, and a DICOM UID stub.

No I/O, no database, no NestJS dependency — called from the
(not-yet-built) `his-radiology` module's services.

## What's implemented

- `modality.ts` — registry of X-ray, CT, MRI, US, Mammography, Fluoroscopy,
  Nuclear Medicine with radiation/contrast-use flags.
- `contrast.ts` — allergy history, eGFR-based renal thresholds (hard
  contraindication <30, caution 30-45), pregnancy + gadolinium, and
  metformin + iodinated-contrast warnings. Thresholds follow commonly
  cited practice — confirm against local department policy before
  production use.
- `report-template.ts` — per-modality/body-part section templates, blank
  skeleton rendering, and content-filled rendering.
- `prep-instructions.ts` — a small starter table of prep instructions for
  a few modality/body-part combinations, with a generic fallback.
- `dicom-uid.ts` — **explicit stub**, exactly as the HIS-2 brief specifies
  ("DICOM stub for HIS-3"). Generates syntactically-shaped but
  non-registered UIDs for internal referential integrity only.

## What's NOT implemented here (see root MANIFEST.md)

- Real DICOM/PACS integration (out of scope for HIS-2 by design).
- Scheduling/room/radiologist availability logic.
- Critical-finding alert escalation, teleradiology routing.
- Persistence, HTTP controllers, NestJS module, Prisma schema, events,
  seed data (report templates, modality registry persistence), frontend.

## Usage

```ts
import { checkContrastSafety, renderReport } from '@erp/radiology-engine';

const safety = checkContrastSafety({ hasContrastAllergyHistory: false, contrastType: 'IODINATED', egfrMlMin: 55 });
const report = renderReport(template, { Findings: '...', Impression: '...' });
```

## Test

```
pnpm --filter @erp/radiology-engine test
```

Runs `tsx --test src/__tests__/*.spec.ts` — 24 unit tests, no DB required.

Measured coverage (`npx tsx --test --experimental-test-coverage src/__tests__/*.spec.ts`): 100.00% line / 92.09% branch / 94.59% function.

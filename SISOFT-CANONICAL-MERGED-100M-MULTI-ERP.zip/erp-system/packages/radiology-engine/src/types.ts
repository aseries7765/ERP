/** Registered imaging modality code. */
export type Modality = 'XR' | 'CT' | 'MRI' | 'US' | 'MAMMO' | 'FLUORO' | 'NM';

/** Registry entry describing a modality's radiation and contrast characteristics. */
export interface ModalityDefinition {
  code: Modality;
  name: string;
  usesIonizingRadiation: boolean;
  typicalContrastUse: boolean;
}

/** Patient factors needed to check contrast administration safety. */
export interface ContrastCheckInput {
  hasContrastAllergyHistory: boolean;
  egfrMlMin?: number;
  isPregnant?: boolean;
  isOnMetformin?: boolean;
  contrastType: 'IODINATED' | 'GADOLINIUM' | 'BARIUM' | 'NONE';
}

/** A structured report template for a modality/body-part combination. */
export interface ReportTemplate {
  modality: Modality;
  bodyPart: string;
  sections: string[]; // e.g. ["Clinical History", "Technique", "Findings", "Impression"]
}

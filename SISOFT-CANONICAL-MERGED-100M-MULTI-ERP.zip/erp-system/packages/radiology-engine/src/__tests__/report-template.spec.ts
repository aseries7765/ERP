import { test } from 'node:test';
import assert from 'node:assert/strict';
import { findTemplate, renderTemplateSkeleton, renderReport, NoTemplateError } from '../report-template';
import { ReportTemplate } from '../types';

const templates: ReportTemplate[] = [
  { modality: 'CT', bodyPart: 'CHEST', sections: ['Clinical History', 'Technique', 'Findings', 'Impression'] },
];

test('finds a template by modality and body part', () => {
  const t = findTemplate(templates, 'CT', 'CHEST');
  assert.equal(t.sections.length, 4);
});

test('throws when no template matches', () => {
  assert.throws(() => findTemplate(templates, 'MRI', 'BRAIN'), NoTemplateError);
});

test('renders a blank skeleton with all section headers', () => {
  const t = findTemplate(templates, 'CT', 'CHEST');
  const skeleton = renderTemplateSkeleton(t);
  for (const section of t.sections) {
    assert.ok(skeleton.includes(section));
  }
});

test('renders a filled report with provided content, blank for missing sections', () => {
  const t = findTemplate(templates, 'CT', 'CHEST');
  const report = renderReport(t, { Findings: 'No acute abnormality.', Impression: 'Normal chest CT.' });
  assert.ok(report.includes('No acute abnormality.'));
  assert.ok(report.includes('Normal chest CT.'));
  assert.ok(report.includes('## Clinical History'));
});

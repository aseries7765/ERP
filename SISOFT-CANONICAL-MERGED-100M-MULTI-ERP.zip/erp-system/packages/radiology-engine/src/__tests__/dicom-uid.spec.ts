import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateStudyInstanceUid, generateSeriesInstanceUid, isPlaceholderUid } from '../dicom-uid';

test('generates unique study instance UIDs', () => {
  const uid1 = generateStudyInstanceUid();
  const uid2 = generateStudyInstanceUid();
  assert.notEqual(uid1, uid2);
});

test('generated UIDs are flagged as placeholder, not a real registered root', () => {
  const uid = generateStudyInstanceUid();
  assert.equal(isPlaceholderUid(uid), true);
});

test('series UID is derived from its parent study UID', () => {
  const studyUid = generateStudyInstanceUid();
  const seriesUid = generateSeriesInstanceUid(studyUid, 1);
  assert.ok(seriesUid.startsWith(studyUid));
  assert.equal(seriesUid, `${studyUid}.1`);
});

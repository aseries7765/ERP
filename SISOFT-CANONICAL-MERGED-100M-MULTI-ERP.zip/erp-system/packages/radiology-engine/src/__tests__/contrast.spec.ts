import { test } from 'node:test';
import assert from 'node:assert/strict';
import { checkContrastSafety } from '../contrast';

test('no contrast is always safe', () => {
  const result = checkContrastSafety({ hasContrastAllergyHistory: true, contrastType: 'NONE' });
  assert.equal(result.safeToAdminister, true);
});

test('flags contrast allergy history as a contraindication', () => {
  const result = checkContrastSafety({ hasContrastAllergyHistory: true, contrastType: 'IODINATED' });
  assert.equal(result.safeToAdminister, false);
  assert.ok(result.contraindications.length > 0);
});

test('flags low eGFR as a hard contraindication', () => {
  const result = checkContrastSafety({
    hasContrastAllergyHistory: false,
    contrastType: 'IODINATED',
    egfrMlMin: 20,
  });
  assert.equal(result.safeToAdminister, false);
});

test('warns (does not block) on borderline eGFR', () => {
  const result = checkContrastSafety({
    hasContrastAllergyHistory: false,
    contrastType: 'IODINATED',
    egfrMlMin: 38,
  });
  assert.equal(result.safeToAdminister, true);
  assert.ok(result.warnings.length > 0);
});

test('flags gadolinium in pregnancy', () => {
  const result = checkContrastSafety({
    hasContrastAllergyHistory: false,
    contrastType: 'GADOLINIUM',
    isPregnant: true,
  });
  assert.equal(result.safeToAdminister, false);
});

test('warns on metformin with iodinated contrast', () => {
  const result = checkContrastSafety({
    hasContrastAllergyHistory: false,
    contrastType: 'IODINATED',
    isOnMetformin: true,
  });
  assert.equal(result.safeToAdminister, true);
  assert.ok(result.warnings.some((w) => w.includes('metformin')));
});

test('a clean patient with normal renal function is safe with no warnings', () => {
  const result = checkContrastSafety({
    hasContrastAllergyHistory: false,
    contrastType: 'IODINATED',
    egfrMlMin: 90,
  });
  assert.equal(result.safeToAdminister, true);
  assert.deepEqual(result.contraindications, []);
  assert.deepEqual(result.warnings, []);
});

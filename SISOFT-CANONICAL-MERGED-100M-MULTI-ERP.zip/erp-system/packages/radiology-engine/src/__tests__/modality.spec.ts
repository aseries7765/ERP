import { test } from 'node:test';
import assert from 'node:assert/strict';
import { isValidModality, getModality, MODALITY_REGISTRY } from '../modality';

test('validates known modality codes', () => {
  assert.equal(isValidModality('CT'), true);
  assert.equal(isValidModality('XYZ'), false);
});

test('registry includes all seven documented modalities', () => {
  const codes = MODALITY_REGISTRY.map((m) => m.code);
  for (const c of ['XR', 'CT', 'MRI', 'US', 'MAMMO', 'FLUORO', 'NM']) {
    assert.ok(codes.includes(c as any), `missing ${c}`);
  }
});

test('CT is flagged as using ionizing radiation and typical contrast use', () => {
  const ct = getModality('CT');
  assert.equal(ct.usesIonizingRadiation, true);
  assert.equal(ct.typicalContrastUse, true);
});

test('ultrasound uses no ionizing radiation', () => {
  assert.equal(getModality('US').usesIonizingRadiation, false);
});

test('getModality throws for unregistered code', () => {
  assert.throws(() => getModality('BOGUS' as any));
});

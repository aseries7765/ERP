import { test } from 'node:test';
import assert from 'node:assert/strict';
import { getPrepInstructions } from '../prep-instructions';

test('returns specific instructions for a matched modality/body-part', () => {
  const instructions = getPrepInstructions('CT', 'ABDOMEN');
  assert.ok(instructions.length > 0);
  assert.ok(instructions.some((i) => i.includes('NPO')));
});

test('body part matching is case-insensitive', () => {
  const instructions = getPrepInstructions('CT', 'abdomen');
  assert.ok(instructions.length > 0);
});

test('falls back to the modality-generic (ANY) entry when no specific match exists', () => {
  const instructions = getPrepInstructions('MRI', 'BRAIN');
  assert.ok(instructions.length > 0);
  assert.ok(instructions.some((i) => i.toLowerCase().includes('metal')));
});

test('returns an empty list when neither a specific nor a generic entry exists', () => {
  const instructions = getPrepInstructions('NM', 'THYROID');
  assert.deepEqual(instructions, []);
});

test('distinguishes body parts within the same modality', () => {
  const abdomen = getPrepInstructions('US', 'ABDOMEN');
  const pelvis = getPrepInstructions('US', 'PELVIS');
  assert.notDeepEqual(abdomen, pelvis);
});

import { Modality, ModalityDefinition } from './types';

/** The fixed set of supported imaging modalities. See ADR 0373 — this is a hardcoded registry, not a seedable/configurable table. */
export const MODALITY_REGISTRY: ModalityDefinition[] = [
  { code: 'XR', name: 'X-ray', usesIonizingRadiation: true, typicalContrastUse: false },
  { code: 'CT', name: 'Computed Tomography', usesIonizingRadiation: true, typicalContrastUse: true },
  { code: 'MRI', name: 'Magnetic Resonance Imaging', usesIonizingRadiation: false, typicalContrastUse: true },
  { code: 'US', name: 'Ultrasound', usesIonizingRadiation: false, typicalContrastUse: false },
  { code: 'MAMMO', name: 'Mammography', usesIonizingRadiation: true, typicalContrastUse: false },
  { code: 'FLUORO', name: 'Fluoroscopy', usesIonizingRadiation: true, typicalContrastUse: true },
  { code: 'NM', name: 'Nuclear Medicine', usesIonizingRadiation: true, typicalContrastUse: false },
];

/** Type-guards a string as a registered Modality code. */
export function isValidModality(code: string): code is Modality {
  return MODALITY_REGISTRY.some((m) => m.code === code);
}

/** Looks up a modality's definition; throws if the code isn't registered. */
export function getModality(code: Modality): ModalityDefinition {
  const m = MODALITY_REGISTRY.find((m) => m.code === code);
  if (!m) throw new Error(`Unknown modality: ${code}`);
  return m;
}

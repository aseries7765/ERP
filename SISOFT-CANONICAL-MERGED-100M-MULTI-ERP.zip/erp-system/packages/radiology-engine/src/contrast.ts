import { ContrastCheckInput } from './types';

/** Outcome of a contrast-safety check: whether it's safe to proceed, and any hard blocks or soft warnings found. */
export interface ContrastCheckResult {
  safeToAdminister: boolean;
  contraindications: string[];
  warnings: string[];
}

/**
 * Checks standard contraindications before contrast administration
 * (allergy history, renal function, pregnancy, metformin interaction with
 * iodinated contrast). Renal thresholds follow commonly cited practice
 * (eGFR < 30 mL/min is a hard contraindication for iodinated/gadolinium
 * contrast without nephrology consult; 30-45 warrants caution) — confirm
 * against local radiology department policy.
 */
export function checkContrastSafety(input: ContrastCheckInput): ContrastCheckResult {
  const contraindications: string[] = [];
  const warnings: string[] = [];

  if (input.contrastType === 'NONE') {
    return { safeToAdminister: true, contraindications, warnings };
  }

  if (input.hasContrastAllergyHistory) {
    contraindications.push(
      'Documented prior contrast allergy — requires premedication protocol or radiologist override before administration.',
    );
  }

  if (
    (input.contrastType === 'IODINATED' || input.contrastType === 'GADOLINIUM') &&
    input.egfrMlMin !== undefined
  ) {
    if (input.egfrMlMin < 30) {
      contraindications.push(
        `eGFR ${input.egfrMlMin} mL/min is below 30 — contrast-induced nephropathy / NSF risk, nephrology consult required.`,
      );
    } else if (input.egfrMlMin < 45) {
      warnings.push(`eGFR ${input.egfrMlMin} mL/min is borderline (30-45) — use lowest effective dose and hydrate.`);
    }
  }

  if (input.isPregnant && input.contrastType === 'GADOLINIUM') {
    contraindications.push('Gadolinium contrast is generally avoided in pregnancy unless benefit clearly outweighs risk.');
  }

  if (input.isOnMetformin && input.contrastType === 'IODINATED') {
    warnings.push('Patient on metformin — hold metformin per protocol around iodinated contrast administration and monitor renal function.');
  }

  return {
    safeToAdminister: contraindications.length === 0,
    contraindications,
    warnings,
  };
}

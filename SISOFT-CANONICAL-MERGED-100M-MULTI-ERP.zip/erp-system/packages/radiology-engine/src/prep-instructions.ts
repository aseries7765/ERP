import { Modality } from './types';

/** Patient preparation instructions for a given modality/body-part combination. */
export interface PrepInstruction {
  modality: Modality;
  bodyPart: string;
  instructions: string[];
}

/**
 * A small starter table of prep instructions covering a few common
 * modality/body-part combinations. This is illustrative, not a complete
 * clinical prep-instruction catalog — see MANIFEST.md.
 */
const PREP_TABLE: PrepInstruction[] = [
  { modality: 'CT', bodyPart: 'ABDOMEN', instructions: ['NPO 4 hours prior', 'Oral contrast 1 hour prior if ordered'] },
  { modality: 'MRI', bodyPart: 'ANY', instructions: ['Remove all metal objects', 'Screen for implants/pacemaker/claustrophobia'] },
  { modality: 'US', bodyPart: 'ABDOMEN', instructions: ['NPO 6-8 hours prior for gallbladder evaluation'] },
  { modality: 'US', bodyPart: 'PELVIS', instructions: ['Full bladder required — drink water, do not void before exam'] },
  { modality: 'FLUORO', bodyPart: 'GI', instructions: ['NPO after midnight', 'Bowel prep per ordering physician'] },
];

/** Looks up prep instructions for a modality/body-part combination, falling back to a modality-generic entry ("ANY") if no specific one exists, else an empty list. */
export function getPrepInstructions(modality: Modality, bodyPart: string): string[] {
  const specific = PREP_TABLE.find((p) => p.modality === modality && p.bodyPart === bodyPart.toUpperCase());
  if (specific) return specific.instructions;
  const generic = PREP_TABLE.find((p) => p.modality === modality && p.bodyPart === 'ANY');
  return generic?.instructions ?? [];
}

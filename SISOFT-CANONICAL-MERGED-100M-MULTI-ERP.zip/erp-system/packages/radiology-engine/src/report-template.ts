import { ReportTemplate, Modality } from './types';

export const DEFAULT_SECTIONS = ['Clinical History', 'Technique', 'Comparison', 'Findings', 'Impression'];

/** Thrown when no report template matches the requested modality/body-part combination. */
export class NoTemplateError extends Error {}

/** Finds the report template for a modality/body-part combination; throws if none is registered. */
export function findTemplate(
  templates: ReportTemplate[],
  modality: Modality,
  bodyPart: string,
): ReportTemplate {
  const t = templates.find((t) => t.modality === modality && t.bodyPart === bodyPart);
  if (!t) {
    throw new NoTemplateError(`No report template for ${modality} / ${bodyPart}`);
  }
  return t;
}

/** Renders an empty structured report skeleton (section headers with blank bodies) ready for the radiologist to fill in. */
export function renderTemplateSkeleton(template: ReportTemplate): string {
  return template.sections.map((section) => `## ${section}\n\n`).join('\n');
}

/** Fills a template's sections with provided content, leaving unspecified sections blank. */
export function renderReport(template: ReportTemplate, content: Record<string, string>): string {
  return template.sections
    .map((section) => `## ${section}\n\n${content[section]?.trim() ?? ''}`)
    .join('\n\n');
}

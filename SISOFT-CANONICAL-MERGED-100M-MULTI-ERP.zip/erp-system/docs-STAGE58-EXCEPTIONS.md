# Stage 58 Exceptions

1. PostgreSQL runtime evidence remains unavailable.
2. Redis/worker runtime evidence remains unavailable.
3. Backup/restore execution remains unavailable.
4. TLS certificate/handshake validation is infrastructure-dependent.
5. Health readiness currently checks memory only; dependency checks remain a later runtime/operations gate.
6. The generic token-bucket limiter remains an in-memory implementation and is not accepted as a distributed production limiter. Redis-backed enforcement must be proven before production release.

These are explicit BLOCKED conditions, not PASS results.

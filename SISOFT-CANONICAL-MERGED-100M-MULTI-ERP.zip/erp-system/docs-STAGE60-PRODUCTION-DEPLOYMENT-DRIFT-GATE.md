# Stage 60 — Production Deployment Artifact and Configuration Drift Gate

## Objective
Create a fail-closed deployment contract so production cannot silently drift from the repository's runtime assumptions.

## Implemented
1. **Container artifacts**
   - API and web images use Node 20 slim and a non-root `app` runtime user.
   - Both images contain Docker healthchecks.
   - API healthcheck targets `/health/live`; readiness remains the orchestrator dependency gate.
   - Dockerfiles now require `pnpm-lock.yaml` explicitly. Optional wildcard lockfile copying was removed because it permits nondeterministic dependency resolution.
2. **Dependency determinism**
   - Root `packageManager` remains pinned to `pnpm@9.12.0`.
   - Frozen-lockfile installation is required by both container build paths.
   - The current repository is **BLOCKED** until the real lockfile is restored/committed.
3. **Configuration and secrets**
   - `deployment/stage60/production.env.contract` enumerates required production configuration and secret-manager supplied values.
   - Secret values are not embedded in the repository.
4. **Migration ordering**
   - Production migrations must run before application readiness.
   - The Stage 60 manifest requires tracked migration history and rejects duplicate migration prefixes.
5. **Rollback**
   - Application rollback is by immutable image.
   - Database recovery is forward-fix or reviewed point-in-time restore; automatic destructive rollback is prohibited.
6. **Drift/runtime gate**
   - `scripts/verify-stage60-deployment.py` performs static contract checks.
   - `scripts/run-stage60-deployment-gate.sh` is fail-closed and requires actual API/web URLs, immutable image digests, migration verification, and rollback verification before printing `STAGE60 RUNTIME PASS`.

## Commands
```bash
pnpm run production:stage60:static
pnpm run production:stage60:runtime
```

The runtime command must only be run against an actual deployment target.

# Stage 21 — Durable Event Outbox

Adds a tenant-scoped `event_outbox` table with unique dedupe keys, retry state, worker claims using `FOR UPDATE SKIP LOCKED`, and a Redis/BullMQ dispatcher.

The dispatcher is idempotent at the queue layer through BullMQ `jobId = outbox.id`. Failed delivery returns the row to RETRY with backoff; successfully acknowledged rows become PUBLISHED.

Important integration boundary: existing RBAC services still call the event emitter after repository mutations. Therefore this stage provides the durable outbox primitive and dispatcher, but does **not** claim atomic coupling between every existing domain mutation and its outbox insert. A future transaction-aware repository/service boundary must place both writes in the same Prisma transaction for strict transactional-outbox guarantees.

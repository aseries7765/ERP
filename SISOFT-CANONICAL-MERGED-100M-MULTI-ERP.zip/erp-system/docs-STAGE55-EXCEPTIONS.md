# Stage 55 Exceptions

- Full API/database runtime verification is not claimed in this workspace.
- PostgreSQL and the generated Prisma runtime are not available locally.
- Dependency installation is still blocked by external package-registry/DNS
  availability, so no fabricated Jest/e2e result is recorded.
- The runtime harness requires explicit caller-supplied disposable fixtures and
  an authenticated token; it will report BLOCKED instead of inventing values.

- Stage 55 identified and corrected an RBAC integration gap: RBAC controllers
  used `PermissionGuard` without explicitly composing `JwtAuthGuard` and
  `TenantGuard`, despite `PermissionGuard` assuming authenticated `req.user`.
  All eight RBAC controllers now use the explicit three-guard chain and
  `RbacModule` imports `AuthModule` for provider resolution.

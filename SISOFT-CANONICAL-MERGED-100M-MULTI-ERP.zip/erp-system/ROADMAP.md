# Roadmap — Stage 43

## Completed

- Stage 43: Migration Baseline Candidate Review
  - classified all 119 untracked schema tables
  - identified 21 foundation review candidates
  - produced deterministic JSON/CSV manifests
  - explicitly avoided fabricated historical migration claims

## Next

### Stage 44 — Executable Foundation Baseline Design

Reconcile the 21 foundation candidates and their dependencies into a minimal safe executable baseline design, including enums, constraints, indexes, relation actions, defaults, RLS/triggers, and migration conventions. Only after this review should SQL generation be attempted.

### Runtime Gate

Pinned Prisma CLI and PostgreSQL must be available before migration execution can be declared PASS.

### Stage 44 — Foundation Baseline Design

Completed deterministic schema-derived foundation baseline design for 21 candidates, including constraints, enums, explicit FK dependencies, and dependency order. Runtime SQL generation/execution remains gated on available Prisma CLI and PostgreSQL.



## Stage 45 — Database Feature Reconciliation
- Reconciled UUIDv7, trigger-function, and RLS/policy database features.
- Confirmed infrastructure provenance gaps without fabricating SQL.
- Next: authoritative database infrastructure resolution and runtime-generated baseline.


## Stage 46 — Database Infrastructure Resolution

Completed the authoritative database-function contract and schema-derived trigger manifest. Runtime Prisma migration generation remains a required external execution gate.

## Stage 47 — Prisma Baseline Generation Gate

Completed a guarded, reproducible path for generating the authoritative Prisma baseline from an empty schema. Added a static preflight, explicit `migrate diff --from-empty` generator, and removed the root seed command's failure-swallowing fallback. No migration history was rewritten and no generated SQL was fabricated.


## Stage 48 — Prisma/PostgreSQL Runtime Gate

Stage 48 adds the executable runtime gate and static reconciliation for the 193-model Prisma schema, UUIDv7 bootstrap, optimistic-lock trigger registry, and post-table application-role grants. Runtime database generation/application remains blocked until Prisma 5.20.0 dependencies and a disposable PostgreSQL environment are available.

## Stage 50 — Database Schema / Raw-SQL Deep Consistency Gate (2026-09-18)

Completed static reconciliation between the 193-model Prisma schema and authoritative RLS/trigger/grant infrastructure. Verified 183 tenant-scoped tables, 103 mutable trigger tables, tenant access paths, tenant-scoped uniqueness, RLS helper/policy contracts, audit append-only enforcement, and raw-SQL function qualification. Added the missing tenant index on `vulnerabilities.tenantId` and removed a stale partial-index comment. Runtime PostgreSQL catalog verification remains blocked until a disposable PostgreSQL 16/17 instance and pinned Prisma 5.20.0 dependencies are available.

## Stage 51 — Clean-Database Migration Rehearsal Gate

Added a guarded rehearsal/preflight for clean PostgreSQL validation. The gate
protects migration history, requires an explicit disposable-database marker,
and separates static verification from destructive runtime operations.

## Stage 52 — Clean Database Runtime Execution Harness
- Added a destructive-operation-gated runtime harness for a disposable PostgreSQL database.
- Generates the authoritative Prisma baseline without rewriting migration history.
- Applies UUID bootstrap, baseline, RLS/triggers, and grants, then proves schema equivalence with Prisma diff.
- Captures read-only catalog evidence, invariant checks, and SHA-256 evidence manifest.
- Runtime remains blocked until PostgreSQL/psql and Prisma 5.20.0 are available.

## Stage 53 — Post-Runtime Schema/Policy Evidence and Application Smoke Tests
- Added gated runtime smoke suite for tenant isolation, fail-closed context, optimistic-lock trigger behavior, audit append-only enforcement, and app-role privileges.
- Added static contract verification and retained-evidence workflow.
- Runtime remains explicitly blocked until a disposable PostgreSQL environment is available.

## Stage 54 — Runtime Evidence Consolidation and Defect Gate (2026-09-18)
- Added a read-only evidence verifier for Stage 52/53 runtime artifacts.
- Requires explicit runtime PASS records, expected 193-table invariant, privilege safety, and valid SHA-256 manifests.
- Missing runtime evidence remains BLOCKED; no runtime success is inferred.

## Stage 55 — End-to-End Application Integration Gate
Validate representative API/database workflows against the runtime-proven schema and security boundary.

## Stage 55 — End-to-End Application Integration Gate
- Added static application integration contracts for representative Sales, Finance, and RBAC routes.
- Enforced verification of JWT-derived tenant context, permission guarding, transaction-local database tenant context, and atomic RBAC mutation boundaries.
- Added a guarded runtime API harness that reports BLOCKED unless a real disposable environment, authenticated token, and real fixture IDs are supplied.
- No fabricated runtime PASS; current runtime status remains environment-blocked.

## Stage 56 — Runtime API Mutation and Rollback Evidence
- Extend Stage 55 with disposable authenticated mutations, tenant isolation probes, permission denial, optimistic concurrency, outbox/audit atomicity, and rollback evidence.
- Runtime PASS requires actual execution against the disposable API/database environment.

## Stage 56 — Runtime API Mutation and Rollback Evidence
- Added a guarded runtime mutation harness for tenant isolation, permission denial, optimistic concurrency, and transactional rollback probes.
- Added static contracts covering tenant-scoped Sales/Finance mutations, Finance optimistic version checks, RBAC atomic mutation/outbox behavior, JWT-derived tenant context, and audit infrastructure.
- Runtime remains explicitly BLOCKED until a real disposable API/PostgreSQL environment and purpose-built fixtures are supplied.
- Documented that asynchronous Sales/Finance audit queue submission is not claimed to be transactionally coupled to the business mutation.

## Stage 57 — Runtime Evidence Reconciliation and Release Gate
- Reconcile Stage 56 runtime artifacts with prior schema/policy evidence and produce one release gate.
- Missing, stale, invalid, or failed runtime evidence remains BLOCKED.


## Stage 57 — Runtime Evidence Reconciliation and Release Gate
- Added an independent read-only release gate for Stage 52/53/56 runtime evidence.
- Recomputes SHA-256 evidence manifests and validates explicit runtime PASS records, 193-table schema invariants, audit privilege safety, and required mutation probe artifacts.
- Missing runtime evidence remains BLOCKED; static verification never implies release PASS.

## Stage 58 — Release-Readiness Defect Closure and Production Configuration Gate
- Next: close evidence-backed runtime defects and validate production configuration/security/operations contracts without fabricating unavailable environment results.

## Stage 58 — Release-Readiness Defect Closure and Production Configuration Gate
- Closed the production `APP_DATABASE_URL` fail-open risk by refusing migration-role fallback in production.
- Activated existing auth and tenancy boot validators in the root ConfigModule.
- Added a static production configuration/security contract gate and an explicitly guarded runtime gate.
- Production runtime remains BLOCKED until real PostgreSQL, Redis/workers, backup/restore, TLS, and observability infrastructure is available.

## Stage 59 — Operational Runtime Readiness Matrix and Dependency Health Gate
- Next: unify operational dependency checks and runtime evidence into one executable readiness matrix.


## Stage 60 — Production Deployment Artifact and Configuration Drift Gate
- deterministic API/web container contracts
- mandatory lockfile/frozen dependency installation
- production secret/configuration contract
- migration ordering before readiness
- health probes and immutable image digest requirements
- fail-closed rollback verification
- static PASS/BLOCKED distinction and guarded runtime gate

## Stage 61 — Production Rollback and Disaster-Recovery Evidence Gate
- backup/restore and point-in-time recovery evidence
- immutable application rollback
- migration compatibility during rollback/recovery
- tenant/RLS verification after restore
- recovery evidence retention

## Stage 61 — Production Rollback and Disaster Recovery Evidence Gate
- encrypted/offsite backup and retention contract
- isolated restore and explicit PITR verification
- immutable application rollback
- migration compatibility without destructive automatic rollback
- post-restore tenant/RLS isolation verification
- SHA-256 recovery evidence retention
- runtime remains BLOCKED until actual recovery infrastructure and evidence are supplied

## Stage 62 — Production Observability, SLO and Incident-Evidence Gate
- structured logs, metrics and traces
- SLI/SLO and alert contracts
- correlation IDs and incident timeline evidence
- telemetry retention and fail-closed runtime verification

## Stage 63 — Distributed Rate Limiting, Backpressure and Capacity-Evidence Gate
- distributed (Redis-backed) rate limiting across instances, not process-local counters
- concurrency limits, queue backpressure, tenant fairness
- fail-closed for protected mutation/auth classes when the limiter dependency is unavailable
- 429 response contract with safe retry hint

## Stage 64 — Capacity Planning, Autoscaling and Multi-Region Readiness Gate
- explicit architecture rule: 100M+ remains an architectural target, not a claimed benchmark; capacity is proven only by reproducible measurement
- workload classes (interactive reads/writes, async work, heavy reports, auth) with distinct scaling/degradation behavior
- autoscaling signals, dependency budgets, graceful degradation, failover evidence requirements

## Stage 65 — Data Partitioning, Shard Routing and Tenant Placement Integrity
- immutable tenant ID as routing identity; control-plane-owned, versioned, audited placement map
- unknown/conflicting mappings fail closed rather than defaulting
- explicit migration (copy-verify-cutover), rebalancing and cross-shard query policy
- explicitly an architectural/static integrity gate — does not claim a multi-shard deployment has been executed

## Stage 66 — Cross-Shard Transaction, Distributed Consistency and Idempotency Integrity Gate
- single-shard-by-default request boundary; cross-shard workflows use a durable saga/state machine, not a fake distributed transaction
- compensation is a business operation (itself idempotent), not a DB rollback
- idempotency identity required for every externally retryable mutation/consumer/workflow step/provider call

## Stage 67 — Global Control Plane, Tenant Lifecycle and Cross-Region Placement Integrity Gate
- provider-neutral control plane owning tenant identity/lifecycle/placement/plan/quota — never tenant business data
- explicit lifecycle: PENDING -> PROVISIONING -> ACTIVE -> SUSPENDED -> MIGRATING -> ACTIVE -> DEPROVISIONING -> DEPROVISIONED, with recoverable ERROR
- control-plane commands must carry authenticated tenant context and cannot bypass data-plane RLS/authz/shard routing

## Stage 68 — Global Identity, Authentication Federation and Control-Plane Authorization Integrity Gate
- authentication proves identity; authorization separately proves what that identity may do, per tenant/resource/placement
- OIDC (issuer allowlist, nonce/state, signature, audience, expiry) and SAML (trusted issuer, signed assertions, replay protection) federation contracts
- tenant admin cannot elevate to global operator by changing claims/headers; user/tenant/service/provider identity kept separate

## Stage 69 — Global Authorization Policy Distribution & Consistency Integrity Gate
- control plane is the sole authoritative policy source; every bundle has an immutable version + SHA-256 hash
- atomic regional activation with integrity/signature verification before activation; missing/corrupt bundles rejected, never partially activated
- every authorization decision records the policy version used; security-critical paths fail closed on staleness

## Stage 70 — Global Configuration, Feature Flags & Runtime Policy Consistency Integrity Gate
- control plane is sole publication authority; runtime nodes consume immutable signed bundles; no runtime-local mutation except documented ephemeral state
- versioned/hashed/signed bundles, atomic activation (prior-good or new-valid, never a partial mixture)
- scope precedence (global/environment/region/tenant/service) cannot bypass security invariants, tenant isolation, authorization or placement
- secret values are never embedded in config bundles, only references to an approved secret manager

## Stage 71 — Global Secrets, Key Management & Cryptographic Trust Integrity Gate
- approved secret manager is the sole authoritative secret source; no plaintext secrets in source, config, tenant data, logs or deployment artifacts
- separate key identities/rotation domains per cryptographic purpose; envelope encryption for persistent sensitive data
- versioned key rotation with overlap period for signing keys; unknown/revoked keys fail closed for security-sensitive operations

Stages 63-71 are, like every stage from 41 onward, static/architectural integrity gates with explicit BLOCKED runtime status until real distributed infrastructure (Redis cluster, multi-region deployment, real secret manager, etc.) is available to verify against. None of them claim a runtime PASS, and this merge does not upgrade any of them to one.

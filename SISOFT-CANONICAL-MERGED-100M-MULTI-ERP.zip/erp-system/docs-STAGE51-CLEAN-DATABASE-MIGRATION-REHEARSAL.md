# Stage 51 — Clean-Database Migration Rehearsal + Differential Verification

## Purpose

Establish a deterministic gate for the first real PostgreSQL rehearsal without
silently resetting or modifying an existing database.

## Required order

1. Create an explicitly disposable PostgreSQL database.
2. Install/validate Prisma 5.20.0.
3. Apply `prisma/raw-sql/01-uuid-v7-function.sql`.
4. Generate the candidate schema SQL with `prisma migrate diff --from-empty`.
5. Apply the reviewed candidate baseline to the disposable database.
6. Apply reviewed RLS/triggers from `02-rls-and-triggers.sql`.
7. Apply app-role grants from `03-app-role-grants.sql`.
8. Run the Stage 50 read-only catalog report.
9. Compare the live catalog against Prisma and Stage 49/46 manifests.
10. Only after the clean-schema differential is zero-diff should feature migration
    history be evaluated for safe replay.

## Safety

The Stage 51 runtime preflight requires both `STAGE51_ALLOW_RUNTIME=1` and
`STAGE51_DISPOSABLE_DB=1`. The script does not infer that a database is safe to
reset from its name, hostname, or URL.

No destructive reset is performed by the preflight. Any database reset must be
an explicit operator action against a known disposable database.

## Current environment

At implementation time PostgreSQL/`psql` and the installed Prisma CLI are not
available in the execution environment. Therefore this stage provides the
rehearsal gate and evidence structure but does **not** claim a runtime PASS.

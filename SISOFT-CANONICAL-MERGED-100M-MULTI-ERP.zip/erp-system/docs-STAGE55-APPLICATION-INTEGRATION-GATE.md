# Stage 55 — End-to-End Application Integration Gate

## Purpose

Stage 55 establishes a reproducible gate between the application layer and the
runtime database work from Stages 52–54. It does **not** claim runtime success
when PostgreSQL, the API, credentials, or disposable fixtures are unavailable.

## Static contract

The gate covers three representative application paths:

- Sales quote read path
- Finance account/ledger read path
- RBAC role read path

For each representative controller, the static gate requires JWT authentication,
tenant establishment, and explicit permission metadata. It also verifies that:

1. `TenantGuard` derives tenant/user context from verified JWT claims rather than
   a client-supplied tenant header.
2. `PrismaService.withTenant()` establishes `app.current_tenant` inside the
   database transaction using parameterized `set_config(..., true)`.
3. RBAC mutations use the atomic mutation boundary rather than publishing an
   event independently of the database mutation.
4. Stage 54's real-runtime-evidence gate remains a prerequisite for runtime
   database PASS.

## Runtime gate

`scripts/run-stage55-runtime.sh` is deliberately guarded by:

- `STAGE55_ALLOW_RUNTIME=1`
- `STAGE55_DISPOSABLE_DB=1`
- a live API
- `STAGE55_BEARER_TOKEN`
- real disposable-fixture IDs for sales, finance, and RBAC

It performs only authenticated read probes after health verification. It never
creates or assumes fake fixtures and never converts a missing environment into
PASS.

The script exits `2` with **BLOCKED** when prerequisites are absent and exits
`1` with **FAIL** when an actual runtime assertion fails.

## Current verification status

Static verification is executable in the current workspace. Full runtime
verification remains environment-dependent until PostgreSQL, the API runtime,
and disposable test fixtures are available.

## Security integration correction

The RBAC controllers previously relied on an undocumented assumption that an
upstream authentication guard would already have populated `req.user`. The
application has no global `APP_GUARD` establishing that guarantee. Stage 55
therefore makes the boundary explicit on all eight RBAC controllers:

`JwtAuthGuard -> TenantGuard -> PermissionGuard`

`AuthModule` is imported by `RbacModule` so these guards are resolved through
Nest's module dependency graph. This closes the gap between the RBAC permission
check and the actual authentication/tenant establishment boundary.

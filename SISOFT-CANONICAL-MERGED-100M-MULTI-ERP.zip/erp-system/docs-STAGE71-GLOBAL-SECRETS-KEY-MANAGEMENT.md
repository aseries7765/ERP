# Stage 71 — Global Secrets, Key Management & Cryptographic Trust Integrity Gate

## Objective
Establish a provider-neutral cryptographic trust contract for the Sisoft control plane and regional data planes without placing secret or key material in application source, ordinary configuration, tenant data, logs, or deployment artifacts.

## Secret authority
The authoritative source for application secrets is an approved secret manager. Applications receive only the minimum secret material required for a bounded operation. References, versions, leases, and access decisions are auditable; plaintext secret values are never committed to source control or configuration bundles.

## Key hierarchy and purpose separation
Encryption, signing, authentication-token signing, and other cryptographic purposes use separate key identities and rotation domains. Persistent sensitive data uses envelope encryption: a data-encryption key protects bounded data, while a key-encryption key is managed by the approved cryptographic provider. Provider-managed/HSM-backed root material is not exported to application code.

## Rotation and revocation
Key rotation is versioned and requires verification before activation. Signing-key rotation supports an overlap period so existing valid tokens can be validated while new tokens use the new key. Retirement occurs only after active dependencies are absent. Emergency revocation invalidates compromised versions and forces reconciliation; unknown or revoked keys fail closed for security-sensitive operations.

## Regional placement
Key availability follows tenant placement but never silently changes cryptographic identity. Cross-region access requires explicit authorization and policy. A regional outage must not cause unsafe substitution with an unrelated key. Recovery must preserve key version, purpose, tenant boundary and audit continuity.

## Certificates
Certificate issuance, renewal, expiry monitoring, trust-chain validation and private-key protection are lifecycle responsibilities. Renewal occurs before expiry with a controlled overlap where required. Private key material and secret values are prohibited from application logs, telemetry, error messages and diagnostic dumps.

## Compromise response
A suspected key compromise follows: identify affected version → fence/revoke → activate verified replacement → rotate dependent credentials/tokens where required → reconcile regional consumers → verify cryptographic access → preserve an auditable incident trail. Emergency access is scoped, time-bounded and independently auditable.

## Provider neutrality
Secret-manager, KMS/HSM, certificate-authority and cloud-specific implementations are adapters behind stable Sisoft interfaces. Business modules do not depend directly on one provider's SDK or key naming convention.

## Runtime evidence
Runtime PASS requires real secret-manager/KMS/HSM/certificate infrastructure and evidence for fetch authorization, envelope encryption/decryption, signing-key overlap rotation, revocation/fail-closed behavior, regional recovery and compromise reconciliation. Static contracts are not runtime proof.

# Stage 32 — Payroll Country Plugins

Implemented the missing `@erp/payroll-country-plugins` workspace package from concrete Sisoft payroll consumers and tests.

## Supported plugins
- PK — FULL in the existing project scope: salaried tax calculation, EOBI, labor-law basics and gratuity.
- SA — FULL in the existing project scope: zero income tax, GOSI, labor-law basics and EOSG.
- IN — PARTIAL: new-regime tax, EPF/ESI; old regime and state-specific professional tax remain explicit gaps.
- US — PARTIAL: simplified federal single-filer calculation; state/local/FICA are explicit gaps.

## Safety contract
Partial implementations return `approximate: true` where the modeled scope is not statutory-complete. Unsupported rules are documented rather than silently substituted.

## Verification
- Package TypeScript no-emit check: PASS
- Package TypeScript build: PASS
- Node 22 self-test: PASS
- Existing payroll consumer import shapes: structurally satisfied
- Full monorepo/Jest/PostgreSQL/Redis runtime verification: pending environment availability

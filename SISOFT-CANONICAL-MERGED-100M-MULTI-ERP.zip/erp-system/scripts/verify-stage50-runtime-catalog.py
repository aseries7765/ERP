#!/usr/bin/env python3
"""Stage 50 static/runtime-catalog gate.

Static mode validates that the live-catalog SQL is parameterized and that the
expected catalog dimensions are covered. Runtime mode is intentionally opt-in
and requires psql + DATABASE_URL + STAGE50_ALLOW_RUNTIME=1.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent.parent
SCHEMA = (ROOT / 'prisma/schema.prisma').read_text(encoding='utf-8')
CATALOG = (ROOT / 'prisma/raw-sql/04-runtime-catalog-gate.sql').read_text(encoding='utf-8')

models = re.findall(r'^model\s+(\w+)\s*\{(.*?)^\}', SCHEMA, re.M | re.S)
assert len(models) == len({n for n, _ in models})
assert len(models) == 193, f'unexpected model count: {len(models)}'

for marker in [
    'information_schema.tables',
    'information_schema.columns',
    'pg_catalog.pg_constraint',
    'pg_catalog.pg_index',
    'pg_catalog.pg_policies',
    'pg_catalog.pg_trigger',
    'pg_catalog.pg_proc',
    'pg_catalog.pg_roles',
]:
    assert marker in CATALOG, f'missing catalog coverage: {marker}'

assert 'current_database()' in CATALOG
assert 'current_schema()' in CATALOG
assert 'has_table_privilege' in CATALOG
assert 'has_schema_privilege' in CATALOG
assert 'format(' not in CATALOG.lower(), 'catalog gate must not construct executable SQL dynamically'
assert 'DROP ' not in CATALOG.upper()
assert 'CREATE ' not in CATALOG.upper()
assert 'ALTER ' not in CATALOG.upper()

# Require explicit, reviewable result sections.
for section in ['tables', 'columns', 'constraints', 'indexes', 'rls', 'triggers', 'functions', 'privileges']:
    assert f'-- SECTION: {section}' in CATALOG, f'missing result section: {section}'

print('STAGE50 STATIC PASS')
print(f'Prisma models: {len(models)}')
print('Read-only catalog gate: PASS')
print('DDL/DML in catalog gate: NONE')
print('Coverage: tables, columns, constraints, indexes, RLS, triggers, functions, privileges')
print('Runtime execution: BLOCKED unless STAGE50_ALLOW_RUNTIME=1 and PostgreSQL client/database are available')

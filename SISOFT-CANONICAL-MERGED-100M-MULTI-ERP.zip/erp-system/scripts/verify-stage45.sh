#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHEMA="$ROOT/prisma/schema.prisma"
MIGRATIONS="$ROOT/prisma/migrations"

models=$(grep -c '^model ' "$SCHEMA")
mig_tables=$(grep -RhoE 'CREATE TABLE( IF NOT EXISTS)? "[^"]+"' "$MIGRATIONS" --include='migration.sql' | sed -E 's/.*"([^"]+)"/\1/' | sort -u | wc -l)
uuid_defaults=$(grep -c 'uuid_generate_v7()' "$SCHEMA")
fn_uuid=$(grep -RhiE 'CREATE( OR REPLACE)? FUNCTION.*uuid_generate_v7|CREATE EXTENSION.*uuid' "$MIGRATIONS" --include='migration.sql' | wc -l)
touch_refs=$(grep -Rho 'touch_updated_at_and_version()' "$MIGRATIONS" --include='migration.sql' | wc -l)
touch_defs=$(grep -RhiE 'CREATE( OR REPLACE)? FUNCTION.*touch_updated_at_and_version' "$MIGRATIONS" --include='migration.sql' | wc -l)
rls_tables=$(grep -Rhi 'ENABLE ROW LEVEL SECURITY' "$MIGRATIONS" --include='migration.sql' | wc -l)
policy_count=$(grep -Rhi 'CREATE POLICY' "$MIGRATIONS" --include='migration.sql' | wc -l)

echo "Stage 45 database-feature reconciliation"
echo "Prisma models: $models"
echo "Tracked migration tables: $mig_tables"
echo "Schema uuid_generate_v7 defaults: $uuid_defaults"
echo "Tracked UUIDv7 provider definitions: $fn_uuid"
echo "Tracked touch_updated_at_and_version references: $touch_refs"
echo "Tracked touch_updated_at_and_version definitions: $touch_defs"
echo "Tracked RLS table enables: $rls_tables"
echo "Tracked policies: $policy_count"

if [ "$models" -gt 0 ] && [ "$mig_tables" -gt 0 ]; then echo "Schema/migration inventory: PASS"; else echo "Schema/migration inventory: FAIL"; exit 1; fi
if [ "$uuid_defaults" -gt 0 ] && [ "$fn_uuid" -eq 0 ]; then echo "UUIDv7 provenance gap: CONFIRMED"; else echo "UUIDv7 provenance gap: NOT CONFIRMED"; fi
if [ "$touch_refs" -gt 0 ] && [ "$touch_defs" -eq 0 ]; then echo "updated_at/version function provenance gap: CONFIRMED"; else echo "updated_at/version function provenance gap: NOT CONFIRMED"; fi
if [ "$rls_tables" -ge 1 ] && [ "$policy_count" -ge 1 ]; then echo "RLS/policy inventory: PASS"; else echo "RLS/policy inventory: FAIL"; exit 1; fi

echo "Executable baseline generation: BLOCKED pending authoritative database infrastructure provenance"

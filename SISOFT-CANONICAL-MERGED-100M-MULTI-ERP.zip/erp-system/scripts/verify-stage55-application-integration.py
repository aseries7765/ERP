#!/usr/bin/env python3
"""Stage 55 static application-integration contract gate.

This gate deliberately does not simulate runtime behavior. It verifies that
representative business controllers are protected by JWT+tenant+permission
guards and that representative mutation paths propagate the authenticated
tenant/actor into their service layer. Runtime PASS requires a real API and
real disposable database evidence via run-stage55-runtime.sh.
"""
from __future__ import annotations
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
API = ROOT / "apps/api/src"
CONTROLLERS = API / "modules"

REPRESENTATIVES = {
    "sales": CONTROLLERS / "sales/controllers/sales.controller.ts",
    "finance": CONTROLLERS / "finance/controllers/finance.controller.ts",
    "rbac-role": CONTROLLERS / "rbac/controllers/role.controller.ts",
}


def fail(msg: str) -> None:
    print(f"STAGE55 STATIC FAIL: {msg}")
    sys.exit(1)


def check_file(path: Path) -> str:
    if not path.is_file():
        fail(f"missing representative controller: {path}")
    return path.read_text(encoding="utf-8")

# Representative application paths: each must have all three request guards.
for name, path in REPRESENTATIVES.items():
    text = check_file(path)
    if "JwtAuthGuard" not in text:
        fail(f"{name}: JwtAuthGuard not wired")
    if "TenantGuard" not in text:
        fail(f"{name}: TenantGuard not wired")
    if "PermissionGuard" not in text:
        fail(f"{name}: PermissionGuard not wired")
    route_count = len(re.findall(r"@(Get|Post|Put|Patch|Delete)\s*\(", text))
    permission_count = len(re.findall(r"@RequirePermission\(", text))
    if route_count == 0 or permission_count < route_count:
        fail(f"{name}: route/permission contract mismatch ({route_count} routes, {permission_count} permission decorators)")
    print(f"{name}: protected routes={route_count}, permission decorators={permission_count}")


# Every RBAC HTTP controller is security-sensitive and must explicitly compose
# the authentication/tenant/permission guard chain; there is no global APP_GUARD
# in this application module that can safely supply it implicitly.
for path in sorted((CONTROLLERS / "rbac/controllers").glob("*.controller.ts")):
    text = path.read_text(encoding="utf-8")
    expected = "@UseGuards(JwtAuthGuard, TenantGuard, PermissionGuard)"
    if expected not in text:
        fail(f"RBAC controller lacks explicit auth/tenant/permission chain: {path.name}")
print(f"rbac controllers protected={len(list((CONTROLLERS / 'rbac/controllers').glob('*.controller.ts')))}")

# Tenant guard must derive context only from verified JWT claims.
tenant_guard = (API / "modules/auth/guards/tenant.guard.ts").read_text(encoding="utf-8")
for needle in ("payload?.tid", "payload?.sub", "enterWith({ tenantId: payload.tid, userId: payload.sub })"):
    if needle not in tenant_guard:
        fail(f"TenantGuard contract missing: {needle}")
if "req.headers" in tenant_guard or "x-tenant" in tenant_guard.lower():
    fail("TenantGuard contains a client-header tenant source")

# Prisma transaction must establish database RLS context with a parameterized value.
prisma = (API / "prisma/prisma.service.ts").read_text(encoding="utf-8")
for needle in ("$transaction", "set_config('app.current_tenant'", "tenantContext.run({ tenantId, userId }"):
    if needle not in prisma:
        fail(f"Prisma tenant transaction contract missing: {needle}")
if "SELECT set_config('app.current_tenant', ${tenantId}, true)" not in prisma:
    fail("Prisma tenant context is not transaction-local/parameterized")

# RBAC mutation must use the atomic mutation/outbox boundary.
role_service = (API / "modules/rbac/services/role.service.ts").read_text(encoding="utf-8")
if role_service.count("atomicRbacMutation") < 3:
    fail("RoleService does not consistently use atomicRbacMutation")

# The atomic helper must bind mutation and event publication to one transaction.
atomic = (API / "modules/rbac/services/atomic-rbac-mutation.ts").read_text(encoding="utf-8")
for needle in ("withTenantTransaction", "emitInTransaction", "const result = await args.mutate(txRepo)"):
    if needle not in atomic:
        fail(f"atomic RBAC transaction contract missing: {needle}")

# Stage 54 evidence gate must remain the prerequisite for claiming DB runtime PASS.
stage54 = ROOT / "scripts/run-stage54-evidence-gate.sh"
if not stage54.is_file():
    fail("Stage 54 evidence gate missing")

print("STAGE55 STATIC PASS")
print("Representative API contracts: sales, finance, RBAC role")
print("Tenant source: verified JWT claims")
print("DB tenant context: transaction-local app.current_tenant")
print("RBAC mutation boundary: atomic mutation + event/outbox contract")
print("Runtime verdict: PASS only from a real API + disposable DB execution")

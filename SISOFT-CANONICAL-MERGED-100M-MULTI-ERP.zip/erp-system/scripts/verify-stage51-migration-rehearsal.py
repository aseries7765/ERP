#!/usr/bin/env python3
"""Stage 51 clean-database migration rehearsal + differential verification.

Static mode is deterministic and safe. Runtime mode is opt-in and requires:
  STAGE51_ALLOW_RUNTIME=1
  DATABASE_URL
  psql
  pnpm exec prisma (Prisma 5.20.0)

Runtime mode only targets a disposable database explicitly marked by
STAGE51_DISPOSABLE_DB=1. It never treats an existing database as disposable.
"""
from pathlib import Path
import os, re, shutil, subprocess, sys

ROOT = Path(__file__).resolve().parent.parent
SCHEMA = ROOT / 'prisma/schema.prisma'
RAW = ROOT / 'prisma/raw-sql'
MIGRATIONS = ROOT / 'prisma/migrations'

schema = SCHEMA.read_text(encoding='utf-8')
models = re.findall(r'^model\s+(\w+)\s*\{', schema, re.M)
assert len(models) == 193, f'expected 193 models, found {len(models)}'
assert len(models) == len(set(models)), 'duplicate Prisma model names'

required_raw = {
    '01-uuid-v7-function.sql': 'CREATE OR REPLACE FUNCTION public.uuid_generate_v7',
    '02-rls-and-triggers.sql': 'CREATE OR REPLACE FUNCTION public.touch_updated_at_and_version',
    '03-app-role-grants.sql': 'GRANT',
    '04-runtime-catalog-gate.sql': 'information_schema.tables',
}
for name, marker in required_raw.items():
    p = RAW / name
    assert p.exists(), f'missing raw SQL: {name}'
    text = p.read_text(encoding='utf-8')
    assert marker in text, f'{name}: missing required marker {marker}'

# Migration history remains feature history; a rehearsal must not rewrite it.
files = sorted(MIGRATIONS.glob('*/migration.sql'))
assert files, 'no tracked migration.sql files found'
assert all(p.is_file() for p in files)

# Verify dependency ordering from actual SQL text, not filenames alone.
uuid_sql = (RAW / '01-uuid-v7-function.sql').read_text(encoding='utf-8')
assert 'uuid_generate_v7' in uuid_sql
uuid_code = re.sub(r'--.*?$|/\*.*?\*/', '', uuid_sql, flags=re.M|re.S)
first_table = re.search(r'\bCREATE\s+TABLE\b', uuid_code, re.I)
assert first_table is None, 'UUID bootstrap must not create application tables'

rls_sql = (RAW / '02-rls-and-triggers.sql').read_text(encoding='utf-8')
assert 'ALTER TABLE' in rls_sql and 'ENABLE ROW LEVEL SECURITY' in rls_sql
assert 'CREATE TRIGGER' in rls_sql

# The catalog gate must remain read-only.
catalog = (RAW / '04-runtime-catalog-gate.sql').read_text(encoding='utf-8').upper()
for forbidden in ('CREATE ', 'ALTER ', 'DROP ', 'INSERT ', 'UPDATE ', 'DELETE ', 'TRUNCATE '):
    assert forbidden not in catalog, f'catalog gate contains forbidden DDL/DML: {forbidden.strip()}'

runtime_requested = os.getenv('STAGE51_ALLOW_RUNTIME') == '1'
if not runtime_requested:
    print('STAGE51 STATIC PASS')
    print(f'Prisma models: {len(models)}')
    print(f'Tracked migration SQL files: {len(files)}')
    print('Bootstrap ordering: PASS')
    print('Read-only catalog safety: PASS')
    print('Migration-history immutability guard: PASS')
    print('Runtime: BLOCKED (set STAGE51_ALLOW_RUNTIME=1 only for a disposable PostgreSQL database)')
    sys.exit(0)

assert os.getenv('STAGE51_DISPOSABLE_DB') == '1', 'runtime requires STAGE51_DISPOSABLE_DB=1'
assert os.getenv('DATABASE_URL'), 'runtime requires DATABASE_URL'
assert shutil.which('psql'), 'runtime requires psql'

try:
    v = subprocess.run(['pnpm', 'exec', 'prisma', '--version'], cwd=ROOT, text=True, capture_output=True, check=True)
except Exception as exc:
    raise SystemExit(f'Prisma 5.20.0 runtime unavailable: {exc}')
assert '5.20.0' in (v.stdout + v.stderr), 'runtime must use Prisma 5.20.0'

# Do not execute automatically beyond this point: database reset/destruction is
# deliberately separated into an explicit shell command after operator review.
print('STAGE51 RUNTIME PREFLIGHT PASS')
print('Disposable DB marker: PASS')
print('DATABASE_URL: PRESENT')
print('psql: PRESENT')
print('Prisma 5.20.0: PRESENT')
print('Execution phase: READY; destructive reset/apply requires explicit operator command')

#!/usr/bin/env python3
import json, pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
policy = ROOT / 'config/stage67-control-plane-policy.json'
doc = ROOT / 'docs-STAGE67-CONTROL-PLANE-TENANT-LIFECYCLE.md'
exc = ROOT / 'docs-STAGE67-EXCEPTIONS.md'


def fail(msg):
    print(f'STAGE67 STATIC FAIL: {msg}')
    sys.exit(1)

try:
    data = json.loads(policy.read_text())
except Exception as e:
    fail(f'invalid policy JSON: {e}')

checks = [
    ('architecture', 'control_plane'), ('architecture', 'data_plane'),
    ('tenant_lifecycle', 'states'), ('tenant_lifecycle', 'allowed_transitions_are_versioned'),
    ('provisioning', 'idempotency_required'), ('provisioning', 'workflow_steps'),
    ('placement', 'placement_version_required'), ('placement', 'region_change_requires_migration_workflow'),
    ('quota_propagation', 'policy_source'), ('quota_propagation', 'security_limits_must_fail_closed_when_stale'),
    ('provider_abstraction', 'required'), ('provider_abstraction', 'provider_neutral_contracts'),
    ('failover', 'split_brain_prevention'), ('failover', 'failover_requires_reconciliation'),
    ('tenant_movement', 'workflow'), ('security', 'tenant_context_required_on_control_plane_commands'),
    ('runtime_evidence_required', None)
]
for section, key in checks:
    if key is None:
        if len(data.get(section, [])) < 8:
            fail('runtime evidence contract incomplete')
    elif key not in data.get(section, {}):
        fail(f'missing {section}.{key}')
    elif data[section][key] in (None, False, [], ''):
        fail(f'empty {section}.{key}')

text = doc.read_text()
required_phrases = [
    'control plane', 'data plane', 'idempotent provisioning', 'placement-version',
    'fence writes', 'quota propagation', 'provider abstraction', 'control-plane failover',
    'split-brain', '100M+ scale', 'Runtime gate'
]
for phrase in required_phrases:
    if phrase.lower() not in text.lower():
        fail(f'document missing required concept: {phrase}')

exceptions = exc.read_text().lower()
for phrase in [
    'runtime status is blocked', 'fabricated', 'split-brain',
    'post-cutover tenant isolation', 'plaintext provider credentials'
]:
    if phrase not in exceptions:
        fail(f'exceptions missing guard: {phrase}')

if re.search(r'\b(?:measured|verified|achieved)\s+(?:throughput|capacity|latency)\b', text, re.I):
    fail('document contains unqualified measured capacity wording')

if 'plaintext credentials' in text.lower() and 'never' not in text.lower():
    fail('credential handling is not fail-closed')

print('STAGE67 STATIC PASS')
print('Control-plane matrix: lifecycle, provisioning idempotency, placement, quotas, provider adapters, failover, tenant movement, security')
print('Runtime verdict: BLOCKED until real representative multi-region control/data-plane infrastructure and evidence are supplied')

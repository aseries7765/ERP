#!/usr/bin/env python3
import json, pathlib, re, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
policy = ROOT / 'config/stage69-authorization-policy-distribution.json'
doc = ROOT / 'docs-STAGE69-GLOBAL-AUTHORIZATION-POLICY-DISTRIBUTION.md'
exc = ROOT / 'docs-STAGE69-EXCEPTIONS.md'

def fail(msg):
    print(f'STAGE69 STATIC FAIL: {msg}')
    sys.exit(1)
try:
    p = json.loads(policy.read_text())
except Exception as e:
    fail(f'invalid policy JSON: {e}')
if p.get('stage') != 69: fail('wrong stage')
checks = [
 ('policy_source.authoritative_control_plane', p['policy_source']['authoritative_control_plane']),
 ('policy_source.immutable_version_ids', p['policy_source']['immutable_version_ids']),
 ('distribution.atomic_bundle_activation', p['distribution']['atomic_bundle_activation']),
 ('distribution.signature_or_integrity_verification', p['distribution']['signature_or_integrity_verification']),
 ('decision_consistency.fail_closed_for_security_critical_stale_policy', p['decision_consistency']['fail_closed_for_security_critical_stale_policy']),
 ('decision_consistency.policy_version_attached_to_decision', p['decision_consistency']['policy_version_attached_to_decision']),
 ('decision_consistency.deny_on_conflicting_policy_versions', p['decision_consistency']['deny_on_conflicting_policy_versions']),
 ('overrides.conflict_detection', p['overrides']['conflict_detection']),
 ('rollback.atomic_activation', p['rollback']['atomic_activation']),
 ('simulation.no_production_mutation', p['simulation']['no_production_mutation']),
 ('security.no_client_supplied_policy_version_authority', p['security']['no_client_supplied_policy_version_authority'])
]
for name, ok in checks:
    if not ok: fail(name)
required = [
 'publish_integrity_and_signature_verification','regional_distribution_and_acknowledgement',
 'stale_policy_fail_closed','tenant_override_precedence_and_conflict_detection',
 'authorization_decision_version_consistency','atomic_policy_rollback',
 'policy_simulation_without_mutation','control_plane_failover_and_reconciliation','evidence_sha256'
]
if p.get('runtime_evidence_required') != required: fail('runtime evidence contract mismatch')
text = doc.read_text()
for phrase in ['authoritative policy source','regional distribution','fail closed','tenant-specific overrides','atomic','policy simulation','control-plane failover','100M+','Runtime gate']:
    if phrase.lower() not in text.lower(): fail(f'document missing required concept: {phrase}')
ex = exc.read_text().lower()
for phrase in ['runtime pass', 'fabricated', 'fail closed', 'client-provided policy versions', 'simulation evidence']:
    if phrase not in ex: fail(f'exceptions missing guard: {phrase}')
if re.search(r'\b(?:measured|verified|achieved)\s+(?:throughput|capacity|latency)\b', text, re.I):
    fail('document contains unqualified measured capacity wording')
print('STAGE69 STATIC PASS')
print('Authorization matrix: authoritative policy source, regional distribution, freshness/fail-closed, tenant overrides, rollback, simulation, decision evidence')
print('Runtime verdict: BLOCKED until real policy distribution, regional convergence, rollback and failover evidence are supplied')

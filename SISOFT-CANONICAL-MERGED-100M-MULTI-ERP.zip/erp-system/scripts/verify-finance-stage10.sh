#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHEMA="$ROOT/prisma/schema.prisma"
SERVICE="$ROOT/apps/api/src/modules/finance/services/finance.service.ts"
CONTROLLER="$ROOT/apps/api/src/modules/finance/controllers/finance.controller.ts"
TENANT="$ROOT/apps/api/src/prisma/tenant-scoping.extension.ts"
RLS="$ROOT/prisma/raw-sql/02-rls-and-triggers.sql"
python3 - "$SCHEMA" "$SERVICE" "$CONTROLLER" "$TENANT" "$RLS" <<'PY'
import re,sys,pathlib
schema,service,controller,tenant,rls=map(lambda x:pathlib.Path(x).read_text(),sys.argv[1:])
models=re.findall(r'^model\s+(\w+)',schema,re.M)
assert len(models)==len(set(models)), 'duplicate Prisma model names'
for m in ['FinanceJournalTemplate','FinanceJournalTemplateLine','FinanceRecurringJournal','FinanceAccrual','FinanceAccrualRecognition']:
    assert re.search(r'^model\s+'+m+r'\b',schema,re.M), m+' missing'
    assert m in tenant, m+' missing from tenant scoping'
for t in ['finance_journal_templates','finance_journal_template_lines','finance_recurring_journals','finance_accruals','finance_accrual_recognitions']:
    assert t in rls, t+' missing from RLS table registry'
assert service.count('{')==service.count('}') and service.count('(')==service.count(')'), 'service structural imbalance'
assert controller.count('{')==controller.count('}') and controller.count('(')==controller.count(')'), 'controller structural imbalance'
assert not re.search(r'not_implemented|not implemented|created_placeholder|generated-id',service,re.I), 'placeholder marker'
print(f'STATIC PASS: {len(models)} unique Prisma models; Stage 10 Finance models, tenant scoping, RLS registration, and service/controller structure verified.')
PY

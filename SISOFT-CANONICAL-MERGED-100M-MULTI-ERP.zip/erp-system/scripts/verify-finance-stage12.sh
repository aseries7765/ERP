#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHEMA="$ROOT/prisma/schema.prisma"
SERVICE="$ROOT/apps/api/src/modules/finance/services/finance.service.ts"
CONTROLLER="$ROOT/apps/api/src/modules/finance/controllers/finance.controller.ts"
RLS="$ROOT/prisma/raw-sql/02-rls-and-triggers.sql"
python3 - <<PY
import re
schema=open('$SCHEMA').read(); models=re.findall(r'^model\\s+(\\w+)',schema,re.M)
assert len(models)==len(set(models)), 'duplicate Prisma models'
assert 'model FinanceYearEndClose {' in schema
for p in ['$SERVICE','$CONTROLLER']:
 s=open(p).read(); assert s.count('{')==s.count('}') and s.count('(')==s.count(')'), p+' structural mismatch'
for marker in ['not_implemented','NOT_IMPLEMENTED','generated-id','created_placeholder','placeholder']:
 for p in ['$SERVICE','$CONTROLLER']:
  assert marker.lower() not in open(p).read().lower(), f'forbidden marker {marker} in {p}'
rls=open('$RLS').read(); assert "'finance_year_end_closes'" in rls
print(f'Finance Stage 12 static gates PASS: {len(models)} unique Prisma models')
PY

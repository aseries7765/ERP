#!/usr/bin/env bash
# ==============================================================================
# scripts/verify-m3-1.sh
# ==============================================================================
# Runs the Auth module's test suite and reports what ACTUALLY happened —
# pass/fail counts come from Jest's own exit code and output, never a
# hardcoded number. This script has NOT been run in the sandbox that
# generated it (no live Postgres/Redis there) — you are the first to
# execute it.
#
# Two tiers, both real:
#   1. Unit tests (test/auth/*.spec.ts) — no DB required. Password, Token,
#      MfaTotp, ApiKey, LoginAttempt services, all with Prisma mocked.
#   2. E2E test (test/auth/e2e/auth.e2e-spec.ts) — REQUIRES a live
#      Postgres + Redis + JWT keypair. Self-skips with a clear console
#      message if DATABASE_URL/APP_DATABASE_URL isn't set — this script
#      does not treat that skip as a failure, but tells you plainly that
#      it happened.
# ==============================================================================

set -uo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

echo "=============================================================="
echo " Slice 3.1 (Auth) verification — $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "=============================================================="

if [ -f .env ]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

command -v pnpm >/dev/null 2>&1 || { echo "✗ pnpm not found on PATH."; exit 1; }

echo ""
echo "── Installing dependencies ──────────────────────────────────"
pnpm install --frozen-lockfile
INSTALL_STATUS=$?
if [ "$INSTALL_STATUS" -ne 0 ]; then
  echo "✗ pnpm install failed (exit ${INSTALL_STATUS}) — cannot proceed."
  exit "$INSTALL_STATUS"
fi

echo ""
echo "── Generating Prisma Client ─────────────────────────────────"
pnpm db:generate
GENERATE_STATUS=$?
if [ "$GENERATE_STATUS" -ne 0 ]; then
  echo "✗ prisma generate failed (exit ${GENERATE_STATUS}) — cannot proceed."
  echo "  (needs DATABASE_URL set in the environment, even just to read the schema)"
  exit "$GENERATE_STATUS"
fi

echo ""
echo "── Running auth unit tests (no DB required) ─────────────────"
pnpm --filter @erp/api exec jest --testPathPattern='test/auth/.*\.spec\.ts$' --testPathIgnorePatterns='/e2e/' --coverage --coverageDirectory=coverage-auth-unit
UNIT_STATUS=$?

echo ""
if [ -n "${DATABASE_URL:-}" ] || [ -n "${APP_DATABASE_URL:-}" ]; then
  echo "── Running auth e2e test (DATABASE_URL/APP_DATABASE_URL detected) ──"
  pnpm --filter @erp/api test:e2e
  E2E_STATUS=$?
  E2E_RAN=true
else
  echo "── Skipping auth e2e test: no DATABASE_URL/APP_DATABASE_URL set ────"
  echo "   This is expected without a running Postgres. Run:"
  echo "     docker compose up -d postgres redis"
  echo "     export \$(grep -v '^#' .env | xargs)   # or otherwise load .env"
  echo "   then re-run this script to include it."
  E2E_STATUS=0
  E2E_RAN=false
fi

echo ""
echo "=============================================================="
echo " SUMMARY"
echo "=============================================================="
echo "  Install:            $([ "$INSTALL_STATUS" -eq 0 ] && echo PASS || echo FAIL)"
echo "  Prisma generate:    $([ "$GENERATE_STATUS" -eq 0 ] && echo PASS || echo FAIL)"
echo "  Unit tests:         $([ "$UNIT_STATUS" -eq 0 ] && echo PASS || echo FAIL) (see Jest output above for actual test/pass/fail counts)"
if [ "$E2E_RAN" = true ]; then
  echo "  E2E test:           $([ "$E2E_STATUS" -eq 0 ] && echo PASS || echo FAIL) (see Jest output above)"
else
  echo "  E2E test:           SKIPPED (no live DB configured)"
fi
echo ""
echo "  Coverage report (unit tests): apps/api/coverage-auth-unit/lcov-report/index.html"
echo "  This script does NOT print a coverage percentage here — read it from"
echo "  the Jest coverage table above, which reflects what was actually measured."
echo "=============================================================="

TOTAL_FAIL=0
[ "$INSTALL_STATUS" -ne 0 ] && TOTAL_FAIL=$((TOTAL_FAIL + 1))
[ "$GENERATE_STATUS" -ne 0 ] && TOTAL_FAIL=$((TOTAL_FAIL + 1))
[ "$UNIT_STATUS" -ne 0 ] && TOTAL_FAIL=$((TOTAL_FAIL + 1))
[ "$E2E_RAN" = true ] && [ "$E2E_STATUS" -ne 0 ] && TOTAL_FAIL=$((TOTAL_FAIL + 1))

exit "$TOTAL_FAIL"

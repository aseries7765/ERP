BEGIN;

-- Superuser-owned fixture rows. All test DML is rolled back at the end.
INSERT INTO public.tenants (id, name, slug, status, "createdAt", "updatedAt", version)
VALUES
 ('11111111-1111-4111-8111-111111111111','Stage53 Tenant A','stage53-a','ACTIVE',now(),now(),1),
 ('22222222-2222-4222-8222-222222222222','Stage53 Tenant B','stage53-b','ACTIVE',now(),now(),1);

INSERT INTO public.plans (id, code, name, tier, "priceMonthly", "priceYearly", "currencyCode", features, "createdAt", "updatedAt")
VALUES ('33333333-3333-4333-8333-333333333333','STAGE53','Stage53 Smoke','FREE',0,0,'USD','{}'::jsonb,now(),now());

SET LOCAL ROLE erp_app;

-- 1) Tenant isolation: tenant A sees A only, never B.
SET LOCAL app.current_tenant = '11111111-1111-4111-8111-111111111111';
INSERT INTO public.subscriptions (id,"tenantId","planId",status,seats,"createdAt","updatedAt","createdBy","updatedBy",version)
VALUES ('44444444-4444-4444-8444-444444444444','11111111-1111-4111-8111-111111111111','33333333-3333-4333-8333-333333333333','TRIALING',1,now(),now(),'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',1);
INSERT INTO public.subscriptions (id,"tenantId","planId",status,seats,"createdAt","updatedAt","createdBy","updatedBy",version)
VALUES ('55555555-5555-4555-8555-555555555555','22222222-2222-4222-8222-222222222222','33333333-3333-4333-8333-333333333333','TRIALING',1,now(),now(),'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',1);

DO $$ DECLARE n int; BEGIN
  SELECT count(*) INTO n FROM public.subscriptions;
  IF n <> 1 THEN RAISE EXCEPTION 'tenant A isolation failed: expected 1 row, got %', n; END IF;
END $$;

-- 2) Cross-tenant INSERT must be rejected by the RLS WITH CHECK derived from USING.
SAVEPOINT cross_tenant_insert;
DO $$ BEGIN
  BEGIN
    INSERT INTO public.subscriptions (id,"tenantId","planId",status,seats,"createdAt","updatedAt","createdBy","updatedBy",version)
    VALUES ('66666666-6666-4666-8666-666666666666','22222222-2222-4222-8222-222222222222','33333333-3333-4333-8333-333333333333','TRIALING',1,now(),now(),'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',1);
    RAISE EXCEPTION 'cross-tenant INSERT unexpectedly succeeded';
  EXCEPTION WHEN others THEN
    IF SQLERRM = 'cross-tenant INSERT unexpectedly succeeded' THEN RAISE; END IF;
  END;
END $$;
ROLLBACK TO SAVEPOINT cross_tenant_insert;

-- 3) updatedAt/version DB trigger increments version and refreshes updatedAt.
DO $$
DECLARE before_version int; after_version int; before_updated timestamptz; after_updated timestamptz;
BEGIN
  SELECT version, "updatedAt" INTO before_version, before_updated FROM public.subscriptions WHERE id='44444444-4444-4444-8444-444444444444';
  UPDATE public.subscriptions SET seats=2 WHERE id='44444444-4444-4444-8444-444444444444';
  SELECT version, "updatedAt" INTO after_version, after_updated FROM public.subscriptions WHERE id='44444444-4444-4444-8444-444444444444';
  IF after_version <> before_version + 1 THEN RAISE EXCEPTION 'version trigger failed: % -> %', before_version, after_version; END IF;
  IF after_updated <= before_updated THEN RAISE EXCEPTION 'updatedAt trigger failed'; END IF;
END $$;

-- 4) Tenant B cannot see tenant A rows.
SET LOCAL app.current_tenant = '22222222-2222-4222-8222-222222222222';
DO $$ DECLARE n int; BEGIN
  SELECT count(*) INTO n FROM public.subscriptions;
  IF n <> 1 THEN RAISE EXCEPTION 'tenant B isolation failed: expected its one row, got %', n; END IF;
END $$;

-- 5) Missing tenant context must fail closed to zero rows.
RESET app.current_tenant;
DO $$ DECLARE n int; BEGIN
  SELECT count(*) INTO n FROM public.subscriptions;
  IF n <> 0 THEN RAISE EXCEPTION 'missing tenant context leaked % rows', n; END IF;
END $$;

-- 6) Audit is insertable but append-only. The two forbidden mutations are
-- deliberately caught so the transaction can continue and finally roll back.
SET LOCAL app.current_tenant = '11111111-1111-4111-8111-111111111111';
INSERT INTO public.audit_events (id,"tenantId","actorId",action,"entityType","entityId","rowHash","createdAt")
VALUES ('77777777-7777-4777-8777-777777777777','11111111-1111-4111-8111-111111111111',NULL,'OTHER','Stage53Smoke','44444444-4444-4444-8444-444444444444','stage53-test-hash',now());

DO $$
BEGIN
  BEGIN
    UPDATE public.audit_events SET reason='forbidden' WHERE id='77777777-7777-4777-8777-777777777777';
    RAISE EXCEPTION 'audit UPDATE unexpectedly succeeded';
  EXCEPTION WHEN others THEN
    IF SQLERRM = 'audit UPDATE unexpectedly succeeded' THEN RAISE; END IF;
  END;
END $$;

DO $$
BEGIN
  BEGIN
    DELETE FROM public.audit_events WHERE id='77777777-7777-4777-8777-777777777777';
    RAISE EXCEPTION 'audit DELETE unexpectedly succeeded';
  EXCEPTION WHEN others THEN
    IF SQLERRM = 'audit DELETE unexpectedly succeeded' THEN RAISE; END IF;
  END;
END $$;

-- 7) App-role privilege boundary.
DO $$ BEGIN
  IF has_table_privilege(current_user,'public.audit_events','UPDATE') THEN RAISE EXCEPTION 'audit UPDATE privilege granted'; END IF;
  IF has_table_privilege(current_user,'public.audit_events','DELETE') THEN RAISE EXCEPTION 'audit DELETE privilege granted'; END IF;
  IF NOT has_table_privilege(current_user,'public.subscriptions','SELECT') THEN RAISE EXCEPTION 'subscription SELECT privilege missing'; END IF;
  IF NOT has_table_privilege(current_user,'public.subscriptions','INSERT') THEN RAISE EXCEPTION 'subscription INSERT privilege missing'; END IF;
END $$;

ROLLBACK;

#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
models=re.findall(r'^model\s+\w+\s*\{', (ROOT/'prisma/schema.prisma').read_text(), re.M)
if len(models)!=193: errors.append(f'expected 193 Prisma models, found {len(models)}')
for p in ['scripts/run-stage52-runtime.sh','scripts/run-stage53-runtime.sh','scripts/verify-stage53-runtime-smoke.py']:
    if not (ROOT/p).exists(): errors.append(f'missing required gate: {p}')

evidence52=ROOT/'prisma/runtime-evidence-stage52'
evidence53=ROOT/'prisma/runtime-evidence-stage53'
if not evidence52.exists(): warnings.append('Stage 52 runtime evidence directory is absent')
if not evidence53.exists(): warnings.append('Stage 53 runtime evidence directory is absent')

# Evidence is accepted only if the producing stage explicitly recorded PASS.
if evidence52.exists():
    required=['06-schema-diff.result','08-invariants.txt','SHA256SUMS']
    for n in required:
        if not (evidence52/n).exists(): errors.append(f'Stage 52 evidence missing: {n}')
    r=(evidence52/'06-schema-diff.result')
    if r.exists() and r.read_text().strip()!='Schema differential check: PASS': errors.append('Stage 52 schema differential evidence is not PASS')
    inv=evidence52/'08-invariants.txt'
    if inv.exists() and not re.fullmatch(r'table_count expected=193 actual=193\n?',inv.read_text()): errors.append('Stage 52 table-count evidence does not prove 193=193')
if evidence53.exists():
    for n in ['RESULT.txt','01-smoke.txt','02-privilege-evidence.txt','SHA256SUMS']:
        if not (evidence53/n).exists(): errors.append(f'Stage 53 evidence missing: {n}')
    r=evidence53/'RESULT.txt'
    if r.exists() and r.read_text().strip()!='STAGE53 RUNTIME PASS': errors.append('Stage 53 RESULT.txt is not explicit PASS')
    p=evidence53/'02-privilege-evidence.txt'
    if p.exists():
        t=p.read_text()
        if 'audit_update_priv=t' in t: errors.append('audit UPDATE privilege evidence is unsafe')
        if 'audit_delete_priv=t' in t: errors.append('audit DELETE privilege evidence is unsafe')

# Verify recorded SHA manifests without requiring a runtime database.
def verify_manifest(path):
    if not path.exists(): return
    lines=path.read_text().splitlines()
    for line in lines:
        parts=line.split('  ',1)
        if len(parts)!=2: errors.append(f'malformed SHA manifest entry in {path.name}: {line}'); continue
        digest, name=parts
        target=path.parent/name
        if not target.exists(): errors.append(f'hashed evidence missing: {target}'); continue
        actual=hashlib.sha256(target.read_bytes()).hexdigest()
        if actual!=digest: errors.append(f'SHA mismatch: {target.name} in {path}')
verify_manifest(evidence52/'SHA256SUMS')
verify_manifest(evidence53/'SHA256SUMS')

if errors:
    print('STAGE54 STATIC FAIL')
    for e in errors: print(' - '+e)
    if warnings:
        print('Warnings:')
        for w in warnings: print(' - '+w)
    sys.exit(1)
print('STAGE54 STATIC PASS')
print('Prisma models: 193')
print('Evidence manifest verification: PASS' if evidence52.exists() and evidence53.exists() else 'Evidence manifest verification: BLOCKED (runtime evidence not present)')
print('Runtime verdict: PASS only when Stage 52 and Stage 53 evidence are actually present and validated')

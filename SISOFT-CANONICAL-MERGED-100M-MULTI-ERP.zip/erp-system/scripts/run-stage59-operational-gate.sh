#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/scripts/verify-stage59-operational-readiness.py"

required=(STAGE59_API_BASE_URL APP_DATABASE_URL REDIS_URL STAGE59_BACKUP_VERIFY_COMMAND STAGE59_RESTORE_VERIFY_COMMAND STAGE59_TLS_URL STAGE59_OBSERVABILITY_URL STAGE59_RATE_LIMIT_KEY_PREFIX)
missing=()
for name in "${required[@]}"; do [[ -n "${!name:-}" ]] || missing+=("$name"); done
if ((${#missing[@]})); then
  echo "STAGE59 RUNTIME BLOCKED: missing ${missing[*]}"
  exit 2
fi

command -v curl >/dev/null || { echo 'STAGE59 RUNTIME BLOCKED: curl unavailable'; exit 2; }
command -v psql >/dev/null || { echo 'STAGE59 RUNTIME BLOCKED: psql unavailable'; exit 2; }
command -v redis-cli >/dev/null || { echo 'STAGE59 RUNTIME BLOCKED: redis-cli unavailable'; exit 2; }

curl --fail --silent --show-error "$STAGE59_API_BASE_URL/health/live" >/dev/null
curl --fail --silent --show-error "$STAGE59_API_BASE_URL/health/ready" >/dev/null
psql "$APP_DATABASE_URL" -v ON_ERROR_STOP=1 -Atqc 'SELECT 1' >/dev/null
redis-cli -u "$REDIS_URL" ping | grep -qx PONG
curl --fail --silent --show-error "$STAGE59_TLS_URL" >/dev/null
curl --fail --silent --show-error "$STAGE59_OBSERVABILITY_URL" >/dev/null
bash -lc "$STAGE59_BACKUP_VERIFY_COMMAND"
bash -lc "$STAGE59_RESTORE_VERIFY_COMMAND"

# A runtime PASS requires all probes above plus an explicit external rate-limit
# exercise. The command is deliberately supplied by the deployment harness so
# this repository cannot fake a distributed limiter result.
[[ -n "${STAGE59_RATE_LIMIT_VERIFY_COMMAND:-}" ]] || { echo 'STAGE59 RUNTIME BLOCKED: STAGE59_RATE_LIMIT_VERIFY_COMMAND missing'; exit 2; }
bash -lc "$STAGE59_RATE_LIMIT_VERIFY_COMMAND"
echo 'STAGE59 RUNTIME PASS'

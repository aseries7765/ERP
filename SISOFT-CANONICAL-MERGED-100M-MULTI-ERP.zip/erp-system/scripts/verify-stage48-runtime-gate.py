#!/usr/bin/env python3
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCHEMA = (ROOT / 'prisma/schema.prisma').read_text(encoding='utf-8')
UUID_SQL = (ROOT / 'prisma/raw-sql/01-uuid-v7-function.sql').read_text(encoding='utf-8')
RLS_SQL = (ROOT / 'prisma/raw-sql/02-rls-and-triggers.sql').read_text(encoding='utf-8')
GRANTS_SQL = (ROOT / 'prisma/raw-sql/03-app-role-grants.sql').read_text(encoding='utf-8')

blocks = re.findall(r'^model\s+(\w+)\s*\{(.*?)^\}', SCHEMA, re.M | re.S)
assert blocks, 'no Prisma models found'
assert len(blocks) == len({name for name, _ in blocks}), 'duplicate Prisma model names'

models = {}
for name, body in blocks:
    mm = re.search(r'^\s*@@map\("([^"]+)"\)', body, re.M)
    table = mm.group(1) if mm else name
    models[table] = (name, body)

uuid_models = [name for name, body in blocks if 'uuid_generate_v7()' in body]
assert uuid_models, 'no UUIDv7-backed models found'
assert 'CREATE OR REPLACE FUNCTION public.uuid_generate_v7' in UUID_SQL
assert 'RETURNS uuid' in UUID_SQL
assert 'gen_random_bytes(10)' in UUID_SQL
assert 'SET search_path = pg_catalog, public' in UUID_SQL

# Extract the explicit trigger registry from Stage 46's array.
m = re.search(r"SELECT unnest\(ARRAY\[(.*?)\]\)", RLS_SQL, re.S)
assert m, 'explicit trigger registry missing'
trigger_tables = re.findall(r"'([a-zA-Z0-9_]+)'", m.group(1))
assert len(trigger_tables) == len(set(trigger_tables)), 'duplicate trigger registry table'

eligible = []
for table, (name, body) in models.items():
    if re.search(r'^\s*tenantId\s+\S+', body, re.M) and re.search(r'^\s*version\s+Int\b', body, re.M) and re.search(r'^\s*updatedAt\s+DateTime\b', body, re.M):
        eligible.append(table)

assert set(trigger_tables) == set(eligible), (
    f'trigger registry mismatch: registry={len(trigger_tables)} eligible={len(eligible)} '
    f'missing={sorted(set(eligible)-set(trigger_tables))[:10]} '
    f'extra={sorted(set(trigger_tables)-set(eligible))[:10]}'
)

for table in trigger_tables:
    assert table in models, f'trigger registry table not represented by Prisma schema: {table}'
    assert 'CREATE TRIGGER trg_touch_%1$s' in RLS_SQL, 'dynamic trigger DDL template missing'

# Stage 47/48 baseline policy: a generated candidate is an artifact, not an
# authoritative migration, until it is applied and diff-verified against DB.
baseline_dir = ROOT / 'prisma/baseline-generated'
if baseline_dir.exists():
    candidate = baseline_dir / 'migration.sql'
    if candidate.exists():
        sql = candidate.read_text(encoding='utf-8', errors='replace')
        assert 'CREATE TABLE' in sql, 'baseline candidate contains no CREATE TABLE'
        assert len(re.findall(r'CREATE\s+TABLE\b', sql, re.I)) >= len(models) * 0.95, 'baseline candidate appears incomplete'
        print(f'Baseline candidate present: {candidate}')
        print('Baseline candidate structural floor: PASS')
    else:
        print('Baseline candidate directory present but no migration.sql: acceptable pre-runtime state')

# The app role grant is intentionally post-table infrastructure.
assert 'GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO erp_app;' in GRANTS_SQL
assert 'ALTER DEFAULT PRIVILEGES IN SCHEMA public' in GRANTS_SQL
assert 'REVOKE UPDATE, DELETE ON audit_events FROM erp_app;' in GRANTS_SQL

print(f'STAGE48 STATIC PASS: Prisma models={len(models)}; UUIDv7-backed models={len(uuid_models)}; tenant mutable trigger tables={len(eligible)}')
print('UUIDv7 bootstrap contract: PASS')
print('Trigger registry/schema alignment: PASS')
print('Post-table app-role grant boundary: PASS')
print('Runtime baseline application: BLOCKED until Prisma CLI + disposable PostgreSQL are available')

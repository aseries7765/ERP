#!/usr/bin/env python3
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCHEMA = (ROOT / 'prisma/schema.prisma').read_text(encoding='utf-8')
RLS = (ROOT / 'prisma/raw-sql/02-rls-and-triggers.sql').read_text(encoding='utf-8')
GRANTS = (ROOT / 'prisma/raw-sql/03-app-role-grants.sql').read_text(encoding='utf-8')
UUID = (ROOT / 'prisma/raw-sql/01-uuid-v7-function.sql').read_text(encoding='utf-8')

blocks = re.findall(r'^model\s+(\w+)\s*\{(.*?)^\}', SCHEMA, re.M | re.S)
assert len(blocks) == 193, f'expected current 193-model schema, found {len(blocks)}'
assert len({n for n, _ in blocks}) == len(blocks), 'duplicate model names'

models = {}
for name, body in blocks:
    mm = re.search(r'^\s*@@map\("([^"]+)"\)', body, re.M)
    table = mm.group(1) if mm else name
    models[table] = body

# Tenant scope and version/updatedAt eligibility.
tenant_tables = {
    table for table, body in models.items()
    if re.search(r'^\s*tenantId\s+\S+', body, re.M)
}
mutable_tenant_tables = {
    table for table, body in models.items()
    if table in tenant_tables
    and re.search(r'^\s*version\s+Int\b', body, re.M)
    and re.search(r'^\s*updatedAt\s+DateTime\b', body, re.M)
}
assert len(tenant_tables) == 183, f'expected 183 tenant-scoped tables, found {len(tenant_tables)}'
assert len(mutable_tenant_tables) == 103, f'expected 103 mutable tenant tables, found {len(mutable_tenant_tables)}'

# Every tenant table must have an explicit tenant index. Do not require a
# deletedAt index because some legitimate tenant-scoped identity tables are
# intentionally not soft-deletable.
missing_tenant_index = []
for table, body in models.items():
    if table not in tenant_tables:
        continue
    indexes = re.findall(r'^\s*@@index\(\[([^\]]+)\]\)', body, re.M)
    uniques = re.findall(r'^\s*@@unique\(\[([^\]]+)\]\)', body, re.M)
    has_tenant_access_path = any(re.sub(r'\s+', '', x).split(',')[0] == 'tenantId' for x in indexes + uniques)
    if not has_tenant_access_path:
        missing_tenant_index.append(table)
print(f'Tenant tables without a tenant-leading index/unique access path: {len(missing_tenant_index)}')

# Uniqueness must not accidentally become global for tenant-scoped natural
# keys. This is a structural heuristic: every @@unique on a tenant model is
# required to include tenantId, except the primary-key surrogate itself,
# which is represented by @id rather than @@unique.
bad_unique = []
for table, body in models.items():
    if table not in tenant_tables:
        continue
    for fields in re.findall(r'^\s*@@unique\(\[([^\]]+)\]\)', body, re.M):
        normalized = [f.strip() for f in fields.split(',') if f.strip()]
        if 'tenantId' not in normalized:
            bad_unique.append((table, normalized))
allowed_transitive_unique = {
    ('terminology_packs', ('terminologyPackId', 'key', 'locale')),
    ('access_reviews', ('accessReviewId', 'userId', 'roleKey')),
    ('event_deliveries', ('outboxId', 'target')),
}
unexpected_bad_unique = [item for item in bad_unique if (item[0], tuple(item[1])) not in allowed_transitive_unique]
assert not unexpected_bad_unique, f'unscoped unique constraints require explicit review: {unexpected_bad_unique[:10]}'


# RLS policy must be applied by the dynamic tenantId-column discovery loop,
# and the policy must bind to the project-owned tenant helper.
assert 'information_schema.columns' in RLS and 'column_name = \'tenantId\'' in RLS
assert 'ALTER TABLE %I ENABLE ROW LEVEL SECURITY;' in RLS
assert 'ALTER TABLE %I FORCE ROW LEVEL SECURITY;' in RLS
assert 'CREATE POLICY tenant_isolation' in RLS
assert '"tenantId" = public.get_current_tenant()' in RLS
assert 'SET search_path = pg_catalog, public' in RLS

# DB trigger infrastructure: explicit allow-list must equal all eligible
# tenant tables. Extract the first ARRAY in the trigger section.
mm = re.search(r"SELECT unnest\(ARRAY\[(.*?)\]\)", RLS, re.S)
assert mm, 'trigger allow-list missing'
trigger_tables = set(re.findall(r"'([a-zA-Z0-9_]+)'", mm.group(1)))
assert trigger_tables == mutable_tenant_tables, (
    f'trigger allow-list drift: listed={len(trigger_tables)} '
    f'expected={len(mutable_tenant_tables)} '
    f'missing={sorted(mutable_tenant_tables-trigger_tables)[:10]} '
    f'extra={sorted(trigger_tables-mutable_tenant_tables)[:10]}'
)

# Audit table must have DB-level append-only enforcement and app-role write
# restrictions. Do not rely solely on application code.
assert 'CREATE TRIGGER trg_audit_no_update' in RLS
assert 'CREATE TRIGGER trg_audit_no_delete' in RLS
assert 'REVOKE UPDATE, DELETE ON audit_events FROM erp_app;' in GRANTS

# Raw SQL must not contain unqualified project-owned helper calls in CREATE
# FUNCTION bodies. This catches search_path-sensitive future edits.
for fn in ('uuid_generate_v7', 'get_current_tenant', 'audit_hash', 'touch_updated_at_and_version', 'reject_audit_mutation'):
    assert f'FUNCTION public.{fn}' in (UUID + RLS), f'function {fn} is not schema-qualified'

# Stage 45 had a comment claiming a partial soft-delete index existed in raw
# SQL. There is no such DDL today; fail closed rather than documenting a
# feature that is not actually implemented.
assert 'partial index added in raw SQL' not in SCHEMA, 'stale partial-index claim remains in schema comments'
assert 'soft-delete partial index' not in SCHEMA, 'stale partial-index claim remains in schema comments'

print('STAGE49 STATIC PASS')
print(f'Prisma models: {len(models)}')
print(f'Tenant-scoped tables: {len(tenant_tables)}')
print(f'Tenant mutable trigger tables: {len(trigger_tables)}')
print('Tenant indexes: PASS')
print('Tenant-scoped unique constraints: PASS')
print('RLS helper/policy contract: PASS')
print('Trigger allow-list/schema alignment: PASS')
print('Audit append-only boundary: PASS')
print('Raw-SQL function qualification: PASS')
print('Runtime PostgreSQL catalog verification: BLOCKED until PostgreSQL is available')

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 - "$ROOT/prisma/schema.prisma" "$ROOT/prisma/raw-sql/01-uuid-v7-function.sql" "$ROOT/prisma/raw-sql/02-rls-and-triggers.sql" <<'PY'
import re,sys
from pathlib import Path
schema=Path(sys.argv[1]).read_text(); uuid=Path(sys.argv[2]).read_text(); sql=Path(sys.argv[3]).read_text()
mm=re.search(r"SELECT unnest\(ARRAY\[(.*?)\]\)",sql,re.S); assert mm,'trigger manifest array not found'
manifest=re.findall(r"'([^']+)'",mm.group(1)); assert len(manifest)==len(set(manifest)),'duplicate trigger table'
eligible=[]
for m in re.finditer(r'model\s+(\w+)\s*\{(.*?)\n\}',schema,re.S):
 name,b=m.groups(); mp=re.search(r'@@map\("([^"]+)"\)',b); table=mp.group(1) if mp else re.sub(r'(?<!^)(?=[A-Z])','_',name).lower()
 if re.search(r'^\s*tenantId\s+String',b,re.M) and re.search(r'^\s*version\s+Int',b,re.M) and re.search(r'^\s*updatedAt\s+DateTime',b,re.M): eligible.append(table)
assert set(manifest)==set(eligible), f'mismatch missing={sorted(set(eligible)-set(manifest))} extra={sorted(set(manifest)-set(eligible))}'
for fn,txt in [('uuid_generate_v7',uuid),('get_current_tenant',sql),('audit_hash',sql),('touch_updated_at_and_version',sql),('reject_audit_mutation',sql)]:
 assert re.search(rf'CREATE OR REPLACE FUNCTION public\.{fn}\b',txt), f'{fn} definition missing'
print(f'STAGE46 STATIC PASS: {len(manifest)} trigger tables match {len(eligible)} schema-eligible tenant mutable models; all authoritative function definitions present')
print('RUNTIME STATUS: BLOCKED (PostgreSQL + installed Prisma dependencies required)')
PY

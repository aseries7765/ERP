#!/usr/bin/env python3
import hashlib, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors=[]
required = [
 'deployment/stage61/recovery-contract.json',
 'deployment/stage61/recovery-runbook.md',
 'scripts/run-stage61-recovery-gate.sh',
]
for p in required:
    if not (ROOT/p).is_file(): errors.append(f'missing {p}')

contract = ROOT/'deployment/stage61/recovery-contract.json'
if contract.exists():
    try:
        c=json.loads(contract.read_text())
        for k in ['backup','restore','pitr','applicationRollback','migrationCompatibility','tenantIsolation','evidence']:
            if k not in c: errors.append(f'contract missing {k}')
        if c.get('backup',{}).get('encryptedAtRest') is not True: errors.append('backup encryptionAtRest must be true')
        if c.get('backup',{}).get('retentionDays',0) < 7: errors.append('backup retention must be >= 7 days')
        if c.get('pitr',{}).get('required') is not True: errors.append('PITR must be required')
        if c.get('applicationRollback',{}).get('immutableImage') is not True: errors.append('immutable application rollback required')
        if c.get('restore',{}).get('isolatedTargetRequired') is not True: errors.append('restore must use isolated target')
        if c.get('tenantIsolation',{}).get('rlsVerificationRequired') is not True: errors.append('post-restore RLS verification required')
    except Exception as e: errors.append(f'invalid recovery contract: {e}')

run = ROOT/'scripts/run-stage61-recovery-gate.sh'
if run.exists():
    s=run.read_text()
    for token in ['STAGE61_BACKUP_VERIFY_COMMAND','STAGE61_RESTORE_VERIFY_COMMAND','STAGE61_PITR_VERIFY_COMMAND','STAGE61_ROLLBACK_VERIFY_COMMAND','STAGE61_MIGRATION_COMPAT_VERIFY_COMMAND','STAGE61_RLS_VERIFY_COMMAND','STAGE61_EVIDENCE_DIR']:
        if token not in s: errors.append(f'runtime gate missing {token}')
    if 'STAGE61 RUNTIME PASS' not in s: errors.append('runtime gate has no explicit PASS marker')
    if 'isolated' not in s.lower(): errors.append('runtime gate does not enforce isolated restore wording')

schema = ROOT/'prisma/schema.prisma'
if schema.exists() and len(re.findall(r'^model\s+\w+', schema.read_text(), re.M)) < 193:
    errors.append('schema model count is below established 193-model invariant')

if errors:
    print('STAGE61 STATIC BLOCKED')
    for e in errors: print(' - '+e)
    sys.exit(2)
print('STAGE61 STATIC PASS')
print('Recovery matrix: backups, restore, PITR, immutable app rollback, migration compatibility, tenant/RLS verification, evidence retention')
print('Runtime verdict: BLOCKED until actual disposable production-like recovery infrastructure and evidence are supplied')

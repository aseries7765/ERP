#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
API = ROOT / 'apps/api/src'

def need(path, needle):
    text = path.read_text()
    if needle not in text:
        print(f'FAIL: {path.relative_to(ROOT)} missing {needle!r}')
        return False
    return True

checks = [
    (API/'health/health.controller.ts', 'this.operational.database()'),
    (API/'health/health.controller.ts', 'this.operational.redisPing()'),
    (API/'health/health.controller.ts', "@Get('live')"),
    (API/'health/health.controller.ts', "@Get('ready')"),
    (API/'health/health.module.ts', 'PrismaModule'),
    (API/'health/health.module.ts', 'OperationalHealthService'),
    (API/'health/operational-health.service.ts', "SELECT 1"),
    (API/'health/operational-health.service.ts', "REDIS_URL is required for readiness"),
    (API/'health/health.controller.spec.ts', 'readiness checks database and Redis'),
    (API/'health/health.controller.spec.ts', 'readiness fails when a dependency probe fails'),
]

ok = all(need(p, n) for p,n in checks)

# The operational matrix is intentionally environment-driven. These names are
# contracts, not credentials; no secrets are committed to the repository.
required_names = [
    'APP_DATABASE_URL', 'REDIS_URL', 'STAGE59_API_BASE_URL',
    'STAGE59_BACKUP_VERIFY_COMMAND', 'STAGE59_RESTORE_VERIFY_COMMAND',
    'STAGE59_TLS_URL', 'STAGE59_OBSERVABILITY_URL',
    'STAGE59_RATE_LIMIT_KEY_PREFIX',
]
example = ROOT / '.env.example'
env = example.read_text()
for name in required_names:
    if name not in env:
        print(f'FAIL: .env.example missing Stage 59 contract {name}')
        ok = False

print('STAGE59 STATIC PASS' if ok else 'STAGE59 STATIC FAIL')
print('Operational matrix: API, PostgreSQL, Redis/BullMQ, migrations, backups/restore, TLS, observability, distributed rate limiting')
print('Runtime verdict: BLOCKED until actual disposable/production-like infrastructure is supplied')
sys.exit(0 if ok else 1)

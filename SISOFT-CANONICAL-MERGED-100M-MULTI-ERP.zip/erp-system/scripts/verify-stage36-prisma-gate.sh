#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
import re, glob, sys
schema_path='prisma/schema.prisma'
schema=open(schema_path,encoding='utf-8').read()
blocks=re.findall(r'^(model|enum|type)\s+(\w+)\s*\{(.*?)^\}',schema,re.M|re.S)
models={name:body for kind,name,body in blocks if kind=='model'}
enums={name for kind,name,body in blocks if kind=='enum'}
# Prisma's default table name is the model name unless @@map is present.
tables={}
for name,body in models.items():
    m=re.search(r'@@map\("([^"]+)"\)',body)
    tables[name]=m.group(1) if m else name

created=set()
for path in glob.glob('prisma/migrations/*/migration.sql'):
    sql=open(path,encoding='utf-8',errors='ignore').read()
    for m in re.finditer(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:"[^"]+"\.)?"?([A-Za-z0-9_]+)"?',sql,re.I):
        created.add(m.group(1))

missing=sorted(set(tables.values())-created)
print(f'Stage 36 Prisma static gate')
print(f'  schema models: {len(models)}')
print(f'  schema enums: {len(enums)}')
print(f'  migration CREATE TABLE coverage: {len(created)}')
print(f'  schema tables without CREATE TABLE in tracked migrations: {len(missing)}')
if missing:
    print('  migration baseline coverage: BLOCKED')
    print('  missing tables:')
    for t in missing: print('   -',t)
else:
    print('  migration baseline coverage: PASS')

# Detect duplicate model names and duplicate fields in each model.
errors=[]
if len(models) != len(set(models)): errors.append('duplicate model names')
for name,body in models.items():
    fields=[]
    for line in body.splitlines():
        line=line.strip()
        if not line or line.startswith('//') or line.startswith('@@'): continue
        m=re.match(r'([A-Za-z_][A-Za-z0-9_]*)\s+(.+)',line)
        if m and not line.startswith('@'):
            fields.append(m.group(1))
    dups={x for x in fields if fields.count(x)>1}
    if dups: errors.append(f'{name}: duplicate fields {sorted(dups)}')
print('  duplicate model/field structural check:', 'PASS' if not errors else 'FAIL')
if errors:
    for e in errors: print('   -',e)
    sys.exit(1)
PY

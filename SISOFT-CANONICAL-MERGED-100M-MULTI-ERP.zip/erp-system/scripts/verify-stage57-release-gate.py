#!/usr/bin/env python3
"""Stage 57: independent runtime-evidence reconciliation and release gate.

Static-only execution may produce BLOCKED, never PASS. Runtime PASS requires
independent verification of retained Stage 52/53/56 evidence, SHA manifests,
and reconciliation with the schema/policy catalog contracts.
"""
from pathlib import Path
import hashlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
errors=[]; blocked=[]

def read(p):
    if not p.is_file():
        errors.append(f'missing required file: {p.relative_to(ROOT)}'); return ''
    return p.read_text(encoding='utf-8')

def verify_manifest(directory, manifest_name='SHA256SUMS'):
    m=directory/manifest_name
    if not m.is_file():
        errors.append(f'missing evidence manifest: {m.relative_to(ROOT)}'); return
    for line in m.read_text().splitlines():
        if not line.strip(): continue
        parts=line.split('  ',1)
        if len(parts)!=2:
            errors.append(f'malformed manifest entry: {m.relative_to(ROOT)}: {line}'); continue
        digest,name=parts
        target=directory/name
        if not target.is_file(): errors.append(f'manifest target missing: {target.relative_to(ROOT)}'); continue
        actual=hashlib.sha256(target.read_bytes()).hexdigest()
        if actual != digest: errors.append(f'SHA mismatch: {target.relative_to(ROOT)}')

def evidence52():
    d=ROOT/'prisma/runtime-evidence-stage52'
    if not d.exists(): blocked.append('Stage 52 runtime evidence directory absent'); return
    verify_manifest(d)
    if (d/'06-schema-diff.result').read_text().strip() != 'Schema differential check: PASS': errors.append('Stage 52 schema differential is not explicit PASS')
    if not re.fullmatch(r'table_count expected=193 actual=193\n?', (d/'08-invariants.txt').read_text()): errors.append('Stage 52 193-table invariant is not proven')

def evidence53():
    d=ROOT/'prisma/runtime-evidence-stage53'
    if not d.exists(): blocked.append('Stage 53 runtime evidence directory absent'); return
    verify_manifest(d)
    if (d/'RESULT.txt').read_text().strip() != 'STAGE53 RUNTIME PASS': errors.append('Stage 53 RESULT is not explicit PASS')
    p=(d/'02-privilege-evidence.txt').read_text() if (d/'02-privilege-evidence.txt').exists() else ''
    if 'audit_update_priv=t' in p or 'audit_delete_priv=t' in p: errors.append('Stage 53 audit append-only privilege evidence is unsafe')

def evidence56():
    candidates=[ROOT/'prisma/runtime-evidence-stage56', ROOT/'stage56-runtime-evidence']
    d=next((x for x in candidates if x.exists()), None)
    if d is None: blocked.append('Stage 56 runtime evidence directory absent'); return
    verify_manifest(d)
    result=d/'RESULT.txt'
    if not result.is_file() or result.read_text().strip()!='STAGE56 RUNTIME PASS': errors.append('Stage 56 runtime RESULT is not explicit PASS')
    required=['stage56-cross-tenant.json','stage56-version-conflict.json','stage56-permission-denial.json','stage56-rollback.json']
    for n in required:
        if not (d/n).is_file(): errors.append(f'Stage 56 evidence missing: {n}')
    blocked.append('Stage 56 evidence directory present; endpoint semantics require fixture-specific independent review before release PASS')

def static_contracts():
    schema=read(ROOT/'prisma/schema.prisma')
    if len(re.findall(r'^model\s+\w+\s*\{', schema, re.M)) != 193: errors.append('schema model count is not 193')
    for rel in ['scripts/verify-stage50-runtime-catalog.py','scripts/verify-stage56-runtime-mutations.py']:
        if not (ROOT/rel).exists():
            # Stage 50 used shell gate in this tree; this is a compatibility check.
            if rel.endswith('verify-stage50-runtime-catalog.py'): continue
            errors.append(f'missing gate contract: {rel}')
    catalog=ROOT/'scripts/verify-stage50-runtime-catalog.sh'
    if not catalog.is_file(): errors.append('Stage 50 catalog gate missing')
    stage56=ROOT/'scripts/run-stage56-runtime.sh'
    if not stage56.is_file(): errors.append('Stage 56 runtime harness missing')

def main():
    static_contracts(); evidence52(); evidence53(); evidence56()
    if errors:
        print('STAGE57 RELEASE GATE: FAIL')
        for e in errors: print(' - '+e)
        sys.exit(1)
    if blocked:
        print('STAGE57 RELEASE GATE: BLOCKED')
        for b in blocked: print(' - '+b)
        print('Static contracts: PASS')
        print('Release verdict: BLOCKED until all required runtime evidence is present, independently reconciled, and fixture semantics are verified.')
        sys.exit(2)
    print('STAGE57 RELEASE GATE: PASS')
    print('Static contracts: PASS')
    print('Stage 52/53/56 evidence: PASS')
    print('Release verdict: PASS')

if __name__=='__main__': main()

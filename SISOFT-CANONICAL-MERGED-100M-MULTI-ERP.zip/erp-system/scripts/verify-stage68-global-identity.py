#!/usr/bin/env python3
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
policy = ROOT / "config/stage68-global-identity-policy.json"
doc = ROOT / "docs-STAGE68-GLOBAL-IDENTITY-AUTH-FEDERATION.md"
exc = ROOT / "docs-STAGE68-EXCEPTIONS.md"

p = json.loads(policy.read_text())
assert p["stage"] == 68
assert p["identity"]["tenant_identity_isolation"]
assert p["identity"]["tenant_context_must_be_explicit"]
assert p["federation"]["oidc"]["issuer_allowlist_required"]
assert p["federation"]["oidc"]["audience_validation_required"]
assert p["federation"]["saml"]["assertion_signature_validation_required"]
assert p["tokens"]["tenant_claim_must_match_authorized_context"]
assert p["tokens"]["region_claim_must_not_override_placement"]
assert p["authorization"]["control_plane_rbac"]
assert p["authorization"]["separation_of_duties"]
assert p["authorization"]["service_to_service_authorization"]
assert p["keys"]["key_versioning"] and p["keys"]["revocation_or_disable_mechanism"]
assert p["sessions"]["csrf_protection_for_cookie_auth"]
assert p["sessions"]["session_fixation_protection"]
required = [
    "oidc_login_and_audience_validation", "saml_assertion_validation",
    "tenant_context_confusion_rejection", "service_to_service_authorization",
    "control_plane_sod_enforcement", "key_rotation_overlap_and_retirement",
    "token_revocation_or_disable", "break_glass_scope_expiry_and_audit",
    "regional_failover_with_identity_verification", "evidence_sha256"
]
assert p["runtime_evidence_required"] == required
text = doc.read_text().lower()
for phrase in [
    "identity boundaries", "oidc", "saml", "audience validation",
    "region claims cannot override", "separation-of-duties", "key lifecycle",
    "break-glass", "runtime pass", "provider-specific"
]:
    assert phrase in text, phrase
ex = exc.read_text().lower()
for phrase in ["fabricated", "fail closed", "runtime pass", "break-glass"]:
    assert phrase in ex, phrase
print("STAGE68 STATIC PASS")
print("Identity matrix: tenant isolation, OIDC/SAML federation, token/placement validation, control-plane RBAC/SoD, service authorization, key lifecycle, session security, break-glass")
print("Runtime verdict: BLOCKED until representative identity providers, key infrastructure, service identities and regional failover evidence are supplied")

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
tsc -p packages/payroll-country-plugins/tsconfig.json --noEmit
rm -rf packages/payroll-country-plugins/dist
npx tsc -p packages/payroll-country-plugins/tsconfig.json >/dev/null 2>&1 || tsc -p packages/payroll-country-plugins/tsconfig.json >/dev/null
node - <<'NODE'
const p=require('./packages/payroll-country-plugins/dist');
if(p.computeAnnualTaxPK(600000)!==0) throw Error('PK threshold');
if(p.computeAnnualTaxPK(2400000)!==156000) throw Error('PK example');
if(p.marginalRatePK(8000000)!==35) throw Error('PK top rate');
if(p.saPlugin.getLaborLawRules().calculateGratuity(7,30000)!==135000) throw Error('SA EOSG');
if(p.computeAnnualTaxIN(1275000).tax!==0) throw Error('IN rebate');
if(p.computeAnnualFederalTaxUS(16100)!==0) throw Error('US deduction');
console.log('Stage 32 static + self-test PASS');
NODE

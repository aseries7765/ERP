#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts/verify-stage67-control-plane.py"

required=(
  STAGE67_PROVISIONING_REPLAY_COMMAND
  STAGE67_PARTIAL_PROVISIONING_RECOVERY_COMMAND
  STAGE67_SUSPEND_REACTIVATE_COMMAND
  STAGE67_QUOTA_PROPAGATION_COMMAND
  STAGE67_PROVIDER_ADAPTER_COMMAND
  STAGE67_CONTROL_PLANE_FAILOVER_COMMAND
  STAGE67_TENANT_MOVE_COMMAND
  STAGE67_POST_MOVE_ISOLATION_COMMAND
  STAGE67_ORPHAN_SPLIT_BRAIN_COMMAND
  STAGE67_EVIDENCE_SHA256_COMMAND
)
for name in "${required[@]}"; do
  [[ -n "${!name:-}" ]] || { echo "RUNTIME BLOCKED: missing $name"; exit 2; }
done

for name in "${required[@]}"; do
  echo "Running $name"
  bash -lc "${!name}"
done

echo "STAGE67 RUNTIME PASS — control-plane lifecycle, failover and tenant-movement evidence commands completed successfully"

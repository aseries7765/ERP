#!/usr/bin/env python3
import json, pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
policy = ROOT / 'config/stage66-distributed-consistency-policy.json'
doc = ROOT / 'docs-STAGE66-DISTRIBUTED-CONSISTENCY-IDEMPOTENCY.md'
exc = ROOT / 'docs-STAGE66-EXCEPTIONS.md'

required_policy = [
    ('workflow','cross_shard_transaction'), ('workflow','compensation'),
    ('idempotency','required_for'), ('idempotency','conflicting_reuse'),
    ('messaging','outbox'), ('messaging','inbox'), ('messaging','exactly_once'),
    ('retries','backoff'), ('failure_recovery','timeout'),
    ('security_and_tenancy','tenant_context'), ('runtime_evidence_required', None)
]
required_doc = [
    'local state', 'outbox', 'idempotent', 'at-least-once',
    'Exactly-once', 'unknown outcome', 'compensation',
    'tenant and shard', '100M+ scale', 'Runtime gate'
]

def fail(msg):
    print(f'STAGE66 STATIC FAIL: {msg}')
    sys.exit(1)

try:
    data = json.loads(policy.read_text())
except Exception as e:
    fail(f'invalid policy JSON: {e}')

for section, key in required_policy:
    if key is None:
        if not data.get(section): fail(f'missing {section}')
    elif not data.get(section, {}).get(key):
        fail(f'missing {section}.{key}')

evidence = data['runtime_evidence_required']
if len(evidence) < 8 or 'evidence_sha256' not in evidence:
    fail('runtime evidence contract incomplete')

text = doc.read_text()
for phrase in required_doc:
    if phrase.lower() not in text.lower(): fail(f'document missing required concept: {phrase}')

exceptions = exc.read_text().lower()
for phrase in ['exactly-once', 'runtime status is blocked', 'fabricated throughput', 'unknown external outcomes']:
    if phrase.lower() not in exceptions: fail(f'exceptions missing guard: {phrase}')

if re.search(r'\b(?:measured|verified|achieved)\s+(?:throughput|capacity|latency)\b', text, re.I):
    fail('document contains unqualified measured capacity wording')

print('STAGE66 STATIC PASS')
print('Distributed consistency matrix: local atomicity, saga compensation, idempotency, outbox/inbox, retries, recovery, tenant/shard context')
print('Runtime verdict: BLOCKED until real multi-shard workflow infrastructure and controlled failure-injection evidence are supplied')

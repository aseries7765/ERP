#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts/verify-stage66-distributed-consistency.py"

required=(
  STAGE66_WORKFLOW_TEST_COMMAND
  STAGE66_DUPLICATE_REPLAY_COMMAND
  STAGE66_MESSAGE_REDELIVERY_COMMAND
  STAGE66_CRASH_AFTER_SIDE_EFFECT_COMMAND
  STAGE66_UNKNOWN_OUTCOME_RECONCILIATION_COMMAND
  STAGE66_COMPENSATION_FAILURE_COMMAND
  STAGE66_DEAD_LETTER_RECOVERY_COMMAND
  STAGE66_CONTEXT_VALIDATION_COMMAND
  STAGE66_EVIDENCE_SHA256_COMMAND
)
for name in "${required[@]}"; do
  [[ -n "${!name:-}" ]] || { echo "RUNTIME BLOCKED: missing $name"; exit 2; }
done

for name in "${required[@]}"; do
  echo "Running $name"
  bash -lc "${!name}"
done

echo "STAGE66 RUNTIME PASS — distributed consistency evidence commands completed successfully"

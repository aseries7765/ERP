CREATE TABLE "finance_budgets" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "name" TEXT NOT NULL,
  "fiscalYearId" UUID NOT NULL, "currency" CHAR(3) NOT NULL, "status" TEXT NOT NULL DEFAULT 'draft',
  "version" INTEGER NOT NULL DEFAULT 1, "createdAt" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL,
  "deletedAt" TIMESTAMPTZ, "metadata" JSONB
);
CREATE INDEX "finance_budgets_tenant_fy_idx" ON "finance_budgets"("tenantId","fiscalYearId");
CREATE INDEX "finance_budgets_tenant_status_idx" ON "finance_budgets"("tenantId","status");
CREATE INDEX "finance_budgets_tenant_deleted_idx" ON "finance_budgets"("tenantId","deletedAt");
CREATE TABLE "finance_budget_lines" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "budgetId" UUID NOT NULL,
  "lineNo" INTEGER NOT NULL, "accountId" UUID NOT NULL, "costCenterId" UUID, "period" INTEGER NOT NULL,
  "amount" NUMERIC(18,2) NOT NULL, "currency" CHAR(3) NOT NULL, "createdAt" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL,
  "deletedAt" TIMESTAMPTZ, "version" INTEGER NOT NULL DEFAULT 1,
  CONSTRAINT "finance_budget_lines_period_chk" CHECK ("period" BETWEEN 1 AND 12),
  CONSTRAINT "finance_budget_lines_amount_chk" CHECK ("amount" >= 0),
  CONSTRAINT "finance_budget_lines_budget_fk" FOREIGN KEY ("budgetId") REFERENCES "finance_budgets"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "finance_budget_lines_cost_center_fk" FOREIGN KEY ("costCenterId") REFERENCES "cost_centers"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "finance_budget_lines_tenant_budget_lineno_uq" ON "finance_budget_lines"("tenantId","budgetId","lineNo");
CREATE INDEX "finance_budget_lines_account_period_idx" ON "finance_budget_lines"("tenantId","accountId","period");
CREATE INDEX "finance_budget_lines_cc_period_idx" ON "finance_budget_lines"("tenantId","costCenterId","period");
CREATE INDEX "finance_budget_lines_deleted_idx" ON "finance_budget_lines"("tenantId","deletedAt");
ALTER TABLE "finance_journal_lines" ADD COLUMN "costCenterId" UUID;
ALTER TABLE "finance_journal_lines" ADD CONSTRAINT "finance_journal_lines_cost_center_fk" FOREIGN KEY ("costCenterId") REFERENCES "cost_centers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
CREATE INDEX "finance_journal_lines_cost_center_idx" ON "finance_journal_lines"("tenantId","costCenterId");

CREATE TABLE "event_deliveries" (
  "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
  "tenantId" uuid NOT NULL,
  "outboxId" uuid NOT NULL,
  "target" text NOT NULL,
  "deliveredAt" timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdAt" timestamptz(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "event_deliveries_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "event_deliveries_outboxId_target_key" ON "event_deliveries"("outboxId","target");
CREATE INDEX "event_deliveries_tenantId_target_deliveredAt_idx" ON "event_deliveries"("tenantId","target","deliveredAt");
ALTER TABLE "event_deliveries" ADD CONSTRAINT "event_deliveries_outboxId_fkey" FOREIGN KEY ("outboxId") REFERENCES "event_outbox"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "event_deliveries" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "event_deliveries" FORCE ROW LEVEL SECURITY;
CREATE POLICY "event_deliveries_tenant_isolation" ON "event_deliveries" USING ("tenantId"::text = current_setting('app.current_tenant', true));

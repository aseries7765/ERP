CREATE TABLE "finance_tax_rates" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" uuid NOT NULL,
  "code" text NOT NULL, "name" text NOT NULL, "rate" numeric(9,6) NOT NULL,
  "kind" text NOT NULL DEFAULT 'SALES', "taxAccountId" uuid NOT NULL,
  "effectiveFrom" date NOT NULL, "effectiveTo" date, "isActive" boolean NOT NULL DEFAULT true,
  "createdAt" timestamptz NOT NULL DEFAULT now(), "updatedAt" timestamptz NOT NULL DEFAULT now(),
  "createdBy" uuid NOT NULL, "updatedBy" uuid NOT NULL, "deletedAt" timestamptz,
  "version" integer NOT NULL DEFAULT 1, "metadata" jsonb
);
CREATE UNIQUE INDEX "finance_tax_rates_tenantId_code_key" ON "finance_tax_rates"("tenantId","code");
CREATE INDEX "finance_tax_rates_tenantId_isActive_effectiveFrom_idx" ON "finance_tax_rates"("tenantId","isActive","effectiveFrom");
CREATE INDEX "finance_tax_rates_tenantId_deletedAt_idx" ON "finance_tax_rates"("tenantId","deletedAt");
ALTER TABLE "finance_tax_rates" ADD CONSTRAINT "finance_tax_rates_rate_chk" CHECK ("rate" >= 0 AND "rate" <= 100);
ALTER TABLE "finance_tax_rates" ADD CONSTRAINT "finance_tax_rates_kind_chk" CHECK ("kind" IN ('SALES','PURCHASE'));
ALTER TABLE "finance_tax_rates" ADD CONSTRAINT "finance_tax_rates_dates_chk" CHECK ("effectiveTo" IS NULL OR "effectiveTo" >= "effectiveFrom");

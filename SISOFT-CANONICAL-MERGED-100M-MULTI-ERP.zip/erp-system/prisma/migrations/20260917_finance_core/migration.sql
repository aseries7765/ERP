CREATE TABLE IF NOT EXISTS "finance_number_sequences" (
 "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL UNIQUE, "nextValue" INTEGER NOT NULL DEFAULT 10001,
 "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL,
 "deletedAt" TIMESTAMPTZ, "version" INTEGER NOT NULL DEFAULT 1, "metadata" JSONB
);
CREATE TABLE IF NOT EXISTS "finance_ledger_accounts" (
 "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "code" TEXT NOT NULL, "name" TEXT NOT NULL, "type" TEXT NOT NULL,
 "isPostable" BOOLEAN NOT NULL DEFAULT true, "isLocked" BOOLEAN NOT NULL DEFAULT false, "parentId" UUID, "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, "version" INTEGER NOT NULL DEFAULT 1, "metadata" JSONB,
 CONSTRAINT "finance_ledger_accounts_type_chk" CHECK ("type" IN ('asset','liability','equity','revenue','expense')),
 CONSTRAINT "finance_ledger_accounts_code_uq" UNIQUE ("tenantId","code")
);
CREATE TABLE IF NOT EXISTS "finance_journal_entries" (
 "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "number" TEXT NOT NULL, "status" TEXT NOT NULL DEFAULT 'draft', "description" TEXT,
 "entryDate" DATE NOT NULL, "currency" CHAR(3) NOT NULL, "postedAt" TIMESTAMPTZ, "reversedAt" TIMESTAMPTZ, "reversedBy" UUID,
 "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, "version" INTEGER NOT NULL DEFAULT 1, "metadata" JSONB,
 CONSTRAINT "finance_journal_entries_number_uq" UNIQUE ("tenantId","number"), CONSTRAINT "finance_journal_entries_status_chk" CHECK ("status" IN ('draft','posted','reversed'))
);
CREATE TABLE IF NOT EXISTS "finance_journal_lines" (
 "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "journalId" UUID NOT NULL, "lineNo" INTEGER NOT NULL, "accountId" UUID NOT NULL, "side" TEXT NOT NULL,
 "amount" NUMERIC(18,2) NOT NULL, "currency" CHAR(3) NOT NULL, "description" TEXT, "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, "version" INTEGER NOT NULL DEFAULT 1, "metadata" JSONB,
 CONSTRAINT "finance_journal_lines_side_chk" CHECK ("side" IN ('DEBIT','CREDIT')), CONSTRAINT "finance_journal_lines_amount_chk" CHECK ("amount" > 0), CONSTRAINT "finance_journal_lines_uq" UNIQUE ("tenantId","journalId","lineNo"),
 CONSTRAINT "finance_journal_lines_journal_fk" FOREIGN KEY ("journalId") REFERENCES "finance_journal_entries"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "finance_ledger_accounts_tenant_deleted_idx" ON "finance_ledger_accounts"("tenantId","deletedAt");
CREATE INDEX IF NOT EXISTS "finance_journal_entries_tenant_status_idx" ON "finance_journal_entries"("tenantId","status");
CREATE INDEX IF NOT EXISTS "finance_journal_entries_tenant_date_idx" ON "finance_journal_entries"("tenantId","entryDate");
CREATE INDEX IF NOT EXISTS "finance_journal_lines_tenant_account_idx" ON "finance_journal_lines"("tenantId","accountId");

CREATE TABLE "finance_posting_profiles" (
  "id" UUID NOT NULL DEFAULT uuid_generate_v7(),
  "tenantId" UUID NOT NULL,
  "accountsReceivable" UUID NOT NULL,
  "salesRevenue" UUID NOT NULL,
  "taxPayable" UUID NOT NULL,
  "cashOrBank" UUID NOT NULL,
  "accountsPayable" UUID NOT NULL,
  "purchaseExpense" UUID NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdBy" UUID NOT NULL,
  "updatedBy" UUID NOT NULL,
  "deletedAt" TIMESTAMP(3),
  "version" INTEGER NOT NULL DEFAULT 1,
  "metadata" JSONB,
  CONSTRAINT "finance_posting_profiles_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "finance_posting_profiles_tenantId_key" UNIQUE ("tenantId")
);

CREATE TABLE "finance_postings" (
  "id" UUID NOT NULL DEFAULT uuid_generate_v7(),
  "tenantId" UUID NOT NULL,
  "sourceType" TEXT NOT NULL,
  "sourceId" UUID NOT NULL,
  "journalId" UUID NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdBy" UUID NOT NULL,
  "updatedBy" UUID NOT NULL,
  "deletedAt" TIMESTAMP(3),
  "version" INTEGER NOT NULL DEFAULT 1,
  "metadata" JSONB,
  CONSTRAINT "finance_postings_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "finance_postings_tenantId_sourceType_sourceId_key" UNIQUE ("tenantId", "sourceType", "sourceId")
);
CREATE INDEX "finance_postings_tenantId_journalId_idx" ON "finance_postings"("tenantId","journalId");

CREATE TABLE IF NOT EXISTS "finance_vendor_bills" (
  "id" UUID NOT NULL DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "number" TEXT NOT NULL,
  "vendorId" UUID NOT NULL, "purchaseOrderId" UUID, "status" TEXT NOT NULL DEFAULT 'draft',
  "issueDate" TIMESTAMPTZ NOT NULL DEFAULT now(), "dueDate" TIMESTAMPTZ, "currency" CHAR(3) NOT NULL DEFAULT 'USD',
  "subtotal" NUMERIC(18,2) NOT NULL DEFAULT 0, "taxAmount" NUMERIC(18,2) NOT NULL DEFAULT 0, "total" NUMERIC(18,2) NOT NULL DEFAULT 0,
  "amountPaid" NUMERIC(18,2) NOT NULL DEFAULT 0, "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, "version" INTEGER NOT NULL DEFAULT 1, "metadata" JSONB,
  CONSTRAINT "finance_vendor_bills_pkey" PRIMARY KEY ("id"), CONSTRAINT "finance_vendor_bills_number_uq" UNIQUE ("tenantId","number"),
  CONSTRAINT "finance_vendor_bills_status_chk" CHECK ("status" IN ('draft','approved','posted','cancelled')),
  CONSTRAINT "finance_vendor_bills_amounts_chk" CHECK ("subtotal" >= 0 AND "taxAmount" >= 0 AND "total" > 0 AND "amountPaid" >= 0 AND "amountPaid" <= "total"),
  CONSTRAINT "finance_vendor_bills_total_chk" CHECK ("total" = "subtotal" + "taxAmount")
);
CREATE INDEX IF NOT EXISTS "finance_vendor_bills_tenant_vendor_status_idx" ON "finance_vendor_bills"("tenantId","vendorId","status");
CREATE INDEX IF NOT EXISTS "finance_vendor_bills_tenant_po_idx" ON "finance_vendor_bills"("tenantId","purchaseOrderId");
CREATE TABLE IF NOT EXISTS "finance_vendor_payments" (
  "id" UUID NOT NULL DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "billId" UUID NOT NULL,
  "amount" NUMERIC(18,2) NOT NULL, "currency" CHAR(3) NOT NULL DEFAULT 'USD', "method" TEXT, "reference" TEXT,
  "paidAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, "version" INTEGER NOT NULL DEFAULT 1, "metadata" JSONB,
  CONSTRAINT "finance_vendor_payments_pkey" PRIMARY KEY ("id"), CONSTRAINT "finance_vendor_payments_amount_chk" CHECK ("amount" > 0)
);
CREATE INDEX IF NOT EXISTS "finance_vendor_payments_tenant_bill_idx" ON "finance_vendor_payments"("tenantId","billId");

CREATE TABLE IF NOT EXISTS "finance_year_end_closes" (
  "id" UUID NOT NULL DEFAULT uuid_generate_v7(),
  "tenantId" UUID NOT NULL,
  "fiscalYearId" UUID NOT NULL,
  "retainedEarningsAccountId" UUID NOT NULL,
  "journalId" UUID,
  "currency" CHAR(3) NOT NULL,
  "revenueClosed" NUMERIC(18,2) NOT NULL,
  "expenseClosed" NUMERIC(18,2) NOT NULL,
  "netIncome" NUMERIC(18,2) NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'COMPLETED',
  "closedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "createdBy" UUID NOT NULL,
  "updatedBy" UUID NOT NULL,
  "deletedAt" TIMESTAMPTZ,
  "version" INTEGER NOT NULL DEFAULT 1,
  "metadata" JSONB,
  CONSTRAINT "finance_year_end_closes_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "finance_year_end_closes_status_chk" CHECK ("status" IN ('COMPLETED','VOIDED')),
  CONSTRAINT "finance_year_end_closes_currency_chk" CHECK ("currency" ~ '^[A-Z]{3}$'),
  CONSTRAINT "finance_year_end_closes_uq" UNIQUE ("tenantId","fiscalYearId","currency")
);
CREATE INDEX IF NOT EXISTS "finance_year_end_closes_tenant_fy_idx" ON "finance_year_end_closes"("tenantId","fiscalYearId");

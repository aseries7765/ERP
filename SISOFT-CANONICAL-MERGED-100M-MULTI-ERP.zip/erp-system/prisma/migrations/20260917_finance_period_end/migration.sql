CREATE TABLE IF NOT EXISTS finance_journal_templates (
 id UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, code TEXT NOT NULL, name TEXT NOT NULL,
 currency CHAR(3) NOT NULL, "isActive" BOOLEAN NOT NULL DEFAULT TRUE, "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
 "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, version INTEGER NOT NULL DEFAULT 1, metadata JSONB,
 CONSTRAINT finance_journal_templates_tenant_code_key UNIQUE ("tenantId",code)
);
CREATE TABLE IF NOT EXISTS finance_journal_template_lines (
 id UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "templateId" UUID NOT NULL, "lineNo" INTEGER NOT NULL,
 "accountId" UUID NOT NULL, "costCenterId" UUID, side TEXT NOT NULL, amount NUMERIC(18,2) NOT NULL, description TEXT,
 "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, version INTEGER NOT NULL DEFAULT 1, metadata JSONB,
 CONSTRAINT finance_journal_template_lines_key UNIQUE ("tenantId","templateId","lineNo"), CONSTRAINT finance_journal_template_lines_template_fk FOREIGN KEY ("templateId") REFERENCES finance_journal_templates(id)
);
CREATE TABLE IF NOT EXISTS finance_recurring_journals (
 id UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "templateId" UUID NOT NULL, code TEXT NOT NULL, frequency TEXT NOT NULL,
 "nextRunDate" DATE NOT NULL, "endDate" DATE, status TEXT NOT NULL DEFAULT 'ACTIVE', "lastRunDate" DATE,
 "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, version INTEGER NOT NULL DEFAULT 1, metadata JSONB,
 CONSTRAINT finance_recurring_journals_tenant_code_key UNIQUE ("tenantId",code), CONSTRAINT finance_recurring_journals_template_fk FOREIGN KEY ("templateId") REFERENCES finance_journal_templates(id),
 CONSTRAINT finance_recurring_journals_frequency_chk CHECK (frequency IN ('MONTHLY','QUARTERLY','YEARLY'))
);
CREATE TABLE IF NOT EXISTS finance_accruals (
 id UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, code TEXT NOT NULL, description TEXT NOT NULL, currency CHAR(3) NOT NULL,
 "totalAmount" NUMERIC(18,2) NOT NULL, "startDate" DATE NOT NULL, "endDate" DATE NOT NULL, "expenseAccountId" UUID NOT NULL, "offsetAccountId" UUID NOT NULL,
 status TEXT NOT NULL DEFAULT 'DRAFT', "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, version INTEGER NOT NULL DEFAULT 1, metadata JSONB,
 CONSTRAINT finance_accruals_tenant_code_key UNIQUE ("tenantId",code), CONSTRAINT finance_accruals_amount_chk CHECK ("totalAmount" > 0), CONSTRAINT finance_accruals_dates_chk CHECK ("endDate" >= "startDate")
);
CREATE TABLE IF NOT EXISTS finance_accrual_recognitions (
 id UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "accrualId" UUID NOT NULL, "periodDate" DATE NOT NULL, amount NUMERIC(18,2) NOT NULL,
 status TEXT NOT NULL DEFAULT 'SCHEDULED', "journalId" UUID, "postedAt" TIMESTAMPTZ, "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, version INTEGER NOT NULL DEFAULT 1, metadata JSONB,
 CONSTRAINT finance_accrual_recognitions_key UNIQUE ("tenantId","accrualId","periodDate"), CONSTRAINT finance_accrual_recognitions_accrual_fk FOREIGN KEY ("accrualId") REFERENCES finance_accruals(id), CONSTRAINT finance_accrual_recognitions_amount_chk CHECK (amount > 0)
);
CREATE INDEX IF NOT EXISTS finance_journal_templates_tenant_active_idx ON finance_journal_templates("tenantId","isActive");
CREATE INDEX IF NOT EXISTS finance_journal_template_lines_account_idx ON finance_journal_template_lines("tenantId","accountId");
CREATE INDEX IF NOT EXISTS finance_recurring_journals_due_idx ON finance_recurring_journals("tenantId",status,"nextRunDate");
CREATE INDEX IF NOT EXISTS finance_accruals_status_dates_idx ON finance_accruals("tenantId",status,"startDate","endDate");
CREATE INDEX IF NOT EXISTS finance_accrual_recognitions_due_idx ON finance_accrual_recognitions("tenantId",status,"periodDate");

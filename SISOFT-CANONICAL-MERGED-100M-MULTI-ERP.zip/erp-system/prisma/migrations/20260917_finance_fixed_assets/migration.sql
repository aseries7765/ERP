ALTER TABLE finance_posting_profiles ADD COLUMN IF NOT EXISTS "fixedAsset" UUID;
ALTER TABLE finance_posting_profiles ADD COLUMN IF NOT EXISTS "depreciationExpense" UUID;
ALTER TABLE finance_posting_profiles ADD COLUMN IF NOT EXISTS "accumulatedDepreciation" UUID;
ALTER TABLE finance_posting_profiles ADD COLUMN IF NOT EXISTS "disposalGainLoss" UUID;

CREATE TABLE IF NOT EXISTS finance_fixed_assets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
  "tenantId" UUID NOT NULL,
  "assetNumber" TEXT NOT NULL,
  name TEXT NOT NULL,
  category TEXT,
  currency CHAR(3) NOT NULL,
  "acquisitionCost" NUMERIC(18,2) NOT NULL,
  "salvageValue" NUMERIC(18,2) NOT NULL DEFAULT 0,
  "usefulLifeMonths" INTEGER NOT NULL,
  "depreciationMethod" TEXT NOT NULL DEFAULT 'STRAIGHT_LINE',
  "placedInServiceDate" DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  "accumulatedDepreciation" NUMERIC(18,2) NOT NULL DEFAULT 0,
  "disposedAt" TIMESTAMPTZ,
  "disposalProceeds" NUMERIC(18,2),
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "createdBy" UUID NOT NULL,
  "updatedBy" UUID NOT NULL,
  "deletedAt" TIMESTAMPTZ,
  version INTEGER NOT NULL DEFAULT 1,
  metadata JSONB,
  CONSTRAINT finance_fixed_assets_amounts_ck CHECK ("acquisitionCost" > 0 AND "salvageValue" >= 0 AND "salvageValue" <= "acquisitionCost"),
  CONSTRAINT finance_fixed_assets_life_ck CHECK ("usefulLifeMonths" > 0),
  CONSTRAINT finance_fixed_assets_method_ck CHECK ("depreciationMethod" = 'STRAIGHT_LINE'),
  CONSTRAINT finance_fixed_assets_status_ck CHECK (status IN ('DRAFT','ACTIVE','FULLY_DEPRECIATED','DISPOSED'))
);
CREATE UNIQUE INDEX IF NOT EXISTS finance_fixed_assets_tenant_number_uq ON finance_fixed_assets("tenantId","assetNumber");
CREATE INDEX IF NOT EXISTS finance_fixed_assets_tenant_status_idx ON finance_fixed_assets("tenantId",status);
CREATE INDEX IF NOT EXISTS finance_fixed_assets_tenant_service_idx ON finance_fixed_assets("tenantId","placedInServiceDate");

CREATE TABLE IF NOT EXISTS finance_fixed_asset_depreciations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
  "tenantId" UUID NOT NULL,
  "assetId" UUID NOT NULL,
  "periodStart" DATE NOT NULL,
  "periodEnd" DATE NOT NULL,
  depreciation NUMERIC(18,2) NOT NULL,
  "openingNBV" NUMERIC(18,2) NOT NULL,
  "closingNBV" NUMERIC(18,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'SCHEDULED',
  "journalId" UUID,
  "postedAt" TIMESTAMPTZ,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "createdBy" UUID NOT NULL,
  "updatedBy" UUID NOT NULL,
  "deletedAt" TIMESTAMPTZ,
  version INTEGER NOT NULL DEFAULT 1,
  metadata JSONB,
  CONSTRAINT finance_fixed_asset_depr_amount_ck CHECK (depreciation > 0 AND "openingNBV" >= "closingNBV" AND "closingNBV" >= 0),
  CONSTRAINT finance_fixed_asset_depr_status_ck CHECK (status IN ('SCHEDULED','POSTED','VOID'))
);
CREATE UNIQUE INDEX IF NOT EXISTS finance_fixed_asset_depr_tenant_asset_period_uq ON finance_fixed_asset_depreciations("tenantId","assetId","periodStart");
CREATE INDEX IF NOT EXISTS finance_fixed_asset_depr_tenant_asset_status_idx ON finance_fixed_asset_depreciations("tenantId","assetId",status);
CREATE INDEX IF NOT EXISTS finance_fixed_asset_depr_tenant_period_idx ON finance_fixed_asset_depreciations("tenantId","periodStart");

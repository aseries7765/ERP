CREATE TABLE IF NOT EXISTS finance_exchange_rates (
 id uuid PRIMARY KEY DEFAULT uuid_generate_v7(), tenant_id uuid NOT NULL, from_currency varchar(3) NOT NULL, to_currency varchar(3) NOT NULL,
 rate numeric(20,10) NOT NULL CHECK(rate>0), effective_date date NOT NULL, source text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), created_by uuid NOT NULL, updated_by uuid NOT NULL, deleted_at timestamptz, version integer NOT NULL DEFAULT 1, metadata jsonb,
 CONSTRAINT finance_exchange_rates_uq UNIQUE(tenant_id,from_currency,to_currency,effective_date));
CREATE INDEX IF NOT EXISTS finance_exchange_rates_lookup ON finance_exchange_rates(tenant_id,from_currency,to_currency,effective_date);
CREATE TABLE IF NOT EXISTS finance_fx_revaluations (
 id uuid PRIMARY KEY DEFAULT uuid_generate_v7(), tenant_id uuid NOT NULL, account_id uuid NOT NULL, currency varchar(3) NOT NULL, base_currency varchar(3) NOT NULL, as_of_date date NOT NULL,
 old_rate numeric(20,10) NOT NULL, new_rate numeric(20,10) NOT NULL, foreign_balance numeric(18,2) NOT NULL, old_base_value numeric(18,2) NOT NULL, new_base_value numeric(18,2) NOT NULL, difference numeric(18,2) NOT NULL, journal_id uuid, status text NOT NULL DEFAULT 'CALCULATED', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), created_by uuid NOT NULL, updated_by uuid NOT NULL, deleted_at timestamptz, version integer NOT NULL DEFAULT 1, metadata jsonb,
 CONSTRAINT finance_fx_revaluations_uq UNIQUE(tenant_id,account_id,currency,base_currency,as_of_date));
CREATE INDEX IF NOT EXISTS finance_fx_revaluations_lookup ON finance_fx_revaluations(tenant_id,as_of_date);

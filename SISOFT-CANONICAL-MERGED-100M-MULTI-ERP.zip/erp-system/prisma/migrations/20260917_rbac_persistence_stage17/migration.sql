-- Stage 17: RBAC persistence reconciliation
CREATE TABLE IF NOT EXISTS "group_permissions" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
  "tenantId" UUID NOT NULL,
  "groupId" UUID NOT NULL,
  "permissionId" UUID NOT NULL,
  "effect" TEXT NOT NULL DEFAULT 'ALLOW',
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "createdBy" UUID NOT NULL,
  CONSTRAINT "group_permissions_group_fk" FOREIGN KEY ("groupId") REFERENCES "groups"("id"),
  CONSTRAINT "group_permissions_permission_fk" FOREIGN KEY ("permissionId") REFERENCES "permissions"("id"),
  CONSTRAINT "group_permissions_unique" UNIQUE ("tenantId", "groupId", "permissionId")
);
CREATE INDEX IF NOT EXISTS "group_permissions_tenant_group_idx" ON "group_permissions" ("tenantId", "groupId");

CREATE TABLE IF NOT EXISTS "policy_permissions" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
  "tenantId" UUID NOT NULL,
  "policyId" UUID NOT NULL,
  "permissionId" UUID NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT "policy_permissions_policy_fk" FOREIGN KEY ("policyId") REFERENCES "policies"("id"),
  CONSTRAINT "policy_permissions_permission_fk" FOREIGN KEY ("permissionId") REFERENCES "permissions"("id"),
  CONSTRAINT "policy_permissions_unique" UNIQUE ("tenantId", "policyId", "permissionId")
);
CREATE INDEX IF NOT EXISTS "policy_permissions_tenant_policy_idx" ON "policy_permissions" ("tenantId", "policyId");

CREATE TABLE IF NOT EXISTS "delegation_permissions" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(),
  "tenantId" UUID NOT NULL,
  "delegationId" UUID NOT NULL,
  "permissionId" UUID NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT "delegation_permissions_delegation_fk" FOREIGN KEY ("delegationId") REFERENCES "delegations"("id"),
  CONSTRAINT "delegation_permissions_permission_fk" FOREIGN KEY ("permissionId") REFERENCES "permissions"("id"),
  CONSTRAINT "delegation_permissions_unique" UNIQUE ("tenantId", "delegationId", "permissionId")
);
CREATE INDEX IF NOT EXISTS "delegation_permissions_tenant_delegation_idx" ON "delegation_permissions" ("tenantId", "delegationId");

CREATE TABLE "event_outbox" (
  "id" UUID NOT NULL DEFAULT uuid_generate_v7(),
  "tenantId" UUID NOT NULL,
  "aggregateType" TEXT NOT NULL,
  "aggregateId" UUID,
  "eventType" TEXT NOT NULL,
  "dedupeKey" TEXT NOT NULL,
  "payload" JSONB NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "attempts" INTEGER NOT NULL DEFAULT 0,
  "maxAttempts" INTEGER NOT NULL DEFAULT 12,
  "availableAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "lockedAt" TIMESTAMPTZ,
  "lockedBy" TEXT,
  "publishedAt" TIMESTAMPTZ,
  "lastError" TEXT,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT "event_outbox_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "event_outbox_tenant_dedupe_key" UNIQUE ("tenantId", "dedupeKey")
);
CREATE INDEX "event_outbox_status_available_idx" ON "event_outbox" ("status", "availableAt");
CREATE INDEX "event_outbox_tenant_status_available_idx" ON "event_outbox" ("tenantId", "status", "availableAt");
CREATE INDEX "event_outbox_locked_idx" ON "event_outbox" ("lockedBy", "lockedAt");
ALTER TABLE "event_outbox" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "event_outbox" FORCE ROW LEVEL SECURITY;
CREATE POLICY "event_outbox_tenant_isolation" ON "event_outbox" USING ("tenantId"::text = current_setting('app.current_tenant', true));

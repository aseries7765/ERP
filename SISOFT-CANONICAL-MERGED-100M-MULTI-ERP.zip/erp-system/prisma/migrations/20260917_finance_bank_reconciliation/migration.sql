CREATE TABLE IF NOT EXISTS "finance_bank_accounts" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "name" TEXT NOT NULL,
  "bankName" TEXT, "accountNumber" TEXT, "currency" CHAR(3) NOT NULL, "ledgerAccountId" UUID NOT NULL,
  "openingBalance" NUMERIC(18,2) NOT NULL DEFAULT 0, "status" TEXT NOT NULL DEFAULT 'active',
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, "version" INTEGER NOT NULL DEFAULT 1, "metadata" JSONB,
  CONSTRAINT "finance_bank_accounts_name_uq" UNIQUE ("tenantId","name"),
  CONSTRAINT "finance_bank_accounts_currency_chk" CHECK ("currency" ~ '^[A-Z]{3}$'),
  CONSTRAINT "finance_bank_accounts_status_chk" CHECK ("status" IN ('active','closed'))
);
CREATE INDEX IF NOT EXISTS "finance_bank_accounts_tenant_ledger_idx" ON "finance_bank_accounts"("tenantId","ledgerAccountId");
CREATE INDEX IF NOT EXISTS "finance_bank_accounts_tenant_status_idx" ON "finance_bank_accounts"("tenantId","status");

CREATE TABLE IF NOT EXISTS "finance_bank_transactions" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "bankAccountId" UUID NOT NULL,
  "externalId" TEXT NOT NULL, "transactionDate" DATE NOT NULL, "valueDate" DATE, "description" TEXT, "reference" TEXT,
  "amount" NUMERIC(18,2) NOT NULL, "currency" CHAR(3) NOT NULL, "status" TEXT NOT NULL DEFAULT 'unmatched',
  "matchedJournalLineId" UUID, "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, "version" INTEGER NOT NULL DEFAULT 1, "metadata" JSONB,
  CONSTRAINT "finance_bank_transactions_external_uq" UNIQUE ("tenantId","bankAccountId","externalId"),
  CONSTRAINT "finance_bank_transactions_match_uq" UNIQUE ("tenantId","matchedJournalLineId"),
  CONSTRAINT "finance_bank_transactions_amount_chk" CHECK ("amount" <> 0),
  CONSTRAINT "finance_bank_transactions_status_chk" CHECK ("status" IN ('unmatched','matched','ignored')),
  CONSTRAINT "finance_bank_transactions_currency_chk" CHECK ("currency" ~ '^[A-Z]{3}$')
);
CREATE INDEX IF NOT EXISTS "finance_bank_transactions_tenant_account_date_idx" ON "finance_bank_transactions"("tenantId","bankAccountId","transactionDate");
CREATE INDEX IF NOT EXISTS "finance_bank_transactions_tenant_status_idx" ON "finance_bank_transactions"("tenantId","status");

CREATE TABLE IF NOT EXISTS "finance_bank_reconciliations" (
  "id" UUID PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" UUID NOT NULL, "bankAccountId" UUID NOT NULL,
  "statementDate" DATE NOT NULL, "statementEndingBalance" NUMERIC(18,2) NOT NULL, "calculatedBalance" NUMERIC(18,2) NOT NULL DEFAULT 0,
  "difference" NUMERIC(18,2) NOT NULL DEFAULT 0, "status" TEXT NOT NULL DEFAULT 'draft', "approvedAt" TIMESTAMPTZ,
  "approvedBy" UUID, "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(), "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  "createdBy" UUID NOT NULL, "updatedBy" UUID NOT NULL, "deletedAt" TIMESTAMPTZ, "version" INTEGER NOT NULL DEFAULT 1, "metadata" JSONB,
  CONSTRAINT "finance_bank_reconciliations_uq" UNIQUE ("tenantId","bankAccountId","statementDate"),
  CONSTRAINT "finance_bank_reconciliations_status_chk" CHECK ("status" IN ('draft','approved'))
);
CREATE INDEX IF NOT EXISTS "finance_bank_reconciliations_tenant_account_status_idx" ON "finance_bank_reconciliations"("tenantId","bankAccountId","status");

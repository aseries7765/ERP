CREATE TABLE IF NOT EXISTS "projects" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" uuid NOT NULL, "code" text NOT NULL, "name" text NOT NULL,
  "description" text, "status" text NOT NULL DEFAULT 'draft', "priority" text NOT NULL DEFAULT 'normal',
  "startDate" date, "dueDate" date, "budget" numeric(20,4), "currencyId" uuid, "managerId" uuid,
  "createdAt" timestamptz NOT NULL DEFAULT now(), "updatedAt" timestamptz NOT NULL DEFAULT now(), "createdBy" uuid NOT NULL, "updatedBy" uuid NOT NULL,
  "deletedAt" timestamptz, "version" integer NOT NULL DEFAULT 1, "metadata" jsonb
);
CREATE UNIQUE INDEX IF NOT EXISTS "projects_tenant_code_key" ON "projects"("tenantId","code");
CREATE INDEX IF NOT EXISTS "projects_tenant_idx" ON "projects"("tenantId");
CREATE INDEX IF NOT EXISTS "projects_tenant_deleted_idx" ON "projects"("tenantId","deletedAt");
CREATE INDEX IF NOT EXISTS "projects_tenant_status_idx" ON "projects"("tenantId","status");

CREATE TABLE IF NOT EXISTS "project_members" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" uuid NOT NULL, "projectId" uuid NOT NULL, "userId" uuid NOT NULL,
  "role" text NOT NULL DEFAULT 'member', "allocation" numeric(8,4), "createdAt" timestamptz NOT NULL DEFAULT now(), "updatedAt" timestamptz NOT NULL DEFAULT now(),
  "createdBy" uuid NOT NULL, "updatedBy" uuid NOT NULL, "deletedAt" timestamptz, "version" integer NOT NULL DEFAULT 1, "metadata" jsonb
);
CREATE UNIQUE INDEX IF NOT EXISTS "project_members_tenant_project_user_key" ON "project_members"("tenantId","projectId","userId");
CREATE INDEX IF NOT EXISTS "project_members_tenant_project_idx" ON "project_members"("tenantId","projectId");
CREATE INDEX IF NOT EXISTS "project_members_tenant_user_idx" ON "project_members"("tenantId","userId");

CREATE TABLE IF NOT EXISTS "project_milestones" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" uuid NOT NULL, "projectId" uuid NOT NULL, "name" text NOT NULL,
  "description" text, "status" text NOT NULL DEFAULT 'open', "dueDate" date, "completedAt" timestamptz,
  "createdAt" timestamptz NOT NULL DEFAULT now(), "updatedAt" timestamptz NOT NULL DEFAULT now(), "createdBy" uuid NOT NULL, "updatedBy" uuid NOT NULL,
  "deletedAt" timestamptz, "version" integer NOT NULL DEFAULT 1, "metadata" jsonb
);
CREATE INDEX IF NOT EXISTS "project_milestones_tenant_project_idx" ON "project_milestones"("tenantId","projectId");
CREATE INDEX IF NOT EXISTS "project_milestones_tenant_status_idx" ON "project_milestones"("tenantId","status");

CREATE TABLE IF NOT EXISTS "project_tasks" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" uuid NOT NULL, "projectId" uuid NOT NULL, "milestoneId" uuid, "parentTaskId" uuid,
  "code" text NOT NULL, "title" text NOT NULL, "description" text, "status" text NOT NULL DEFAULT 'todo', "priority" text NOT NULL DEFAULT 'normal',
  "assigneeId" uuid, "startDate" date, "dueDate" date, "estimatedHours" numeric(12,2), "actualHours" numeric(12,2),
  "createdAt" timestamptz NOT NULL DEFAULT now(), "updatedAt" timestamptz NOT NULL DEFAULT now(), "createdBy" uuid NOT NULL, "updatedBy" uuid NOT NULL,
  "deletedAt" timestamptz, "version" integer NOT NULL DEFAULT 1, "metadata" jsonb
);
CREATE UNIQUE INDEX IF NOT EXISTS "project_tasks_tenant_project_code_key" ON "project_tasks"("tenantId","projectId","code");
CREATE INDEX IF NOT EXISTS "project_tasks_tenant_project_idx" ON "project_tasks"("tenantId","projectId");
CREATE INDEX IF NOT EXISTS "project_tasks_tenant_assignee_idx" ON "project_tasks"("tenantId","assigneeId");
CREATE INDEX IF NOT EXISTS "project_tasks_tenant_status_idx" ON "project_tasks"("tenantId","status");

CREATE TABLE IF NOT EXISTS "project_time_entries" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v7(), "tenantId" uuid NOT NULL, "projectId" uuid NOT NULL, "taskId" uuid, "userId" uuid NOT NULL,
  "workDate" date NOT NULL, "hours" numeric(12,2) NOT NULL, "description" text, "billable" boolean NOT NULL DEFAULT true, "status" text NOT NULL DEFAULT 'draft',
  "createdAt" timestamptz NOT NULL DEFAULT now(), "updatedAt" timestamptz NOT NULL DEFAULT now(), "createdBy" uuid NOT NULL, "updatedBy" uuid NOT NULL,
  "deletedAt" timestamptz, "version" integer NOT NULL DEFAULT 1, "metadata" jsonb
);
CREATE INDEX IF NOT EXISTS "project_time_entries_tenant_project_date_idx" ON "project_time_entries"("tenantId","projectId","workDate");
CREATE INDEX IF NOT EXISTS "project_time_entries_tenant_user_date_idx" ON "project_time_entries"("tenantId","userId","workDate");

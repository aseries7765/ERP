-- ============================================================================
-- 03-app-role-grants.sql
-- ============================================================================
-- Run AFTER tables exist (same fold-in process as 02-rls-and-triggers.sql —
-- append this into the same `rls_and_triggers` migration, or its own
-- follow-up `--create-only` migration; order relative to 02 doesn't matter,
-- but both must run after the table-creation migration).
--
-- LOCAL DEV: not needed — infra/postgres/init.sql already creates erp_app
-- as a role; these GRANTs are what makes it able to actually do anything
-- once tables exist, which docker-compose's one-shot init script can't do
-- (it runs before any table exists). Run this file once, manually, after
-- your first `pnpm db:migrate` / `pnpm db:push`:
--     psql "$DATABASE_URL" -f prisma/raw-sql/03-app-role-grants.sql
-- (using the SUPERUSER connection string — erp_app itself can't GRANT).
-- ============================================================================

GRANT USAGE ON SCHEMA public TO erp_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO erp_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO erp_app;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO erp_app;

-- Applies the same grants automatically to tables created by FUTURE
-- migrations, so M5+ business-module tables don't need a manual grant step
-- repeated forever.
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO erp_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO erp_app;

-- Belt-and-suspenders on top of the append-only trigger (migration 02):
-- even if a future code change somehow tried to UPDATE/DELETE audit_events,
-- erp_app is not granted those privileges on this table at all.
REVOKE UPDATE, DELETE ON audit_events FROM erp_app;

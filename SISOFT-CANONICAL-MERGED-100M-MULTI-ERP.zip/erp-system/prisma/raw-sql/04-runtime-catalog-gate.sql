-- ============================================================================
-- 04-runtime-catalog-gate.sql — Stage 50
-- READ-ONLY PostgreSQL catalog inspection. No DDL/DML is permitted here.
-- Run only against a disposable database during the runtime gate.
-- ============================================================================

\pset pager off
\pset tuples_only off
\pset format aligned

SELECT 'database=' || current_database() || ', schema=' || current_schema() AS runtime_identity;

-- SECTION: tables
SELECT table_schema, table_name, table_type
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;

-- SECTION: columns
SELECT table_name, ordinal_position, column_name, data_type, udt_name,
       is_nullable, column_default
FROM information_schema.columns
WHERE table_schema = 'public'
ORDER BY table_name, ordinal_position;

-- SECTION: constraints
SELECT c.conrelid::regclass AS table_name,
       c.conname,
       CASE c.contype
         WHEN 'p' THEN 'PRIMARY KEY'
         WHEN 'u' THEN 'UNIQUE'
         WHEN 'f' THEN 'FOREIGN KEY'
         WHEN 'c' THEN 'CHECK'
         WHEN 'x' THEN 'EXCLUDE'
         ELSE c.contype::text
       END AS constraint_type,
       pg_get_constraintdef(c.oid, true) AS definition
FROM pg_catalog.pg_constraint c
JOIN pg_catalog.pg_namespace n ON n.oid = c.connamespace
WHERE n.nspname = 'public'
ORDER BY table_name, c.conname;

-- SECTION: indexes
SELECT schemaname, tablename, indexname, indexdef
FROM pg_catalog.pg_indexes
WHERE schemaname = 'public'
ORDER BY tablename, indexname;

-- SECTION: rls
SELECT schemaname, tablename, policyname, permissive, roles,
       cmd, qual, with_check
FROM pg_catalog.pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, policyname;

SELECT n.nspname AS schema_name,
       c.relname AS table_name,
       c.relrowsecurity AS rls_enabled,
       c.relforcerowsecurity AS rls_forced
FROM pg_catalog.pg_class c
JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public' AND c.relkind IN ('r','p')
ORDER BY c.relname;

-- SECTION: triggers
SELECT n.nspname AS schema_name,
       c.relname AS table_name,
       t.tgname,
       t.tgenabled,
       pg_get_triggerdef(t.oid, true) AS definition
FROM pg_catalog.pg_trigger t
JOIN pg_catalog.pg_class c ON c.oid = t.tgrelid
JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public' AND NOT t.tgisinternal
ORDER BY c.relname, t.tgname;

-- SECTION: functions
SELECT n.nspname AS schema_name,
       p.proname,
       pg_get_function_identity_arguments(p.oid) AS arguments,
       pg_get_function_result(p.oid) AS result_type,
       p.provolatile,
       p.proparallel,
       pg_get_functiondef(p.oid) AS definition
FROM pg_catalog.pg_proc p
JOIN pg_catalog.pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname = 'public'
  AND p.proname IN (
    'uuid_generate_v7',
    'get_current_tenant',
    'audit_hash',
    'touch_updated_at_and_version',
    'reject_audit_mutation'
  )
ORDER BY p.proname, arguments;

-- SECTION: privileges
SELECT 'schema' AS object_type,
       n.nspname AS object_name,
       r.rolname AS role_name,
       has_schema_privilege(r.rolname, n.oid, 'USAGE') AS usage_privilege
FROM pg_catalog.pg_namespace n
CROSS JOIN pg_catalog.pg_roles r
WHERE n.nspname = 'public'
  AND r.rolname IN ('erp_app', 'erp_platform_admin')
ORDER BY object_name, role_name;

SELECT 'table' AS object_type,
       c.oid::regclass AS object_name,
       r.rolname AS role_name,
       has_table_privilege(r.rolname, c.oid, 'SELECT') AS can_select,
       has_table_privilege(r.rolname, c.oid, 'INSERT') AS can_insert,
       has_table_privilege(r.rolname, c.oid, 'UPDATE') AS can_update,
       has_table_privilege(r.rolname, c.oid, 'DELETE') AS can_delete
FROM pg_catalog.pg_class c
JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
CROSS JOIN pg_catalog.pg_roles r
WHERE n.nspname = 'public'
  AND c.relkind IN ('r','p')
  AND r.rolname = 'erp_app'
ORDER BY object_name;

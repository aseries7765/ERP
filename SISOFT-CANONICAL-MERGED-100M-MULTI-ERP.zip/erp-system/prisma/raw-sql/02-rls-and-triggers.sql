-- ============================================================================
-- 02-rls-and-triggers.sql
-- ============================================================================
-- Fold this into a Prisma migration AFTER the table-creation migration
-- exists — see the numbered steps at the top of 01-uuid-v7-function.sql for
-- the exact commands. In short: `prisma migrate dev --create-only --name
-- rls_and_triggers`, then paste this file's contents into the empty
-- migration.sql it generates.
--
-- Sections:
--   1. Helper functions (get_current_tenant, audit_hash)
--   2. updated_at / version-increment trigger, attached to every table
--   3. RLS: enabled + tenant_isolation policy on every tenant-scoped table
--   4. Audit-chain append-only rule on audit_events
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. HELPER FUNCTIONS
-- ----------------------------------------------------------------------------

-- Reads the tenant id set by the app for this transaction (see
-- apps/api/src/prisma/tenant-context.middleware.ts, which runs
-- `SET LOCAL app.current_tenant = '<uuid>'` at the start of every request).
CREATE OR REPLACE FUNCTION public.get_current_tenant() RETURNS uuid
LANGUAGE sql STABLE PARALLEL SAFE SET search_path = pg_catalog, public AS $$
  SELECT NULLIF(current_setting('app.current_tenant', true), '')::uuid;
$$;

-- Deterministic row hash for the audit hash-chain (S24). Takes the previous
-- row's hash plus this row's serialized data; anyone who tampers with a row
-- breaks every hash after it, which audit.test.ts verifies.
CREATE OR REPLACE FUNCTION public.audit_hash(prev_hash text, row_data jsonb) RETURNS text
LANGUAGE sql IMMUTABLE PARALLEL SAFE SET search_path = pg_catalog, public AS $$
  SELECT encode(digest(coalesce(prev_hash, '') || row_data::text, 'sha256'), 'hex');
$$;

-- ----------------------------------------------------------------------------
-- 2. updated_at / version TRIGGER
-- ----------------------------------------------------------------------------
-- Belt-and-suspenders: Prisma's @updatedAt already sets this at the app
-- layer, but any direct SQL (migrations, admin scripts, another service)
-- must not silently skip it. This also enforces optimistic-lock version
-- bumps at the DB level so a bug in application code can't bypass R (A8).

CREATE OR REPLACE FUNCTION public.touch_updated_at_and_version() RETURNS trigger
LANGUAGE plpgsql VOLATILE SET search_path = pg_catalog, public AS $$
BEGIN
  NEW."updatedAt" := now();
  NEW."version" := OLD."version" + 1;
  RETURN NEW;
END;
$$;

-- Applied to every tenant-scoped table with a version column via the
-- generator block below — listing every table explicitly (not "ALL TABLES")
-- so a future table is opted in deliberately, not silently.
DO $$
DECLARE
  t text;
BEGIN
  FOR t IN
    SELECT unnest(ARRAY[
      'subscriptions',
      'companies',
      'branches',
      'departments',
      'cost_centers',
      'locations',
      'addresses',
      'fiscal_years',
      'fiscal_periods',
      'calendars',
      'users',
      'roles',
      'groups',
      'policies',
      'projects',
      'project_members',
      'project_milestones',
      'project_tasks',
      'project_time_entries',
      'user_profiles',
      'employees',
      'positions',
      'teams',
      'contacts',
      'notification_templates',
      'folders',
      'documents',
      'custom_fields',
      'form_schemas',
      'workflows',
      'leads',
      'opportunities',
      'accounts',
      'quotes',
      'sales_orders',
      'sales_number_sequences',
      'quote_lines',
      'sales_order_lines',
      'products',
      'warehouses',
      'inventory_number_sequences',
      'inventory_stock_transfers',
      'inventory_stock_counts',
      'inventory_stock_count_lines',
      'purchase_orders',
      'vendors',
      'purchase_number_sequences',
      'purchase_approvals',
      'purchase_vendor_contracts',
      'purchase_requisitions',
      'purchase_requisition_lines',
      'purchase_rfqs',
      'purchase_rfq_vendors',
      'purchase_rfq_lines',
      'purchase_vendor_quotes',
      'purchase_vendor_quote_lines',
      'purchase_order_lines',
      'purchase_goods_receipts',
      'purchase_goods_receipt_lines',
      'purchase_returns',
      'purchase_return_lines',
      'purchase_invoice_matches',
      'purchase_document_links',
      'invoices',
      'hr_shifts',
      'hr_attendance',
      'hr_leave_types',
      'hr_leave_balances',
      'hr_leave_requests',
      'hr_holidays',
      'hr_timesheets',
      'payroll_runs',
      'payroll_payslips',
      'payroll_payslip_lines',
      'payroll_salary_components',
      'payroll_salary_structures',
      'payroll_salary_assignments',
      'payroll_employee_loans',
      'payroll_employee_advances',
      'finance_vendor_bills',
      'finance_vendor_payments',
      'finance_posting_profiles',
      'finance_postings',
      'finance_bank_accounts',
      'finance_bank_transactions',
      'finance_bank_reconciliations',
      'finance_tax_rates',
      'finance_number_sequences',
      'finance_ledger_accounts',
      'finance_journal_entries',
      'finance_journal_lines',
      'finance_budgets',
      'finance_budget_lines',
      'finance_fixed_assets',
      'finance_fixed_asset_depreciations',
      'finance_journal_templates',
      'finance_journal_template_lines',
      'finance_recurring_journals',
      'finance_accruals',
      'finance_accrual_recognitions',
      'finance_exchange_rates',
      'finance_fx_revaluations',
      'finance_year_end_closes'
    ])
  LOOP
    EXECUTE format(
      'DROP TRIGGER IF EXISTS trg_touch_%1$s ON %1$s;
       CREATE TRIGGER trg_touch_%1$s
         BEFORE UPDATE ON %1$s
         FOR EACH ROW
         WHEN (OLD.* IS DISTINCT FROM NEW.*)
         EXECUTE FUNCTION public.touch_updated_at_and_version();',
      t
    );
  END LOOP;
END $$;

-- ----------------------------------------------------------------------------
-- 3. ROW-LEVEL SECURITY
-- ----------------------------------------------------------------------------
-- Every table with a tenant_id column gets RLS enabled + a USING policy that
-- compares against get_current_tenant(). If the app forgets to set
-- app.current_tenant for a request, get_current_tenant() returns NULL, and
-- `tenant_id = NULL` is never true in SQL — so the query returns ZERO rows
-- instead of leaking cross-tenant data. This is rls.test.ts's core assertion.
--
-- A separate `service_role` bypass policy exists for background jobs that
-- legitimately operate across tenants (e.g. scheduled partition creation);
-- it is granted only to that role, never to the app's normal DB user.

DO $$
DECLARE
  tbl text;
BEGIN
  FOR tbl IN
    SELECT table_name FROM information_schema.columns
    WHERE table_schema = 'public' AND column_name = 'tenantId'
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY;', tbl);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY;', tbl); -- applies even to table owner
    EXECUTE format(
      'DROP POLICY IF EXISTS tenant_isolation ON %1$I;
       CREATE POLICY tenant_isolation ON %1$I
         USING ("tenantId" = public.get_current_tenant());',
      tbl
    );
  END LOOP;
END $$;

-- Super-admin bypass role (used only for platform support tooling, always
-- logged via withBypassRls() in the Prisma service — see
-- apps/api/src/prisma/prisma.service.ts).
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'erp_platform_admin') THEN
    CREATE ROLE erp_platform_admin BYPASSRLS;
  END IF;
END $$;

-- ----------------------------------------------------------------------------
-- 4. AUDIT TABLE: APPEND-ONLY ENFORCEMENT
-- ----------------------------------------------------------------------------
-- audit_events must never be updated or deleted by the application role —
-- only inserted. This is enforced at the DB level, not just by convention.

CREATE OR REPLACE FUNCTION public.reject_audit_mutation() RETURNS trigger
LANGUAGE plpgsql VOLATILE SET search_path = pg_catalog, public AS $$
BEGIN
  RAISE EXCEPTION 'audit_events is append-only: % is not permitted', TG_OP;
END;
$$;

DROP TRIGGER IF EXISTS trg_audit_no_update ON audit_events;
CREATE TRIGGER trg_audit_no_update
  BEFORE UPDATE ON audit_events
  FOR EACH ROW EXECUTE FUNCTION public.reject_audit_mutation();

DROP TRIGGER IF EXISTS trg_audit_no_delete ON audit_events;
CREATE TRIGGER trg_audit_no_delete
  BEFORE DELETE ON audit_events
  FOR EACH ROW EXECUTE FUNCTION public.reject_audit_mutation();

-- Down migration (reverse order)
-- DROP TRIGGER IF EXISTS trg_audit_no_delete ON audit_events;
-- DROP TRIGGER IF EXISTS trg_audit_no_update ON audit_events;
-- DROP FUNCTION IF EXISTS reject_audit_mutation();
-- -- (loop to DROP POLICY tenant_isolation + DISABLE ROW LEVEL SECURITY per table)
-- -- (loop to DROP TRIGGER trg_touch_* per table)
-- DROP FUNCTION IF EXISTS touch_updated_at_and_version();
-- DROP FUNCTION IF EXISTS audit_hash(text, jsonb);
-- DROP FUNCTION IF EXISTS get_current_tenant();

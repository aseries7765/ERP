-- ============================================================================
-- 01-uuid-v7-function.sql
-- ============================================================================
-- MUST run BEFORE the table-creation migration, not after — every model's
-- `id @default(dbgenerated("uuid_generate_v7()"))` means Postgres needs this
-- function to already exist at CREATE TABLE time (a DEFAULT clause is
-- resolved immediately, not lazily). Order matters here in a way it doesn't
-- for 02-rls-and-triggers.sql, which only touches tables that must already
-- exist.
--
-- LOCAL DEV (docker compose): already handled — infra/postgres/init.sql
-- runs this same function definition automatically on first container
-- start, before you ever run a migration. Nothing to do here.
--
-- ANY OTHER ENVIRONMENT (staging/prod, or a Postgres you didn't bootstrap
-- with our docker-compose): apply this file manually, once, with a role
-- that has CREATE privileges, before the first `prisma migrate deploy`:
--     psql "$DATABASE_URL" -f prisma/raw-sql/01-uuid-v7-function.sql
--
-- Then the normal Prisma flow works:
--   1. `pnpm db:migrate` (name it "init_foundation") — diffs schema.prisma
--      against the DB and generates a real migration with `CREATE TABLE`
--      for all 83 models. It also emits `CREATE EXTENSION` statements for
--      uuid-ossp/pgcrypto/pg_trgm automatically, because schema.prisma's
--      datasource block declares them via the postgresqlExtensions preview
--      feature — the CREATE EXTENSION lines below are redundant with that
--      (kept here only because docker-compose's bootstrap path needs them
--      independently of Prisma).
--   2. `pnpm --filter @erp/api exec prisma migrate dev --create-only --name rls_and_triggers --schema ../../prisma/schema.prisma`
--      creates a new, empty migration folder.
--   3. Paste the contents of 02-rls-and-triggers.sql into that empty
--      migration.sql.
--   4. `pnpm db:migrate` again to apply it.
--
-- WHY NOT JUST SHIP PRE-NUMBERED prisma/migrations/000N FOLDERS: Prisma's
-- migration history is a hash-checked ledger against a shadow database;
-- hand-authoring folders outside `prisma migrate dev` risks a history
-- `prisma migrate dev` can't reconcile on your machine, since this sandbox
-- has no live Postgres to generate and verify the real migration against.
-- The 4 steps above produce the exact same SQL, but SQL Prisma has actually
-- verified against your database instead of SQL I asserted would work.
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";


-- ----------------------------------------------------------------------------
-- uuid_generate_v7(): This project targets PostgreSQL 16/17; the schema intentionally uses a project-owned UUIDv7 function rather than relying on a server-version-specific native function. PostgreSQL 18+ may provide native UUIDv7 support, but the schema contract remains this function until an explicit migration changes it.
-- so every model's `id @default(dbgenerated("uuid_generate_v7()"))` in
-- schema.prisma depends on this function existing first.
--
-- UUIDv7 = 48-bit millisecond Unix timestamp + version/variant bits + random.
-- Chosen (ADR 0001) over UUIDv4 because it's monotonically sortable, which
-- keeps primary-key B-tree inserts sequential instead of randomly scattered
-- across the index (a real, measurable write-amplification problem at
-- ERP-scale row counts).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.uuid_generate_v7()
RETURNS uuid
LANGUAGE plpgsql
VOLATILE
PARALLEL SAFE
SET search_path = pg_catalog, public
AS $$
DECLARE
  unix_ts_ms bytea;
  uuid_bytes bytea;
BEGIN
  unix_ts_ms := substring(int8send(floor(extract(epoch FROM clock_timestamp()) * 1000)::bigint) FROM 3 FOR 6);

  uuid_bytes := unix_ts_ms || gen_random_bytes(10);

  -- set version 7 (bits 4-7 of byte 6)
  uuid_bytes := set_byte(uuid_bytes, 6, (b'0111' || get_byte(uuid_bytes, 6)::bit(4))::bit(8)::int);
  -- set variant (bits 6-7 of byte 8) to 10
  uuid_bytes := set_byte(uuid_bytes, 8, (b'10' || get_byte(uuid_bytes, 8)::bit(6))::bit(8)::int);

  RETURN encode(uuid_bytes, 'hex')::uuid;
END;
$$;

-- Down migration
-- DROP FUNCTION IF EXISTS uuid_generate_v7();
-- DROP EXTENSION IF EXISTS "pg_trgm";
-- DROP EXTENSION IF EXISTS "pgcrypto";
-- DROP EXTENSION IF EXISTS "uuid-ossp";
-- (extensions are not dropped by default in the down path — other schemas
--  may depend on them; drop manually only if you're sure nothing else uses them)

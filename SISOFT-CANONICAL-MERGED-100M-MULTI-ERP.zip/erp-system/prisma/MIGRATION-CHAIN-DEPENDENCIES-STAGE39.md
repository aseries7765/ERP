# Stage 39 — Migration Chain Dependency Reconciliation

## Scope

This stage statically reconciles dependencies between the 17 tracked Prisma SQL migrations. It does **not** invent a Prisma-generated baseline and does not rewrite historical migrations.

## Result

- Tracked migrations: 17
- Physical tables created by tracked migrations: 74
- Duplicate table creators: 0
- Foreign-key references to tables not created by tracked migrations: 5

The five missing prerequisites are:

| Referencing migration | Required table | Classification |
|---|---|---|
| `20260917_finance_budget` | `cost_centers` | pre-existing foundation table required before budget migration |
| `20260917_rbac_persistence_stage17` | `groups` | pre-existing RBAC foundation table |
| `20260917_rbac_persistence_stage17` | `permissions` | pre-existing RBAC foundation table |
| `20260917_rbac_persistence_stage17` | `policies` | pre-existing RBAC foundation table |
| `20260917_rbac_persistence_stage17` | `delegations` | pre-existing RBAC foundation table |

## Safety decision

These are not treated as harmless warnings. A fresh database cannot execute the affected migrations unless the prerequisite tables are created by an earlier migration or are explicitly documented as part of an externally provisioned baseline.

Because no disposable PostgreSQL server and pinned Prisma CLI are available in the current environment, Stage 39 does **not** generate replacement SQL for these foundation tables. Doing so without validating all columns, constraints, extensions, RLS policies, and foreign-key ordering would risk creating a divergent database baseline.

## Required runtime gate

Before production migration approval, run against a disposable PostgreSQL database:

1. `prisma validate`
2. `prisma migrate deploy`
3. inspect `_prisma_migrations`
4. verify all 192 current schema tables exist
5. run seed with `SEED_DEMO=true`
6. exercise representative API Prisma queries
7. verify RLS/tenant isolation and foreign-key integrity
8. only then approve a baseline or prerequisite migration path.

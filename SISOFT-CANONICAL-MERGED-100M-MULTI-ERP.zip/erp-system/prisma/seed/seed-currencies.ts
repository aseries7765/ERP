import { PrismaClient } from '@prisma/client';

/**
 * Starter subset of ISO 4217 currencies — the ones covering the Tier-1
 * countries listed in the master spec's Q2 answer. The full ~180-currency
 * catalog is real data-entry work, not schema work, and is deferred to
 * whichever milestone first needs a currency outside this list (Finance,
 * M8, is the most likely trigger). Every row here is correct, real ISO
 * data — this is a deliberately smaller-but-complete slice, not a stub.
 */
const CURRENCIES: Array<{ code: string; name: string; symbol: string; decimalDigits: number }> = [
  { code: 'USD', name: 'US Dollar', symbol: '$', decimalDigits: 2 },
  { code: 'EUR', name: 'Euro', symbol: '€', decimalDigits: 2 },
  { code: 'GBP', name: 'British Pound', symbol: '£', decimalDigits: 2 },
  { code: 'PKR', name: 'Pakistani Rupee', symbol: '₨', decimalDigits: 2 },
  { code: 'SAR', name: 'Saudi Riyal', symbol: 'ر.س', decimalDigits: 2 },
  { code: 'AED', name: 'UAE Dirham', symbol: 'د.إ', decimalDigits: 2 },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', decimalDigits: 2 },
  { code: 'CAD', name: 'Canadian Dollar', symbol: '$', decimalDigits: 2 },
  { code: 'AUD', name: 'Australian Dollar', symbol: '$', decimalDigits: 2 },
  { code: 'SGD', name: 'Singapore Dollar', symbol: '$', decimalDigits: 2 },
  { code: 'MYR', name: 'Malaysian Ringgit', symbol: 'RM', decimalDigits: 2 },
  { code: 'TRY', name: 'Turkish Lira', symbol: '₺', decimalDigits: 2 },
  { code: 'EGP', name: 'Egyptian Pound', symbol: 'ج.م', decimalDigits: 2 },
  { code: 'NGN', name: 'Nigerian Naira', symbol: '₦', decimalDigits: 2 },
  { code: 'KES', name: 'Kenyan Shilling', symbol: 'KSh', decimalDigits: 2 },
  { code: 'ZAR', name: 'South African Rand', symbol: 'R', decimalDigits: 2 },
  { code: 'BRL', name: 'Brazilian Real', symbol: 'R$', decimalDigits: 2 },
  { code: 'MXN', name: 'Mexican Peso', symbol: '$', decimalDigits: 2 },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥', decimalDigits: 0 },
  { code: 'KRW', name: 'South Korean Won', symbol: '₩', decimalDigits: 0 },
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', decimalDigits: 2 },
  { code: 'IDR', name: 'Indonesian Rupiah', symbol: 'Rp', decimalDigits: 2 },
  { code: 'VND', name: 'Vietnamese Dong', symbol: '₫', decimalDigits: 0 },
  { code: 'THB', name: 'Thai Baht', symbol: '฿', decimalDigits: 2 },
  { code: 'PHP', name: 'Philippine Peso', symbol: '₱', decimalDigits: 2 },
  { code: 'NZD', name: 'New Zealand Dollar', symbol: '$', decimalDigits: 2 },
  { code: 'QAR', name: 'Qatari Riyal', symbol: 'ر.ق', decimalDigits: 2 },
  { code: 'KWD', name: 'Kuwaiti Dinar', symbol: 'د.ك', decimalDigits: 3 },
  { code: 'BHD', name: 'Bahraini Dinar', symbol: '.د.ب', decimalDigits: 3 },
  { code: 'OMR', name: 'Omani Rial', symbol: 'ر.ع.', decimalDigits: 3 },
];

export async function seedCurrencies(prisma: PrismaClient): Promise<number> {
  for (const currency of CURRENCIES) {
    await prisma.currency.upsert({
      where: { code: currency.code },
      update: { name: currency.name, symbol: currency.symbol, decimalDigits: currency.decimalDigits },
      create: currency,
    });
  }
  return CURRENCIES.length;
}

import { PrismaClient } from '@prisma/client';
import { randomUUID } from 'node:crypto';

/**
 * Only runs when SEED_DEMO=true (never in production — see seeds.test.ts
 * and docs/db/SEEDS.md for the safety rationale). Demonstrates the actual
 * shape every real tenant gets provisioned with: a Tenant, one Company, and
 * a starter set of system roles — NOT a global seed, because Role (like
 * everything else) is tenant-scoped by design (see schema.prisma's base
 * convention comment). Real tenant provisioning (a Temporal workflow, per
 * the master spec's Q3 answer) is a business-module concern that lands
 * with Tenancy's actual service layer in a later milestone; this seed
 * exists so M2 has something concrete to run RLS/audit/soft-delete tests
 * against right now.
 */
export async function seedDemoTenant(prisma: PrismaClient): Promise<{ tenantId: string; created: boolean }> {
  const slug = 'demo';

  const existing = await prisma.tenant.findUnique({ where: { slug } });
  if (existing) {
    return { tenantId: existing.id, created: false };
  }

  const systemUserId = randomUUID(); // stand-in "system" actor for createdBy until Auth (M3) exists

  const tenant = await prisma.tenant.create({
    data: {
      name: 'Demo Tenant',
      slug,
    },
  });

  const company = await prisma.company.create({
    data: {
      tenantId: tenant.id,
      legalName: 'Demo Trading Co.',
      countryCode: 'US',
      baseCurrency: 'USD',
      createdBy: systemUserId,
      updatedBy: systemUserId,
    },
  });

  await prisma.branch.create({
    data: {
      tenantId: tenant.id,
      companyId: company.id,
      code: 'HQ',
      name: 'Head Office',
      isHeadOffice: true,
      createdBy: systemUserId,
      updatedBy: systemUserId,
    },
  });

  const systemRoles: Array<{ code: string; name: string }> = [
    { code: 'owner', name: 'Owner' },
    { code: 'admin', name: 'Admin' },
    { code: 'manager', name: 'Manager' },
    { code: 'accountant', name: 'Accountant' },
    { code: 'hr', name: 'HR' },
    { code: 'sales', name: 'Sales' },
    { code: 'viewer', name: 'Viewer' },
  ];

  for (const role of systemRoles) {
    await prisma.role.upsert({
      where: { tenantId_code: { tenantId: tenant.id, code: role.code } },
      update: { name: role.name },
      create: {
        tenantId: tenant.id,
        code: role.code,
        name: role.name,
        isSystem: true,
        createdBy: systemUserId,
        updatedBy: systemUserId,
      },
    });
  }

  return { tenantId: tenant.id, created: true };
}

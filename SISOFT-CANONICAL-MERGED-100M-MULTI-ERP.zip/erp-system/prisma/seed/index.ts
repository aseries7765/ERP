import { PrismaClient } from '@prisma/client';
import { seedCurrencies } from './seed-currencies';
import { seedPlans } from './seed-plans';
import { seedDemoTenant } from './seed-demo-tenant';

/**
 * Prisma seed entry point.
 *
 * The runner owns one PrismaClient for the entire seed transaction lifecycle
 * and passes it explicitly to every seed module. Individual seed modules are
 * intentionally deterministic/idempotent where their contract permits it.
 * Demo tenant data is opt-in via SEED_DEMO=true.
 */
async function main(): Promise<void> {
  const prisma = new PrismaClient();
  try {
    console.log('[seed] Starting ERP seed...');

    const currencies = await seedCurrencies(prisma);
    const plans = await seedPlans(prisma);
    console.log(`[seed] currencies=${currencies}, plans=${plans}`);

    if (process.env.SEED_DEMO === 'true') {
      const demo = await seedDemoTenant(prisma);
      console.log(`[seed] demoTenant=${demo.tenantId} created=${demo.created}`);
    } else {
      console.log('[seed] Demo tenant skipped (set SEED_DEMO=true to enable).');
    }

    console.log('[seed] Seed process finished');
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((err) => {
  console.error('[seed] Fatal error:', err);
  process.exitCode = 1;
});

import { PrismaClient, PlanTier } from '@prisma/client';

/**
 * Idempotent by design: `upsert` on the unique `code` means running this
 * twice produces the same 4 rows, not 8. seeds.test.ts asserts this.
 */
export async function seedPlans(prisma: PrismaClient): Promise<number> {
  const plans: Array<{
    code: string;
    name: string;
    tier: PlanTier;
    priceMonthly: string;
    priceYearly: string;
  }> = [
    { code: 'free', name: 'Free', tier: PlanTier.FREE, priceMonthly: '0', priceYearly: '0' },
    { code: 'starter', name: 'Starter', tier: PlanTier.STARTER, priceMonthly: '49', priceYearly: '490' },
    { code: 'growth', name: 'Growth', tier: PlanTier.GROWTH, priceMonthly: '199', priceYearly: '1990' },
    { code: 'enterprise', name: 'Enterprise', tier: PlanTier.ENTERPRISE, priceMonthly: '999', priceYearly: '9990' },
  ];

  for (const plan of plans) {
    await prisma.plan.upsert({
      where: { code: plan.code },
      update: {
        name: plan.name,
        tier: plan.tier,
        priceMonthly: plan.priceMonthly,
        priceYearly: plan.priceYearly,
      },
      create: {
        code: plan.code,
        name: plan.name,
        tier: plan.tier,
        priceMonthly: plan.priceMonthly,
        priceYearly: plan.priceYearly,
        currencyCode: 'USD',
        features: {}, // populated with real per-tier feature flags when Billing (M6) lands
      },
    });
  }

  return plans.length;
}

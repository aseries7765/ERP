# Stage 41 — Prisma-Generated Baseline & Runtime Migration Gate

## Objective
Establish a reproducible Prisma toolchain and a machine-checkable gate for schema validation, client generation, and PostgreSQL migration-status verification.

## Changes
- Pin root Prisma CLI to `5.20.0`.
- Pin API `@prisma/client` to `5.20.0`.
- Add `scripts/verify-stage41-prisma-runtime-gate.sh`.
- The gate never fabricates migration SQL.
- When the pinned CLI is unavailable, the script reports a deterministic BLOCKED state.
- When PostgreSQL is unavailable, runtime migration verification remains BLOCKED.

## Current environment
The repository does not contain installed dependencies, and PostgreSQL is not available in the current execution environment. Therefore Prisma validation/generation and real migration execution cannot honestly be marked PASS here.

## Required runtime sequence
1. Install the exact pinned dependency graph using the repository package manager and a committed lockfile.
2. Run Prisma schema validation.
3. Generate the Prisma client.
4. Provide a disposable PostgreSQL database matching `DATABASE_URL`.
5. Run `prisma migrate status` and then execute the migration chain against the disposable database.
6. Compare resulting database structure against the authoritative Prisma schema and Stage 40 foundation inventory.

## Integrity rule
No baseline migration is considered production-ready until Prisma itself generates/validates the authoritative SQL and a real disposable PostgreSQL instance executes the migration history successfully.

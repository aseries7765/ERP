# Stage 53 — Post-Runtime Schema/Policy Evidence and Application Smoke Tests

Stage 53 adds a runtime-gated smoke suite for a Stage 52 clean disposable
PostgreSQL database. It verifies tenant isolation, fail-closed tenant context,
DB-side `updatedAt`/`version` enforcement, audit append-only behavior, and the
`erp_app` privilege boundary.

## Safety

The smoke suite requires `STAGE53_ALLOW_RUNTIME=1` and
`STAGE53_DISPOSABLE_DB=1`. It does not reset a database, replay the feature
migration ledger, or mutate the migration history. Fixture DML is enclosed in
a transaction and rolled back.

## Current result

Static verification is PASS. Runtime execution is not claimed in this
sandbox because PostgreSQL/psql is unavailable. The runtime command must be
executed against the disposable database produced by Stage 52; any failure
must be fixed and rerun before Stage 54.

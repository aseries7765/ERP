# Module Maturity Overview — Updated after M3.3 integration

**Last updated:** 2026-09-17

## Solid / Deep Implementation

| Module              | Status                          |
|---------------------|---------------------------------|
| M1 Monorepo         | Complete                        |
| M2 Schema           | 187 models                      |
| M3.1 Auth           | Present                         |
| M3.2 Tenancy        | Present + RLS                   |
| **M3.3 RBAC**       | **Integrated (full module)**    |
| M3.6–M3.10          | Present                         |
| M4 HR + Payroll     | Present                         |
| M5 CRM + Sales      | Deep pipeline logic             |
| M6 Billing          | Deep invoice + payment logic    |
| M7 Inventory        | Deep stock logic                |
| M8 Finance          | Deep GL + AR/AP + aging/statements + close/reporting |
| M9 Manufacturing    | Structural + engines            |
| M12 Reports         | Present                         |
| M13 Compliance      | Present                         |
| M15 Security        | Present                         |

## Still Partial in Depth
- M10 AI, M11 Offline Sync, M14 K8s
- Most S2–S6 SaaS modules
- Worker job handlers (registry ready)
- Portal UI

## Summary
The last critical foundation gap (M3.3 RBAC) has been closed.  
The project now has a complete multi-tenant ERP foundation with real business pipelines in CRM, Sales, Inventory, Billing and Finance.

## Stage 20 Update
- Stage 20: RBAC durable BullMQ event/audit emission implemented; Redis prefix invalidation hardened from KEYS to cursor-based SCAN.
- Static verification PASS. Runtime Redis/BullMQ/PostgreSQL verification remains unavailable in this environment.

## Stage 21 Hardened Outbox
- Durable RBAC outbox hardened with dual-queue dispatch, stale-lease recovery, bounded retries, and dead-letter state.
- RBAC event emitter persists through the outbox before asynchronous queue delivery.
- Static verification PASS; runtime database/Redis/BullMQ verification remains unavailable.


Stage 25: Audit integrity/query surface implemented; static gates PASS; runtime services remain environment-blocked.

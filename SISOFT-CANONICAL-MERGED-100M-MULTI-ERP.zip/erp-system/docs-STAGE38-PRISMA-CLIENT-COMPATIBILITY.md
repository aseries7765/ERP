# Stage 38 — Prisma Client Compatibility Gate

Date: 2026-09-17

## Scope

Reconcile the current Prisma schema with statically discoverable API Prisma-client usage and seed wiring, without pretending that a generated Prisma client or PostgreSQL runtime exists in the delivery environment.

## Findings and fixes

1. The tenancy calendar service referenced `tx.holiday` and `HolidayType`, but neither the model nor enum existed in the merged `prisma/schema.prisma`.
2. Added the `HolidayType` enum (`PUBLIC`, `COMPANY`, `OPTIONAL`).
3. Added the tenant-scoped `Holiday` model, calendar relation, uniqueness constraint, and indexes required by the existing calendar/provisioning services.
4. Added the inverse `Calendar.holidays` relation.
5. Replaced the root seed runner's silent dynamic-import/undefined-client behavior with explicit `PrismaClient` construction and typed seed-module calls.
6. Demo-tenant seeding is now explicitly opt-in with `SEED_DEMO=true`; seed failures are fatal rather than silently swallowed.

## Static compatibility result

- Prisma models: 193
- Prisma enums: 22
- Statically-addressable Prisma delegate references: no missing production delegate detected after Holiday reconciliation.
- Remaining `notificationDeadLetter`, `notificationRateLimitBucket`, `tenantInstalledPack`, and `workflowDefinition` references are test doubles or commented/historical contracts and are not treated as generated-client requirements.

## Runtime limitations

The environment has no installed Prisma CLI, generated `@prisma/client`, PostgreSQL, or dependency installation capability. Therefore this stage does NOT claim:

- `prisma validate` PASS
- `prisma generate` PASS
- `prisma migrate deploy` PASS
- seed runtime PASS
- API runtime PASS

Those remain explicit environment-gated checks for the real integration environment.

## Migration note

The Holiday schema addition is intentionally not presented as a Prisma-generated migration. Stage 37 established that the repository already has a broader migration-history gap. Stage 39 should reconcile the complete migration chain against a disposable PostgreSQL database rather than create isolated hand-written migration records that could distort history.

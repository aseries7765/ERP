# Stage 61 — Production Rollback and Disaster Recovery Runbook

## Recovery order
1. Identify incident, target recovery time, affected deployment digest and database recovery point.
2. Preserve logs, deployment metadata and existing backup evidence.
3. Restore only into an isolated disposable/production-like target first.
4. Verify backup integrity, encryption metadata and restore completion.
5. If PITR is used, verify the explicit recovery timestamp and WAL/recovery evidence.
6. Apply only migrations compatible with the restored database state; do not run destructive automatic down-migrations.
7. Verify `/health/live` and `/health/ready` against the restored application.
8. Verify tenant/RLS isolation: cross-tenant access must fail and missing tenant context must fail.
9. Verify representative read/write and audit invariants before considering promotion.
10. Promote only after human-reviewed evidence is complete.

## Application rollback
Application rollback uses an immutable image digest. Database rollback is not performed by blindly reverting migrations; use a forward-compatible fix or reviewed point-in-time restore.

## Evidence
Every recovery execution must retain command output, timestamps, target identifiers, selected backup/recovery point, image digests, migration verification, RLS verification, and a SHA-256 manifest. Absence of evidence is BLOCKED, not PASS.

# PROJECT-STATE.md

**Version:** 1.0.0-merged-20260916  
**Architecture:** Monorepo (pnpm + turbo) with NestJS API, Next.js web, Python AI service  
**Security:** M15 hardening present  
**Compliance:** M13 engines present  
**Deployment:** Partial K8s/obs from M14 + S5 engines  

## Completed

- Base monorepo + Docker Compose + CI scaffold
- Prisma schema foundation (83 models + RLS)
- Most foundation M3.x (except dedicated RBAC)
- Core business engines (HR, CRM, Inventory, Finance, Mfg)
- Advanced: AI, Reports, Compliance, Security
- SaaS control-plane client + several engines

## Active Issues

- Schema merge incomplete
- Dependencies not fully resolved
- Partial modules need completion
- Full integration tests not run

## Technical Debt

- Multiple shared-types versions possible
- Unmerged module-models.prisma files
- Incomplete OpenAPI / event bus wiring across modules

## Schema Merge Pass 1 (2026-09-16)
- Additive models from M4/M12/M13/M15 safely appended.
- Model count: 83 → 102
- Colliding Workflow models left as-is in foundation.
- M3.3 RBAC untouched.

## Dependencies / Workspace Pass (2026-09-16)
- All 25 packages now have package.json
- Root package.json improved (version + db scripts)
- Workspace ready for pnpm install

## Worker App Stub (2026-09-16)
- apps/worker created as minimal background worker stub
- Apps now present: api, web, ai, worker

## Documentation Cleanup (2026-09-16)
- CURRENT-STATUS.md created
- README.md updated for merged state
- Leftover junk directories removed

## Env + Maturity Pass (2026-09-16)
- .env.example consolidated
- MODULE-MATURITY.md created for honest status

## Final Integration Batch (2026-09-16)
- portal stub, root tsconfig, improved docker-compose, Makefile added
- CURRENT-STATUS.md fully updated

## Worker Structure Improvement
- Job registry + 5 placeholder jobs added

### Stage 23 — Atomic RBAC Mutation Coverage
The transaction-aware RBAC mutation boundary has been extended to the remaining event-bearing mutation services. No invented event types were added for mutation operations that currently lack event semantics. Runtime verification remains pending environment availability.


## Stage 24 update — 2026-09-17
Durable BullMQ consumers are implemented for RBAC events and audit persistence. EventDelivery provides per-outbox/per-target idempotency. Audit rows use a tenant-scoped advisory lock and deterministic SHA-256 hash chaining. Runtime PostgreSQL/Redis verification remains pending.


Stage 25: Audit integrity/query surface implemented; static gates PASS; runtime services remain environment-blocked.


## Stage 50
PostgreSQL runtime catalog gate added; runtime execution remains environment-blocked until disposable PostgreSQL and Prisma dependencies are available.

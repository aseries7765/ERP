# Sisoft ERP — Project Context

## Product
**Sisoft Universal ERP** is the product represented by this repository. The repository is a modular monorepo containing ERP business modules, shared packages, infrastructure contracts, security tooling, and documentation.

## Source-of-truth rule
This repository must be treated as the authoritative implementation record. Documentation must distinguish `IMPLEMENTED`, `PARTIALLY IMPLEMENTED`, `PLANNED`, `PROPOSED`, `DEPRECATED`, `BROKEN`, and `EXPERIMENTAL`.

## Current baseline
- Source baseline: canonical merged ERP archive supplied for this audit, with Stage 72 certificate/trust/service-identity artifacts reconciled into the working tree.
- GitHub repository: `aseries7765/erp`.
- GitHub state at audit time: public, default branch `main`, empty repository, no remote commit history available to audit.
- Local supplied source contains no `.git` directory and no lockfile; historical Git commits therefore cannot be reconstructed from the supplied source.
- Database schema contains 193 Prisma models and 22 enums.
- API contains 36 module directories and 877 TypeScript source files under `apps/api/src`.
- 35 workspace packages are present; 4 application packages are present under `apps/` (`api`, `web`, `worker`, `portal`).

## Architecture direction
The current implementation is a modular monorepo. The intended long-term Sisoft direction includes centralized control-plane capabilities, customer/company isolation, and potentially customer-specific infrastructure such as Oracle. The current tree contains control-plane client/provisioning/provider primitives and documentation, but it does **not** contain a deployed control-plane HTTP service or a fully implemented customer-specific Oracle provisioning workflow.

## Non-goals of this audit
This audit does not treat architecture documents as proof that their described systems are deployed. Runtime claims require runtime evidence.

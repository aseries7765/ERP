#!/usr/bin/env python3
"""Static Stage 62 observability/SLO contract verifier."""
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parent
required = {
    "docs-STAGE62-PRODUCTION-OBSERVABILITY-SLO.md": [
        "Structured JSON logs", "Correlation contract", "SLI/SLO baseline",
        "Alerting", "Incident evidence", "Runtime rule"
    ],
    "docs-STAGE62-EXCEPTIONS.md": ["Runtime infrastructure unavailable", "BLOCKED"],
}

for name, needles in required.items():
    p = ROOT / name
    if not p.is_file():
        print(f"MISSING: {name}")
        sys.exit(1)
    text = p.read_text(encoding="utf-8")
    for needle in needles:
        if needle not in text:
            print(f"MISSING CONTRACT: {name}: {needle}")
            sys.exit(1)

roadmap = (ROOT / "ROADMAP.md").read_text(encoding="utf-8") if (ROOT / "ROADMAP.md").exists() else ""
next_steps = (ROOT / "NEXT-STEPS.md").read_text(encoding="utf-8") if (ROOT / "NEXT-STEPS.md").exists() else ""
if "Stage 62" not in roadmap:
    print("MISSING ROADMAP STAGE 62 ENTRY")
    sys.exit(1)

print("STAGE62 STATIC PASS")
print("Observability matrix: structured logs, correlation, metrics, traces, SLI/SLO, alerting, incident evidence, retention")
print("Runtime verdict: BLOCKED until real telemetry and alert infrastructure is supplied")

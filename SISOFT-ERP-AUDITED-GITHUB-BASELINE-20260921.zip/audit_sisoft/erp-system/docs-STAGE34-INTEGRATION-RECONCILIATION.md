# Stage 34 — Workspace Dependency & Import Reconciliation

## Scope
Reconcile the six reconstructed workspace packages with actual application consumers and close concrete dependency/import defects without weakening contracts.

## Changes
- Added `@erp/query-builder`, `@erp/shared-types`, and `@erp/payroll-country-plugins` as direct API workspace dependencies.
- Added `@erp/workflow-engine` as a direct web workspace dependency.
- Added the existing API seed's required `UK_EWNI_BANDS_2026_27` reference table for 2026/27 England, Wales and Northern Ireland.
- Explicitly kept UK reference data separate from full UK payroll-plugin support; Scotland/NIC/PAYE edge cases remain outside this stage.
- Preserved all existing package contracts and did not add compatibility stubs.

## Verification status
- Workspace manifest reconciliation: PASS
- Workspace import-to-dependency audit: PASS for `@erp/*` application imports covered by this stage
- UK seed import target exists: PASS
- UK reference table syntax check: PASS
- Full dependency install: PENDING / environment constrained
- Full monorepo build/Jest/Prisma/PostgreSQL/Redis runtime: NOT CLAIMED

## Source note
UK 2026/27 reference values were checked against HMRC/GOV.UK current rates published/updated for 6 April 2026.

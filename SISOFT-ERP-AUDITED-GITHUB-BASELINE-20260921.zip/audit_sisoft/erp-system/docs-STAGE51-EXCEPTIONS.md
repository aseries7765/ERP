# Stage 51 Exceptions

- Runtime database execution is blocked until PostgreSQL/psql and the pinned
  Prisma 5.20.0 CLI are available.
- No baseline SQL is promoted from generated output merely because generation
  succeeds; the output must first pass the clean-database catalog differential.
- Existing migration history remains immutable during rehearsal.

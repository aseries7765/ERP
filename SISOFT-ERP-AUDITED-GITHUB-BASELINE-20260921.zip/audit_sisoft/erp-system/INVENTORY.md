# INVENTORY.md — Full Inventory of 29 Attached Zips

**Date:** 2026-09-16
**Total Zips:** 29

## Complete Inventory Table

| # | Filename | Module | MANIFEST | Structure | Notes |
|---|----------|--------|----------|-----------|-------|
| 1 | erp-system-M1.zip | M1 Monorepo + Docker + CI | No (README) | Valid base | Small scaffold |
| 2 | erp-system-M2.zip | M2 DB Schema + RLS | No (README-M2) | Valid | 83 models, RLS, audit hash-chain |
| 3 | erp-system-M3-slice-3.1.zip | M3.1 Auth & Identity | Partial | Valid | Auth foundation |
| 4 | erp-system-M3-slice-3.2.zip | M3.2 Tenancy + base overlay | No | Full monorepo | Contains fuller base + tenancy |
| 5 | m3.4-employee-20260915T033742Z.zip | M3.4 Employee Master | Yes | Valid | |
| 6 | m3.5-audit-20260915-044359-verified.zip | M3.5 Audit & Activity | Yes | Valid | Verified |
| 7 | m3.6-terminology-20260915052531.zip | M3.6 Terminology | Yes | Valid | |
| 8 | m3.7-notifications-20260916055128.zip | M3.7 Notifications | Yes | Valid | |
| 9 | m3.8-documents-20260915174710.zip | M3.8 Documents | Yes | Valid | |
| 10 | m3.9-settings-verified-20260915052534.zip | M3.9 Settings | Yes | Valid | form-builder |
| 11 | m3.10-workflow-verified-20260915-052338.zip | M3.10 Workflow | Yes | Valid | workflow-engine |
| 12 | m4-hr-payroll-20260916-113418-verified.zip | M4 HR + Payroll | Yes | Valid | payroll-country-plugins |
| 13 | m5-crm-sales-verified-20260915-105200.zip | M5 CRM + Sales | Yes | Valid | sales-pipeline-engine |
| 14 | m6-billing-invoicing-20260914-201228.zip | M6 Billing + Invoicing | Yes | Valid | Partial |
| 15 | m7-inventory-purchase-20260915182449.zip | M7 Inventory + Purchase | Yes | Valid | barcode + uom engines |
| 16 | m8-finance-accounting-20260915052622.zip | M8 Finance + Accounting | Yes | Valid | gl-engine |
| 17 | m9-manufacturing-projects-verified-20260916073322.zip | M9 Manufacturing + Projects | Yes | Valid | mrp/gantt/quality |
| 18 | m10-ai-service-20260915053124.zip | M10 AI Service | Yes | Valid | apps/ai |
| 19 | m11-offline-sync-20260915-034801.zip | M11 Offline Sync | Yes | Valid | Partial |
| 20 | m12-reports-dashboards-20260916-044507.zip | M12 Reports + Dashboards | Yes | Valid | query-builder |
| 21 | m13-compliance-center-20260915174217.zip | M13 Compliance | Yes | Valid | compliance + dsr engines |
| 22 | m14-k8s-observability-slice1-verified-20260915055650.zip | M14 K8s + Observability | Yes | Valid | Slice 1 |
| 23 | m15-security-hardening-VERIFIED-20260916-164418.zip | M15 Security Hardening | Yes | Valid | security package + tools |
| 24 | s1-control-plane-20260916061444.zip | S1 Control Plane | Yes | Valid | |
| 25 | s2-oracle-provisioning-20260915173005.zip | S2 Oracle Provisioning | Yes (nested) | Nested | Partial |
| 26 | s3-backup-dr-slice-20260915T103638Z.zip | S3 Backup/DR | Yes | Valid | Partial |
| 27 | s4-billing-automation-20260916-060319-v2-verified.zip | S4 Billing Automation | Yes | Valid | billing-engine partial |
| 28 | s5-deployment-orchestration-20260915-183555-v2.zip | S5 Deployment Orchestration | Yes | Valid | Partial |
| 29 | s6-customer-portal-verified-20260915-112917.zip | S6 Customer Portal | Yes | Valid | Partial (core services) |

## Missing / Incomplete

- M3.3 RBAC: not present as dedicated zip (may be in M3.1 slice)
- Many S* and advanced are partial deliveries per their own MANIFESTs (honest about network limits and no base repo)

## Merge Status

Base (M1+M2+M3 slices) + most packages merged via skip-old-files.

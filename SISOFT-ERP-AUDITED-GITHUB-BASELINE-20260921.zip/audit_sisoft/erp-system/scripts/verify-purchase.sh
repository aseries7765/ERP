#!/usr/bin/env bash
set -euo pipefail

: "${DATABASE_URL:?DATABASE_URL is required}"
: "${APP_DATABASE_URL:?APP_DATABASE_URL is required for runtime/RLS verification}"
: "${REDIS_URL:?REDIS_URL is required for audit queue verification}"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

pnpm exec prisma validate --schema=prisma/schema.prisma
pnpm exec prisma generate --schema=prisma/schema.prisma
pnpm --filter @erp/api test -- --runInBand purchase
pnpm --filter @erp/api typecheck

# Runtime gates are intentionally explicit. This script refuses to call them
# PASS unless the required services are available and the commands succeed.
pnpm exec prisma migrate deploy --schema=prisma/schema.prisma
pnpm --filter @erp/api test:e2e -- --runInBand purchase

echo "PURCHASE MODULE AUTOMATED GATES PASSED"

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHEMA="$ROOT/prisma/schema.prisma"
MIG="$ROOT/prisma/migrations/20260917_rbac_persistence_stage17/migration.sql"
python3 - "$SCHEMA" "$MIG" <<'PY'
import re,sys
schema=open(sys.argv[1]).read(); mig=open(sys.argv[2]).read()
models=re.findall(r'^model\s+(\w+)\s*\{',schema,re.M)
assert len(models)==len(set(models)), 'duplicate Prisma models'
for m in ['GroupPermission','PolicyPermission','DelegationPermission']:
    assert re.search(r'^model\s+'+m+r'\s*\{',schema,re.M), m+' missing'
    assert m[0].lower()+m[1:] in schema, m+' relation/name missing'
for table in ['group_permissions','policy_permissions','delegation_permissions']:
    assert f'CREATE TABLE IF NOT EXISTS "{table}"' in mig, table+' migration missing'
    assert f'"tenantId" UUID NOT NULL' in mig, table+' tenant scope missing'
    assert 'UNIQUE' in mig, table+' uniqueness missing'
for table in ['group_permissions','policy_permissions','delegation_permissions']:
    assert table in schema, table+' schema mapping missing'
print(f'RBAC Stage 17 static gates PASS: {len(models)} unique Prisma models; 3 persistence bridge models; migration present')
PY

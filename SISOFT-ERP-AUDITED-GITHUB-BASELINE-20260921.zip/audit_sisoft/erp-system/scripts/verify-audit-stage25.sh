#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -q "class AuditService" apps/api/src/audit/audit.service.ts || fail "AuditService missing"
grep -q "append({" apps/api/src/audit/audit.service.ts || fail "durable outbox append missing"
grep -q "class AuditIntegrityService" apps/api/src/audit/audit-integrity.service.ts || fail "integrity service missing"
grep -q "pg_advisory" apps/api/src/queue/audit-consumer.service.ts || fail "audit consumer chain lock missing"
grep -q "erp.core.audit_trail.read" apps/api/src/audit/audit.controller.ts || fail "audit permission missing"
grep -q "AuditModule" apps/api/src/app.module.ts || fail "AuditModule not registered"
python3 - <<'PY'
from pathlib import Path
for f in ['apps/api/src/audit/audit.service.ts','apps/api/src/audit/audit-integrity.service.ts','apps/api/src/audit/audit-query.service.ts','apps/api/src/audit/audit.controller.ts','apps/api/src/audit/audit.module.ts']:
    s=Path(f).read_text();
    if s.count('{') != s.count('}'): raise SystemExit(f'brace mismatch: {f}')
    if s.count('(') != s.count(')'): raise SystemExit(f'paren mismatch: {f}')
models=[]
for line in Path('prisma/schema.prisma').read_text().splitlines():
    if line.startswith('model '): models.append(line.split()[1])
if len(models)!=len(set(models)): raise SystemExit('duplicate Prisma model')
print(f'Audit Stage 25 static gates PASS: {len(models)} unique Prisma models')
PY

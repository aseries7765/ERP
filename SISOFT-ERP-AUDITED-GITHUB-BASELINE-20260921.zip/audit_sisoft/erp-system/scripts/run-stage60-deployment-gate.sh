#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

python3 scripts/verify-stage60-deployment.py

: "${STAGE60_API_BASE_URL:?STAGE60_API_BASE_URL is required}"
: "${STAGE60_WEB_BASE_URL:?STAGE60_WEB_BASE_URL is required}"
: "${STAGE60_API_IMAGE_DIGEST:?STAGE60_API_IMAGE_DIGEST is required}"
: "${STAGE60_WEB_IMAGE_DIGEST:?STAGE60_WEB_IMAGE_DIGEST is required}"
: "${STAGE60_MIGRATION_VERIFY_COMMAND:?STAGE60_MIGRATION_VERIFY_COMMAND is required}"
: "${STAGE60_ROLLBACK_VERIFY_COMMAND:?STAGE60_ROLLBACK_VERIFY_COMMAND is required}"

command -v curl >/dev/null || { echo 'STAGE60 RUNTIME BLOCKED: curl is required'; exit 2; }

curl --fail --silent --show-error --max-time 10 "$STAGE60_API_BASE_URL/health/live" >/dev/null
curl --fail --silent --show-error --max-time 10 "$STAGE60_API_BASE_URL/health/ready" >/dev/null
curl --fail --silent --show-error --max-time 10 "$STAGE60_WEB_BASE_URL/" >/dev/null

case "$STAGE60_API_IMAGE_DIGEST" in sha256:*) ;; *) echo 'STAGE60 RUNTIME BLOCKED: API image must be immutable sha256 digest'; exit 2;; esac
case "$STAGE60_WEB_IMAGE_DIGEST" in sha256:*) ;; *) echo 'STAGE60 RUNTIME BLOCKED: web image must be immutable sha256 digest'; exit 2;; esac

bash -lc "$STAGE60_MIGRATION_VERIFY_COMMAND"
bash -lc "$STAGE60_ROLLBACK_VERIFY_COMMAND"

echo 'STAGE60 RUNTIME PASS'

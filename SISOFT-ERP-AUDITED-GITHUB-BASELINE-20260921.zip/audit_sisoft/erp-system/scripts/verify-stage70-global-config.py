#!/usr/bin/env python3
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
policy_path = ROOT / "config/stage70-global-configuration-policy.json"
doc_path = ROOT / "docs-STAGE70-GLOBAL-CONFIG-FEATURE-FLAGS.md"
exc_path = ROOT / "docs-STAGE70-EXCEPTIONS.md"

policy = json.loads(policy_path.read_text())
doc = doc_path.read_text()
exc = exc_path.read_text()

required_scopes = {"global", "environment", "region", "tenant", "service"}
assert set(policy["scopes"]) == required_scopes
assert policy["precedence"] == ["global", "environment", "region", "tenant", "service"]
assert policy["principles"]["single_authority"] == "control-plane"
assert policy["principles"]["immutable_versions"] is True
assert policy["principles"]["typed_validation"] is True
assert policy["principles"]["secrets_are_references_only"] is True
assert policy["principles"]["fail_closed_for_security_critical_stale_config"] is True
assert policy["publication"]["atomic_activation_required"] is True
assert policy["publication"]["rollback_to_known_good_required"] is True
assert policy["feature_flags"]["percentage_rollout_requires_stable_hash"] is True

terms = [
    "control plane", "immutable", "typed", "secret", "deterministic",
    "percentage rollout", "canary", "kill switch", "atomic", "rollback",
    "fail closed", "drift", "reconciliation", "tenant isolation", "runtime evidence"
]
for term in terms:
    assert term.lower() in doc.lower(), f"missing documentation term: {term}"

assert "No runtime PASS" in exc
assert "No fabricated" in exc
assert "100M+" in exc

# Reject obvious measured-looking claims in this static contract unless explicitly marked unavailable.
for pattern in [r"\b\d+(?:\.\d+)?\s*(?:ms|sec|seconds)\s*(?:p95|p99|latency)", r"\b\d+(?:\.\d+)?\s*(?:requests|rps)\s*/?\s*(?:sec|second)"]:
    assert not re.search(pattern, doc, re.I), "unverified runtime measurement found in static stage document"

print("STAGE70 STATIC PASS")
print("Configuration matrix: typed config, scoped precedence, feature flags, rollout, kill switch, freshness, rollback, drift reconciliation")
print("Runtime verdict: BLOCKED until representative configuration distribution and multi-region evidence are supplied")

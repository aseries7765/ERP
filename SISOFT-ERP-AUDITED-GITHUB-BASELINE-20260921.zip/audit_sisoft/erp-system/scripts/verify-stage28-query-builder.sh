#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$ROOT/packages/query-builder/src/index.ts"
test -f "$ROOT/packages/query-builder/src/compiler.ts"
test -f "$ROOT/packages/query-builder/src/safety.ts"
grep -q "Tenant scope is required" "$ROOT/packages/query-builder/src/compiler.ts"
grep -q 'params: unknown\[\]' "$ROOT/packages/query-builder/src/compiler.ts"
grep -q 'MAX_ROW_LIMIT = 10_000' "$ROOT/packages/query-builder/src/safety.ts"
grep -q 'workspace:\*' "$ROOT/apps/api/package.json"
if tsc -p "$ROOT/packages/query-builder/tsconfig.json" --noEmit; then
  echo "Stage 28 static gates PASS: query-builder source recovered and type-checks"
else
  echo "Stage 28 static gates FAIL: query-builder type-check failed" >&2; exit 1
fi

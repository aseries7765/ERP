#!/usr/bin/env python3
"""Stage 58 static production-configuration and operational safety gate.

This gate never proves that production infrastructure exists. It verifies that
source/configuration contracts fail closed and that deployment requirements are
explicitly documented. Runtime checks remain BLOCKED until an actual target
environment is supplied.
"""
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]

def fail(msg):
    print(f"STAGE58 STATIC FAIL: {msg}")
    sys.exit(1)

def read(path):
    p=ROOT/path
    if not p.is_file(): fail(f"missing {path}")
    return p.read_text(encoding='utf-8')

prisma=read('apps/api/src/prisma/prisma.service.ts')
main=read('apps/api/src/main.ts')
health=read('apps/api/src/health/health.controller.ts')
env=read('.env.example')
security_env=read('apps/api/security.env.example')
rate=read('apps/api/src/common/rate-limiter.ts')

def require(text, needle, label):
    if needle not in text: fail(f"{label}: missing {needle}")

# Database least privilege: production must not silently fall back to migration role.
require(prisma, "process.env.NODE_ENV === 'production'", 'database runtime role')
require(prisma, 'throw new Error(', 'database runtime role')
require(prisma, 'APP_DATABASE_URL is required in production', 'database runtime role')
require(prisma, 'return appUrl ?? process.env.DATABASE_URL', 'database runtime resolution')

# Auth/security configuration must be fail-fast and use RS256 public-key verification.
require(read('apps/api/src/config/auth.config.ts'), 'JWT_PRIVATE_KEY', 'auth secrets')
require(read('apps/api/src/config/auth.config.ts'), 'JWT_PUBLIC_KEY', 'auth secrets')
require(read('apps/api/src/config/auth.config.ts'), 'NODE_ENV !== \'production\' || !!cfg.WEBAUTHN_RP_ID', 'production auth config')
require(read('apps/api/src/modules/auth/strategies/jwt.strategy.ts'), "algorithms: ['RS256']", 'JWT algorithm')

# CORS/CSRF origin allowlisting exists; no wildcard origin should be used.
csrf=read('apps/api/src/security/middleware/csrf.middleware.ts')
require(csrf, 'ALLOWED_ORIGINS', 'origin allowlist')
if re.search(r"ALLOWED_ORIGINS\s*=\s*\*", env): fail('wildcard ALLOWED_ORIGINS in example')

# Security headers / CSRF package contracts remain present.
security_files=list((ROOT/'apps/api/src/security').rglob('*.ts'))
security_text='\n'.join(p.read_text(encoding='utf-8') for p in security_files)
require(security_text, 'isTrustedOrigin', 'strict CORS resolver')
require(security_text, 'csrf', 'CSRF security implementation')

# Rate limiting is explicitly identified as a distributed production dependency.
require(rate, 'Redis-backed', 'distributed rate limiting')
require(rate, 'per tenant + per IP + per endpoint', 'rate-limit scope')

# Health endpoints exist, but readiness must not be misrepresented as dependency proof.
require(health, "@Get('live')", 'liveness endpoint')
require(health, "@Get('ready')", 'readiness endpoint')
if 'Database/Redis/queue checks are added here in M3+' in health:
    print('STAGE58 NOTE: readiness dependency checks are not yet implemented; runtime release gate remains BLOCKED.')

# TLS is an infrastructure control and must be explicit in production documentation/config.
require(security_env, 'TLS_CERT_ROTATION_DAYS=60', 'TLS operational contract')
for phrase in ('TLS 1.3', 'TLS 1.2', 'backup'):
    require(read('docs/security/DATA_ENCRYPTION.md'), phrase, f'infrastructure security contract ({phrase})')

# Production env must not silently use development credentials.
for bad in ('erp_dev_password', 'erp_minio_password', 'changeme-32-byte-random-value-here'):
    if bad in env:
        # Development .env.example may contain placeholders, but the gate requires
        # explicit production instructions to reject these values.
        pass
prod=read('PRODUCTION-READINESS.md')
require(read('docs/security/SECRETS_MANAGEMENT.md'), 'HashiCorp Vault', 'production secret management')
require(prod, 'APP_DATABASE_URL', 'production DB role')
require(prod, 'backups', 'backup requirement')
require(prod, 'observability', 'observability requirement')

# No real secret-looking private key may be committed in the example configuration.
if 'BEGIN PRIVATE KEY' in env or 'BEGIN RSA PRIVATE KEY' in env:
    fail('private key material found in .env.example')

print('STAGE58 STATIC PASS')
print('Production DB role fail-closed: PASS')
print('Auth/JWT production contract: PASS')
print('Origin/CSRF allowlist contract: PASS')
print('Distributed rate-limit requirement: DOCUMENTED')
print('TLS/secrets/backup/observability requirements: DOCUMENTED')
print('Runtime production verification: BLOCKED until real target environment exists')

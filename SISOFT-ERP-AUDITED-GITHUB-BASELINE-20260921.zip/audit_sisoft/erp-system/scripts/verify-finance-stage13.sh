#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE="$ROOT/apps/api/src/modules/finance/services/finance.service.ts"
CONTROLLER="$ROOT/apps/api/src/modules/finance/controllers/finance.controller.ts"
DOC="$ROOT/docs/modules/finance/STAGE13-AR-AP-AGING.md"
python3 - "$SERVICE" "$CONTROLLER" <<'PY'
from pathlib import Path
import sys,re
svc,ctl=map(lambda x:Path(x).read_text(),sys.argv[1:])
checks=[
 ('AR method','async accountsReceivableAging(' in svc),
 ('AP method','async accountsPayableAging(' in svc),
 ('AR tenant scope',"where:{tenantId,deletedAt:null,status:{in:['issued','partially_paid','overdue']}" in svc),
 ('AP tenant scope',"where:{tenantId,deletedAt:null,status:'posted'" in svc),
 ('AR decimal balance','inv.total.sub(inv.amountPaid)' in svc),
 ('AP decimal balance','bill.total.sub(bill.amountPaid)' in svc),
 ('AR endpoint',"reports/ar-aging" in ctl),
 ('AP endpoint',"reports/ap-aging" in ctl),
 ('report permission',"erp.finance.financial_report.read" in ctl),
]
for name,ok in checks:
    if not ok: raise SystemExit('FAIL: '+name)
for label,text in [('service',svc),('controller',ctl)]:
    if text.count('{')!=text.count('}') or text.count('(')!=text.count(')'):
        raise SystemExit('FAIL: '+label+' delimiter imbalance')
print('Finance Stage 13 static gates PASS')
print('AR/AP aging methods and endpoints present; tenant/decimal guards detected')
PY
[[ -s "$DOC" ]]
echo "Finance Stage 13 documentation PASS"

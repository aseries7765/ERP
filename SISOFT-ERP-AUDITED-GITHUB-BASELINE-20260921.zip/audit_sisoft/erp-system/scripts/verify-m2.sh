#!/usr/bin/env bash
# ==============================================================================
# scripts/verify-m2.sh
# ==============================================================================
# Runs the actual M2 pipeline (schema sync -> raw SQL -> seed -> DB tests)
# against a real Postgres and prints what actually happened — pass/fail
# counts come from Jest's own exit code and output, never a hardcoded
# number. This script has NOT been run in the sandbox that generated it
# (no live Postgres, no network there) — you are the first to execute it.
#
# WHAT THIS SCRIPT DOES vs. prisma/README.md's full workflow:
# This script uses `prisma db push` (schema -> DB directly, no migration
# history), the same approach CI uses, because it's meant to be a fast,
# repeatable "does everything actually work" check you can re-run anytime
# — not a substitute for generating real tracked migrations. Do the
# `prisma migrate dev` dance in prisma/README.md once, for real, tracked
# migration history; use this script as a smoke test whenever you want to
# confirm the schema, RLS, and seeds all still work together.
#
# REQUIRES: docker compose up -d postgres already running (or any Postgres
# 16 reachable at DATABASE_URL), and .env populated from .env.example.
# ==============================================================================

set -uo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

PASS=0
FAIL=0
STEPS_RUN=()

step() {
  local description="$1"
  shift
  echo ""
  echo "── ${description} ──────────────────────────────────────────"
  if "$@"; then
    echo "✓ PASS: ${description}"
    PASS=$((PASS + 1))
    STEPS_RUN+=("PASS: ${description}")
    return 0
  else
    local code=$?
    echo "✗ FAIL (exit ${code}): ${description}"
    FAIL=$((FAIL + 1))
    STEPS_RUN+=("FAIL: ${description}")
    return "${code}"
  fi
}

echo "=============================================================="
echo " M2 verification — $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "=============================================================="

# ---- 0. Preconditions -------------------------------------------------------
if [ -f .env ]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

if [ -z "${DATABASE_URL:-}" ]; then
  echo "✗ DATABASE_URL is not set (copy .env.example to .env, or export it)."
  exit 1
fi
if [ -z "${APP_DATABASE_URL:-}" ]; then
  echo "✗ APP_DATABASE_URL is not set. The DB test suite refuses to run"
  echo "  without it (see apps/api/test/db/test-db.helper.ts) — running RLS"
  echo "  tests as the migration superuser would make them pass for the"
  echo "  wrong reason. See .env.example."
  exit 1
fi

command -v pnpm >/dev/null 2>&1 || { echo "✗ pnpm not found on PATH."; exit 1; }
command -v psql >/dev/null 2>&1 || { echo "✗ psql not found on PATH."; exit 1; }

# ---- 1. Install + generate ---------------------------------------------------
step "pnpm install" pnpm install --frozen-lockfile
step "prisma generate" pnpm db:generate

# ---- 2. Schema sync (db push — see header note on why, not migrate here) ----
step "apply uuid_generate_v7() (idempotent)" \
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f prisma/raw-sql/01-uuid-v7-function.sql

step "prisma db push (sync schema.prisma -> database)" \
  pnpm --filter @erp/api db:push --accept-data-loss --skip-generate

step "apply RLS + triggers (idempotent — uses DROP POLICY/TRIGGER IF EXISTS)" \
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f prisma/raw-sql/02-rls-and-triggers.sql

step "apply erp_app grants (idempotent)" \
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f prisma/raw-sql/03-app-role-grants.sql

# ---- 3. Seed -----------------------------------------------------------------
step "pnpm db:seed" pnpm db:seed

# ---- 4. Tests ------------------------------------------------------------
step "pnpm test (unit tests)" pnpm test
step "pnpm test:e2e (health endpoint, full AppModule)" pnpm test:e2e
step "pnpm test:db (RLS / soft-delete / audit / optimistic-lock / schema / seeds)" pnpm test:db

# ---- 5. Report -----------------------------------------------------------
echo ""
echo "=============================================================="
echo " SUMMARY"
echo "=============================================================="
for line in "${STEPS_RUN[@]}"; do
  echo "  $line"
done
echo ""
echo "  ${PASS} step(s) passed, ${FAIL} step(s) failed."
if [ "$FAIL" -eq 0 ]; then
  echo "  M2 pipeline verified end-to-end."
else
  echo "  M2 pipeline has failures — see the step output above for the"
  echo "  actual error, not a summary of it."
fi
echo "=============================================================="

exit "$FAIL"

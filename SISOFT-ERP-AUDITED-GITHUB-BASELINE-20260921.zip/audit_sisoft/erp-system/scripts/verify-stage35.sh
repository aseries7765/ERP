#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
node - <<'JS'
const fs=require('fs'),path=require('path');
const root=process.cwd();
const packages={};
for(const d of fs.readdirSync(path.join(root,'packages'))){const f=path.join(root,'packages',d,'package.json');if(fs.existsSync(f)){const p=JSON.parse(fs.readFileSync(f));packages[p.name]=d;}}
const errors=[];
for(const app of fs.readdirSync(path.join(root,'apps'))){const f=path.join(root,'apps',app,'package.json');if(!fs.existsSync(f))continue;const p=JSON.parse(fs.readFileSync(f));for(const dep of Object.keys({...p.dependencies,...p.devDependencies}))if(dep.startsWith('@erp/')&&!packages[dep])errors.push(`${p.name}: unresolved workspace dependency ${dep}`);}
if(errors.length){console.error(errors.join('\n'));process.exit(1)}
console.log(`Stage 35 workspace dependency graph PASS: ${Object.keys(packages).length} workspace packages resolved`);
JS
node - <<'JS'
const fs=require('fs');
for(const f of ['apps/api/package.json','apps/api/compliance.dependencies.json']){const p=JSON.parse(fs.readFileSync(f));if(p.dependencies&&p.dependencies['@erp/compliance-engine'])process.exit(1)}
console.log('Stage 35 stale compliance-engine dependency removal PASS');
JS
node - <<'JS'
const fs=require('fs'),path=require('path');
let bad=[];
for(const base of ['packages','apps'])for(const name of fs.readdirSync(path.join(process.cwd(),base))){const f=path.join(process.cwd(),base,name,'package.json');if(!fs.existsSync(f))continue;const p=JSON.parse(fs.readFileSync(f));for(const [k,v] of Object.entries({...p.dependencies,...p.devDependencies}))if(k.startsWith('@erp/')&&v==='workspace:*'&&!fs.existsSync(path.join(process.cwd(),'packages',k.slice(5),'package.json')))bad.push(`${p.name}:${k}`)}
if(bad.length){console.error(bad.join('\n'));process.exit(1)}
console.log('Stage 35 workspace protocol consistency PASS');
JS
for p in packages/*; do if [[ -f "$p/tsconfig.json" ]]; then tsc -p "$p/tsconfig.json" --noEmit; fi; done
echo 'Stage 35 reconstructed-package static typecheck PASS'

#!/usr/bin/env python3
"""Stage 56 static mutation/rollback contract gate.

This verifies source contracts only. Runtime PASS is reserved for the guarded
HTTP/database harness after real disposable fixtures are supplied.
"""
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
API=ROOT/'apps/api/src'

def fail(m): print('STAGE56 STATIC FAIL:',m); sys.exit(1)
def read(p):
    if not p.is_file(): fail(f'missing {p}')
    return p.read_text(encoding='utf-8')

sales=read(API/'modules/sales/services/sales.service.ts')
finance=read(API/'modules/finance/services/finance.service.ts')
role=read(API/'modules/rbac/services/role.service.ts')
atomic=read(API/'modules/rbac/services/atomic-rbac-mutation.ts')
prisma=read(API/'prisma/prisma.service.ts')
tenant=read(API/'modules/auth/guards/tenant.guard.ts')

# Mutation paths must remain tenant-bound and optimistic-concurrency aware where
# a mutable row is updated. These are source contracts, not simulated results.
for name,text in [('sales',sales),('finance',finance)]:
    if 'tenantId' not in text: fail(f'{name}: tenant scope missing')
    if 'withTenant' not in text and '$transaction' not in text: fail(f'{name}: tenant transaction wrapper missing')
    if not re.search(r'\.update\(|\.updateMany\(', text): fail(f'{name}: mutation update contract missing')
if 'version' not in finance: fail('finance: optimistic version contract missing')


# RBAC writes must remain in the transaction/outbox boundary.
if role.count('atomicRbacMutation') < 3: fail('RBAC role writes lost atomic mutation boundary')
for needle in ('withTenantTransaction','emitInTransaction','mutate(txRepo)'):
    if needle not in atomic: fail(f'atomic helper missing {needle}')

# Tenant context must be derived from verified JWT and transaction-local DB state.
for needle in ('payload?.tid','payload?.sub','enterWith({ tenantId: payload.tid, userId: payload.sub })'):
    if needle not in tenant: fail(f'TenantGuard missing {needle}')
if 'req.headers' in tenant or 'x-tenant' in tenant.lower(): fail('client-controlled tenant header detected')
if "SELECT set_config('app.current_tenant', ${tenantId}, true)" not in prisma:
    fail('database tenant context is not parameterized transaction-local state')

# Audit/outbox implementation must be present and append-only protections must
# remain part of the database gate chain.
outbox=ROOT/'apps/api/src/audit'
if not outbox.exists(): fail('audit module missing')
if not list(outbox.rglob('*.ts')): fail('audit module has no TypeScript implementation')
if not (ROOT/'scripts/run-stage54-evidence-gate.sh').is_file(): fail('Stage 54 evidence prerequisite missing')

# Controller-level negative authorization contract: all RBAC controllers keep
# explicit guard composition so mutation denial cannot rely on an implicit global guard.
rbac_dir=API/'modules/rbac/controllers'
for p in rbac_dir.glob('*.controller.ts'):
    t=read(p)
    if '@UseGuards(JwtAuthGuard, TenantGuard, PermissionGuard)' not in t:
        fail(f'RBAC controller guard chain missing: {p.name}')

print('STAGE56 STATIC PASS')
print('Mutation tenant scope: PASS')
print('Optimistic concurrency contract: PASS')
print('RBAC atomic mutation + outbox boundary: PASS')
print('JWT-derived tenant + transaction-local DB context: PASS')
print('Audit/outbox prerequisite: PASS')
print('Runtime verdict: BLOCKED until real disposable API/database execution')

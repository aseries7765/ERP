#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
import json, pathlib, sys
p=pathlib.Path('prisma/BASELINE-CANDIDATE-STAGE43.json')
d=json.load(open(p))
assert d['schema_model_count']==193
assert d['tracked_table_count']==74
assert d['untracked_table_count']==119
assert len(d['rows'])==119
assert sum(x['executable_baseline_candidate'] for x in d['rows'])==21
assert all(x['historical_status']=='RECONSTRUCTED_FROM_CURRENT_SCHEMA_ONLY' for x in d['rows'])
assert all(x['runtime_validation']=='BLOCKED_UNTIL_PRISMA_POSTGRES_AVAILABLE' for x in d['rows'])
print('Stage 43 baseline-candidate inventory PASS: 119 untracked tables classified')
print('Foundation executable-candidate review flag PASS: 21 models')
print('Historical recovery claims: 0')
print('Runtime validation: BLOCKED (Prisma/PostgreSQL unavailable)')
PY

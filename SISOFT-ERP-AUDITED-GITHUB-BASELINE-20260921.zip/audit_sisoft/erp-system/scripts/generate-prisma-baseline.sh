#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHEMA="$ROOT/prisma/schema.prisma"
OUT_DIR="$ROOT/prisma/baseline-generated"
OUT="$OUT_DIR/migration.sql"

if [[ "${ALLOW_BASELINE_GENERATION:-}" != "1" ]]; then
  echo "Refusing baseline generation without ALLOW_BASELINE_GENERATION=1" >&2
  echo "This guard prevents accidental migration-history mutation." >&2
  exit 2
fi

if ! command -v pnpm >/dev/null 2>&1; then
  echo "pnpm is required; install the pinned package-manager version first." >&2
  exit 3
fi

if ! pnpm exec prisma --version >/dev/null 2>&1; then
  echo "Prisma CLI is not installed. Run the repository dependency installation first." >&2
  exit 4
fi

bash "$ROOT/scripts/verify-stage47-prisma-baseline-gate.sh"
mkdir -p "$OUT_DIR"
TMP="$OUT.tmp"
rm -f "$TMP"

# migrate diff --from-empty is deliberately used instead of migrate dev.
# It does not inspect or rewrite the existing migration ledger.
pnpm exec prisma migrate diff \
  --from-empty \
  --to-schema-datamodel "$SCHEMA" \
  --script > "$TMP"

mv "$TMP" "$OUT"
sha256sum "$OUT" | tee "$OUT.sha256"
echo "Generated candidate baseline: $OUT"
echo "Review the SQL before creating/installing any migration folder."

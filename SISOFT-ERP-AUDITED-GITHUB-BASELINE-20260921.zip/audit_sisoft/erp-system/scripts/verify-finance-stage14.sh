#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
S="$ROOT/apps/api/src/modules/finance/services/finance.service.ts"
C="$ROOT/apps/api/src/modules/finance/controllers/finance.controller.ts"
D="$ROOT/docs/modules/finance/STAGE14-AR-AP-STATEMENTS.md"
for f in "$S" "$C" "$D"; do test -f "$f"; done
grep -q 'async accountsReceivableStatement' "$S"
grep -q 'async accountsPayableStatement' "$S"
grep -q "reports/ar-statements/:accountId" "$C"
grep -q "reports/ap-statements/:vendorId" "$C"
grep -q 'tenantId' "$S"
grep -q 'Prisma.Decimal' "$S"
python3 - "$S" "$C" <<'PY'
import sys
for p in sys.argv[1:]:
 s=open(p).read()
 for a,b,name in [('{','}','braces'),('(',')','parentheses')]:
  if s.count(a)!=s.count(b): raise SystemExit(f'{p}: {name} mismatch')
PY
printf '%s\n' 'Finance Stage 14 static gates PASS'

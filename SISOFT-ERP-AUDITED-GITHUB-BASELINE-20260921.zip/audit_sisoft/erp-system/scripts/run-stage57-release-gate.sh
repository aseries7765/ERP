#!/usr/bin/env bash
set -euo pipefail
python3 scripts/verify-stage57-release-gate.py

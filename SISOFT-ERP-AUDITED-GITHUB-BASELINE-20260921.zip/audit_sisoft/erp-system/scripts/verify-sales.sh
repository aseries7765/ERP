#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL is required}"
: "${APP_DATABASE_URL:?APP_DATABASE_URL is required}"
: "${REDIS_URL:?REDIS_URL is required}"
pnpm exec prisma validate
pnpm exec prisma generate
pnpm exec jest --runInBand apps/api/test/sales
pnpm --filter api typecheck
pnpm exec prisma migrate deploy
pnpm exec jest --runInBand apps/api/test/e2e/sales
printf 'SALES MODULE AUTOMATED GATES PASSED\n'

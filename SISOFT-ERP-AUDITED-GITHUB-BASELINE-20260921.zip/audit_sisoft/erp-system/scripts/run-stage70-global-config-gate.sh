#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts/verify-stage70-global-config.py"

required=(
  STAGE70_CONTROL_PLANE_CONFIG_URL
  STAGE70_PRIMARY_REGION_CONFIG_URL
  STAGE70_SECONDARY_REGION_CONFIG_URL
  STAGE70_PUBLISH_VERIFY_COMMAND
  STAGE70_ROLLOUT_VERIFY_COMMAND
  STAGE70_STALE_CONFIG_VERIFY_COMMAND
  STAGE70_ROLLBACK_VERIFY_COMMAND
  STAGE70_DRIFT_RECONCILIATION_VERIFY_COMMAND
)
for name in "${required[@]}"; do
  if [[ -z "${!name:-}" ]]; then
    echo "RUNTIME BLOCKED: missing $name" >&2
    exit 2
  fi
done

command -v curl >/dev/null || { echo "RUNTIME BLOCKED: curl unavailable" >&2; exit 2; }

curl --fail --silent --show-error --max-time 10 "$STAGE70_CONTROL_PLANE_CONFIG_URL" >/dev/null
curl --fail --silent --show-error --max-time 10 "$STAGE70_PRIMARY_REGION_CONFIG_URL" >/dev/null
curl --fail --silent --show-error --max-time 10 "$STAGE70_SECONDARY_REGION_CONFIG_URL" >/dev/null

bash -lc "$STAGE70_PUBLISH_VERIFY_COMMAND"
bash -lc "$STAGE70_ROLLOUT_VERIFY_COMMAND"
bash -lc "$STAGE70_STALE_CONFIG_VERIFY_COMMAND"
bash -lc "$STAGE70_ROLLBACK_VERIFY_COMMAND"
bash -lc "$STAGE70_DRIFT_RECONCILIATION_VERIFY_COMMAND"

echo "STAGE70 RUNTIME PASS"

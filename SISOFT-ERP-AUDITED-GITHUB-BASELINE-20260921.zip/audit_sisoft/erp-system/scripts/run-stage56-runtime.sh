#!/usr/bin/env bash
set -euo pipefail

: "${STAGE56_ALLOW_RUNTIME:=0}"
: "${STAGE56_DISPOSABLE_DB:=0}"
: "${API_BASE_URL:=http://localhost:3001}"

if [[ "$STAGE56_ALLOW_RUNTIME" != "1" || "$STAGE56_DISPOSABLE_DB" != "1" ]]; then
  echo "STAGE56 RUNTIME BLOCKED: set STAGE56_ALLOW_RUNTIME=1 and STAGE56_DISPOSABLE_DB=1"
  exit 2
fi
for cmd in curl python3; do command -v "$cmd" >/dev/null || { echo "STAGE56 RUNTIME BLOCKED: missing $cmd"; exit 2; }; done
: "${STAGE56_BEARER_TOKEN:?STAGE56 RUNTIME BLOCKED: STAGE56_BEARER_TOKEN is required}"
: "${STAGE56_TENANT_A_ID:?STAGE56 RUNTIME BLOCKED: STAGE56_TENANT_A_ID is required}"
: "${STAGE56_TENANT_B_ID:?STAGE56 RUNTIME BLOCKED: STAGE56_TENANT_B_ID is required}"
: "${STAGE56_SALES_QUOTE_ID:?STAGE56 RUNTIME BLOCKED: STAGE56_SALES_QUOTE_ID is required}"
: "${STAGE56_FINANCE_ACCOUNT_ID:?STAGE56 RUNTIME BLOCKED: STAGE56_FINANCE_ACCOUNT_ID is required}"
: "${STAGE56_RBAC_ROLE_ID:?STAGE56 RUNTIME BLOCKED: STAGE56_RBAC_ROLE_ID is required}"
: "${STAGE56_CURRENT_VERSION:?STAGE56 RUNTIME BLOCKED: STAGE56_CURRENT_VERSION is required}"

python3 scripts/verify-stage56-runtime-mutations.py

curl -fsS --max-time 10 "$API_BASE_URL/health/live" > stage56-health-response.txt
headers=(-H "Authorization: Bearer $STAGE56_BEARER_TOKEN" -H 'Accept: application/json' -H 'Content-Type: application/json')

# 1) Cross-tenant read must not expose Tenant-B resource through Tenant-A token.
# The endpoint/fixture are caller supplied; HTTP 404/403 is accepted as the
# expected isolation result, while 200 is a hard failure.
code=$(curl -sS -o stage56-cross-tenant.json -w '%{http_code}' --max-time 15 "${headers[@]}" "$API_BASE_URL/v1/sales/quotes/$STAGE56_SALES_QUOTE_ID?tenant_probe=$STAGE56_TENANT_B_ID")
if [[ "$code" == "200" ]]; then echo 'STAGE56 RUNTIME FAIL: cross-tenant resource was readable'; exit 1; fi
if [[ "$code" != "403" && "$code" != "404" ]]; then echo "STAGE56 RUNTIME BLOCKED/FAIL: isolation probe returned HTTP $code"; exit 2; fi

# 2) Optimistic concurrency denial: send an intentionally stale version.
code=$(curl -sS -o stage56-version-conflict.json -w '%{http_code}' --max-time 15 -X POST "${headers[@]}" -d "{\"version\":-1}" "$API_BASE_URL/v1/finance/accounts/$STAGE56_FINANCE_ACCOUNT_ID/lock")
if [[ "$code" == "200" || "$code" == "201" ]]; then echo 'STAGE56 RUNTIME FAIL: stale version mutation succeeded'; exit 1; fi
if [[ "$code" != "400" && "$code" != "409" ]]; then echo "STAGE56 RUNTIME BLOCKED: version probe returned HTTP $code"; exit 2; fi

# 3) Permission denial requires an explicitly supplied low-privilege token.
if [[ -z "${STAGE56_LOW_PRIVILEGE_TOKEN:-}" ]]; then echo 'STAGE56 RUNTIME BLOCKED: STAGE56_LOW_PRIVILEGE_TOKEN required for permission-denial evidence'; exit 2; fi
low=(-H "Authorization: Bearer $STAGE56_LOW_PRIVILEGE_TOKEN" -H 'Accept: application/json' -H 'Content-Type: application/json')
code=$(curl -sS -o stage56-permission-denial.json -w '%{http_code}' --max-time 15 -X POST "${low[@]}" -d '{"name":"stage56-denial-probe"}' "$API_BASE_URL/v1/rbac/roles")
if [[ "$code" != "401" && "$code" != "403" ]]; then echo "STAGE56 RUNTIME FAIL: expected permission denial, got HTTP $code"; exit 1; fi

# 4) A mutation that is expected to fail after its transactional work must be
# exercised only when a caller supplies a purpose-built rollback fixture and URL.
if [[ -z "${STAGE56_ROLLBACK_URL:-}" || -z "${STAGE56_ROLLBACK_BODY:-}" ]]; then
  echo 'STAGE56 RUNTIME BLOCKED: rollback fixture URL/body not supplied; no rollback PASS inferred'
  exit 2
fi
code=$(curl -sS -o stage56-rollback.json -w '%{http_code}' --max-time 20 -X POST "${headers[@]}" -d "$STAGE56_ROLLBACK_BODY" "$STAGE56_ROLLBACK_URL")
if [[ "$code" == "2"* ]]; then echo "STAGE56 RUNTIME FAIL: rollback probe unexpectedly succeeded HTTP $code"; exit 1; fi
if [[ "$code" != "4"* && "$code" != "5"* ]]; then echo "STAGE56 RUNTIME BLOCKED: rollback probe returned HTTP $code"; exit 2; fi

echo 'STAGE56 RUNTIME PASS'
echo 'Disposable authenticated mutation, tenant isolation, permission denial, optimistic concurrency, and rollback probes executed.'

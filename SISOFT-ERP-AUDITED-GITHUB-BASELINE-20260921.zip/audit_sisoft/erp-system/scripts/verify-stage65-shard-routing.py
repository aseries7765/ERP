#!/usr/bin/env python3
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
POLICY = ROOT / "config" / "stage65-shard-routing-policy.json"
DOC = ROOT / "docs-STAGE65-SHARD-ROUTING-TENANT-PLACEMENT.md"
EXC = ROOT / "docs-STAGE65-EXCEPTIONS.md"

required_routing = {"authority", "tenant_key", "deterministic_algorithm", "mapping_version_required", "unknown_tenant", "mapping_change"}
required_runtime = {
    "real-multi-shard-topology", "tenant-routing-resolution", "placement-version-consistency",
    "migration-copy-and-verification", "cutover-fencing", "rollback-or-recovery",
    "cross-shard-query-restriction", "rebalancing-checkpoint-and-orphan-detection", "evidence_sha256"
}
required_doc_terms = [
    "Tenant-to-shard routing", "Partitioning boundaries", "Safe shard migration",
    "Rebalancing", "Cross-shard query restrictions", "100M+", "Runtime evidence gate"
]


def fail(msg):
    raise SystemExit(f"STAGE65 STATIC FAIL: {msg}")

if not POLICY.exists():
    fail("missing shard routing policy")
if not DOC.exists() or not EXC.exists():
    fail("missing Stage 65 documentation")

try:
    policy = json.loads(POLICY.read_text())
except Exception as exc:
    fail(f"invalid JSON policy: {exc}")

if policy.get("version") != 1:
    fail("unexpected policy version")
if not required_routing.issubset(policy.get("routing", {})):
    fail("routing contract is incomplete")
if policy.get("partition_boundaries", {}).get("cross_tenant_access") != "forbidden-by-default":
    fail("cross-tenant default is not fail-closed")
if policy.get("partition_boundaries", {}).get("cross_shard_query") != "explicit-command-or-analytics-path-only":
    fail("cross-shard query boundary is incomplete")
if policy.get("migration", {}).get("strategy") != "copy-verify-cutover":
    fail("migration strategy is not copy-verify-cutover")
if policy.get("migration", {}).get("cutover") != "versioned-fencing-token":
    fail("cutover fencing contract missing")
if not policy.get("rebalancing", {}).get("rate_limited"):
    fail("rebalancing is not rate-limited")
if not policy.get("rebalancing", {}).get("one_authoritative_owner"):
    fail("single authoritative owner invariant missing")
if policy.get("query_policy", {}).get("multi_shard_join") != "forbidden-in-request-path":
    fail("ordinary request-path multi-shard joins are not forbidden")

runtime = set(policy.get("runtime_evidence_required", []))
missing = required_runtime - runtime
if missing:
    fail("runtime evidence contract missing: " + ", ".join(sorted(missing)))

text = (DOC.read_text() + "\n" + EXC.read_text())
for term in required_doc_terms:
    if term.lower() not in text.lower():
        fail(f"documentation missing required concept: {term}")

# Reject accidental measured-looking certification language in Stage 65 docs.
for pattern in [r"\b100M\+\s+(?:users|tenants)\s+(?:is|are)\s+(?:verified|proven|certified)", r"\b100M\+\s+(?:users|tenants)\s+(?:verified|proven|certified)"]:
    if re.search(pattern, text, re.I):
        fail("contains an unverified capacity certification claim")

print("STAGE65 STATIC PASS")
print("Shard matrix: routing, partition boundaries, migration fencing, rebalancing, cross-shard query controls")
print("Runtime verdict: BLOCKED until real representative multi-shard infrastructure and evidence are supplied")

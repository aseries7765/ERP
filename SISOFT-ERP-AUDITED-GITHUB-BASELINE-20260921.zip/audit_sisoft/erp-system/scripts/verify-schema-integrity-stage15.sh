#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHEMA="$ROOT/prisma/schema.prisma"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

python3 - "$ROOT" "$SCHEMA" <<'PY'
from pathlib import Path
import re, sys
from collections import Counter
root=Path(sys.argv[1]); schema_path=Path(sys.argv[2])
schema=schema_path.read_text()

def models(text): return re.findall(r'^model\s+(\w+)', text, re.M)
sm=models(schema)
if len(sm) != len(set(sm)):
    print('FAIL: duplicate model names in merged schema')
    raise SystemExit(1)

frags=[]
for p in sorted(root.rglob('*-models.prisma')):
    if 'prisma/schema.prisma' in str(p): continue
    for name in models(p.read_text()): frags.append((p,name))

# The monorepo contains an older workflow fragment whose model names conflict
# with the frozen M2 workflow foundation. These are intentionally excluded;
# merging them would create duplicate/conflicting workflow systems.
intentional_workflow={'WorkflowDefinition','WorkflowVersion','WorkflowTrigger','WorkflowInstance','WorkflowInstanceStep','WorkflowTask','WorkflowLog'}
missing=[]
for p,name in frags:
    if name not in sm and name not in intentional_workflow:
        missing.append((p,name))
if missing:
    print('FAIL: unrepresented non-workflow model fragments:')
    for p,n in missing: print(f'  {p}: {n}')
    raise SystemExit(1)

# Validate each model block has unique field names and no duplicate @@ attributes.
block_re=re.compile(r'^model\s+(\w+)\s*\{(.*?)^\}', re.M|re.S)
for m in block_re.finditer(schema):
    name,body=m.group(1),m.group(2)
    fields=[]; attrs=[]
    for line in body.splitlines():
        s=line.strip()
        if not s or s.startswith('//') or s.startswith('///'): continue
        if s.startswith('@@'): attrs.append(s); continue
        mm=re.match(r'(\w+)\s+',s)
        if mm: fields.append(mm.group(1))
    dup_fields=[x for x,c in Counter(fields).items() if c>1]
    dup_attrs=[x for x,c in Counter(attrs).items() if c>1]
    if dup_fields or dup_attrs:
        print(f'FAIL: duplicate declarations in {name}: fields={dup_fields} attrs={dup_attrs}')
        raise SystemExit(1)

print(f'Merged schema models: {len(sm)} (unique)')
print(f'Model-fragment declarations checked: {len(frags)}')
print('Workflow conflicting fragments: intentionally excluded (foundation schema retained)')
print('Model/field/attribute uniqueness: PASS')
print('ERP Stage 15 schema integrity: PASS')
PY

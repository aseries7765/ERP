#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
from pathlib import Path
import re, sys
root=Path('prisma/migrations')
migs=sorted(p for p in root.iterdir() if p.is_dir() and (p/'migration.sql').exists())
created={}; refs=[]
for m in migs:
    s=(m/'migration.sql').read_text(errors='ignore')
    for a,b in re.findall(r'CREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+(?:"([^"]+)"|([A-Za-z_]\w*))',s,re.I):
        t=a or b; created.setdefault(t,[]).append(m.name)
    for a,b in re.findall(r'REFERENCES\s+(?:"([^"]+)"|([A-Za-z_]\w*))',s,re.I):
        refs.append((m.name,a or b))

dups={t:v for t,v in created.items() if len(v)>1}
missing=sorted(set(t for _,t in refs if t not in created))
print(f'Stage 39 migration-chain static gate: {len(migs)} migrations, {len(created)} created tables')
if dups:
    print('FAIL: duplicate CREATE TABLE ownership')
    for t,v in sorted(dups.items()): print(' ',t,'<-',', '.join(v))
    sys.exit(1)
print('Duplicate table creators: PASS')
print(f'Uncreated FK prerequisites: {len(missing)}')
for t in missing: print(' -',t)
expected={'cost_centers','delegations','groups','permissions','policies'}
if set(missing) != expected:
    print('FAIL: dependency inventory changed unexpectedly')
    sys.exit(1)
print('Dependency inventory: PASS (5 known foundation prerequisites)')
print('Fresh-database migration execution: BLOCKED (PostgreSQL runtime unavailable)')
PY

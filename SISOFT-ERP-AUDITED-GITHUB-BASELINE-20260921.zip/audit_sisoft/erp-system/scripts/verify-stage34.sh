#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
for p in packages/*; do
  if [[ -f "$p/tsconfig.json" ]]; then tsc -p "$p/tsconfig.json" --noEmit; fi
done
node packages/workflow-engine/scripts/selftest.cjs
node - <<'JS'
const fs=require('fs'), path=require('path');
const root=process.cwd();
const workspace=new Set(fs.readdirSync(path.join(root,'packages')).filter(x=>fs.existsSync(path.join(root,'packages',x,'package.json'))).map(x=>JSON.parse(fs.readFileSync(path.join(root,'packages',x,'package.json'))).name));
let errors=[];
for(const app of fs.readdirSync(path.join(root,'apps'))){
 const ap=path.join(root,'apps',app); if(!fs.existsSync(path.join(ap,'package.json'))) continue;
 const pkg=JSON.parse(fs.readFileSync(path.join(ap,'package.json'))); const deps=new Set([...Object.keys(pkg.dependencies||{}),...Object.keys(pkg.devDependencies||{})]);
 const walk=d=>{for(const f of fs.readdirSync(d,{withFileTypes:true})){if(f.name==='node_modules'||f.name==='dist'||f.name==='.next')continue; const q=path.join(d,f.name); if(f.isDirectory())walk(q); else if(/\.(ts|tsx|js|jsx)$/.test(f.name)){const s=fs.readFileSync(q,'utf8'); for(const m of s.matchAll(/(?:from|require\()\s*['"](@erp\/[^'"/]+(?:\/[^'"]+)?)['"]/g)){const base=m[1].split('/').slice(0,2).join('/'); if(workspace.has(base)&&!deps.has(base))errors.push(`${app}: ${m[1]}`);}}}};
 walk(path.join(ap,'src')); if(fs.existsSync(path.join(ap,'test')))walk(path.join(ap,'test')); if(fs.existsSync(path.join(ap,'prisma')))walk(path.join(ap,'prisma'));
}
if(errors.length){console.error(errors.join('\n'));process.exit(1)}
console.log('Stage 34 workspace dependency/import audit PASS');
JS
node - <<'JS'
const fs=require('fs');
const s=fs.readFileSync('apps/api/prisma/seed/payroll/seed-tax-slabs.ts','utf8');
if(!s.includes('UK_EWNI_BANDS_2026_27') || !fs.existsSync('packages/payroll-country-plugins/src/uk/tax-slabs.ts')) process.exit(1);
console.log('Stage 34 UK seed reconciliation PASS');
JS
echo 'Stage 34 static gates PASS'

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 "$ROOT/scripts/verify-stage48-runtime-gate.py"

if [ -x "$ROOT/node_modules/.bin/prisma" ]; then
  PRISMA="$ROOT/node_modules/.bin/prisma"
elif command -v prisma >/dev/null 2>&1; then
  PRISMA="$(command -v prisma)"
else
  echo 'Prisma CLI runtime: BLOCKED (not installed)'
  exit 0
fi

VERSION="$($PRISMA --version 2>/dev/null | head -1 || true)"
echo "Prisma CLI runtime: AVAILABLE (${VERSION:-unknown})"

if [ -z "${DATABASE_URL:-}" ]; then
  echo 'PostgreSQL runtime: BLOCKED (DATABASE_URL not set)'
  exit 0
fi

if command -v pg_isready >/dev/null 2>&1 && pg_isready -d "$DATABASE_URL" >/dev/null 2>&1; then
  echo 'PostgreSQL runtime: AVAILABLE'
  echo 'Running Prisma schema validation only; baseline application still requires an explicitly disposable database workflow.'
  "$PRISMA" validate --schema="$ROOT/prisma/schema.prisma"
  echo 'Prisma schema validation: PASS'
else
  echo 'PostgreSQL runtime: BLOCKED (pg_isready unavailable or database unavailable)'
fi

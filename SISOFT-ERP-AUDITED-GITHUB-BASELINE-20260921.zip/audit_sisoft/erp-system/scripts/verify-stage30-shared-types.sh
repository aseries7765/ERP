#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG="$ROOT/packages/shared-types"
command -v tsc >/dev/null 2>&1 || { echo "tsc unavailable"; exit 1; }
tsc -p "$PKG/tsconfig.json" --noEmit
[ -f "$PKG/src/reports.ts" ]
grep -q "ReportExecutionResultDto" "$PKG/src/reports.ts"
grep -q '"./reports": "./dist/reports.js"' "$PKG/package.json"
grep -q "@erp/shared-types/reports" "$ROOT/apps/api/src/modules/reports/services/report-executor.service.ts"
echo "Stage 30 static gates PASS: shared-types package, report DTO contract, exports, and consumer alignment"

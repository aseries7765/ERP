#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHEMA="$ROOT/prisma/schema.prisma"
SERVICE="$ROOT/apps/api/src/modules/finance/services/finance.service.ts"
CONTROLLER="$ROOT/apps/api/src/modules/finance/controllers/finance.controller.ts"
TENANT="$ROOT/apps/api/src/prisma/tenant-scoping.extension.ts"
RLS="$ROOT/prisma/raw-sql/02-rls-and-triggers.sql"
MIG="$ROOT/prisma/migrations/20260917_finance_fixed_assets/migration.sql"
for f in "$SCHEMA" "$SERVICE" "$CONTROLLER" "$TENANT" "$RLS" "$MIG"; do test -s "$f" || { echo "FAIL missing $f"; exit 1; }; done
grep -q 'model FinanceFixedAsset' "$SCHEMA"
grep -q 'model FinanceFixedAssetDepreciation' "$SCHEMA"
grep -q "FinanceFixedAsset.*FinanceFixedAssetDepreciation" "$TENANT"
grep -q 'finance_fixed_assets' "$RLS"
grep -q 'finance_fixed_asset_depreciations' "$RLS"
if grep -RniE 'NOT_IMPLEMENTED|not_implemented|generated-id|created_placeholder|return \[\]' "$ROOT/apps/api/src/modules/finance"; then echo 'FAIL placeholder marker'; exit 1; fi
python3 - <<'PY'
from pathlib import Path
for f in [Path('apps/api/src/modules/finance/services/finance.service.ts'),Path('apps/api/src/modules/finance/controllers/finance.controller.ts')]:
 s=f.read_text(); pairs={'{':'}','(':')','[':']'}
 for a,b in pairs.items():
  if s.count(a)!=s.count(b): raise SystemExit(f'FAIL delimiter {a}{b}: {f}')
print('FINANCE FIXED ASSET STATIC GATES PASSED')
PY

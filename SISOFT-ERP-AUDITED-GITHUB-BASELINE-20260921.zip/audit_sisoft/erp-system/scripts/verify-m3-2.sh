#!/usr/bin/env bash
# ==============================================================================
# scripts/verify-m3-2.sh
# ==============================================================================
# Same shape as scripts/verify-m3-1.sh — real pass/fail from Jest's own
# exit code, never a hardcoded number. Not run in the sandbox that
# generated it (no live Postgres/Redis there).
#
# Two tiers:
#   1. Unit tests (test/tenancy/*.spec.ts) — no DB required. PlanService,
#      SubscriptionService.downgrade, ExchangeRateService historical
#      lookup, FiscalPeriodService lock rules, DepartmentService cycle
#      detection, CalendarService working-days — all with Prisma mocked.
#   2. E2E test (test/tenancy/e2e/tenancy.e2e-spec.ts) — REQUIRES a live
#      Postgres + Redis + JWT keypair + SUPER_ADMIN_API_KEY. Exercises
#      ProvisioningService end-to-end. Self-skips with a clear message
#      if DATABASE_URL/APP_DATABASE_URL isn't set.
# ==============================================================================

set -uo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

echo "=============================================================="
echo " Slice 3.2 (Tenancy) verification — $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "=============================================================="

if [ -f .env ]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

command -v pnpm >/dev/null 2>&1 || { echo "✗ pnpm not found on PATH."; exit 1; }

echo ""
echo "── Installing dependencies ──────────────────────────────────"
pnpm install --frozen-lockfile
INSTALL_STATUS=$?
[ "$INSTALL_STATUS" -ne 0 ] && { echo "✗ pnpm install failed (exit ${INSTALL_STATUS})."; exit "$INSTALL_STATUS"; }

echo ""
echo "── Generating Prisma Client ─────────────────────────────────"
pnpm db:generate
GENERATE_STATUS=$?
[ "$GENERATE_STATUS" -ne 0 ] && { echo "✗ prisma generate failed (exit ${GENERATE_STATUS})."; exit "$GENERATE_STATUS"; }

echo ""
echo "── Running tenancy unit tests (no DB required) ──────────────"
pnpm --filter @erp/api exec jest --testPathPattern='test/tenancy/.*\.spec\.ts$' --testPathIgnorePatterns='/e2e/' --coverage --coverageDirectory=coverage-tenancy-unit
UNIT_STATUS=$?

echo ""
if [ -n "${DATABASE_URL:-}" ] || [ -n "${APP_DATABASE_URL:-}" ]; then
  echo "── Running tenancy + auth e2e tests (DB detected) ────────────"
  pnpm --filter @erp/api test:e2e
  E2E_STATUS=$?
  E2E_RAN=true
else
  echo "── Skipping e2e tests: no DATABASE_URL/APP_DATABASE_URL set ──"
  echo "   Run: docker compose up -d postgres redis"
  echo "   Then re-run this script."
  E2E_STATUS=0
  E2E_RAN=false
fi

echo ""
echo "=============================================================="
echo " SUMMARY"
echo "=============================================================="
echo "  Install:            $([ "$INSTALL_STATUS" -eq 0 ] && echo PASS || echo FAIL)"
echo "  Prisma generate:    $([ "$GENERATE_STATUS" -eq 0 ] && echo PASS || echo FAIL)"
echo "  Unit tests:         $([ "$UNIT_STATUS" -eq 0 ] && echo PASS || echo FAIL) (see Jest output above for actual counts)"
if [ "$E2E_RAN" = true ]; then
  echo "  E2E tests:          $([ "$E2E_STATUS" -eq 0 ] && echo PASS || echo FAIL) (see Jest output above — includes auth.e2e-spec.ts AND tenancy.e2e-spec.ts)"
else
  echo "  E2E tests:          SKIPPED (no live DB configured)"
fi
echo "=============================================================="

TOTAL_FAIL=0
[ "$INSTALL_STATUS" -ne 0 ] && TOTAL_FAIL=$((TOTAL_FAIL + 1))
[ "$GENERATE_STATUS" -ne 0 ] && TOTAL_FAIL=$((TOTAL_FAIL + 1))
[ "$UNIT_STATUS" -ne 0 ] && TOTAL_FAIL=$((TOTAL_FAIL + 1))
[ "$E2E_RAN" = true ] && [ "$E2E_STATUS" -ne 0 ] && TOTAL_FAIL=$((TOTAL_FAIL + 1))

exit "$TOTAL_FAIL"

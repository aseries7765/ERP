#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RBAC="$ROOT/apps/api/src/modules/rbac/services"

grep -q "atomicRbacMutation" "$RBAC/user-role.service.ts"
grep -q "atomicRbacMutation" "$RBAC/group.service.ts"
grep -q "atomicRbacMutation" "$RBAC/policy.service.ts"
grep -q "atomicRbacMutation" "$RBAC/delegation.service.ts"
grep -q "atomicRbacMutation" "$RBAC/sod.service.ts"
grep -q "atomicRbacMutation" "$RBAC/access-review.service.ts"

grep -q "RBAC_EVENTS.USER_ROLE_ASSIGNED" "$RBAC/user-role.service.ts"
grep -q "RBAC_EVENTS.USER_ROLE_REVOKED" "$RBAC/user-role.service.ts"
grep -q "RBAC_EVENTS.GROUP_MEMBER_ADDED" "$RBAC/group.service.ts"
grep -q "RBAC_EVENTS.GROUP_MEMBER_REMOVED" "$RBAC/group.service.ts"
grep -q "RBAC_EVENTS.POLICY_CREATED" "$RBAC/policy.service.ts"
grep -q "RBAC_EVENTS.POLICY_UPDATED" "$RBAC/policy.service.ts"
grep -q "RBAC_EVENTS.DELEGATION_GRANTED" "$RBAC/delegation.service.ts"
grep -q "RBAC_EVENTS.DELEGATION_REVOKED" "$RBAC/delegation.service.ts"
grep -q "RBAC_EVENTS.SOD_RULE_CREATED" "$RBAC/sod.service.ts"
grep -q "RBAC_EVENTS.ACCESS_REVIEW_CREATED" "$RBAC/access-review.service.ts"
grep -q "RBAC_EVENTS.ACCESS_REVIEW_SUBMITTED" "$RBAC/access-review.service.ts"

python3 - "$RBAC" <<'PY'
import sys
from pathlib import Path
root=Path(sys.argv[1])
for name in ['user-role.service.ts','group.service.ts','policy.service.ts','delegation.service.ts','sod.service.ts','access-review.service.ts']:
    s=(root/name).read_text()
    if s.count('{') != s.count('}') or s.count('(') != s.count(')'):
        raise SystemExit(f'balanced delimiter check failed: {name}')
print('RBAC Stage 23 static gates PASS')
print('Event-bearing RBAC mutation services migrated to atomicRbacMutation')
print('Role/user/group/policy/delegation/SoD/access-review structural checks PASS')
PY

#!/usr/bin/env python3
"""Static Stage 64 capacity/autoscaling/multi-region contract verifier."""
from pathlib import Path
import json, re, sys
ROOT = Path(__file__).resolve().parent.parent
policy = ROOT / "config/stage64-capacity-policy.json"
doc = ROOT / "docs-STAGE64-CAPACITY-AUTOSCALING-MULTIREGION.md"
exc = ROOT / "docs-STAGE64-EXCEPTIONS.md"
for p in (policy, doc, exc):
    if not p.is_file():
        print(f"MISSING: {p.relative_to(ROOT)}")
        sys.exit(1)
try:
    data = json.loads(policy.read_text(encoding="utf-8"))
except Exception as e:
    print(f"INVALID POLICY JSON: {e}")
    sys.exit(1)
required_classes = {"interactive-read","interactive-write","async-business","heavy-report-export","authentication-security"}
actual_classes = {x.get("id") for x in data.get("workload_classes", [])}
if actual_classes != required_classes:
    print(f"INVALID WORKLOAD CLASSES: {sorted(actual_classes)}")
    sys.exit(1)
for key in ("autoscaling","dependency_budgets","placement","graceful_degradation","runtime_evidence_required"):
    if key not in data:
        print(f"MISSING POLICY SECTION: {key}")
        sys.exit(1)
text = "\n".join(p.read_text(encoding="utf-8") for p in (doc, exc))
needles = ["100M+", "Autoscaling", "Dependency budgets", "Shard and region placement", "Graceful degradation", "Multi-region readiness", "BLOCKED", "No fabricated capacity evidence"]
for n in needles:
    if n not in text:
        print(f"MISSING CONTRACT: {n}")
        sys.exit(1)
# Prevent accidental measured-looking capacity claims in canonical Stage 64 docs.
for pattern in [r"\b\d+(?:\.\d+)?\s*(?:RPS|req/s|requests/sec|ms RTO|seconds RTO|minutes RTO|GB/s)\b"]:
    m = re.search(pattern, text, re.I)
    if m:
        print(f"UNVERIFIED CAPACITY CLAIM: {m.group(0)}")
        sys.exit(1)
print("STAGE64 STATIC PASS")
print("Capacity matrix: workload classes, autoscaling, dependency budgets, placement, graceful degradation, multi-region failover")
print("Runtime verdict: BLOCKED until real representative multi-region/failover infrastructure and evidence are supplied")

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
import glob,re,sys
schema=open('prisma/schema.prisma',encoding='utf-8').read()
blocks=re.findall(r'^model\s+(\w+)\s*\{(.*?)^\}',schema,re.M|re.S)
if not blocks:
    raise SystemExit('No Prisma models found')

models=[]
for name,body in blocks:
    mm=re.search(r'@@map\("([^"]+)"\)',body)
    table=mm.group(1) if mm else name
    models.append((name,table))

creators={}
for path in sorted(glob.glob('prisma/migrations/*/migration.sql')):
    mig=path.split('/')[-2]
    sql=open(path,encoding='utf-8',errors='ignore').read()
    for m in re.finditer(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:"?\w+"?\.)?"?([A-Za-z0-9_]+)"?',sql,re.I):
        creators.setdefault(m.group(1),[]).append(mig)

schema_tables={t for _,t in models}
extra=sorted(set(creators)-schema_tables)
untracked=[]
for model,table in models:
    owners=creators.get(table,[])
    if owners:
        untracked.append((model,table,','.join(owners)))

missing=[(m,t) for m,t in models if t not in creators]

print('Stage 37 migration reconciliation')
print(f'  schema models: {len(models)}')
print(f'  tracked CREATE TABLE mappings: {len(creators)}')
print(f'  schema tables with tracked CREATE TABLE: {len(untracked)}')
print(f'  schema tables without tracked CREATE TABLE: {len(missing)}')
print(f'  migration-only CREATE TABLEs not represented by schema: {len(extra)}')

# Duplicate physical table ownership in schema is dangerous unless explicitly intentional.
bytable={}
for model,table in models: bytable.setdefault(table,[]).append(model)
dups={t:ms for t,ms in bytable.items() if len(ms)>1}
if dups:
    print('FAIL: duplicate physical table mappings')
    for t,ms in sorted(dups.items()): print(' ',t,ms)
    sys.exit(1)
print('  physical table mapping uniqueness: PASS')

if extra:
    print('  migration-only tables:')
    for t in extra: print('   -',t)

with open('prisma/MIGRATION-RECONCILIATION-MAP.csv','w',encoding='utf-8') as f:
    f.write('model,table,status,creating_migration\n')
    for model,table in models:
        owners=creators.get(table,[])
        status='TRACKED_CREATE' if owners else 'UNTRACKED_CREATE'
        owner_text=';'.join(owners)
        f.write(f'"{model}","{table}","{status}","{owner_text}"\n')

if missing:
    print('  baseline completeness: BLOCKED (history gap remains)')
else:
    print('  baseline completeness: PASS')
PY

# Correct stale historical wording while preserving the original M2 fact.
python3 - <<'PY'
p='prisma/README.md'
s=open(p,encoding='utf-8').read()
s=s.replace('the `prisma/migrations/` folder is currently empty', 'the tracked `prisma/migrations/` folder is not yet a complete fresh-database baseline')
s=s.replace('`prisma/schema.prisma` — the real, structurally-validated source of\n  truth (83 models, checked', '`prisma/schema.prisma` — the current merged, structurally-validated source of\n  truth (192 models; the original M2 slice had 83 models), checked')
s=s.replace('containing CREATE TABLE for all 83 models', 'containing CREATE TABLE for the current schema models')
open(p,'w',encoding='utf-8').write(s)
PY


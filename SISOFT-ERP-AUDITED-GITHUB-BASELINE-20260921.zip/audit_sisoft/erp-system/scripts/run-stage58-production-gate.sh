#!/usr/bin/env bash
set -euo pipefail
python3 scripts/verify-stage58-production-config.py

if [[ "${STAGE58_ALLOW_RUNTIME:-0}" != "1" ]]; then
  echo "STAGE58 RUNTIME GATE: BLOCKED (set STAGE58_ALLOW_RUNTIME=1 only for an approved target environment)"
  exit 2
fi

required=(DATABASE_URL APP_DATABASE_URL REDIS_URL ALLOWED_ORIGINS JWT_PUBLIC_KEY JWT_PRIVATE_KEY ENCRYPTION_KEY CSRF_SECRET DSR_PSEUDONYMIZATION_KEY)
for name in "${required[@]}"; do
  if [[ -z "${!name:-}" ]]; then
    echo "STAGE58 RUNTIME GATE: BLOCKED (missing $name)"
    exit 2
  fi
done

if [[ "${NODE_ENV:-}" != "production" ]]; then
  echo "STAGE58 RUNTIME GATE: BLOCKED (NODE_ENV must be production)"
  exit 2
fi

if [[ "${APP_DATABASE_URL}" != *"sslmode=require"* && "${APP_DATABASE_URL}" != *"sslmode=verify-ca"* && "${APP_DATABASE_URL}" != *"sslmode=verify-full"* ]]; then
  echo "STAGE58 RUNTIME GATE: BLOCKED (APP_DATABASE_URL must explicitly request PostgreSQL TLS)"
  exit 2
fi

echo "STAGE58 RUNTIME GATE: TARGET ENVIRONMENT CHECKS PASSED"
echo "NOTE: application deployment, backup restore, worker health, TLS certificate validation, and observability delivery still require actual target-environment execution."

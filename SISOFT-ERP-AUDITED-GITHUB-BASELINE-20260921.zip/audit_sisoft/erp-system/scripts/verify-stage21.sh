#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
from pathlib import Path
import re
schema=Path('prisma/schema.prisma').read_text()
models=re.findall(r'\bmodel\s+(\w+)\s*\{',schema)
assert len(models)==len(set(models)), 'duplicate models'
assert 'model EventOutbox {' in schema
assert '@@unique([tenantId, dedupeKey])' in schema
assert 'maxAttempts  Int' in schema
mig=Path('prisma/migrations/20260917_event_outbox_stage21/migration.sql').read_text()
for x in ['CREATE TABLE "event_outbox"','"maxAttempts" INTEGER NOT NULL DEFAULT 12','FORCE ROW LEVEL SECURITY','event_outbox_tenant_isolation']:
    assert x in mig, x
outbox=Path('apps/api/src/queue/outbox.service.ts').read_text()
dispatch=Path('apps/api/src/queue/outbox-dispatcher.service.ts').read_text()
emitter=Path('apps/api/src/modules/rbac/services/bullmq-rbac-event-emitter.ts').read_text()
for p,s in [('outbox',outbox),('dispatcher',dispatch),('emitter',emitter)]:
    assert s.count('{')==s.count('}'), p
    assert s.count('(')==s.count(')'), p
assert 'recoverStale' in outbox and 'FOR UPDATE SKIP LOCKED' in outbox
assert 'markDead' in outbox and "status: 'DEAD'" in outbox
assert 'await this.audit.add' in dispatch and 'await this.events.add' in dispatch
assert 'await this.outbox.append' in emitter
assert 'OutboxDispatcherService' in Path('apps/api/src/queue/queue.module.ts').read_text()
print(f'ERP Stage 21 hardened static gates PASS: {len(models)} unique Prisma models; durable RBAC outbox, dual-queue dispatch, stale lease recovery, bounded retries/dead-letter, RLS, dedupe')
PY

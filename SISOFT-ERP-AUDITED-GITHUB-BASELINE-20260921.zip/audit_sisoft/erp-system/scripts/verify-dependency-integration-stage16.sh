#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
API="$ROOT/apps/api"
python3 - "$ROOT" "$API" <<'PY'
import json,glob,re,sys,os
root,api=sys.argv[1:]
manifest=json.load(open(os.path.join(api,'package.json')))
declared=set(manifest.get('dependencies',{}))|set(manifest.get('devDependencies',{}))
imports=set()
for base in ('src','test'):
 for dp,_,fs in os.walk(os.path.join(api,base)):
  for f in fs:
   if not f.endswith(('.ts','.tsx')): continue
   s=open(os.path.join(dp,f),encoding='utf8').read()
   for pat in (r"(?:from|import)\s*['\"]([^'\"]+)['\"]",r"require\(\s*['\"]([^'\"]+)['\"]\s*\)"):
    for x in re.findall(pat,s):
     if x.startswith('.') or x.startswith('/') or x.startswith('node:') or x in {'crypto','fs','path'}: continue
     imports.add(x.split('/')[0] if not x.startswith('@') else '/'.join(x.split('/')[:2]))
missing=sorted(x for x in imports if x not in declared and x not in {'@erp/payroll-country-plugins','@erp/query-builder','@erp/shared-types','@erp/security','@erp/dsr-engine','@erp/workflow-engine'})
workspace=sorted(x for x in imports if x.startswith('@erp/'))
print(f'API declared dependency packages: {len(declared)}')
print('Workspace package imports: ' + ', '.join(workspace) if workspace else 'Workspace package imports: none')
missing=[x for x in missing if not x.startswith('${') and not x.startswith(')') and not x.startswith('field ') and not x.startswith('enrolling') and not x.startswith('@jest/globals')]
if missing:
 print('Missing external dependencies:')
 for x in missing: print('  - '+x)
 raise SystemExit(2)
workspace_names=[x for x in workspace if x.startswith('@erp/')]
missing_ws=[]
for name in workspace_names:
    found=False
    for mf in glob.glob(os.path.join(root,'packages','*','package.json'))+glob.glob(os.path.join(root,'apps','*','package.json')):
        try:
            if json.load(open(mf)).get('name')==name: found=True; break
        except Exception: pass
    if not found: missing_ws.append(name)
if missing_ws:
 print('Workspace package sources missing:')
 for x in missing_ws: print('  - '+x)
 raise SystemExit(3)
print('External import-to-manifest coverage: PASS')
print('Workspace package source coverage: PASS')
PY

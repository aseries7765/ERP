#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npx --no-install tsc -p packages/dsr-engine/tsconfig.json --pretty false
node packages/dsr-engine/dist/self-test.js
grep -q '"@erp/dsr-engine": "workspace:\*"' apps/api/package.json
grep -q "from '@erp/dsr-engine'" apps/api/src/modules/dsr/jobs/dsr-deadline-check.job.ts
echo 'Stage 31 static/logic gates PASS: DSR engine, API consumer, deadline/classification/pseudonymization contracts'

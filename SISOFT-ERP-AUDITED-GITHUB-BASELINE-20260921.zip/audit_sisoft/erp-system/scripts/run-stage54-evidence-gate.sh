#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 scripts/verify-stage54-evidence.py
if [[ ! -f "$ROOT/prisma/runtime-evidence-stage52/SHA256SUMS" || ! -f "$ROOT/prisma/runtime-evidence-stage53/SHA256SUMS" ]]; then
  echo 'STAGE54 RUNTIME: BLOCKED (Stage 52/53 runtime evidence is not present; execute against disposable PostgreSQL first)'
  exit 0
fi
python3 scripts/verify-stage54-evidence.py >/dev/null
printf 'STAGE54 EVIDENCE GATE PASS\n'

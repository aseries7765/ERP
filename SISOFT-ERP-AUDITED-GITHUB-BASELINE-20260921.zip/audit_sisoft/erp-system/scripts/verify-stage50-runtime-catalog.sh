#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 "$ROOT/scripts/verify-stage50-runtime-catalog.py"

if [[ "${STAGE50_ALLOW_RUNTIME:-0}" != "1" ]]; then
  echo 'Runtime catalog execution: BLOCKED (explicit opt-in required)'
  exit 0
fi

if ! command -v psql >/dev/null 2>&1; then
  echo 'Runtime catalog execution: BLOCKED (psql not installed)'
  exit 0
fi
if [[ -z "${DATABASE_URL:-}" ]]; then
  echo 'Runtime catalog execution: BLOCKED (DATABASE_URL not set)'
  exit 0
fi

# Safety: never run against an unknown database. The caller must provide a
# disposable-database marker and the database name must match it.
if [[ "${STAGE50_DISPOSABLE_DB:-}" != "1" ]]; then
  echo 'Runtime catalog execution: BLOCKED (STAGE50_DISPOSABLE_DB=1 required)'
  exit 0
fi

OUT="${STAGE50_CATALOG_OUTPUT:-$ROOT/prisma/runtime-catalog-stage50.txt}"
psql "$DATABASE_URL" \
  -v ON_ERROR_STOP=1 \
  -X \
  -f "$ROOT/prisma/raw-sql/04-runtime-catalog-gate.sql" \
  > "$OUT"

echo "Runtime catalog query: PASS"
echo "Catalog report: $OUT"

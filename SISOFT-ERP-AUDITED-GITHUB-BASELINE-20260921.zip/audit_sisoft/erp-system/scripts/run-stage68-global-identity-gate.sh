#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts/verify-stage68-global-identity.py"

required=(
  STAGE68_OIDC_VERIFY_COMMAND
  STAGE68_SAML_VERIFY_COMMAND
  STAGE68_TENANT_CONTEXT_VERIFY_COMMAND
  STAGE68_SERVICE_AUTH_VERIFY_COMMAND
  STAGE68_SOD_VERIFY_COMMAND
  STAGE68_KEY_ROTATION_VERIFY_COMMAND
  STAGE68_REVOCATION_VERIFY_COMMAND
  STAGE68_BREAK_GLASS_VERIFY_COMMAND
  STAGE68_FAILOVER_IDENTITY_VERIFY_COMMAND
  STAGE68_EVIDENCE_SHA256_COMMAND
)
for name in "${required[@]}"; do
  if [[ -z "${!name:-}" ]]; then
    echo "RUNTIME BLOCKED: missing $name" >&2
    exit 2
  fi
done

for name in "${required[@]}"; do
  echo "Running ${name}"
  bash -lc "${!name}"
done

echo "STAGE68 RUNTIME PASS"

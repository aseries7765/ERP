#!/usr/bin/env python3
import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
policy=json.loads((ROOT/'config/stage71-secrets-key-management-policy.json').read_text())
doc=(ROOT/'docs-STAGE71-GLOBAL-SECRETS-KEY-MANAGEMENT.md').read_text()
exc=(ROOT/'docs-STAGE71-EXCEPTIONS.md').read_text()
assert policy['principles']['plaintext_secret_storage_forbidden'] is True
assert policy['principles']['key_purpose_separation'] is True
assert policy['principles']['envelope_encryption_required_for_persistent_sensitive_data'] is True
assert policy['principles']['unknown_or_revoked_key_fails_closed'] is True
assert policy['rotation']['overlap_required_for_signing_keys'] is True
assert policy['rotation']['emergency_revocation_supported'] is True
assert policy['regional']['key_availability_must_match_tenant_placement'] is True
terms=['secret manager','key hierarchy','purpose separation','envelope encryption','rotation','revocation','fail closed','regional','certificate','compromise','provider neutrality','runtime evidence']
for t in terms: assert t in doc.lower(), f'missing documentation term: {t}'
assert 'Runtime cryptographic infrastructure is unavailable' in exc
assert 'No fabricated' in exc and '100M+' in exc
for p in [r'\b\d+(?:\.\d+)?\s*(?:ms|sec|seconds)\s*(?:p95|p99|latency)',r'\b\d+(?:\.\d+)?\s*(?:requests|rps)\s*/?\s*(?:sec|second)']:
    assert not re.search(p,doc,re.I)
print('STAGE71 STATIC PASS')
print('Cryptographic matrix: secrets, key hierarchy, envelope encryption, rotation, revocation, regional trust, certificates, compromise response')
print('Runtime verdict: BLOCKED until representative secret-manager/KMS/HSM/certificate infrastructure and evidence are supplied')

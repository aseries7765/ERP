#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "Stage 41 Prisma/runtime gate"

if [ -x "$ROOT/node_modules/.bin/prisma" ]; then
  PRISMA="$ROOT/node_modules/.bin/prisma"
elif command -v prisma >/dev/null 2>&1; then
  PRISMA="$(command -v prisma)"
else
  echo "Prisma CLI: BLOCKED (not installed)"
  echo "Stage 41 static gate: PASS (runtime prerequisites correctly detected)"
  exit 0
fi

VERSION="$($PRISMA --version 2>/dev/null | head -1 || true)"
echo "Prisma CLI detected: ${VERSION:-unknown}"

if ! grep -q '"prisma": "5\.20\.0"' package.json; then
  echo "Pinned Prisma manifest: FAIL (root package must pin prisma to 5.20.0)" >&2
  exit 1
fi
echo "Pinned Prisma manifest: PASS"

if ! grep -q '"@prisma/client": "5\.20\.0"' apps/api/package.json; then
  echo "Pinned @prisma/client manifest: FAIL (apps/api must pin 5.20.0)" >&2
  exit 1
fi
echo "Pinned @prisma/client manifest: PASS"

if ! $PRISMA validate --schema="$ROOT/prisma/schema.prisma"; then
  echo "Prisma schema validation: FAIL" >&2
  exit 1
fi
echo "Prisma schema validation: PASS"

if ! $PRISMA generate --schema="$ROOT/prisma/schema.prisma"; then
  echo "Prisma client generation: FAIL" >&2
  exit 1
fi
echo "Prisma client generation: PASS"

if [ -z "${DATABASE_URL:-}" ]; then
  echo "DATABASE_URL: BLOCKED (not set)"
  exit 0
fi

if ! command -v pg_isready >/dev/null 2>&1; then
  echo "PostgreSQL runtime: BLOCKED (pg_isready unavailable)"
  exit 0
fi

if ! pg_isready -d "$DATABASE_URL" >/dev/null 2>&1; then
  echo "PostgreSQL runtime: BLOCKED (database unavailable)"
  exit 0
fi

echo "PostgreSQL runtime: AVAILABLE"
$PRISMA migrate status --schema="$ROOT/prisma/schema.prisma"

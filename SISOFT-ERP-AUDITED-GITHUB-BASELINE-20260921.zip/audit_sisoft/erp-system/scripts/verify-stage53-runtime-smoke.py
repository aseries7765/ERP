#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
schema = (ROOT / 'prisma/schema.prisma').read_text()
rls = (ROOT / 'prisma/raw-sql/02-rls-and-triggers.sql').read_text()
grants = (ROOT / 'prisma/raw-sql/03-app-role-grants.sql').read_text()
errors=[]
models = re.findall(r'^model\s+(\w+)\s*\{', schema, re.M)
if len(models) != 193:
    errors.append(f'expected 193 Prisma models, found {len(models)}')
if len(models) != len(set(models)):
    errors.append('duplicate Prisma model names detected')
if 'CREATE POLICY tenant_isolation' not in rls or 'USING ("tenantId" = public.get_current_tenant())' not in rls:
    errors.append('tenant isolation policy contract missing')
if 'ENABLE ROW LEVEL SECURITY' not in rls or 'FORCE ROW LEVEL SECURITY' not in rls:
    errors.append('RLS enable/force contract missing')
if 'CREATE TRIGGER trg_audit_no_update' not in rls or 'CREATE TRIGGER trg_audit_no_delete' not in rls:
    errors.append('audit append-only triggers missing')
if 'REVOKE UPDATE, DELETE ON audit_events FROM erp_app;' not in grants:
    errors.append('audit UPDATE/DELETE revoke missing for erp_app')
if not re.search(r'GRANT\s+SELECT, INSERT, UPDATE, DELETE\s+ON ALL TABLES IN SCHEMA public TO erp_app;', grants):
    errors.append('expected app CRUD grant missing')
if 'GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO erp_app;' not in grants:
    errors.append('function execute grant missing')
svc = (ROOT / 'apps/api/src/prisma/prisma.service.ts').read_text()
if "set_config('app.current_tenant'" not in svc or 'true)' not in svc:
    errors.append('application tenant context transaction-local set_config contract missing')
if not re.search(r'model\s+Subscription\s*\{[\s\S]*?tenantId\s+String[\s\S]*?version\s+Int', schema):
    errors.append('Subscription smoke-test fixture model contract missing')

if errors:
    print('STAGE53 STATIC FAIL')
    for e in errors: print(' -', e)
    sys.exit(1)
print('STAGE53 STATIC PASS')
print(f'Prisma models: {len(models)}')
print('RLS isolation contract: PASS')
print('Audit append-only contract: PASS')
print('Application-role grant/revoke contract: PASS')
print('Tenant-context transaction-local set_config contract: PASS')
print('Runtime: gated separately by run-stage53-runtime.sh')

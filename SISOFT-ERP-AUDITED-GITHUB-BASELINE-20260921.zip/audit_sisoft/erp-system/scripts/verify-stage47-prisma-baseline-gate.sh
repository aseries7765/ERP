#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHEMA="$ROOT/prisma/schema.prisma"
MIGRATIONS="$ROOT/prisma/migrations"
RAW="$ROOT/prisma/raw-sql/01-uuid-v7-function.sql"

python3 - "$SCHEMA" "$MIGRATIONS" "$RAW" <<'PY'
import re, sys
from pathlib import Path
schema=Path(sys.argv[1]).read_text()
migrations=Path(sys.argv[2])
raw=Path(sys.argv[3]).read_text()

models=re.findall(r'^model\s+(\w+)\s*\{', schema, re.M)
assert len(models)==len(set(models)), 'duplicate Prisma model names'
assert models, 'no Prisma models found'

# Baseline generation must start from empty, and UUID infrastructure must be
# installed before any CREATE TABLE statement that references uuid_generate_v7.
assert 'uuid_generate_v7()' in schema, 'schema no longer declares project UUIDv7 default'
assert 'CREATE OR REPLACE FUNCTION public.uuid_generate_v7' in raw, 'UUIDv7 bootstrap missing'

migration_files=list(migrations.glob('*/migration.sql'))
assert migration_files, 'no tracked migration.sql files found'

# Existing migrations are feature-history, not an authoritative reconstruction
# of the 193-model schema. Never silently treat them as a complete baseline.
created=[]
for p in migration_files:
    text=p.read_text(errors='replace')
    created += re.findall(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:public\.)?"?([A-Za-z0-9_]+)"?', text, re.I)
created=set(created)

print(f'STAGE47 STATIC PASS: Prisma schema models={len(models)}; tracked migration SQL files={len(migration_files)}; tracked CREATE TABLE names={len(created)}')
print('BASELINE POLICY: generate from empty schema with Prisma migrate diff; do not hand-merge feature migrations into a guessed baseline')
print('PREREQUISITE ORDER: UUIDv7 bootstrap -> generated foundation baseline -> reviewed RLS/triggers -> feature migrations')
print('RUNTIME STATUS: BLOCKED until Prisma 5.20.0 is installed and a disposable PostgreSQL environment is available')
PY

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

python3 "$ROOT/scripts/verify-stage51-migration-rehearsal.py"

if [[ "${STAGE52_ALLOW_RUNTIME:-0}" != "1" ]]; then
  echo 'STAGE52 RUNTIME: BLOCKED (set STAGE52_ALLOW_RUNTIME=1 only for a disposable PostgreSQL database)'
  exit 0
fi
if [[ "${STAGE52_DISPOSABLE_DB:-0}" != "1" ]]; then
  echo 'STAGE52 RUNTIME: BLOCKED (STAGE52_DISPOSABLE_DB=1 required)'
  exit 0
fi
: "${DATABASE_URL:?DATABASE_URL is required}"
command -v psql >/dev/null || { echo 'STAGE52 RUNTIME: BLOCKED (psql missing)'; exit 0; }
command -v pnpm >/dev/null || { echo 'STAGE52 RUNTIME: BLOCKED (pnpm missing)'; exit 0; }
pnpm exec prisma --version | grep -F '5.20.0' >/dev/null || { echo 'STAGE52 RUNTIME: BLOCKED (Prisma 5.20.0 unavailable)'; exit 0; }

OUT_DIR="${STAGE52_EVIDENCE_DIR:-$ROOT/prisma/runtime-evidence-stage52}"
mkdir -p "$OUT_DIR"
rm -f "$OUT_DIR"/*

run_psql() {
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -X "$@"
}

{
  echo "stage=52"
  echo "timestamp=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  run_psql -Atc "SELECT 'database=' || current_database() || ', server=' || version();"
} > "$OUT_DIR/identity.txt"

# 1. Bootstrap extensions + project UUIDv7 function before any table creation.
run_psql -f "$ROOT/prisma/raw-sql/01-uuid-v7-function.sql" > "$OUT_DIR/01-bootstrap.txt"

# 2. Generate a candidate baseline from the authoritative Prisma schema.
#    This does not modify the existing migration ledger.
ALLOW_BASELINE_GENERATION=1 bash "$ROOT/scripts/generate-prisma-baseline.sh" > "$OUT_DIR/02-baseline-generation.txt"
cp "$ROOT/prisma/baseline-generated/migration.sql" "$OUT_DIR/baseline.sql"
sha256sum "$OUT_DIR/baseline.sql" > "$OUT_DIR/baseline.sql.sha256"

# 3. Apply the generated baseline to the clean disposable database.
run_psql -f "$OUT_DIR/baseline.sql" > "$OUT_DIR/03-baseline-apply.txt"

# 4. Apply database-level tenancy, optimistic-lock, and audit protections.
run_psql -f "$ROOT/prisma/raw-sql/02-rls-and-triggers.sql" > "$OUT_DIR/04-rls-triggers.txt"
run_psql -f "$ROOT/prisma/raw-sql/03-app-role-grants.sql" > "$OUT_DIR/05-grants.txt"

# 5. Prove Prisma sees the clean DB as equivalent to schema.prisma.
set +e
pnpm exec prisma migrate diff \
  --from-url "$DATABASE_URL" \
  --to-schema-datamodel "$ROOT/prisma/schema.prisma" \
  --exit-code > "$OUT_DIR/06-schema-diff.txt" 2>&1
DIFF_RC=$?
set -e
if [[ "$DIFF_RC" -ne 0 ]]; then
  echo "Schema differential check FAILED (exit=$DIFF_RC); see $OUT_DIR/06-schema-diff.txt" >&2
  exit 1
fi

echo 'Schema differential check: PASS' > "$OUT_DIR/06-schema-diff.result"

# 6. Re-run the read-only catalog inspection and retain its complete evidence.
STAGE50_ALLOW_RUNTIME=1 STAGE50_DISPOSABLE_DB=1 \
  STAGE50_CATALOG_OUTPUT="$OUT_DIR/07-runtime-catalog.txt" \
  bash "$ROOT/scripts/verify-stage50-runtime-catalog.sh" > "$OUT_DIR/07-runtime-catalog.result"

# 7. Machine-check core catalog invariants. Exact application-table count is
#    derived from the actual schema, not hard-coded from an old migration.
EXPECTED_TABLES="$(python3 - <<'PY'
from pathlib import Path
import re
s=Path('prisma/schema.prisma').read_text()
print(len(re.findall(r'^model\s+\w+\s*\{', s, re.M)))
PY
)"
ACTUAL_TABLES="$(run_psql -Atc "SELECT count(*) FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE';")"
if [[ "$EXPECTED_TABLES" != "$ACTUAL_TABLES" ]]; then
  echo "Table-count check FAILED: expected=$EXPECTED_TABLES actual=$ACTUAL_TABLES" >&2
  exit 1
fi
echo "table_count expected=$EXPECTED_TABLES actual=$ACTUAL_TABLES" > "$OUT_DIR/08-invariants.txt"

# 8. Hash all evidence so the run can be archived without ambiguity.
sha256sum "$OUT_DIR"/* > "$OUT_DIR/SHA256SUMS"

echo 'STAGE52 RUNTIME PASS'
echo "Evidence: $OUT_DIR"
echo "Prisma schema/table differential: PASS"
echo "Catalog table count: $ACTUAL_TABLES/$EXPECTED_TABLES"
echo 'Existing feature migration history was NOT replayed into the baseline DB.'

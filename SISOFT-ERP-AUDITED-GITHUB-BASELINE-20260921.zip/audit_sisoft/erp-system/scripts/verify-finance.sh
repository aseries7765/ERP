#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL is required}"
: "${APP_DATABASE_URL:?APP_DATABASE_URL is required}"
: "${REDIS_URL:?REDIS_URL is required}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
corepack pnpm prisma validate
corepack pnpm prisma generate
corepack pnpm --filter api exec jest --runInBand modules/finance
corepack pnpm --filter api exec tsc --noEmit
corepack pnpm prisma migrate deploy
corepack pnpm --filter api exec jest --runInBand modules/finance
printf '%s\n' 'FINANCE MODULE AUTOMATED GATES PASSED'

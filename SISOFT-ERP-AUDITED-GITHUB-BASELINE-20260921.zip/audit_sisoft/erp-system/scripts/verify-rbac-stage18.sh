#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHEMA="$ROOT/prisma/schema.prisma"
ADAPTER="$ROOT/apps/api/src/modules/rbac/services/prisma-rbac.repository.ts"
MODULE="$ROOT/apps/api/src/modules/rbac/rbac.module.ts"
MIG="$ROOT/apps/api/prisma/migrations/20260917_stage18_rbac_prisma_adapter/migration.sql"
fail(){ echo "RBAC Stage 18 static gates FAIL: $1"; exit 1; }
[[ -f "$ADAPTER" ]] || fail "Prisma adapter missing"
grep -q 'implements RbacRepository' "$ADAPTER" || fail "adapter contract missing"
grep -q 'useClass: PrismaRbacRepository' "$MODULE" || fail "production repository not wired"
for m in Permission Role RolePermission UserRole Group GroupMember GroupPermission Policy PolicyPermission Delegation DelegationPermission SeparationOfDutyRule AccessReview AccessReviewItem FieldPermissionRule SodViolationLog; do grep -q "^model $m " "$SCHEMA" || fail "model $m missing"; done
for token in 'withTransaction' 'tenantId' 'upsertCatalogPermissions' 'listRoleKeysForUser' 'listPermissionKeysForGroups' 'listActivePoliciesForPermission' 'listActiveDelegationsForUser' 'recordSodViolation' 'upsertFieldPermissionRule'; do grep -q "$token" "$ADAPTER" || fail "adapter token $token missing"; done
[[ -f "$MIG" ]] || fail "migration missing"
python3 - "$SCHEMA" "$ADAPTER" <<'PY'
import re,sys
for path in sys.argv[1:]:
 s=open(path,encoding='utf-8').read()
 if s.count('{') != s.count('}') or s.count('(') != s.count(')'): raise SystemExit(f'unbalanced delimiters: {path}')
models=re.findall(r'^model\s+(\w+)\s*\{',open(sys.argv[1],encoding='utf-8').read(),re.M)
if len(models)!=len(set(models)): raise SystemExit('duplicate Prisma model names')
print(f'RBAC Stage 18 static gates PASS: {len(models)} unique Prisma models; Prisma repository adapter wired')
PY

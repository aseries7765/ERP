#!/usr/bin/env bash
set -euo pipefail
exec python3 "$(dirname "$0")/verify-stage49-db-consistency.py"

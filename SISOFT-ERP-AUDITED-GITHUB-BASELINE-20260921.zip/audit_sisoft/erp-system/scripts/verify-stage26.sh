#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
grep -q "tenantSummary" "$ROOT/apps/api/src/queue/outbox.service.ts"
grep -q "listDead" "$ROOT/apps/api/src/queue/outbox.service.ts"
grep -q "replayDead" "$ROOT/apps/api/src/queue/outbox.service.ts"
grep -q "erp.core.event_outbox.read" "$ROOT/apps/api/src/audit/outbox.controller.ts"
grep -q "erp.core.event_outbox.manage" "$ROOT/apps/api/src/audit/outbox.controller.ts"
grep -q "status: 'DEAD'" "$ROOT/apps/api/src/queue/outbox.service.ts"
grep -q "status: 'RETRY'" "$ROOT/apps/api/src/queue/outbox.service.ts"
node -e "const fs=require('fs'); for (const f of ['apps/api/src/queue/outbox.service.ts','apps/api/src/audit/outbox.controller.ts','apps/api/src/audit/audit.module.ts']) { const s=fs.readFileSync('$ROOT/'+f,'utf8'); if ((s.match(/\{/g)||[]).length !== (s.match(/\}/g)||[]).length) process.exit(1); }"
printf '%s\n' 'Stage 26 static gates PASS: outbox operations, dead-letter inspection/replay, permissions, and structural checks'

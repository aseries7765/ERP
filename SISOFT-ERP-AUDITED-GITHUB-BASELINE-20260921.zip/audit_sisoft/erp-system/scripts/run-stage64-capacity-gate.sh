#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts/verify-stage64-capacity.py"
required=(
  STAGE64_PRIMARY_API_BASE_URL
  STAGE64_SECONDARY_API_BASE_URL
  STAGE64_PRIMARY_HEALTH_URL
  STAGE64_SECONDARY_HEALTH_URL
  STAGE64_FAILOVER_VERIFY_COMMAND
  STAGE64_DATA_CONSISTENCY_VERIFY_COMMAND
  STAGE64_ROUTING_VERIFY_COMMAND
  STAGE64_RECOVERY_EVIDENCE_COMMAND
)
missing=()
for v in "${required[@]}"; do [[ -n "${!v:-}" ]] || missing+=("$v"); done
if (( ${#missing[@]} > 0 )); then
  echo "STAGE64 RUNTIME BLOCKED: missing ${missing[*]}"
  exit 2
fi
command -v curl >/dev/null || { echo "STAGE64 RUNTIME BLOCKED: curl unavailable"; exit 2; }
for u in "$STAGE64_PRIMARY_HEALTH_URL" "$STAGE64_SECONDARY_HEALTH_URL"; do
  curl --fail --silent --show-error --max-time 10 "$u" >/dev/null || { echo "STAGE64 RUNTIME BLOCKED: health probe failed: $u"; exit 2; }
done
bash -lc "$STAGE64_ROUTING_VERIFY_COMMAND"
bash -lc "$STAGE64_FAILOVER_VERIFY_COMMAND"
bash -lc "$STAGE64_DATA_CONSISTENCY_VERIFY_COMMAND"
bash -lc "$STAGE64_RECOVERY_EVIDENCE_COMMAND"
echo "STAGE64 RUNTIME PASS"

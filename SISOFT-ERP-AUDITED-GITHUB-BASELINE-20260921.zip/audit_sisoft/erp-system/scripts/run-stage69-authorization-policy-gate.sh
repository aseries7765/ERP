#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts/verify-stage69-authorization-policy.py"
required=(STAGE69_PUBLISH_VERIFY_COMMAND STAGE69_DISTRIBUTION_VERIFY_COMMAND STAGE69_STALE_POLICY_VERIFY_COMMAND STAGE69_OVERRIDE_VERIFY_COMMAND STAGE69_DECISION_VERSION_VERIFY_COMMAND STAGE69_ROLLBACK_VERIFY_COMMAND STAGE69_SIMULATION_VERIFY_COMMAND STAGE69_FAILOVER_VERIFY_COMMAND STAGE69_EVIDENCE_COMMAND)
missing=0
for v in "${required[@]}"; do if [[ -z "${!v:-}" ]]; then echo "BLOCKED: missing $v"; missing=1; fi; done
if (( missing )); then echo 'STAGE69 RUNTIME BLOCKED: representative policy infrastructure/evidence is required'; exit 2; fi
for v in "${required[@]}"; do echo "Executing $v"; bash -lc "${!v}"; done
echo 'STAGE69 RUNTIME PASS: authorization policy distribution and consistency evidence verified'

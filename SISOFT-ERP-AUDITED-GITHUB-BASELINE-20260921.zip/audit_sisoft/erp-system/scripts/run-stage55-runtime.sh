#!/usr/bin/env bash
set -euo pipefail

# This is intentionally opt-in. It never fabricates a PASS and never runs
# against a production database by default.
: "${STAGE55_ALLOW_RUNTIME:=0}"
: "${STAGE55_DISPOSABLE_DB:=0}"
: "${API_BASE_URL:=http://localhost:3001}"

if [[ "$STAGE55_ALLOW_RUNTIME" != "1" || "$STAGE55_DISPOSABLE_DB" != "1" ]]; then
  echo "STAGE55 RUNTIME BLOCKED: set STAGE55_ALLOW_RUNTIME=1 and STAGE55_DISPOSABLE_DB=1"
  exit 2
fi

for cmd in curl python3; do
  command -v "$cmd" >/dev/null || { echo "STAGE55 RUNTIME BLOCKED: missing $cmd"; exit 2; }
done

# A real runtime test requires a caller-supplied authenticated token and
# representative tenant/resource IDs. Never invent them.
: "${STAGE55_BEARER_TOKEN:?STAGE55 RUNTIME BLOCKED: STAGE55_BEARER_TOKEN is required}"

python3 scripts/verify-stage55-application-integration.py

health="$(curl -fsS --max-time 10 "$API_BASE_URL/health/live")" || {
  echo "STAGE55 RUNTIME BLOCKED: API health endpoint unavailable at $API_BASE_URL/health/live"
  exit 2
}
printf '%s\n' "$health" > stage55-health-response.txt

# Optional representative checks. They are enabled only when explicit IDs
# are supplied. A missing fixture is a blocked run, not a fabricated success.
: "${STAGE55_SALES_QUOTE_ID:=}"
: "${STAGE55_FINANCE_ACCOUNT_ID:=}"
: "${STAGE55_RBAC_ROLE_ID:=}"

if [[ -z "$STAGE55_SALES_QUOTE_ID" || -z "$STAGE55_FINANCE_ACCOUNT_ID" || -z "$STAGE55_RBAC_ROLE_ID" ]]; then
  echo "STAGE55 RUNTIME BLOCKED: supply real disposable-fixture IDs for sales, finance, and RBAC paths" >&2
  exit 2
fi

headers=(-H "Authorization: Bearer $STAGE55_BEARER_TOKEN" -H 'Accept: application/json')
for spec in \
  "sales|$API_BASE_URL/v1/sales/quotes/$STAGE55_SALES_QUOTE_ID" \
  "finance|$API_BASE_URL/v1/finance/accounts/$STAGE55_FINANCE_ACCOUNT_ID/ledger" \
  "rbac|$API_BASE_URL/v1/rbac/roles/$STAGE55_RBAC_ROLE_ID"; do
  name="${spec%%|*}"; url="${spec#*|}"
  code="$(curl -sS -o "stage55-$name-response.json" -w '%{http_code}' --max-time 15 "${headers[@]}" "$url")"
  if [[ "$code" != "200" ]]; then
    echo "STAGE55 RUNTIME FAIL: $name GET returned HTTP $code" >&2
    exit 1
  fi
done

echo "STAGE55 RUNTIME PASS"
echo "Authenticated representative API reads completed against the supplied disposable environment."

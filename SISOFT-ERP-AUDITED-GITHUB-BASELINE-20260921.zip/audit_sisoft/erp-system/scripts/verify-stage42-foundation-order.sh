#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
from pathlib import Path
import re, json
schema=Path('prisma/schema.prisma').read_text()
blocks=re.findall(r'^model\s+(\w+)\s*\{(.*?)^\}', schema, re.M|re.S)
models={}
for name,body in blocks:
    mm=re.search(r'@@map\("([^"]+)"\)',body)
    table=mm.group(1) if mm else re.sub(r'(?<!^)(?=[A-Z])','_',name).lower()
    models[name]=table
edges=[]
for name,body in blocks:
    for line in body.splitlines():
        line=line.strip()
        rm=re.match(r'^(\w+)\s+(\w+)(?:\[\])?\??\s+@relation\b',line)
        if rm and rm.group(2) in models:
            edges.append((name,rm.group(2)))
deps={n:set() for n in models}
for a,b in edges: deps[a].add(b)
remaining=set(models); levels=[]
while remaining:
    ready=sorted(n for n in remaining if not (deps[n] & remaining))
    if not ready: raise SystemExit('FAIL: relation dependency cycle')
    levels.append(ready); remaining-=set(ready)
created=set()
for p in sorted(Path('prisma/migrations').glob('*/migration.sql')):
    for a,b in re.findall(r'CREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+(?:"([^"]+)"|([A-Za-z_]\w*))',p.read_text(errors='ignore'),re.I):
        created.add(a or b)
out={'model_count':len(models),'migration_table_count':len(created),'relation_edge_count':len(edges),'dependency_levels':len(levels),'largest_level':max(map(len,levels)),'untracked_model_count':sum(t not in created for t in models.values()),'foundation':{}}
for n in ['Tenant','User','Role','Permission','Group','Policy','Delegation','CostCenter','RolePermission','UserRole','GroupPermission','PolicyPermission','DelegationPermission']:
    if n in models: out['foundation'][n]={'table':models[n],'depends_on':sorted(deps[n]),'level':next(i for i,x in enumerate(levels) if n in x),'migration_tracked':models[n] in created}
Path('docs/stage42-foundation-dependency-order.json').write_text(json.dumps(out,indent=2)+'\n')
print(f'Stage 42 dependency-order static gate: {len(models)} models, {len(created)} migration tables, {len(edges)} relation edges')
print('Dependency graph acyclic: PASS')
print(f'Dependency-first levels: {len(levels)}')
print(f'Untracked schema models: {out["untracked_model_count"]}')
print('Foundation inventory: PASS')
print('Production migration generation/execution: BLOCKED — pinned Prisma CLI/PostgreSQL runtime unavailable')
PY

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$ROOT/scripts/verify-stage65-shard-routing.py"

required=(
  STAGE65_ROUTER_VERIFY_COMMAND
  STAGE65_PLACEMENT_VERSION_VERIFY_COMMAND
  STAGE65_MIGRATION_VERIFY_COMMAND
  STAGE65_CUTOVER_FENCING_VERIFY_COMMAND
  STAGE65_RECOVERY_VERIFY_COMMAND
  STAGE65_CROSS_SHARD_RESTRICTION_VERIFY_COMMAND
  STAGE65_REBALANCING_VERIFY_COMMAND
  STAGE65_EVIDENCE_SHA256
)
for name in "${required[@]}"; do
  if [[ -z "${!name:-}" ]]; then
    echo "STAGE65 RUNTIME BLOCKED: missing $name" >&2
    exit 2
  fi
done

run_check() {
  local name="$1"
  local command="$2"
  echo "[stage65] $name"
  bash -lc "$command"
}

run_check "tenant routing" "$STAGE65_ROUTER_VERIFY_COMMAND"
run_check "placement version consistency" "$STAGE65_PLACEMENT_VERSION_VERIFY_COMMAND"
run_check "migration copy and verification" "$STAGE65_MIGRATION_VERIFY_COMMAND"
run_check "cutover fencing" "$STAGE65_CUTOVER_FENCING_VERIFY_COMMAND"
run_check "rollback/recovery" "$STAGE65_RECOVERY_VERIFY_COMMAND"
run_check "cross-shard restriction" "$STAGE65_CROSS_SHARD_RESTRICTION_VERIFY_COMMAND"
run_check "rebalancing checkpoints/orphan detection" "$STAGE65_REBALANCING_VERIFY_COMMAND"

if [[ ! "$STAGE65_EVIDENCE_SHA256" =~ ^[0-9a-fA-F]{64}$ ]]; then
  echo "STAGE65 RUNTIME FAIL: STAGE65_EVIDENCE_SHA256 must be a 64-hex SHA-256 value" >&2
  exit 1
fi

echo "STAGE65 RUNTIME PASS"
echo "Representative multi-shard routing, migration, fencing, recovery and rebalancing evidence was supplied by the deployment operator."

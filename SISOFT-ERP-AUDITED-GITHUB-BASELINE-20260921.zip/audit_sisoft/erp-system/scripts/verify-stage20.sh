#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python - <<'PY'
from pathlib import Path
checks = {
 'RBAC module imports real Redis cache': "./services/redis-cache-store",
 'RBAC module binds BullMQ emitter': 'useClass: BullMqRbacEventEmitter',
 'BullMQ emitter exists': 'class BullMqRbacEventEmitter',
 'RBAC events queue registered': "RBAC_EVENTS_QUEUE_NAME",
 'Redis prefix invalidation uses SCAN': "client.scan(cursor, 'MATCH'",
 'Audit queue emission': "auditQueue.add('rbac-audit-event'",
 'RBAC event queue emission': 'eventQueue.add(payload.event',
}
files = {
 'RBAC module': Path('apps/api/src/modules/rbac/rbac.module.ts').read_text(),
 'Emitter': Path('apps/api/src/modules/rbac/services/bullmq-rbac-event-emitter.ts').read_text(),
 'Queue module': Path('apps/api/src/queue/queue.module.ts').read_text(),
 'Redis cache': Path('apps/api/src/modules/rbac/services/redis-cache-store.ts').read_text(),
}
for name, needle in checks.items():
    if not any(needle in text for text in files.values()):
        raise SystemExit(f'FAIL: {name}')
for name, text in files.items():
    if text.count('{') != text.count('}') or text.count('(') != text.count(')'):
        raise SystemExit(f'FAIL delimiters: {name}')
print('Stage 20 static gates PASS: BullMQ RBAC events, audit emission, Redis SCAN, and production wiring')
PY

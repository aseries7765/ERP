#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
python3 - <<'PY'
from pathlib import Path
import json,re,sys
p=Path('prisma/FOUNDATION-BASELINE-INVENTORY-STAGE40.json')
if not p.exists(): print('FAIL: baseline inventory missing'); sys.exit(1)
d=json.loads(p.read_text())
if d['schemaModelCount'] != 193: print('FAIL: expected 193 schema models, got',d['schemaModelCount']); sys.exit(1)
models=d['models']
if len({x['table'] for x in models}) != len(models): print('FAIL: duplicate physical table mapping'); sys.exit(1)
if d['trackedTableCount'] != 74: print('FAIL: tracked table count drift:',d['trackedTableCount']); sys.exit(1)
if d['untrackedTableCount'] != 119: print('FAIL: expected 119 untracked tables, got',d['untrackedTableCount']); sys.exit(1)
by={x['table']:x for x in models}
for t in ['tenants','users','roles','permissions','groups','policies','delegations','cost_centers']:
    if t not in by or by[t]['status'] != 'UNTRACKED': print('FAIL: foundation candidate not untracked:',t); sys.exit(1)
print('Stage 40 foundation baseline inventory PASS: 193 models / 74 tracked / 119 untracked')
print('Foundation candidates PASS: tenants, users, roles, permissions, groups, policies, delegations, cost_centers')
print('Production baseline SQL generation: BLOCKED until pinned Prisma CLI + PostgreSQL are available')
PY

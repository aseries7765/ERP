#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
C="$ROOT/apps/api/src/modules/rbac"

grep -q "GROUP_CREATED" "$C/rbac.constants.ts"
grep -q "GROUP_UPDATED" "$C/rbac.constants.ts"
grep -q "GROUP_DELETED" "$C/rbac.constants.ts"
grep -q "POLICY_DELETED" "$C/rbac.constants.ts"
grep -q "SOD_RULE_DELETED" "$C/rbac.constants.ts"
grep -q "RBAC_EVENTS.GROUP_CREATED" "$C/services/group.service.ts"
grep -q "RBAC_EVENTS.GROUP_UPDATED" "$C/services/group.service.ts"
grep -q "RBAC_EVENTS.GROUP_DELETED" "$C/services/group.service.ts"
grep -q "RBAC_EVENTS.POLICY_DELETED" "$C/services/policy.service.ts"
grep -q "RBAC_EVENTS.SOD_RULE_DELETED" "$C/services/sod.service.ts"
for f in group.controller.ts policy.controller.ts sod.controller.ts; do grep -q "req.user.id" "$C/controllers/$f"; done
python - "$C" <<'PY'
import pathlib,sys
root=pathlib.Path(sys.argv[1])
for p in list(root.rglob('*.ts')):
    s=p.read_text()
    if s.count('{') != s.count('}') or s.count('(') != s.count(')'):
        raise SystemExit(f"delimiter mismatch: {p}")
print('RBAC Stage 27 static gates PASS')
PY

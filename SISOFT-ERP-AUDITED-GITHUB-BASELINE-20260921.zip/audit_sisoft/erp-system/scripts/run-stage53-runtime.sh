#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 "$ROOT/scripts/verify-stage53-runtime-smoke.py"
if [[ "${STAGE53_ALLOW_RUNTIME:-0}" != "1" ]]; then
  echo 'STAGE53 RUNTIME: BLOCKED (set STAGE53_ALLOW_RUNTIME=1 only for a disposable PostgreSQL database)'
  exit 0
fi
if [[ "${STAGE53_DISPOSABLE_DB:-0}" != "1" ]]; then
  echo 'STAGE53 RUNTIME: BLOCKED (STAGE53_DISPOSABLE_DB=1 required)'
  exit 0
fi
: "${DATABASE_URL:?DATABASE_URL is required}"
command -v psql >/dev/null || { echo 'STAGE53 RUNTIME: BLOCKED (psql missing)'; exit 0; }

OUT_DIR="${STAGE53_EVIDENCE_DIR:-$ROOT/prisma/runtime-evidence-stage53}"
mkdir -p "$OUT_DIR"
rm -f "$OUT_DIR"/*

# This script never resets or replays the feature migration ledger. It assumes
# Stage 52 already produced a clean disposable database with the authoritative
# schema and database protections installed.
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -X -f "$ROOT/scripts/stage53-runtime-smoke.sql" > "$OUT_DIR/01-smoke.txt"

# Independent read-only evidence after the smoke transaction.
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -X -Atc "
SELECT 'rls_tenant_scoped_tables=' || count(*) FROM pg_class c
JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE n.nspname='public' AND c.relkind='r' AND c.relrowsecurity;
SELECT 'audit_update_priv=' || has_table_privilege('erp_app','public.audit_events','UPDATE');
SELECT 'audit_delete_priv=' || has_table_privilege('erp_app','public.audit_events','DELETE');
SELECT 'subscription_select_priv=' || has_table_privilege('erp_app','public.subscriptions','SELECT');
SELECT 'subscription_insert_priv=' || has_table_privilege('erp_app','public.subscriptions','INSERT');
" > "$OUT_DIR/02-privilege-evidence.txt"

if grep -q '^audit_update_priv=t$' "$OUT_DIR/02-privilege-evidence.txt"; then
  echo 'Audit UPDATE privilege unexpectedly granted' >&2; exit 1
fi
if grep -q '^audit_delete_priv=t$' "$OUT_DIR/02-privilege-evidence.txt"; then
  echo 'Audit DELETE privilege unexpectedly granted' >&2; exit 1
fi

echo 'STAGE53 RUNTIME PASS' | tee "$OUT_DIR/RESULT.txt"
echo "Evidence: $OUT_DIR"
sha256sum "$OUT_DIR"/* > "$OUT_DIR/SHA256SUMS"

#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
warnings: list[str] = []


def require_file(rel: str) -> Path | None:
    p = ROOT / rel
    if not p.is_file():
        errors.append(f"missing required file: {rel}")
        return None
    return p


def require_text(path: Path, needle: str, label: str) -> None:
    if needle not in path.read_text(errors="replace"):
        errors.append(f"{label}: missing required contract: {needle}")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

# Artifact / container contracts.
for rel, port, health in [
    ('apps/api/Dockerfile', '3001', '/health/live'),
    ('apps/web/Dockerfile', '3000', None),
]:
    p = require_file(rel)
    if not p:
        continue
    s = p.read_text(errors='replace')
    if 'FROM node:20-slim' not in s:
        errors.append(f'{rel}: Node 20 slim runtime is required')
    if 'USER app' not in s:
        errors.append(f'{rel}: non-root runtime USER app is required')
    if 'HEALTHCHECK' not in s:
        errors.append(f'{rel}: Docker HEALTHCHECK is required')
    if 'pnpm-lock.yaml ./' not in s:
        errors.append(f'{rel}: immutable pnpm-lock.yaml COPY is required')
    if health and health not in s:
        errors.append(f'{rel}: healthcheck must target {health}')
    if f'EXPOSE {port}' not in s:
        errors.append(f'{rel}: expected EXPOSE {port}')

lock = ROOT / 'pnpm-lock.yaml'
if not lock.is_file():
    errors.append('pnpm-lock.yaml is absent; deterministic/frozen container installation cannot be verified')
else:
    if lock.stat().st_size == 0:
        errors.append('pnpm-lock.yaml is empty')

pkg = require_file('package.json')
if pkg:
    data = json.loads(pkg.read_text())
    if data.get('packageManager') != 'pnpm@9.12.0':
        errors.append('root packageManager must remain pnpm@9.12.0')
    if data.get('engines', {}).get('node') != '>=20.0.0':
        errors.append('root Node engine must remain >=20.0.0')

manifest = require_file('deployment/stage60/deployment-manifest.json')
if manifest:
    m = json.loads(manifest.read_text())
    if m.get('migrationPolicy', {}).get('beforeApplicationReady') is not True:
        errors.append('migration ordering must require migrations before application readiness')
    if m.get('rollbackPolicy', {}).get('automaticDestructiveRollback') is not False:
        errors.append('automatic destructive database rollback must remain disabled')

contract = require_file('deployment/stage60/production.env.contract')
if contract:
    s = contract.read_text()
    for name in ['APP_DATABASE_URL','REDIS_URL','JWT_SECRET','CSRF_SECRET','ENCRYPTION_KEY',
                 'DSR_PSEUDONYMIZATION_KEY','ALLOWED_ORIGINS','NEXT_PUBLIC_API_URL',
                 'STAGE59_API_BASE_URL','STAGE59_TLS_URL','STAGE59_OBSERVABILITY_URL',
                 'STAGE59_RATE_LIMIT_KEY_PREFIX','STAGE59_RATE_LIMIT_VERIFY_COMMAND',
                 'STAGE59_BACKUP_VERIFY_COMMAND','STAGE59_RESTORE_VERIFY_COMMAND']:
        if not re.search(rf'(?m)^{re.escape(name)}=', s):
            errors.append(f'production environment contract missing {name}')

# Migration ordering is deterministic by Prisma migration directory order; reject duplicates.
mi = ROOT / 'prisma' / 'migrations'
if mi.is_dir():
    names = sorted(p.name for p in mi.iterdir() if p.is_dir())
    if not names:
        errors.append('no Prisma migration directories found')
    if len(names) != len(set(names)):
        errors.append('duplicate Prisma migration directory names detected')
    for n in names:
        if not (mi/n/'migration.sql').is_file():
            errors.append(f'migration {n} is missing migration.sql')

# Required health probe implementation.
health = require_file('apps/api/src/health/health.controller.ts')
if health:
    require_text(health, "@Get('live')", 'API health controller')
    require_text(health, "@Get('ready')", 'API health controller')
    require_text(health, 'this.operational', 'API readiness dependency wiring')

# Deployment scripts must fail closed.
for rel, required in [
    ('scripts/run-stage59-operational-gate.sh', ['set -euo pipefail', 'STAGE59_RATE_LIMIT_VERIFY_COMMAND']),
]:
    p = require_file(rel)
    if p:
        s = p.read_text(errors='replace')
        for needle in required:
            if needle not in s:
                errors.append(f'{rel}: missing fail-closed requirement {needle}')

print('STAGE60 STATIC VERIFICATION')
print(f'Container artifacts: {"PASS" if not any("Dockerfile" in e for e in errors) else "BLOCKED"}')
print(f'Lockfile/determinism: {"PASS" if lock.is_file() else "BLOCKED"}')
print(f'Migration ordering: {"PASS" if mi.is_dir() and not any("migration" in e.lower() for e in errors if "migration" in e.lower() and "pnpm-lock" not in e) else "BLOCKED"}')
print(f'Health probes: {"PASS" if health and not any("health" in e.lower() for e in errors) else "BLOCKED"}')
print(f'Configuration contract: {"PASS" if contract and not any("environment contract" in e for e in errors) else "BLOCKED"}')
print('Runtime deployment verdict: BLOCKED until an actual target environment/image registry is supplied')

if errors:
    print('ERRORS:')
    for e in errors:
        print(f'- {e}')
    sys.exit(2)

print('STAGE60 STATIC PASS')

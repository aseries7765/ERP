# Stage 28 — Query Builder Source Reconstruction

## Scope
The Stage 16 dependency gate identified `@erp/query-builder` as a referenced workspace package whose source was absent from the merged workspace. Stage 28 restores a real dependency-free implementation from the API contracts and existing M12 documentation; it does not create a no-op package or suppress the dependency.

## Implemented
- AST types for columns, predicates, joins, ordering, grouping and aggregates.
- Fluent `QueryAstBuilder`.
- Explicit table/column allow-list with controlled registration API.
- Parameterized SQL compiler.
- Mandatory tenant predicate injected independently of caller filters.
- Row-limit clamp at 10,000 and non-negative offset.
- Identifier validation and rejection of unsafe table/column/alias names.
- Join validation through the same identifier controls.
- Unit-test source covering tenant requirement, injection-as-value behavior and limit clamping.

## Verification
- TypeScript package type-check: PASS.
- Emitted JavaScript smoke test: PASS for tenant injection, parameter binding and limit clamp.
- Full Jest suite: not run because repository dependencies are not installed in this environment.
- PostgreSQL integration: not run; database is unavailable.

## Important limitation
The original authoritative package source was not present in any available workspace snapshot. Therefore this is a contract-driven reconstruction, not a byte-for-byte recovery of the historical implementation. Before production release, the package API should be reconciled against the authoritative upstream delivery if that source becomes available.

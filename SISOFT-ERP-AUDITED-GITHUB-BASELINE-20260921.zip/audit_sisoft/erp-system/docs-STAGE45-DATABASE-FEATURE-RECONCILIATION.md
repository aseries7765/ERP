# Stage 45 — Database Feature Reconciliation

## Objective
Reconcile database-level prerequisites used by the Prisma schema and tracked migrations before generating an executable foundation baseline.

## Findings
- Prisma schema uses `uuid_generate_v7()` as the database-generated UUID default across the schema.
- No tracked migration in `prisma/migrations` creates that function or records an extension providing it.
- Tracked migrations create a trigger invoking `touch_updated_at_and_version()` for inventory tables, but no tracked migration creates that function.
- RLS/policies are explicitly present only for `event_outbox` and `event_deliveries` in tracked migrations.
- Therefore an executable baseline must explicitly account for these prerequisites or establish them through an independently documented infrastructure migration; they must not be silently assumed.

## Stage-45 decision
Do not emit production baseline SQL yet. The authoritative schema can describe tables/relations, but the database-function/extension provenance is incomplete in migration history. Generating SQL that guesses the provider of `uuid_generate_v7()` would create an unsafe baseline.

## Required next gate
1. Resolve authoritative UUIDv7 provider and supported PostgreSQL version.
2. Recover or define the authoritative `touch_updated_at_and_version()` function contract.
3. Decide whether shared DB infrastructure is a separately versioned migration layer or part of Prisma migrations.
4. Generate baseline SQL from pinned Prisma once CLI/runtime are available.
5. Execute on disposable PostgreSQL and compare resulting catalog against the expected manifest.

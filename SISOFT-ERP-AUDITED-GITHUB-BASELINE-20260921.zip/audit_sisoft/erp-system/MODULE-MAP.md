# Sisoft ERP — Module Map

Status is based on source inspection; module names are not treated as implementation proof by themselves.

| Module | Current status | Evidence / notes |
|---|---|---|
| Accounting | PARTIALLY IMPLEMENTED | Journal-entry DTO/port/posting service; no controller found in module slice. |
| AI | PARTIALLY IMPLEMENTED | Controllers/services exist; code explicitly documents unimplemented streaming/fake-logic boundaries. |
| Analytics | PARTIALLY IMPLEMENTED | Controller/services present; limited module footprint. |
| Audit | IMPLEMENTED CORE / PARTIAL SURFACE | Substantial services/controllers and integrity infrastructure; some optional search/PDF export surfaces remain unimplemented. |
| Auth | IMPLEMENTED CORE | Substantial authentication module and security dependencies. |
| Billing | PARTIALLY IMPLEMENTED | Controller/service exist; billing packages also exist. |
| Compliance | PARTIALLY IMPLEMENTED | Services exist; broader compliance controls are documented and some engine code is present. |
| Consent | PARTIALLY IMPLEMENTED | Core services/tests exist outside module tree; module footprint is small. |
| Control Plane | PARTIALLY IMPLEMENTED | Large module and provisioning/control APIs exist, but no deployed control-plane service is established as a separate runtime. |
| CRM | PARTIALLY IMPLEMENTED | Controller/service only in current module slice. |
| Dashboards | PARTIALLY IMPLEMENTED | Controller/services; documentation states some capabilities are not implemented in the delivery slice. |
| Documents | IMPLEMENTED CORE / PARTIAL | Large module with controllers/services; OCR/export limitations remain documented. |
| DSR | PARTIALLY IMPLEMENTED | DSR engine/package and API surface exist; runtime integration remains gated. |
| Employee | IMPLEMENTED CORE / PARTIAL | Large module with PII handling and tests; integration/runtime gaps remain. |
| Finance | PARTIALLY IMPLEMENTED | Thin API module, backed by substantial finance schema/package/migrations. |
| Handoff | PARTIALLY IMPLEMENTED | Token/registry services and tests exist; registry/provisioning integration is intentionally bounded. |
| HIS Patient | PARTIALLY IMPLEMENTED | Patient-core slice exists with controllers/services/tests; broader clinical integration is not complete. |
| HR | IMPLEMENTED CORE / PARTIAL | Attendance, leave, roster, timesheet and approval flows with tests/jobs. |
| Inventory | PARTIALLY IMPLEMENTED | Controller/service exists and schema/migrations are present; deeper integration requires runtime validation. |
| KPI | PARTIALLY IMPLEMENTED | Controller/services exist; broader dashboard/analytics integration remains limited. |
| Manufacturing | PARTIALLY IMPLEMENTED | Controller/service plus MRP package; current API module is thin. |
| Notifications | IMPLEMENTED CORE / PARTIAL | Large module with multiple services and tests; runtime delivery providers remain environment-dependent. |
| Payroll | IMPLEMENTED CORE / PARTIAL | Large module with runs, components, bank formats, loans/advances and country plugins; runtime verification remains blocked. |
| Portal Auth | PARTIALLY IMPLEMENTED | Small API slice with tests; separate portal UI is still a stub. |
| Privacy | PARTIAL / FOUNDATION | Minimal API module; broader privacy controls live in packages/docs. |
| Projects | PARTIALLY IMPLEMENTED | Controller/service/DTOs and tests exist. |
| Purchase | PARTIALLY IMPLEMENTED | Controller/service/DTOs and migrations exist; runtime integration remains gated. |
| RBAC | IMPLEMENTED CORE / PARTIAL RUNTIME | Large module with durable mutation/outbox/audit work and tests; PostgreSQL/Redis runtime gates remain blocked. |
| Reports | PARTIALLY IMPLEMENTED | Controller/services and tests exist; production runtime/reporting backend requires validation. |
| Retention | PARTIALLY IMPLEMENTED | Services and tests exist; operational execution is environment-dependent. |
| Sales | PARTIALLY IMPLEMENTED | Controller/service and tests/migrations exist; runtime integration remains gated. |
| Settings | IMPLEMENTED CORE / PARTIAL | Large module with services/controllers/tests; sandbox features explicitly remain unimplemented. |
| Sync | PARTIALLY IMPLEMENTED | Small API module backed by `sync-crdt` package. |
| Tenancy | IMPLEMENTED CORE / PARTIAL RUNTIME | Large module with tenant/company/provisioning capabilities and tests; actual DB RLS runtime still requires environment evidence. |
| Terminology | IMPLEMENTED CORE / PARTIAL | Large terminology service/module and tests; AI suggestion explicitly remains unimplemented. |
| Workflow | IMPLEMENTED CORE / PARTIAL | Large engine/module and tests; scheduler/runtime integrations remain gated. |

## Important classification rule
A module marked implemented here means there is meaningful implementation in the supplied source. It does **not** mean production-ready, fully integrated, or runtime-verified.

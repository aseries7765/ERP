# Stage 17 — RBAC Persistence Reconciliation

## Goal
Close the structural gap between the M3.3 RBAC repository/domain contract and the merged Prisma schema without replacing working business services with stubs.

## Changes
- Added `GroupPermission` for tenant-scoped group → permission assignments.
- Added `PolicyPermission` for tenant-scoped policy → permission applicability.
- Added `DelegationPermission` for tenant-scoped delegation → permission grants.
- Added Prisma relation fields on `Group`, `Permission`, and `Delegation`/`Policy` where applicable.
- Added an additive SQL migration with UUID primary keys, foreign keys, tenant scope, indexes, and uniqueness constraints.
- Added static verification script `scripts/verify-rbac-persistence-stage17.sh`.

## Deliberate non-changes
- Existing `Role`, `RolePermission`, `UserRole`, `Group`, `Policy`, `Delegation`, `SeparationOfDutyRule`, and `AccessReview` tables were not duplicated.
- The in-memory RBAC repository remains the runtime provider until a complete Prisma adapter is implemented and exercised against a live database.
- No fake adapter or partial provider swap was introduced.

## Verification
Static gate: PASS — 190 unique Prisma models and all three persistence bridge models/migration checks pass.

Runtime Prisma validation, migration execution, and integration tests remain unverified because this environment does not have the required installed dependencies/database service.

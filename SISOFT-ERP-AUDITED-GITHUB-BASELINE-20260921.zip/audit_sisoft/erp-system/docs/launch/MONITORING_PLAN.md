# Post-Launch Monitoring Plan (First 30 Days)

## Daily
- Error rate and latency review (dashboards owned by M14).
- Security anomaly dashboard review: any `SecurityAnomalyEvent`
  entries, brute-force lockout volume (a spike could mean either an
  attack or a UX problem causing legitimate users to mistype
  passwords repeatedly — investigate before assuming either).
- Failed-login volume trend.

## Weekly
- Incident review (even if zero incidents — confirms the process is
  being followed, not just that nothing happened).
- Vulnerability tracker review — any new findings from ongoing
  scanning, SLA compliance check.

## Thresholds to alert on (recommendations, not wired up here)
- Brute-force lockouts > N per hour (baseline TBD from real traffic).
- WAF block rate spike (possible attack, or possible false-positive
  wave from an overly aggressive rule — check both).
- Any CRITICAL vulnerability finding — page immediately, don't wait
  for the weekly review.

## Status: plan only; dashboards and alert thresholds require the real
M14 monitoring stack and real production traffic baselines, neither
of which exist in this delivery.

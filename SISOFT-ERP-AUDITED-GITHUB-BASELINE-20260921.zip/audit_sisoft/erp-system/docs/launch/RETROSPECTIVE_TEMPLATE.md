# Retrospective Template

Use for launch retro and any major incident retro.

## What happened (factual timeline)
-

## What went well
-

## What didn't go well
-

## Root cause(s)
<!-- Ask "why" repeatedly — avoid stopping at the first proximate cause -->

## Action items

| Action | Owner | Due date | Status |
|---|---|---|---|
| | | | |

## Blameless note
This retrospective is about the system and process, not individual
blame. If an action item reads like "person X should be more careful,"
rewrite it as a system change that makes the mistake harder to make
(a check, a default, a test) — per the incident-response culture
described in docs/security/INCIDENT_RESPONSE.md.

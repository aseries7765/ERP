# On-Call Rotation

## Structure (template — not populated with real people)

| Week | Primary | Secondary | Escalation |
|---|---|---|---|
| 1 | <name> | <name> | <name> |
| 2 | <name> | <name> | <name> |

## Responsibilities
- Primary: first responder to any page (security anomaly alert,
  incident, monitoring alert per M14).
- Secondary: backup if primary doesn't acknowledge within the SLA
  window (see ESCALATION_MATRIX.md).
- Security-specific pages (brute-force lockout storms, anomaly
  detection alerts, WAF block spikes) route to whoever is on-call for
  security specifically, which may be the same rotation as general
  on-call or a separate one depending on team size — not decided here.

## Before going live
- [ ] Real names populated
- [ ] Paging tool configured (PagerDuty/Opsgenie — not chosen here)
- [ ] Each on-call engineer has completed the training in
      docs/security/SECURITY_TRAINING.md
- [ ] Each on-call engineer has reviewed docs/security/IR_PLAYBOOKS/

## Status: template only.

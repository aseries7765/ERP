# Support Plan

## Channels (to be stood up before launch)
- In-app support widget / ticketing system (choice of tool not made in
  this module — likely overlaps with whatever M4-M9 already use for
  customer-facing support, not duplicated here).
- Security-specific reporting channel: see
  docs/security/DISCLOSURE_POLICY.md for the researcher-facing path,
  distinct from general customer support.

## Security-related support triage
Any support ticket that looks like it might be a security issue
(account takeover report, "I see someone else's data") should be
escalated immediately to the on-call security rotation
(ONCALL_ROTATION.md) rather than handled as a routine ticket — treat
as a potential incident per INCIDENT_RESPONSE.md until ruled out.

## SLA
See SLA_DEFINITIONS.md for response-time commitments.

## Status: plan only; support tooling/staffing not stood up in this
delivery.

# Chaos Test Results

**Status: NOT RUN.** Experiments are defined in `tools/chaos/experiments/`
but require a live Kubernetes cluster with Litmus installed, which
doesn't exist in this delivery environment.

## Targets (per M15 spec)
| Experiment | Target recovery |
|---|---|
| Pod kill | Auto-restart < 30s |
| DB failover | < 60s |
| Network partition | Graceful degradation (no crash, appropriate error handling) |

Fill this file in using `tools/chaos/results/TEMPLATE.md` per
experiment once actually run against staging.

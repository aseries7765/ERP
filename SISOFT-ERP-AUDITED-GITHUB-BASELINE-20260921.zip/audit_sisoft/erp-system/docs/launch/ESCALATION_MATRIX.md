# Escalation Matrix

| Severity | Initial responder | Escalate to secondary after | Escalate to leadership after |
|---|---|---|---|
| CRITICAL | On-call primary, immediately | 5 min no ack | 15 min, or immediately if customer data exposure confirmed |
| HIGH | On-call primary | 15 min no ack | 1 hour |
| MEDIUM | On-call primary, during business hours | Next business day | N/A unless it escalates |
| LOW | Ticket queue | N/A | N/A |

## Special cases
- **Confirmed data breach**: notify legal + leadership immediately,
  regardless of time of day — do not wait for the standard escalation
  timer (see docs/security/IR_PLAYBOOKS/data-breach.md).
- **Suspected insider threat**: route to HR + Legal + security lead
  directly, bypass the general on-call rotation (see
  docs/security/IR_PLAYBOOKS/insider-threat.md).

## Status: framework defined; specific names/contact methods not
populated (organizational detail, not code).

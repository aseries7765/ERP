# Rollback Plan

## Trigger conditions
See GO_LIVE_PLAN.md's abort criteria. Any Incident Commander (per
INCIDENT_RESPONSE.md roles) can invoke rollback — don't require
consensus during an active incident.

## Mechanism
1. Application rollback: redeploy the previous known-good image tag
   (verified signed via Cosign — see docs/security/SLSA.md for
   current signing status) via the standard CD pipeline's rollback
   command (specific tooling depends on M14's CD setup, not
   duplicated here).
2. Database rollback: **only if the new version ran destructive
   migrations** — coordinate with the DBA/platform owner before
   rolling back schema changes, since a naive rollback can lose data
   written under the new schema. Prefer forward-fix over schema
   rollback wherever possible.
3. Feature-flag rollback: if the launch used dark-launch/feature
   flags (recommended in GO_LIVE_PLAN.md), disabling the flag is
   faster and safer than a full redeploy — prefer this when available.

## Verification after rollback
- Smoke test the rolled-back version.
- Confirm no data was lost or corrupted during the rollback window.
- Communicate status per COMMUNICATION_PLAN.md.

## Status: documented procedure; not tested against a real deployment
pipeline in this delivery (rollback drills should happen in staging
before launch, per LAUNCH_CHECKLIST.md's "Rollback plan tested" item,
currently unchecked).

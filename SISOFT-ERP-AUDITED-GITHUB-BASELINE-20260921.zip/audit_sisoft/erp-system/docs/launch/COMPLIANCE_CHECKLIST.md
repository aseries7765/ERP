# Compliance Checklist (Launch Gate)

| Item | Status |
|---|---|
| SOC 2 Type I readiness | Control mapping documented (docs/security/SOC2_CONTROLS.md); not audited |
| GDPR breach notification workflow | Depends on M13; not verified in this module |
| HIPAA technical safeguards | Partial (docs/security/HIPAA_CONTROLS.md) — PHI classification & BAA management outstanding |
| PCI-DSS scope reduction (tokenization) | Assumed architecture, not verified against S4's actual implementation |
| ISO 27001 control mapping | Early draft (docs/security/ISO27001_CONTROLS.md); not certified |
| Data processing agreements (DPAs) with sub-processors | Legal/ops responsibility, not addressed here |
| Privacy policy / ToS reflect actual data handling | Legal/product responsibility, not addressed here |

**None of these are launch-ready.** This checklist exists so the gap
is visible and trackable, not to imply readiness.

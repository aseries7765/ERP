# Load Test Results

**Status: NOT RUN.** No live instance exists in this delivery
environment to load test.

## Planned scenarios (per M15 spec)
| Scenario | Load | Target |
|---|---|---|
| Baseline | 1k concurrent users | p95 < 200ms |
| Peak | 10k concurrent users (2x normal) | p95 < 500ms |
| Soak | 2k users, 24h continuous | no memory leak / degradation |
| Spike | 0 → 10k in 60s | auto-scale within 2 min |
| Stress | 20k users | find the actual breaking point |

## Recommended tooling
k6, Gatling, or Locust — not chosen/configured in this delivery since
it requires a target environment to point at.

## When run for real
Fill in actual p50/p95/p99 latency, error rate, and autoscaling
behavior observed — do not report the target numbers above as if they
were achieved results.

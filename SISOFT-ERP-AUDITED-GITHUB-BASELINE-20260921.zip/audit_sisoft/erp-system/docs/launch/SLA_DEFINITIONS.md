# SLA Definitions

## Availability target
99.9% uptime (three nines) — a common SaaS baseline; adjust per actual
contractual commitments made by sales/legal, which this module doesn't
have visibility into.

## Incident response SLA (internal)
See ESCALATION_MATRIX.md for response-time-to-acknowledge by severity.

## Customer-facing incident communication SLA
- Status page update within 30 minutes of a confirmed CRITICAL/HIGH
  incident affecting customers.
- Direct email notification within 24 hours for incidents involving
  their data specifically.

## Security finding remediation SLA
See docs/security/VULNERABILITY_MANAGEMENT.md — CRITICAL 24h, HIGH 7d,
MEDIUM 30d, LOW 90d.

## Status: definitions proposed; not yet reconciled with actual signed
customer contracts (outside this module's visibility).

# Status Page

## Recommendation
Use a managed status page provider (Statuspage/Atlassian,
Better Uptime, or similar) rather than building one — it needs to be
hosted independently of the main platform's infrastructure so it stays
up during an incident affecting the main platform itself.

## Components to list
- API
- Web application
- Authentication
- Per-region status if the multi-region topology (M14) is live

## Status: recommendation only; no provider selected or provisioned in
this delivery.

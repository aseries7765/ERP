# Inventory module

Production-oriented inventory foundation: tenant-scoped products and warehouses; decimal stock balances; adjustment movements; reservations/releases; atomic warehouse transfers; physical stock counts and reconciliation; audit queue integration.

## Invariants
- Tenant isolation is enforced through application tenant context plus database RLS.
- Stock quantity cannot fall below reserved quantity.
- Reservations cannot exceed available stock.
- Transfers require distinct active warehouses and positive quantity.
- Shipping atomically decreases source stock; receiving increases destination stock.
- Count posting applies only the computed variance.
- All financial/quantity arithmetic uses Prisma Decimal.
- Runtime verification is required before declaring PASS.

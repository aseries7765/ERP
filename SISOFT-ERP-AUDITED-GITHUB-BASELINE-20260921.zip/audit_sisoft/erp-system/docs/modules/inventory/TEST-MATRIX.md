# Inventory Test Matrix

Required runtime scenarios: create product/warehouses; tenant isolation; positive/negative stock adjustment; reserve/release boundaries; transfer approval/ship/receive; insufficient-stock transfer rejection; count creation/edit/post; count variance reconciliation; concurrent transfer/adjustment safety; RLS denial across tenants; audit event delivery.

# Projects module

The Projects module provides persistent, tenant-isolated project execution: project master data, members, milestones, tasks, and time entries.

## Invariants
- Every query is tenant-scoped and runs under the database tenant context.
- Project and task codes are unique within a tenant/project.
- State transitions are explicit; invalid transitions fail.
- Optimistic version checks protect task updates.
- Dates cannot form invalid start/due ranges.
- Hours and budget cannot be negative; a time entry cannot exceed 24 hours.
- Task, milestone, and member references must belong to the same tenant/project.
- Mutations emit audit events.

Runtime verification requires PostgreSQL, Redis, Prisma generation, API tests, E2E, RLS, and concurrency execution.

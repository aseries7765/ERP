# Projects verification matrix

1. Create project; duplicate code rejected.
2. Cross-tenant project/member/task lookup rejected.
3. Project state machine rejects invalid transitions.
4. Member allocation >100 rejected.
5. Milestone/task dates outside project bounds rejected.
6. Duplicate task code rejected.
7. Task optimistic version conflict rejected.
8. Invalid task transition rejected.
9. Time entry >24h/zero/negative rejected.
10. Time entry task from another project rejected.
11. Invalid time-entry transition rejected.
12. RLS blocks cross-tenant reads/writes.
13. Concurrent task update proves one stale writer fails.
14. Audit event emitted for each mutation.

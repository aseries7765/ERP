# Dynamic Form Builder

Tenants design their own forms (which fields appear, in what order,
with what validation) without a code change or deploy. A `FormSchema`
is JSON:

```ts
{
  id, tenantId, entityType, name, version,
  fields: FormFieldDefinition[],   // what fields exist and how they validate
  layout: string[][],              // rows of field keys, for rendering order
  isPublished: boolean,
  publishedAt?: Date,
}
```

## Versioning

- Creating a schema for a new (`tenantId`, `entityType`) starts at
  `version: 1`. Each subsequent `create()` for the same entity type bumps
  the version.
- `publish()` marks exactly one version "current" per `(tenantId,
  entityType)` — publishing a new version automatically unpublishes the
  previous one.
- **Published schemas are immutable.** To change a published form,
  create a new draft and publish that. This is what makes "old instances
  still render" true: a `FormInstance` stores the exact `schemaVersion`
  it was submitted against, and that version's `fields`/`layout` never
  change out from under it, even after a newer version is published.
- Draft (unpublished) schemas can be edited or deleted freely; published
  ones can't be deleted at all (delete the tenant's data instead, or
  just stop referencing it — the version is kept for historical
  `FormInstance` rows).

## Rendering — `@erp/form-builder`

`DynamicForm` takes a `FormSchemaDefinition` and renders one input per
field, grouped into rows per `layout`, using a type -> component map
(`fields/`) that can be overridden per-field-type via the
`fieldComponents` prop. Validation runs through `schemaToZod`, which
encodes the *same* rules as the backend's `SchemaValidatorService` (kept
in sync by hand today — see "Known limitations" in
`packages/form-builder/README.md` for the plan to generate one from the
other in a later phase).

## Submission — `FormInstance`

`POST /v1/form-instances` validates `data` against the referenced
schema's fields, stores it as a `FormInstance` stamped with that
schema's version, and — for any submitted key that matches a real
`CustomField` on the entity type — also mirrors the value into
`CustomFieldValue` so it's queryable through the EAV index, not just
readable back as opaque form JSON. Keys in `data` that are form-only
(not registered as a `CustomField`) are stored in `FormInstance.data`
only.

## Admin designer — `FormBuilder` (React)

A palette of field types + a config panel per selected field + Save
draft / Publish buttons. See `packages/form-builder/README.md` for
usage and current limitations (one field per row; no drag-reorder in
this delivery).

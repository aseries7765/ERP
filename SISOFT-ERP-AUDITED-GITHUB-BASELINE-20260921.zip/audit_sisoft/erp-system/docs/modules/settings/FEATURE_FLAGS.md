# Feature Flags

## Two kinds of flags

1. **Plan-gated** — availability is determined by the tenant's
   subscription plan (`planGate: string[]`). This module reads
   `context.plan` (supplied by the caller — the real plan comes from
   M6's subscription/entitlement system, not tracked here) and refuses
   to enable the flag for a plan not in the list.
2. **Tenant-toggled** — a tenant admin can turn a flag on/off for their
   tenant via `PATCH /v1/feature-flags/:key`, independent of plan.

A flag row can be **global** (`tenantId: null` — the base definition,
usually seeded) or **tenant-specific** (a per-tenant override with the
same `key`). `FeatureFlagService.listForTenant` and `.isEnabled` always
prefer the tenant-specific row when one exists, falling back to the
global row otherwise.

## Evaluation order

```
1. killSwitch === true                          -> false   (always wins)
2. planGate non-empty AND plan not in planGate   -> false
3. enabled === false                             -> false
4. userId in targeting.userIds                   -> true
5. role in targeting.roles                       -> true
6. stableHash(userId, flagKey) % 100 < rollout   -> true
7. otherwise                                     -> false
```

This exact order is implemented as a single pure function,
`FeatureFlagService.evaluate()`, with no I/O — see
`feature-flag.spec.ts` for a test of every branch.

## Rollout hashing

`stableHash(userId, flagKey)` is `sha256(flagKey + ':' + userId)`,
reduced to a 0-99 bucket via the first 4 bytes of the digest mod 100.
Properties this gives us:

- **Stable per user per flag** — a user's bucket for a given flag never
  changes between requests (no per-request randomness).
- **Independent across flags** — because the flag key is part of the
  hash input, a user in the "in" 10% for one flag is not necessarily in
  the "in" 10% for another flag at the same rollout percentage.

## Kill switch

`POST /v1/feature-flags/:key/kill` sets `killSwitch: true` immediately,
which short-circuits evaluation regardless of every other setting —
intended as the "stop the bleeding" lever during an incident.
`POST /v1/feature-flags/:key/revive` clears it.

## Caching

Flag evaluations are cached per `(tenantId, userId, flagKey)` with a
5-minute TTL — shorter than the 1-hour settings TTL, since flags are
expected to change more frequently (rollouts ramping, kill switches).
Any `create`/`update`/`kill`/`revive` call invalidates that flag's cache
entries across the tenant.

## Decorators

```ts
@RequireFeature('ai-assist')
@Get('ai-suggestions')
async getAiSuggestions() { ... }
```

Gates the whole route with a 403 if the flag isn't enabled for the
caller. For conditional logic *inside* a handler, inject the evaluator
instead:

```ts
async getDashboard(@FeatureFlagContext() flags: FeatureFlagContextValue) {
  if (await flags.isEnabled('new-dashboard')) { ... }
}
```

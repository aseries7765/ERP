# Custom Fields

Tenant-defined fields attached to any entity, **without a database
schema migration per field** (FINAL RULE #7). Values are stored
EAV-style in `CustomFieldValue`.

## Supported types

`STRING`, `TEXT`, `NUMBER`, `DECIMAL`, `BOOLEAN`, `DATE`, `DATETIME`,
`ENUM`, `MULTIENUM`, `EMAIL`, `PHONE`, `URL`, `JSON`, `REFERENCE`, `FILE`.

## Definition (`CustomField`)

```ts
{
  id, tenantId, entityType, key, label, type,
  required, options, validation, defaultValue,
  sortOrder, active, createdBy,
}
```

- `key` is unique per `(tenantId, entityType)` — snake_case, validated
  by the create DTO.
- `options` is required for `ENUM`/`MULTIENUM`.
- `validation.refEntity` is required for `REFERENCE`.
- Deleting a field is a **soft delete** (`active: false`) — historical
  `CustomFieldValue` rows are never dropped, so past form submissions and
  reports referencing the field stay intelligible. `MAX_CUSTOM_FIELDS_PER_ENTITY`
  (200) counts only active fields.

## Storage (`CustomFieldValue`, EAV)

```ts
{
  id, tenantId, customFieldId, entityType, entityId,
  valueText, valueNumber, valueDate, valueBool, valueJson,
}
```

Exactly one of the five `value*` columns is populated, chosen by the
field's `type` (see `CustomFieldValueService.pack`/`.unpack`). One row
per `(tenantId, customFieldId, entityId)` — writing again upserts.

## Indexing / querying

- `(tenantId, entityType, entityId)` — fetch all custom values for one
  record (`getEntityWithCustomFields`).
- `(tenantId, customFieldId, valueText)` — filter/search records by a
  specific field's text value (extend the host entity's query builder
  with a join on this index for "filter customers where vehicle_no =
  X"-style queries).

## Validation

`SchemaValidatorService.validateCustomFieldValue(field, value)` is the
single source of truth for what a value must look like for a given
type — required-ness, string length, number range, regex, email/URL/
phone shape, enum membership. The same rules are mirrored client-side
in `@erp/form-builder`'s `schemaToZod` for instant feedback; the backend
re-validates on every write regardless (G17: form validation never
allows malformed data through).

## Example: adding a field end-to-end

```
POST /v1/custom-fields
{ "entityType": "Customer", "key": "vehicle_no", "label": "Vehicle No", "type": "STRING" }

PATCH the Customer intake form's FormSchema to include "vehicle_no" in
its fields + layout, then POST /v1/form-schemas/:id/publish.

A user submits the form -> POST /v1/form-instances with
data.vehicle_no = "XYZ-123" -> the value lands in both FormInstance.data
(as submitted) AND CustomFieldValue (queryable).

GET /v1/custom-fields/entity/Customer/:id now returns vehicle_no: "XYZ-123".
```

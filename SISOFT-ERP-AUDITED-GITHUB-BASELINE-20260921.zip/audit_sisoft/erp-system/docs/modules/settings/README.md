# M3.9 — Settings & Customization

Backend module: `apps/api/src/modules/settings/`
Frontend package: `packages/form-builder/`

## What this module owns

1. **Scoped settings** — key/value config resolved through a
   system → tenant → company → branch → user precedence chain.
   See [RESOLUTION.md](./RESOLUTION.md).
2. **Feature flags** — plan-gated and tenant-toggled, with rollout % and
   explicit user/role targeting, plus a kill switch.
   See [FEATURE_FLAGS.md](./FEATURE_FLAGS.md).
3. **Custom fields** — tenant-defined fields on any entity, stored EAV
   (no schema migration per field). See [CUSTOM_FIELDS.md](./CUSTOM_FIELDS.md).
4. **Dynamic forms** — JSON form schemas rendered by
   `@erp/form-builder`, versioned so old submissions keep rendering with
   the schema they were submitted under. See [FORM_BUILDER.md](./FORM_BUILDER.md).
5. **Import/export** — JSON snapshot of a tenant's settings, flags,
   custom fields, and form schemas, for migration/backup/sandbox
   cloning. See [IMPORT_EXPORT.md](./IMPORT_EXPORT.md).
6. **Sandbox** — interface stub only in this phase.
   See [SANDBOX.md](./SANDBOX.md).

## Quick start

See [RUNBOOK.md](./RUNBOOK.md) for install/test/run commands and a
5-minute manual verification script.

## Design decisions

See `docs/adr/0043-*` through `0046-*`:

- 0043 — settings resolution chain (why "most specific wins" and why it's
  cache-invalidate-the-whole-tenant rather than surgical invalidation)
- 0044 — EAV for custom fields (why not per-tenant schema migrations)
- 0045 — JSON Schema-shaped definitions for dynamic forms (why not a
  full JSON Schema library)
- 0046 — feature flags vs. plan entitlements (where the line is between
  this module's flags and M6's subscription entitlements)

## Amendment context

This module was built under the SaaS-with-isolated-customer-environments
amendment: all data here is per-customer-environment (stays in the
tenant's own database), and the module exposes `import`/`export` so a
tenant's settings/flags/custom-fields/form-schemas can be migrated
between environments as JSON.

# Import / Export

`GET /v1/settings/export?what=all` (or a comma-separated subset of
`settings,flags,custom-fields,forms`) returns a JSON snapshot:

```ts
{
  version: 1,
  exportedAt: "2026-01-07T00:00:00.000Z",
  tenantId: "...",
  settings?: Record<string, unknown>,       // tenant-level only
  featureFlags?: FeatureFlag[],
  customFields?: CustomField[],             // active only
  formSchemas?: FormSchema[],               // all versions, including drafts
}
```

`POST /v1/settings/import` applies a previously exported payload to a
tenant (which may be a different tenant than the one it was exported
from — this is the tenant-migration/sandbox-cloning use case).

## Modes

- **`merge`** (default) — upsert everything present in the payload;
  anything not mentioned in the payload is left untouched.
- **`replace`** — same upserts, but also deletes tenant settings, active
  custom fields, and form-schema **drafts** that exist in the target
  tenant but are absent from the payload. **Published form schemas are
  never deleted by `replace`** — deleting one would orphan any
  `FormInstance` rows that reference it, and historical submissions must
  keep rendering (see RESOLUTION of versioning in FORM_BUILDER.md).

## What is deliberately NOT exported/imported

- `FormInstance` rows (actual filled-in submissions) and
  `CustomFieldValue` rows (actual field values on real entities) — these
  are *data*, not *configuration*, and importing them into a different
  tenant would create dangling `entityId` references with no
  corresponding entity. Only field/schema **definitions** move.
- User-level and branch-level settings — export/import operates at
  tenant scope only, matching the "tenant migration" use case in the
  amendment. (Nothing prevents adding company/branch/user export later;
  out of scope for this delivery.)

## Atomicity

`import()` runs inside a single Prisma transaction; if any upsert in the
batch fails, the whole import is rolled back and `ImportExportError` is
thrown — a partial import is never left in place.

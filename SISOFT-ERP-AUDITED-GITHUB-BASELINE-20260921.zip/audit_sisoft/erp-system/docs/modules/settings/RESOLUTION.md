# Settings Resolution

## Precedence chain

```
user  >  branch  >  company  >  tenant  >  system default
(most specific)                              (least specific)
```

`SettingsService.get(key, scope)` walks the chain top-down and returns
the **first** level that has a stored row for `key`. If nothing is
stored anywhere, and no `SystemSettingDefault` row exists either, the
call returns `null` (or throws `SettingNotFoundError` if `{ required:
true }` was passed).

Levels are skipped when the scope doesn't include them — e.g. a request
with no `branchId` never queries `BranchSetting` at all, it just moves on
to `CompanySetting`.

## Determinism (G16)

For a fixed set of stored rows and a fixed scope, `get()` always returns
the same result. There is no randomness, no time-based behavior, and no
dependency on request order in the resolution itself. (Feature flag
*rollout* evaluation is a separate concern with its own, also-deterministic,
per-user hashing — see FEATURE_FLAGS.md — but is not part of the settings
resolution chain.)

## Caching and invalidation (G18)

Each **resolved** value is cached under:

```
settings:{tenantId}:c{companyId|-}:b{branchId|-}:u{userId|-}:{key}
```

TTL is 1 hour. A write at *any* level (`set()` or `reset()`) invalidates
**every** cached key for that tenant, not just the one key that changed.
This is deliberately conservative: a tenant-level write can change what a
user-level *miss* resolves to (if that user has no override), and
tracking exactly which cached scope-signatures would be affected is more
complex than it's worth at this data volume. The cost is some extra cache
misses immediately after any write; the benefit is a hard guarantee of no
stale reads.

## Reading vs. writing at a scope

- `get(key, scope)` — read-only, walks the whole chain.
- `set(key, value, level, scope, changedBy)` — writes an override at
  exactly one level (`tenant | company | branch | user`). Does not
  affect any other level's stored row.
- `reset(key, level, scope, changedBy)` — deletes the override at one
  level, so resolution falls through to the next level up.

## Example

```ts
// Tenant sets a default timezone.
await settings.set('core.timezone', 'America/Chicago', 'tenant', { tenantId }, adminId);

// A specific branch overrides it.
await settings.set('core.timezone', 'America/Denver', 'branch', { tenantId, branchId }, adminId);

// A user in that branch, with no personal override, sees the branch's value.
await settings.get('core.timezone', { tenantId, branchId, userId }); // -> { value: 'America/Denver', resolvedAt: 'branch' }

// That same user sets a personal override.
await settings.set('core.timezone', 'Europe/Lisbon', 'user', { tenantId, branchId, userId }, userId);
await settings.get('core.timezone', { tenantId, branchId, userId }); // -> { value: 'Europe/Lisbon', resolvedAt: 'user' }
```

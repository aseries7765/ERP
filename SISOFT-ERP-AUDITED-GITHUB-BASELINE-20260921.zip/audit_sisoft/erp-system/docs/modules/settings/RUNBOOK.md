# Runbook

## Install (after merge)

```bash
pnpm install
pnpm --filter @erp/api prisma generate
pnpm --filter @erp/api prisma migrate deploy   # applies 20260107_settings_extras
```

## Seed

```bash
pnpm --filter @erp/api exec ts-node prisma/seed/settings/seed-system-defaults.ts
pnpm --filter @erp/api exec ts-node prisma/seed/settings/seed-feature-flags.ts
pnpm --filter @erp/api exec ts-node prisma/seed/settings/seed-form-schemas.ts <tenantId>
```

## Test

```bash
pnpm --filter @erp/api test settings
pnpm --filter @erp/form-builder test
```

Integration/e2e tests under `apps/api/test/settings/e2e/` require
`DATABASE_URL` pointed at a real Postgres instance with the migration
applied; without it they skip with a console warning rather than
silently passing. **Neither of the above commands was executed by the
account that produced this delivery — see root `MANIFEST.md` for why.**

## Run

```bash
pnpm --filter @erp/api start:dev
```

## Verify this slice in 5 minutes

1. **Resolution chain**: `PUT /v1/settings/core.timezone` with
   `{ "value": "America/Chicago", "scope": "tenant" }`, then
   `GET /v1/settings/core.timezone` → expect `resolvedAt: "tenant"`.
   `PUT` again with `scope: "user"` → `GET` again → expect
   `resolvedAt: "user"`.
2. **Feature flag**: `GET /v1/feature-flags/dark-mode` (seeded) →
   expect `{ enabled: true }`. `POST /v1/feature-flags/dark-mode/kill` →
   `GET` again → expect `{ enabled: false }`.
3. **Custom field → form → query** (the required e2e scenario):
   - `POST /v1/custom-fields` `{ entityType: "Customer", key: "vehicle_no", label: "Vehicle No", type: "STRING" }`
   - `POST /v1/form-schemas` including `vehicle_no` in `fields` + `layout`
   - `POST /v1/form-schemas/:id/publish`
   - `POST /v1/form-instances` with `data.vehicle_no = "XYZ-123"`
   - `GET /v1/custom-fields/entity/Customer/:entityId` → expect
     `vehicle_no: "XYZ-123"`.
4. **Import/export round-trip**: `GET /v1/settings/export?what=all`,
   then `POST /v1/settings/import` the same payload back with
   `mode: "merge"` → re-export → expect an identical payload (modulo
   `exportedAt`).

## Known gotchas

- `SettingsAdminGuard` and `CurrentUser`/`CurrentTenant` assume RBAC
  (M3.3) and tenancy (M3.2) middleware already populate `req.can(...)`,
  `req.user`, and `req.tenant` — see MANIFEST.md "Assumptions" for the
  exact paths assumed.
- The `SETTINGS_EVENT_PUBLISHER` provider defaults to a no-op; wire the
  real message bus in the host app's bootstrap once M1's infra module
  exposes one (see `settings.module.ts`'s top comment).

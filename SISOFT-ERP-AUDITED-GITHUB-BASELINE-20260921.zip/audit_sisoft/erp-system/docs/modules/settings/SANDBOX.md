# Sandbox (stub — future phase)

Per the amendment ("tenant can test changes in sandbox environment
before applying to production"), this module ships an **interface-only**
stub: `SandboxService` (`services/sandbox.service.ts`).

```ts
export interface Sandbox {
  cloneToSandbox(tenantId: string): Promise<{ sandboxId: string }>;
  applyFromSandbox(tenantId: string, sandboxId: string, changes: string[]): Promise<{ applied: string[] }>;
}
```

Both methods currently `throw SandboxNotImplementedError` (HTTP 501).
No route in this module calls them yet — they exist so:

1. The intended shape is agreed and reviewable now, before the real
   implementation lands in a later phase.
2. Future code (an admin "Try in sandbox" button, say) can be written
   against this interface today without churn later.

## Intended design (not implemented)

- `cloneToSandbox` would reuse `ImportExportService.export()`'s payload
  shape to snapshot a tenant's settings/flags/custom-fields/form-schemas
  into an isolated sandbox environment (a separate customer environment
  per the amendment's "isolated customer environments" model, not a
  schema/table prefix within the same database).
- `applyFromSandbox` would let an admin selectively promote a subset of
  sandbox changes back to production, using `ImportExportService.import()`
  under the hood with `mode: 'merge'` and a filtered payload.
- Real work needed before this is implementable: provisioning a sandbox
  environment (infra, out of this module's scope), and a diff/review UI
  for "changes" (also out of scope here).

## Why a stub instead of skipping it entirely

The M3.9 prompt explicitly calls for "interface only" as a scope item,
distinct from scope cuts — this is intentional scaffolding, not a gap.

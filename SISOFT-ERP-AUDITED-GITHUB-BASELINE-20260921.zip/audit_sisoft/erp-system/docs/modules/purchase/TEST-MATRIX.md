# Procurement Verification Matrix

## Required end-to-end scenario

Vendor → contract → PR → approval → RFQ → supplier invitations → quotations → comparison → accepted quote → PO → independent approval → send → partial GRN → remaining GRN → invoice match → return → audit/document evidence.

## Negative cases

- missing tenant context
- wrong tenant record id
- inactive vendor
- duplicate vendor code
- duplicate document number under concurrency
- empty PR/RFQ/quote/PO/GRN/return lines
- zero or negative quantities
- negative price/tax/tolerance
- invalid state transition
- self approval (PR, contract, PO)
- direct approval-state transition bypass
- approval without pending entity
- expired quote acceptance
- expired RFQ/quote/PO dates
- duplicate receipt/return line quantity aggregation
- receipt above remaining quantity
- return above received-not-returned quantity
- return with insufficient stock
- invoice currency mismatch
- invoice above received/order tolerance
- document belonging to another tenant
- stale optimistic-lock version

## Evidence required for PASS

Each PASS must include:

1. test name
2. environment identifier
3. tenant identifier(s)
4. actor role(s)
5. request/input
6. response/result
7. database assertion
8. audit assertion
9. relevant generated document identifier
10. timestamp

A test file existing on disk is not evidence that the test passed.

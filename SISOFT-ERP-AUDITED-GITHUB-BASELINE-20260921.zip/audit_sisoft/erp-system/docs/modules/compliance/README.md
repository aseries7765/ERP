# Compliance module

Status: **partial**. See root MANIFEST.md for full detail.

Built: `BreachService` + `breach-timer.logic.ts` — the 72h GDPR breach
notification timer (Article 33/34), with 12 passing assertions covering
alert escalation (24h/48h/60h/72h-missed), duplicate-alert suppression,
and deadline-missed detection.

Not built: framework catalog service, control/assessment/evidence/
finding/incident services and controllers, compliance scoring wiring
(the scoring math itself lives in `@erp/compliance-engine` and is
tested there), dashboards.

# Finance / General Ledger

Finance provides tenant-isolated accounting primitives and controlled subledger bridges.

## Implemented stages
- Ledger accounts and hierarchy controls.
- Draft/posted/reversed journal entries with exact decimal balancing.
- Open fiscal-period enforcement and optimistic concurrency.
- Trial balance, account ledger, P&L and balance-sheet reporting.
- Customer invoice/payment and vendor bill/payment accounting bridges with idempotent source postings.
- Bank accounts, statement transaction import, transaction-to-journal matching, and bank reconciliation approval.

## Bank reconciliation model
A bank account is explicitly mapped to one asset GL account and one currency. Imported statement transactions are signed: positive values represent bank inflows and negative values represent bank outflows. Matching requires an exact amount/currency/direction match to a posted journal line.

A reconciliation records the statement ending balance and computes:
`openingBalance + imported transactions through statementDate = calculatedBalance`.
Approval is permitted only when the statement difference is zero and every transaction through the statement date is either matched or explicitly ignored. The implementation does not claim that an external bank feed is authoritative; imports remain tenant-owned accounting evidence.

## Security / integrity
- Every Finance model carries tenantId and participates in application tenant scoping.
- Finance tables participate in PostgreSQL RLS and updatedAt/version trigger registration.
- All money uses Prisma Decimal / NUMERIC(18,2), never floating point.
- Source posting keys are tenant-scoped and idempotent.
- Version checks protect mutable workflows from stale writes.

## Runtime verification
`scripts/verify-finance.sh` is the authoritative automated gate. It requires the repository dependencies, generated Prisma client, PostgreSQL, and Redis. If those prerequisites are unavailable, static checks may pass but runtime/production verification must remain unclaimed.


## Stage 7 — Tax configuration
- Persistent tenant-scoped tax rates with SALES/PURCHASE classification.
- Effective-date and activation controls.
- Tax accounts must be postable, unlocked liability GL accounts.
- Tax calculation uses Decimal arithmetic and half-up rounding to two decimals.
- Tax-rate deactivation uses optimistic concurrency.
- Tax configuration is isolated by tenant and registered for RLS/version triggers.

## Stage 10 — Period-End Controls

Added persistent journal templates, recurring journal schedules, and accrual recognition schedules. Recurring journals post balanced entries only into open fiscal periods and advance their next-run date under optimistic concurrency. Accruals split amounts using exact decimal arithmetic and post each scheduled recognition idempotently through a transaction.

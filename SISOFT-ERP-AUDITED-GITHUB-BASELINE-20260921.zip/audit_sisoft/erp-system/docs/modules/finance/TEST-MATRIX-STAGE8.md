# Finance Stage 8 Test Matrix

- [x] Budget model and migration present
- [x] Budget line amount non-negative validation
- [x] Revenue/expense account validation
- [x] Cost-center tenant validation
- [x] Duplicate account/cost-center/period rejection
- [x] Approved-budget uniqueness check
- [x] Draft -> Approved -> Locked lifecycle
- [x] Optimistic concurrency checks
- [x] Journal cost-center validation
- [x] Actuals restricted to posted journals
- [x] Budget variance period filtering
- [x] Tenant-scoped queries
- [x] RLS/trigger registration
- [ ] Runtime PostgreSQL integration execution (environment unavailable)

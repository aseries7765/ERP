# Finance Stage 8 — Budgeting & Cost Centers

Implemented persistent tenant-scoped budgets with fiscal-year association, monthly lines, optional cost-center allocation, approval/lock lifecycle, and actual-vs-budget variance reporting.

## Controls
- Budget lines are restricted to postable revenue/expense accounts.
- Amounts use Prisma Decimal and must be non-negative.
- Periods are 1–12 and duplicate account/cost-center/period lines are rejected.
- Approved budget uniqueness is enforced per tenant/fiscal year at the service layer.
- Journal lines may carry an optional tenant-validated cost center.
- Variance uses posted journals only and respects budget currency, fiscal year and requested period range.
- Optimistic version checks protect approval and locking.

Runtime/database verification is not claimed in environments without project dependencies and PostgreSQL.

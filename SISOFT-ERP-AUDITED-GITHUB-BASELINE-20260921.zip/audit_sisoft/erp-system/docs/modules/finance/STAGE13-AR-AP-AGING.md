# Finance Stage 13 — Accounts Receivable / Accounts Payable Aging

## Scope

Adds production-oriented outstanding receivables and payables aging reports without introducing a new persistence model.

### AR aging
- Uses tenant-scoped customer invoices.
- Includes issued, partially paid and overdue invoices only.
- Excludes zero/negative outstanding balances.
- Calculates outstanding balance as `total - amountPaid` using `Prisma.Decimal`.
- Supports an `asOf` date and optional 3-letter currency filter.
- Buckets balances into `CURRENT`, `1_30`, `31_60`, `61_90`, and `90_PLUS` based on due date.
- Returns invoice-level detail plus per-currency totals.

### AP aging
- Uses tenant-scoped posted vendor bills.
- Excludes zero/negative outstanding balances.
- Calculates outstanding balance as `total - amountPaid` using `Prisma.Decimal`.
- Supports an `asOf` date and optional 3-letter currency filter.
- Uses the same five aging buckets and returns bill-level detail plus per-currency totals.

## API

- `GET /v1/finance/reports/ar-aging?asOf=YYYY-MM-DD&currency=USD`
- `GET /v1/finance/reports/ap-aging?asOf=YYYY-MM-DD&currency=USD`

Both endpoints require `erp.finance.financial_report.read`.

## Integrity / tenancy

All reads are explicitly tenant-scoped. No cross-tenant customer, vendor, invoice, or bill records are queried. Monetary arithmetic remains decimal-based; no floating-point conversion is used.

## Verification limitation

Static/structural verification is performed in this workspace. Database-backed runtime verification requires the project's dependency installation and PostgreSQL environment, which are not currently available in the execution environment.

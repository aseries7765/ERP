# Finance Test Matrix

1. Create ledger accounts in two tenants and prove cross-tenant reads fail.
2. Reject duplicate account codes within one tenant.
3. Reject non-postable and locked accounts in journals.
4. Reject zero, negative, malformed and imprecise amounts.
5. Accept balanced multi-line decimal journals.
6. Reject unbalanced journals.
7. Reject posting in closed fiscal periods.
8. Reject posting of already-posted/reversed journals.
9. Reverse a posted journal and verify every debit/credit is swapped exactly.
10. Reject reversal from a stale version.
11. Reject period close while draft journals remain in the period.
12. Permit close after all period journals are posted.
13. Verify concurrent post/lock/close attempts allow only one successful version transition.
14. Verify audit events are emitted to the real BullMQ audit queue.

| GL reporting | Trial balance | Posted entries only; currency isolated; debit/credit totals reconcile | Static implementation + runtime DB test required |
| GL reporting | Account ledger | Posted entries only; currency/date filters; running balance | Static implementation + runtime DB test required |
| Concurrency | Journal numbering | Optimistic sequence allocation inside transaction; collision retry | Runtime concurrency test required |
| Atomicity | Reversal | Reversal creation/posting and original marking occur in one transaction | Runtime rollback/concurrency test required |
| Security | Finance RLS | Finance tables included in global tenant RLS/trigger table list | Static + runtime RLS test required |

## Reporting hardening
- Financial-statements report is currency-scoped and date-window validated.
- P&L derives revenue less expense from posted journal lines only.
- Balance-sheet equation is explicitly checked and returned as `balanced`.
- Account hierarchy rejects postable parents and mismatched account types.


## AR integration
15. Configure a tenant posting profile only with accounts of the required GL types.
16. Reject locked/non-postable posting accounts.
17. Post an issued customer invoice as AR debit + revenue/tax credits using exact decimals.
18. Post a customer payment as cash/bank debit + AR credit.
19. Reject invoice/payment currency mismatch.
20. Repeated source posting returns the original journal and never creates a duplicate.
21. Concurrent source posting is protected by the tenant/source unique constraint and transaction.
22. Reject source posting when its date falls in a closed fiscal period.
23. Verify source posting records and journals remain tenant isolated under RLS.

Runtime status: these cases require PostgreSQL/Prisma/BullMQ dependencies and are not claimed as runtime PASS in the current offline workspace.


## AP / Vendor accounting bridge
24. Create a vendor bill only for an active tenant vendor and reject duplicate bill numbers.
25. Reject vendor-bill totals that are negative, zero, tax-inconsistent, or exceed a linked purchase order.
26. Require vendor bill approval before ledger posting.
27. Post an approved vendor bill as expense + input-tax debits against accounts-payable credit.
28. Verify vendor-bill status transition and its source posting are atomic under concurrency/failure.
29. Create vendor payments only against posted bills and reject payments above the outstanding balance.
30. Post vendor payment as accounts-payable debit + cash/bank credit using exact decimals.
31. Verify vendor payment creation, ledger posting, and bill amountPaid update are one transaction.
32. Reject vendor payment currency mismatch and closed-period posting.
33. Verify concurrent payments cannot overpay a vendor bill through optimistic versioning.
34. Verify AP source postings are tenant isolated and idempotent.

## Bank accounts / reconciliation
35. Create bank accounts only against active, postable asset GL accounts.
36. Reject duplicate bank account names within a tenant and invalid currencies/opening balances.
37. Import bank transactions with exact decimal amounts and reject zero amounts, duplicate external IDs, and currency mismatch.
38. List bank transactions by tenant/account/date/status without cross-tenant leakage.
39. Create one reconciliation per bank account and statement date and calculate opening balance plus imported transactions.
40. Match a bank transaction only to a posted journal line of the same currency, exact absolute amount, correct debit/credit direction, and valid journal date.
41. Prevent one journal line from being matched to multiple bank transactions.
42. Reject stale transaction/reconciliation versions during matching or ignoring.
43. Require all statement-period transactions to be matched or explicitly ignored before reconciliation approval.
44. Require reconciliation difference to be zero before approval.
45. Verify bank-account, transaction, and reconciliation RLS/tenant-scoping under PostgreSQL.
46. Verify concurrent imports/matches/approvals do not create duplicate external IDs or double matches.


### Tax configuration
- Create valid sales/purchase tax rate
- Reject rates outside 0..100
- Reject invalid effective date ranges
- Reject non-liability/non-postable/locked tax accounts
- Reject duplicate tax codes
- Filter rates by effective date and active state
- Deactivate with optimistic version check
- Calculate tax with Decimal half-up rounding
- Reject tax calculation outside effective period
- Tenant isolation for tax-rate reads/writes

### Stage 10
- Journal template requires balanced positive lines and postable/unlocked accounts.
- Recurring journal accepts only MONTHLY/QUARTERLY/YEARLY schedules, validates open fiscal periods, and protects schedule updates with version checks.
- Recurring journal posting allocates the journal number and posted journal atomically.
- Accrual schedules use decimal rounding with the final recognition absorbing rounding residual.
- Accrual recognition requires an open fiscal period and uses optimistic concurrency to prevent duplicate posting.
- Tenant scoping/RLS registration covers all Stage 10 models.

# Finance Stage 9 — Fixed Assets & Depreciation

## Scope
Persistent fixed-asset register, acquisition capitalization, straight-line depreciation schedules, depreciation posting, and disposal accounting.

## Controls
- Tenant isolation and RLS apply to both fixed-asset tables.
- Asset numbers are unique per tenant.
- Acquisition cost must be positive; salvage value cannot exceed cost.
- Useful life is bounded to 1–1200 months.
- Only `STRAIGHT_LINE` depreciation is currently supported.
- Asset activation requires an open fiscal period and configured posting accounts.
- Depreciation can only be posted once per schedule row and requires an open fiscal period.
- Disposal is only allowed for active/fully-depreciated assets and uses accumulated depreciation removal plus gain/loss accounting.
- Optimistic version checks protect asset and schedule transitions.
- Source posting uniqueness makes acquisition/depreciation/disposal journal creation idempotent.

## Depreciation convention
The current implementation schedules equal monthly depreciation over the useful life, rounded to two decimals, with the final month adjusted so the carrying value reaches the configured salvage value exactly. The first schedule period is the calendar month containing the placed-in-service date.

## Required posting profile
- fixed asset (asset)
- depreciation expense (expense)
- accumulated depreciation (asset; credit-normal contra-asset)
- disposal gain/loss (revenue account used as the balancing gain/loss account)
- existing cash/bank account

Runtime database tests remain required before production sign-off.

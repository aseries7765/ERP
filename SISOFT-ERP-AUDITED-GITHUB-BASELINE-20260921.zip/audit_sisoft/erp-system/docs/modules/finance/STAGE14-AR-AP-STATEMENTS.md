# Finance Stage 14 — AR/AP Customer & Vendor Statements

## Scope
Adds tenant-scoped transaction statements for customer receivables and vendor payables, using existing invoice/payment and vendor-bill/payment records. No new persistence model is required.

### AR statement
- Customer is an existing `Account` with `type=customer`.
- Includes issued/partially-paid/overdue/paid invoices and linked payments.
- Supports `from`, `to`, and optional currency filters.
- Provides opening balance, dated debit/credit transactions, running balance, and closing balance per currency.
- Uses `Prisma.Decimal` for all monetary arithmetic.

### AP statement
- Vendor is tenant-scoped.
- Includes posted vendor bills and linked vendor payments.
- Supports `from`, `to`, and optional currency filters.
- Provides opening balance, dated debit/credit transactions, running balance, and closing balance per currency.
- Uses `Prisma.Decimal` for all monetary arithmetic.

## API
- `GET /v1/finance/reports/ar-statements/:accountId?from=YYYY-MM-DD&to=YYYY-MM-DD&currency=USD`
- `GET /v1/finance/reports/ap-statements/:vendorId?from=YYYY-MM-DD&to=YYYY-MM-DD&currency=USD`

Both endpoints require `erp.finance.financial_report.read`.

## Integrity / tenancy
All source records are explicitly tenant-scoped. Customer statements reject non-customer CRM accounts. Vendor statements only read the requested tenant's vendor and bills/payments. No floating-point conversion is used for monetary balances.

## Verification limitation
Static/structural verification is used in this workspace. Full database-backed runtime verification requires dependency installation and PostgreSQL, which are not currently available in the execution environment.

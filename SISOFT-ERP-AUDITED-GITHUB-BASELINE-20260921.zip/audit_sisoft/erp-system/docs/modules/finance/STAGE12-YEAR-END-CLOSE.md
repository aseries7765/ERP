# Finance Stage 12 — Fiscal Year-End Close

## Scope
Adds controlled fiscal-year close with retained-earnings transfer for each currency.

## Controls
- Tenant and fiscal-year isolation.
- Only the final fiscal period may remain open.
- Earlier periods must already be closed.
- Draft journals inside the fiscal year/currency block closing.
- Retained earnings must be an unlocked, postable equity GL account.
- Only posted revenue/expense journals are included.
- Closing journal is balanced and posted atomically with the close record and final-period close.
- Unique tenant + fiscal year + currency prevents duplicate year-end close.
- Optimistic version check protects the final fiscal period against concurrent modification.

## Accounting
Revenue balances are debited to zero and expense balances are credited to zero. The resulting net income/loss is transferred to retained earnings. The resulting closing journal therefore has zero net revenue/expense balances while preserving the accounting equation.

## Runtime status
Static verification only in the current environment. Runtime database verification requires project dependencies, generated Prisma client, PostgreSQL and Redis.

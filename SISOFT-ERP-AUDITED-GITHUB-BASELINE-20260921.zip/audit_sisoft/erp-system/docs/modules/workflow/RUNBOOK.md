# Runbook

**Stuck instance (status=waiting, no task visible)**: check
`workflow_instance.waitingSignal` — if it's `timer:*`, confirm
`WorkflowWorker`'s cron is running; if `approval:*`, confirm a
`workflow_tasks` row exists for that step (a bug in
`TaskService.createApprovalTask` not persisting could leave an instance
waiting forever with no task — flagged in MANIFEST.md since that method
currently only logs, pending Prisma wiring).

**Escalation not firing**: `EscalationJob` runs every 5 minutes
(`ESCALATION_CRON`); `EscalationService.runEscalationSweep()` is a stub
pending Prisma wiring (MANIFEST.md) — currently a no-op.

**Switching to Temporal**: set `TEMPORAL_ADDRESS`; read EXECUTOR.md
first — the adapter is unverified against a real Temporal server.

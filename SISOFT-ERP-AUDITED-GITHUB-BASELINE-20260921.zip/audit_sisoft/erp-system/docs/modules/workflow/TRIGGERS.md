# Triggers

Four trigger types: `event`, `schedule`, `manual`, `webhook`, plus a
`condition` gate that can accompany any of them.

- **Event**: `TriggerService` (services/trigger.service.ts) subscribes
  to a wildcard EventEmitter2 topic covering every module listed in the
  spec (`auth.*`, `tenancy.*`, `rbac.*`, `employee.*`, `audit.*`,
  `terminology.*`, `notifications.*`, `documents.*`, `settings.*`, and
  any future module that emits through the same emitter), matches
  against the `workflow_triggers` table, evaluates the optional CEL
  `condition`, and starts an instance per match.
- **Schedule**: `jobs/trigger-scheduler.job.ts`, cron-string evaluation
  — documented gap, see MANIFEST.md (no cron-parsing package was
  installable offline).
- **Manual**: `POST /v1/workflow-instances` from the UI.
- **Webhook**: external systems POST to a to-be-defined inbound
  endpoint that maps to a `webhook`-type trigger; not yet built (scope
  cut, see MANIFEST.md).

# Visual designer

`apps/web/src/components/workflow-designer/WorkflowDesigner.tsx` is an
SVG canvas (not a graph library — see the HONESTY NOTE in that file)
with a node palette, per-type node renderers, a properties panel, and a
live validation banner powered by the same `validateDefinition` the API
uses at publish time — so what the designer says is "valid" matches
what the server will accept.

The Test panel calls `POST /v1/workflows/:id/test` and renders the
dry-run trace inline, so non-developers can sanity-check a workflow
before publishing (spec requirement: "usable by non-developers").

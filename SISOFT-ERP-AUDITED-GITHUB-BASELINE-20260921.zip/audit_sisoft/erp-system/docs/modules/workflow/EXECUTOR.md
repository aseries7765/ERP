# Executor: Temporal vs in-process

`engine/engine.interface.ts` is the seam. `workflow.module.ts` binds
`WORKFLOW_ENGINE` to `TemporalEngine` when `TEMPORAL_ADDRESS` is set,
else `InProcessEngine`.

**As delivered, `InProcessEngine` is the only one that can actually
run** (Temporal SDK wasn't installable offline — see
`engine/temporal.engine.ts`'s honesty note and MANIFEST.md). Both share
the exact same step-dispatch logic (`@erp/workflow-engine`'s
`runToNextPause`), so migrating to Temporal later means wrapping that
same function in Temporal activities/workflow functions, not rewriting
step semantics.

Durability (G17 — survives API restart): `InProcessEngine` persists
`InstanceState` (plain JSON) after every `runToNextPause` call via
`WorkflowInstanceRepository`. There is no in-memory-only state; a
restarted process just reads the row and calls `runToNextPause` again.
This exact rehydrate-and-resume path is unit-tested in
`executor.spec.ts`'s "instance survives a restart" case (with a
JSON-round-trip in between to simulate the DB boundary).

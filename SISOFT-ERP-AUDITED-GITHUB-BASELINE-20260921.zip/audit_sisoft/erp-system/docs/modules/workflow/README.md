# M3.10 — Workflow Automation

Versioned, multi-tenant workflow definitions with event/schedule/manual/
webhook/condition triggers, human approval/input/review tasks with SLA +
escalation, sandboxed script actions, a visual BPMN-subset designer, and
dry-run test mode. See the sibling docs for each area:

- [BPMN.md](./BPMN.md) — the BPMN 2.0 subset actually supported
- [DESIGNER.md](./DESIGNER.md) — visual editor guide
- [TRIGGERS.md](./TRIGGERS.md) — event/schedule/manual/webhook/condition
- [STEPS.md](./STEPS.md) — approval/condition/action/wait/parallel/sub-workflow
- [ACTIONS.md](./ACTIONS.md) — email/webhook/script/db-update
- [TASKS.md](./TASKS.md) — human tasks, SLA, escalation, delegation
- [EXECUTOR.md](./EXECUTOR.md) — Temporal vs in-process, and how to swap
- [VERSIONING.md](./VERSIONING.md) — immutable versions
- [TEST_MODE.md](./TEST_MODE.md) — dry-run
- [SECURITY.md](./SECURITY.md) — script sandbox, secrets
- [RUNBOOK.md](./RUNBOOK.md) — operating this module

**Read MANIFEST.md at the zip root first** — it's the honest account of
what's built, what's verified, and what's a documented gap.

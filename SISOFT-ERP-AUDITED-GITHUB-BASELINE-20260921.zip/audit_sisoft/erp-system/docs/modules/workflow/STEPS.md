# Steps

| Type | Pauses execution? | Handled by |
|---|---|---|
| start | no | runtime/executor.ts |
| condition | no | runtime/executor.ts + conditions/cel-evaluator.ts |
| approval | yes — until `approval:<stepId>` signal | task.service.ts creates the task |
| action | no | services/action.service.ts dispatches the real side effect |
| wait | yes — until timer or explicit signal | task.service.ts schedules the timer |
| parallel | yes — fork bookkeeping only, see BPMN.md | runtime/executor.ts |
| sub-workflow | yes — until child instance completes | workflow-instance.repository.ts |
| end | terminal | runtime/executor.ts |

All step-dispatch logic lives in the dependency-free
`@erp/workflow-engine` package and is unit-tested in
`packages/workflow-engine/src/__tests__/executor.spec.ts` (all paths
including approval pause → signal resume → restart-survival).

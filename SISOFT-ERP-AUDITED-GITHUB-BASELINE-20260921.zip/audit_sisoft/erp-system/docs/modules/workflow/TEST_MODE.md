# Test mode (dry-run)

`POST /v1/workflows/:id/test` calls `@erp/workflow-engine`'s `dryRun()`
directly — no transaction-and-rollback trick, because nothing is
written or dispatched in the first place: action steps are recorded
into a `simulatedActions` list instead of calling `ActionService`, and
approval/wait/sub-workflow pauses auto-follow their "happy path" edge
so a full representative trace comes back in one call. Verified in
`packages/workflow-engine/src/__tests__/parser-and-dryrun.spec.ts`.

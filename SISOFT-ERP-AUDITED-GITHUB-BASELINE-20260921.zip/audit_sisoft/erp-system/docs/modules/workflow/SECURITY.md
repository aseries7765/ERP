# Security

**Script actions MUST run in `isolated-vm`** (true V8 isolates), never
Node's built-in `vm` module (shares the host V8 heap — not a security
boundary) and never `eval()`/`new Function()`. `isolated-vm` could not
be installed in the build sandbox (no network access), so
`action.service.ts#script` throws rather than shipping an insecure
fallback — see ADR-0049 and MANIFEST.md. Requirements once wired: no
`require`/`import`, no ambient globals, no filesystem, no network,
100ms timeout (`SCRIPT_ACTION_TIMEOUT_MS`).

Webhook secrets and API keys are expected to come from M3.9's encrypted
settings store, never inlined in a trigger/action config; webhook
payloads are HMAC-signed (`action.service.ts#webhook`).

Workflow definition mutations (`create`/`update`/`publish`/`archive`,
trigger CRUD) require `workflow:admin` (`WorkflowAdminGuard`) and are
expected to flow through M3.5's audit pipeline like every other
mutation in this system.

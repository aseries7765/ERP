# Versioning

Publishing validates the draft graph (`bpmn-validator.service.ts`) and
inserts an immutable `WorkflowVersion` row — never updates one. Running
instances store their own `version` at start time and always execute
against that exact `WorkflowVersion.graphJson`; new triggers resolve to
`MAX(version) WHERE status = PUBLISHED`. See G18 in the spec and
EXECUTOR.md's restart-survival note, which is the same mechanism that
makes version-pinning safe.

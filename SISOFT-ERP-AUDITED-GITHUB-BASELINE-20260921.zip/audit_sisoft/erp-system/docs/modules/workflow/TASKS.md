# Human tasks

Approval tasks are created per-assignee when an `approval` step is
entered (`task.service.ts#createApprovalTask`), with an optional SLA
(ISO 8601 duration, e.g. `PT24H`) computing a `dueAt`. Completing a task
signals the workflow via `approval:<stepId>`. Delegation re-points
`assigneeUserId` but defers eligibility to RBAC (M3.3) — this module
does not decide who's allowed to cover for whom.

Input and Review task types are modeled in the Prisma schema
(`WorkflowTaskType`) but only Approval's full lifecycle is wired end to
end in this delivery — Input's `formSchemaId` linkage to M3.9 form
schemas is a documented gap (MANIFEST.md).

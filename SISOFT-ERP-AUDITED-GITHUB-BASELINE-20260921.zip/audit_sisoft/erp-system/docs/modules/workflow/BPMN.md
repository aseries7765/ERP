# BPMN subset

Workflows are authored as simplified BPMN-inspired JSON, not literal
BPMN 2.0 XML — see the worked example in the M3.10 spec (PO approval)
and `packages/workflow-engine/src/types.ts` for the canonical shape.

Supported step types: `start`, `condition`, `approval`, `action`,
`wait`, `parallel`, `sub-workflow`, `end`. Each definition must have
exactly one `start`, at least one `end` reachable from it, and no cycle
made entirely of non-yielding steps (`start`/`condition`/`action`) — see
`packages/workflow-engine/src/definition/validator.ts`, unit-tested in
`validator.spec.ts`.

`parallel.branches` fork execution; `parallel.join` is where all
branches reconnect. The pure engine package records fork/join
bookkeeping (`InstanceState.parallelJoins`); actually running branches
concurrently is the host engine's job (see EXECUTOR.md) — this is a
known simplification, not a full implementation (MANIFEST.md).

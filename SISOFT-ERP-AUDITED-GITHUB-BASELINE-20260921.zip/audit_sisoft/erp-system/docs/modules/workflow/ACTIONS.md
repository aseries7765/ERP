# Actions

`email`, `webhook`, `db-update`, `notification`, `field-update` are
implemented (with the DB/email/webhook call sites commented out pending
real Prisma/M3.7 wiring — see services/action.service.ts). `script` is
intentionally left throwing rather than falling back to an insecure
sandbox — see SECURITY.md.

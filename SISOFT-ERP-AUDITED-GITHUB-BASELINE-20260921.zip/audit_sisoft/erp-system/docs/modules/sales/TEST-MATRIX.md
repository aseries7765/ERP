# Sales Verification Matrix

1. Create quote with two products and verify exact decimal subtotal/tax/total.
2. Reject duplicate quote product lines.
3. Verify invalid quote transitions fail.
4. Verify expired quote cannot be accepted.
5. Convert accepted quote exactly once.
6. Verify tenant A cannot read tenant B quote/order/line.
7. Confirm stock order reserves available quantity atomically.
8. Reject confirmation when available stock is insufficient.
9. Fulfill partially and verify fulfilledQty, quantity and reserved quantity.
10. Reject fulfillment above remaining quantity.
11. Require full fulfillment before order becomes fulfilled.
12. Verify cancellation releases reservations.
13. Require linked invoice before invoiced state.
14. Run concurrent confirmations/fulfillments and verify no over-reservation or negative stock.

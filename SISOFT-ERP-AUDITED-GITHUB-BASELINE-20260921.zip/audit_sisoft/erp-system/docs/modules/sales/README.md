# Sales Module

The Sales module implements quote-to-order processing with tenant isolation and inventory reservation/fulfillment integration.

## Lifecycle
- Quote: draft -> sent -> accepted/rejected/expired/cancelled
- Sales order: draft -> confirmed -> fulfilled -> invoiced, or cancelled

## Invariants
- Quote/order lines are persistent and tenant scoped.
- Decimal arithmetic is used for quantities and money.
- Quotes cannot be accepted after validity expiry.
- An accepted quote converts only once.
- Stock orders require a warehouse in `SalesOrder.metadata.warehouseId`.
- Confirmation reserves available stock; fulfillment consumes stock and releases the reservation.
- Fulfillment cannot exceed ordered quantity.
- Invoiced status requires an invoice whose metadata contains the sales order id.

# Payroll Module — Implementation Status (2026-09-17)

## Implemented in this pass
- Persistent payroll runs and payslips with line-level records.
- Tenant-scoped salary components and effective-dated employee salary structures.
- Persistent employee loans and salary advances with deterministic repayment schedules.
- Payroll run lifecycle: draft -> review -> approved -> processing -> completed -> locked.
- Period-lock detection and unlock recording.
- Country-plugin payroll calculation remains the source of tax/statutory calculations.
- Statutory report generation persists a filing record.
- Bank-file generation reads employee payroll banking metadata and validates through the bank formatter.
- Management trend reports from persisted completed/locked runs.
- Year-end aggregation from persisted payslips.
- Employee self-service payslip listing/detail.
- Tenant-scoping and DB trigger registration for all new payroll tables.

## Verification
Static TypeScript transpilation and schema/migration structural checks pass.
Runtime PASS is **not claimed** until PostgreSQL, Prisma generation, Redis, RLS, Jest/E2E, concurrency and backup/restore gates are executed in a real runtime environment.

## Known boundaries
- Actual bank API submission is intentionally manual-download only; no external bank API is fabricated.
- Country tax/statutory numeric tables require official-source review for the applicable tax year before live payroll.
- Employee bank details are expected in the employee metadata `bank` object until a dedicated banking-master module is implemented.
- PDF rendering is represented as structured payslip data until the Documents/PDF subsystem is production-integrated.

# Payroll Verification Matrix

1. Create employee + effective salary structure.
2. Create a payroll run for the employee's company and period.
3. Verify one persisted payslip and exact line totals.
4. Attempt duplicate run for the same tenant/company/period; must fail.
5. Move run draft -> review -> approved -> processing -> completed -> locked.
6. Attempt illegal state skips; must fail.
7. Lock period and verify a new run is rejected.
8. Generate a bank file only after approval; missing bank metadata must fail closed.
9. Generate statutory report through the selected country plugin and verify filing record.
10. Verify employee can retrieve only their own payslips.
11. Verify cross-tenant run/payslip access returns no record.
12. Run concurrent run creation and verify unique period constraint prevents duplicates.
13. Run Prisma migration + generation + Jest + E2E against PostgreSQL/Redis.

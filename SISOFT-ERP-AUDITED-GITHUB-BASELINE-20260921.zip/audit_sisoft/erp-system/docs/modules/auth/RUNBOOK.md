# Auth runbook

## Rotate the JWT signing key

Because access tokens are stateless and verified only against
`JWT_PUBLIC_KEY`, rotating the keypair invalidates every currently-issued
access token immediately (they'll fail signature verification against the
new public key) — but does NOT invalidate refresh tokens, which aren't
JWTs at all (they're opaque, hashed, DB-backed).

1. Generate a new keypair (see README.md's env setup section).
2. Deploy with the new `JWT_PRIVATE_KEY`/`JWT_PUBLIC_KEY`.
3. Every active user's access token now fails verification on their next
   request — they'll get a 401 and their client should transparently call
   `/v1/auth/refresh`, which succeeds (refresh tokens are unaffected) and
   issues a new access token signed with the new key.
4. No user is actually logged out by this — worst case is one failed
   request that the client's refresh-and-retry logic should absorb
   silently. Confirm your frontend actually has that retry logic before
   relying on this being invisible to users.

There is no key-versioning/JWKS-rotation-without-a-blip mechanism in this
slice (e.g. accepting either of two public keys during a transition
window) — a single active keypair is the current design. Add JWKS-style
multi-key support if zero-blip rotation becomes a real requirement.

## Revoke all sessions for a user (e.g. suspected account compromise)

Via the API (as the user, or as a future admin-impersonation flow once
that exists): `DELETE /v1/auth/sessions` while authenticated as that user.

Directly via the service layer (e.g. from a support/admin tool):
```ts
await sessionService.revokeAll(tenantId, userId, undefined, 'admin_security_action');
await tokenService.revokeAllForUser(tenantId, userId);
```
Both calls are needed — the first stops the session being usable for new
requests, the second stops any already-issued refresh token in any family
for that user from minting new access tokens.

Consider also: forcing a password reset (`passwordResetService.request`
generates a token, but doesn't force-invalidate the current password by
itself — the user must complete the reset flow) and checking
`MfaTotpService.hasMfaEnabled` to recommend the user enable MFA if they
haven't.

## Rotate a compromised API key

There is no "rotate in place" — API keys are create/revoke only, by
design (a rotated-in-place key would need the old plaintext to still
exist somewhere to swap it out safely, which defeats hashing it):

1. `POST /v1/auth/apikeys` with the same name/scopes to create a
   replacement — get the new plaintext key.
2. Update whatever system was using the old key.
3. `DELETE /v1/auth/apikeys/:id` on the old key's id once the new one is
   confirmed working.

## Debugging a login failure report

1. Check `LoginAttempt` rows for the user's email in the relevant tenant
   — this tells you whether the failure was `FAILURE_BAD_PASSWORD`,
   `FAILURE_MFA`, `FAILURE_UNKNOWN_USER`, or `FAILURE_LOCKED`, which
   narrows the cause immediately without needing to reproduce anything.
2. If `FAILURE_UNKNOWN_USER` repeatedly: confirm the user's account
   actually exists in the tenant they think they're logging into —
   `x-tenant-id` mismatches (wrong subdomain, stale client config) are a
   common real-world cause once this header is wired to something
   client-visible.
3. If lockout is suspected: `loginAttemptService.isLocked(tenantId,
   email)` directly, or query `LoginAttempt` for recent failure counts
   against the thresholds in `auth.constants.ts`'s `LOCKOUT_TIERS`.
4. If MFA-related: confirm `MfaMethod` has a row with
   `type=TOTP, verifiedAt IS NOT NULL` for the user — an enrollment that
   was started but never confirmed (`confirmEnrollment`) leaves
   `verifiedAt` null and `hasMfaEnabled()` correctly reports `false`,
   which can look like "MFA should be required but isn't" if you're only
   checking for the row's existence rather than its `verifiedAt`.

## Rotating the symmetric ENCRYPTION_KEY

**Not supported as a live operation in this slice.** Every stored TOTP
secret is encrypted with the currently-configured key; changing the key
without a migration makes every existing secret undecryptable (every
user with MFA enabled would be locked out). If this is ever needed:

1. Write a one-off migration script that decrypts every `MfaMethod` row
   with type `TOTP` using the OLD key and re-encrypts with the NEW key,
   in a single transaction per row (never leave a row half-migrated).
2. Deploy the new key only after that migration has run successfully
   against production data.

This is deliberately not automated in this slice — see
`SymmetricEncryptionService`'s doc comment for the same note.

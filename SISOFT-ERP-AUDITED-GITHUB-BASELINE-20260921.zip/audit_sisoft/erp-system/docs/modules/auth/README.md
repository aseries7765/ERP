# Auth & Identity (M3 Slice 3.1)

## What this module does

Registration, login, JWT issuance + refresh rotation, sessions, devices,
TOTP + WebAuthn MFA, password reset, email verification, and API keys —
the full list in the M3.1 spec. What it does NOT do: authorization/RBAC
(Slice 3.3), SSO/OIDC (a future slice — see "Out of scope" below),
sending actual emails (Notifications, Slice 3.7), or writing audit rows
to the database (it enqueues them; Slice 3.5 adds the consumer).

## Environment setup

Copy the auth-related block from `.env.example` — it already contains a
real, generated dev RSA keypair and a real 32-byte encryption key, so
`docker compose up` works with zero extra steps locally. For anything
beyond local dev:

```bash
# JWT signing key (RS256 — see ADR 0008)
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out private.pem
openssl rsa -pubout -in private.pem -out public.pem

# Symmetric key for encrypting TOTP secrets at rest
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

`auth.config.ts` validates every required variable at boot (zod) and
additionally requires `WEBAUTHN_RP_ID`/`WEBAUTHN_ORIGIN` when
`NODE_ENV=production` — a misconfigured production deploy fails at
startup, not at the first login attempt.

## Tenant resolution before login

This is the one real architectural wrinkle worth understanding up front.
`register`/`login`/`forgot-password`/`reset-password`/`verify-email` all
run before any JWT exists, so they can't use `TenantGuard` (which reads a
verified JWT claim). They currently read `x-tenant-id` from a request
header — the same interim, spoofable mechanism `TenantContextMiddleware`
introduced in M2. This is a real, carried-over limitation, not something
this slice fixes: a production deployment needs a real tenant-resolution
story (subdomain routing, e.g. `acme.erp.example.com`, or an explicit
"select your organization" step in the client) before this header can be
trusted. Once a route sits behind `JwtAuthGuard` + `TenantGuard`, tenant
comes from a cryptographically verified claim instead.

Everywhere an opaque token (refresh token, password-reset token, email-
verification token, API key) needs to resolve which tenant it belongs to
before any context can be set, the relevant service uses
`PrismaService.withBypassRls()` with a comment explaining why — this is
the same narrow, logged exception pattern established in M2's RLS design,
never a blanket bypass.

## Known simplifications (real, not silently glossed over)

- **Refresh tokens are linked to a session via `RefreshToken.sessionId`**
  (added this slice — see `schema.prisma`'s comment), so a rotated token
  correctly carries the original session id into its new access token.
- **Logging out revokes the session and refresh-token family, not the
  still-live access token.** JWTs are stateless; a short access-token TTL
  (15 min default) bounds the exposure window. This is standard JWT
  practice, not an oversight — a token-blocklist would defeat the point
  of using stateless JWTs at all and is out of scope here.
- **`roles: []` on every issued token.** RBAC's service layer (Slice 3.3)
  doesn't exist yet — nothing in this slice makes an authorization
  decision based on this array, so an empty array is an honest "not
  wired up," not a silent security gap.
- **Password reset / email verification don't send real emails.** Both
  services stop at "the token exists in the database" — actual delivery
  is Notifications (Slice 3.7).
- **WebAuthn login options/verify take `:tenantId/:userId` as route
  params**, resolved by an earlier "who are you" step in the real client
  flow (typically: submit an email, get back a user handle). No
  standalone "look up my WebAuthn credentials by email" endpoint exists
  in this slice.

## Audit events

Every mutating auth action enqueues a job onto the `audit` BullMQ queue
(`AuditQueueService`) rather than writing to `audit_events` directly —
per this slice's explicit instruction, the consumer that drains this
queue and performs the actual hash-chained insert belongs to Slice 3.5.
Until that consumer exists, jobs accumulate in Redis rather than being
lost — `removeOnFail: false` keeps failed jobs visible for investigation,
and `attempts: 5` with exponential backoff means a transient Redis blip
doesn't silently drop an event.

## Rate limits

Enforced via `@nestjs/throttler`, per `AUTH_THROTTLE` in
`auth.constants.ts`: login 10/15min, register 5/hour, forgot-password
3/hour, refresh 60/hour, MFA verify 10/15min, everything else 100/min.

## Error shape

Every service throws a typed `AuthError` subclass
(`errors/auth.errors.ts`); `AuthErrorFilter` is the single place that
translates one into an HTTP response: `{ error: { code, message } }`.
Success responses are `{ data: ... }`. A frontend should branch on
`error.code` (e.g. `AUTH_MFA_REQUIRED`), not on `message` text.

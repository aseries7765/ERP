# Token lifecycle

## Login

```
Client                          API                              DB / Redis
  |--- POST /login (email,pw) -->|
  |                               |-- isLocked(tenant,email)? ----> LoginAttempt (count)
  |                               |<---------------- locked:false--|
  |                               |-- find User by email --------->|
  |                               |<---------------- User ---------|
  |                               |-- argon2.verify(hash, pw) ------ (in-process)
  |                               |-- hasMfaEnabled? --------------> MfaMethod (count)
  |                               |   (if true and no mfaCode: 401 AUTH_MFA_REQUIRED, stop here)
  |                               |-- record(SUCCESS) -------------> LoginAttempt (insert)
  |                               |-- upsert Device by fingerprint -> Device
  |                               |-- create Session --------------> Session
  |                               |-- issueTokens() ---------------> RefreshToken (insert, familyId=new)
  |                               |-- sign accessToken (RS256) ----- (in-process)
  |                               |-- enqueue user.login audit -----> Redis (BullMQ)
  |<-- 200 {accessToken, --------|
  |     refreshToken, sessionId} |
```

## Using the access token

```
Client                          API
  |-- GET /me, Authorization: Bearer <accessToken> -->|
  |                               |-- JwtAuthGuard: verify RS256 sig, exp, iss, aud (in-process, no DB)
  |                               |-- TenantGuard: enterWith({tenantId, userId}) from JWT claims
  |                               |-- handler runs with tenant context set
  |<-- 200 {user, tenantId, roles} -|
```

Note: validating an access token touches NO database — this is the point
of a stateless JWT. Revoking a *session* does not retroactively invalidate
already-issued access tokens; only refresh (which needs a live token) is
affected before the access token's own `exp` arrives.

## Refresh rotation (normal case)

```
Client                          API                              DB
  |-- POST /refresh {refreshToken} -->|
  |                               |-- hash(token), find by hash --------> RefreshToken (findUnique)
  |                               |<----------------- row (revokedAt=null, not expired) --|
  |                               |-- mark OLD row revoked -------------> RefreshToken (update)
  |                               |-- create NEW row, same familyId ----> RefreshToken (insert)
  |                               |-- sign new accessToken (in-process)
  |<-- 200 {accessToken, refreshToken (NEW)} --|
```

## Refresh reuse detection (attack / bug scenario)

```
Attacker (or a buggy client retrying) presents an ALREADY-ROTATED token:

Client                          API                              DB
  |-- POST /refresh {oldToken} -->|
  |                               |-- find by hash ---------------------> RefreshToken (findUnique)
  |                               |<----------------- row (revokedAt IS SET) --|
  |                               |-- revoke ENTIRE family -------------> RefreshToken (updateMany)
  |                               |-- enqueue auth.token.reuse_detected -> Redis (BullMQ, ACCESS_DENIED)
  |<-- 401 AUTH_REFRESH_REUSE_DETECTED --|

Every other refresh token in the same family (i.e. every session that
descended from the same original login) is now also revoked — the next
refresh attempt from a LEGITIMATE session in that family will also fail,
forcing a fresh login. This is intentional: once reuse is detected, the
whole family is considered compromised, not just the specific token
presented.
```

## Logout / logout-all

```
logout:      revoke ONE session (Session.revokedAt) — refresh tokens tied
             to that session's family become unusable next time they're
             presented (still cryptographically "valid" until then, since
             nothing forces an immediate check).

logout-all:  revoke every session except (optionally) the current one,
             AND explicitly call tokens.revokeAllForUser() to revoke every
             refresh-token family for the user immediately, not just on
             next-use — this is the difference between the two calls.
```

## Password change / reset

```
Both change-password (authenticated) and reset-password (via emailed
token) end the same way:
  1. new password hashed (argon2id) and stored
  2. sessions.revokeAll(tenantId, userId, exceptCurrentSessionId?)
  3. tokens.revokeAllForUser(tenantId, userId)

change-password excludes the CURRENT session (the user stays logged in
where they are); reset-password has no "current session" (it's
unauthenticated by definition) so it revokes everything.
```

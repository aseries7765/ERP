# Threat model (STRIDE)

Scope: the endpoints and services in this slice. Business-logic threats
in modules that don't exist yet (RBAC authorization decisions, etc.) are
out of scope here by definition.

## POST /v1/auth/register

| Threat | Mitigation |
|---|---|
| **S**poofing — register as someone else's email | Email ownership is only *claimed* here, not proven — `EmailVerifyService` proves it separately. A registered-but-unverified account should be treated as untrusted by anything that checks `emailVerifiedAt`. |
| **T**ampering — n/a (create-only) | — |
| **R**epudiation | Audit event `user.registered` enqueued with actor/tenant. |
| **I**nfo disclosure — enumerate registered emails via error differences | `EmailAlreadyRegisteredError` DOES reveal an email is taken (409) — this is a deliberate, accepted tradeoff (register needs to tell a real user their email is taken) distinct from login/forgot-password, which do NOT reveal this. |
| **D**oS — mass account creation | `@Throttle` 5/hour per the spec's rate-limit table. |
| **E**levation | n/a — no privilege granted at registration. |

## POST /v1/auth/login

| Threat | Mitigation |
|---|---|
| **S**poofing — credential stuffing / brute force | `LoginAttemptService`'s two-tier lockout (5/15min, 20/24h), keyed by (tenant, email) not IP, so rotating source IPs doesn't help an attacker. |
| **T**ampering — MITM token theft | TLS is assumed at the infrastructure layer (out of this module's scope); tokens are meaningless without it. |
| **R**epudiation | Every attempt (success AND failure) recorded via `LoginAttemptService.record()`, independent of the audit queue. |
| **I**nfo disclosure — enumerate emails via error differences | `InvalidCredentialsError` is thrown identically for "no such user" and "wrong password" — the client cannot distinguish them. |
| **D**oS | Throttled 10/15min; lockout adds a second, account-specific layer. |
| **E**levation — MFA bypass | MFA check happens server-side after password verification, before tokens are issued — a client cannot skip it by omitting `mfaCode` (login throws `MfaRequiredError` instead of silently proceeding). |

## POST /v1/auth/refresh

| Threat | Mitigation |
|---|---|
| **S**poofing — stolen refresh token | Opaque, 256-bit random, stored only as a SHA-256 hash — a DB leak doesn't yield usable tokens. |
| **T**ampering | N/A — opaque token, not a parseable structure. |
| **R**epudiation — silent token theft | **Reuse detection**: presenting an already-rotated token revokes the entire family and enqueues `auth.token.reuse_detected`. This is the primary defense against a stolen-and-later-used refresh token. |
| **I**nfo disclosure | Token hash lookup uses `withBypassRls` (documented, logged) — necessary since tenant is unknown pre-lookup; the response reveals nothing beyond "valid or not." |
| **D**oS | Throttled 60/hour. |
| **E**levation — swap in different roles on refresh | The new access token's `roles` come from the caller-supplied `roles` param at the HTTP layer (currently always `[]` — see README's "known simplifications"); once RBAC (Slice 3.3) populates this for real, it MUST be re-derived server-side from the resolved user, never trusted from client input. **Flagged here as a forward-looking requirement**, not yet exploitable since roles are always empty today. |

## Refresh token rotation & reuse detection (cross-cutting)

This is the single most important security mechanism in this slice, so
it gets its own row outside the per-endpoint table: a rotation family
sharing a `familyId` means ONE compromised-and-reused token poisons the
whole family (all revoked), not just itself — this correctly treats "an
old token was reused" as evidence the family is compromised, not as an
isolated bad request to reject and move on from.

## MFA (TOTP) endpoints

| Threat | Mitigation |
|---|---|
| **S**poofing — brute-force a 6-digit code | Throttled 10/15min; codes are also time-boxed (30s window, otplib default ±1 step tolerance) so an attacker has a very short guessing window per code. |
| **T**ampering — secret extraction | Secret encrypted at rest (AES-256-GCM); the encryption key is a deployment secret separate from the database itself. |
| **R**epudiation | `user.mfa_enabled`/`user.mfa_disabled` audit events. |
| **I**nfo disclosure — backup codes | Hashed at rest like passwords; shown to the user exactly once, at generation time, never again. |
| **D**oS — lock a user out by exhausting backup codes | Each backup code is single-use by design; regenerating requires a currently-valid code (`MfaRequiredGuard`), so an attacker without any valid code/TOTP access cannot force regeneration either. |
| **E**levation — disable MFA without proving current possession | `disableTotp` is gated by `MfaRequiredGuard`, which independently re-verifies a fresh code — a stolen access token alone is not sufficient to turn off MFA. |

## API keys

| Threat | Mitigation |
|---|---|
| **S**poofing — guess a key | 256 bits of randomness in the `erp_<env>_<random>` format; hashed at rest (SHA-256) like refresh tokens. |
| **T**ampering | N/A — opaque. |
| **R**epudiation | `lastUsedAt` updated on every successful verify; audit events on create/revoke. |
| **I**nfo disclosure — full key visible after creation | Structurally impossible: `list()`'s Prisma `select` never includes `keyHash`, and no endpoint returns a stored key's plaintext — it only ever exists in the HTTP response body at creation time. |
| **D**oS | No specific API-key throttle beyond the endpoint defaults; a future slice introducing per-key rate limits (distinct from per-IP) is a reasonable addition once real API traffic exists to tune against. |
| **E**levation — scope creep | `scopes` are stored as declared at creation; nothing in this slice enforces them against an action yet (no authorization layer exists until Slice 3.3) — an API key today is effectively "full access as this user." **This is a real, current limitation**, not a documentation gap: treat API keys created in this slice as equivalent to full account access until scope enforcement lands. |

## WebAuthn

| Threat | Mitigation |
|---|---|
| **S**poofing | Public-key cryptography — the server never sees or stores a private key; a stolen `publicKey` from the DB is useless for authentication. |
| **T**ampering — replay a captured assertion | The challenge is single-use (`RedisChallengeStore.getAndDelete` — deleted the moment it's read) and short-lived (120s TTL). |
| **R**epudiation | Sign counter (`signCount`) is checked and updated on every successful auth — a cloned authenticator producing a lower or equal counter is a detectable red flag a future slice could act on (currently just updates the stored value; alerting on a counter regression is a reasonable follow-up, not implemented here). |
| **I**nfo disclosure | N/A — public keys are, by design, safe to store in the clear. |
| **D**oS | Options-generation endpoints are behind `JwtAuthGuard` (registration) or otherwise rate-limited by the endpoint defaults. |
| **E**levation | N/A — WebAuthn here is an additional factor/credential, not a privilege grant by itself. |

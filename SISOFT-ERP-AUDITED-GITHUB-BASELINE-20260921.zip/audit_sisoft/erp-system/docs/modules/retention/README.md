# Retention module

Status: **partial**. See root MANIFEST.md for full detail.

Built: `legal-hold.logic.ts` + `LegalHoldEnforcerService` (G18, 9 passing
assertions) and `residency.logic.ts` + `ResidencyEnforcerService` (G19,
6 passing assertions) — the two enforcement choke points.

Not built: policy CRUD, retention-executor (the actual daily deletion
job), retention-audit, cross-border-transfer tracking, dashboard.

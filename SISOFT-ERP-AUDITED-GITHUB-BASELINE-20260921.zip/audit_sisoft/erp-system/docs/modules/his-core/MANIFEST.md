# MANIFEST — HIS-1 Slice: Patient Core (verified)

## What this is

One real, working slice of the HIS-1 Core Clinical prompt — not the full
150+ file delivery. Scope rationale unchanged from the first pass: the
full prompt (7 modules, 3 packages, ICD-10/CPT/LOINC, drug-interaction
engine, full IPD/OPD/MPI/Consent, >85% coverage) is realistically weeks
of work; shipping it as "done" in one pass would mean stubs dressed up
as real code, which the prompt's own "Honesty over Speed" section
forbids. This delivery covers Patient Core only: registration, get/update,
allergies, PHI audit.

## Verification pass — what was actually done

This zip was audited after the first delivery, on request. Because this
sandbox has no network access (no `npm install` against the real
registry) and no copy of the actual monorepo (no real `@nestjs/common`,
`zod`, `@prisma/client`, or `jest`), full integration testing against the
real toolchain was not possible. What *was* done, for real:

1. **Structural TypeScript check.** Built minimal `.d.ts` stubs for
   `@nestjs/common` and `zod` (decorator/type signatures only) and ran
   `tsc --strict --noEmit` against every source file in this slice.
   Result: **0 errors**, after two rounds of fixes (see "Bugs found and
   fixed" below).
2. **Real runtime execution of the business logic.** Built a ~120-line
   hand-rolled test runner (`describe`/`it`/`expect`/`jest.fn`/`jest.spyOn`,
   not real Jest) plus no-op runtime stubs for the `@nestjs/common`
   decorators and a pass-through `zod` stub, then actually executed every
   `.spec.ts` file's real assertions against the real service/generator/
   validator/encryptor code (not mocked out — the actual classes from this
   delivery). Result: **56 of 56 tests passed.**
3. **Caveat, stated plainly:** because `@nestjs/common` decorators are
   no-ops in this harness and `zod`'s `.parse()` is a pass-through, this
   run does **not** verify NestJS dependency-injection wiring at
   container-boot time, nor zod's actual input-validation behavior. It
   verifies the business logic — MRN generation, validation rules,
   registration/update/allergy workflows, PHI audit, AES-GCM encryption,
   the permission guard — which is where the real risk was. DI wiring and
   zod validation should still be smoke-tested once this lands in the
   real monorepo with real `pnpm install`.

## Bugs found and fixed during verification

1. **DI token bug (found in the first delivery, already fixed before
   this pass):** `his-patient.module.ts` tried to inject
   `PatientRepository` / `DomainEventEmitter` / `FieldEncryptor` by bare
   TypeScript interface type, which NestJS cannot resolve at runtime.
   Fixed with explicit `Symbol()` tokens (`services/tokens.ts`) and
   `@Inject(...)` everywhere.
2. **Zero test coverage on `PatientService`** (get/update) — a real gap.
   The original HIS-1 prompt explicitly names `patient.service.spec.ts`
   in its test list, and this class had no tests in the first delivery.
   Added `apps/api/test/his-patient/patient.service.spec.ts` (9 tests):
   found-vs-not-found on `getById`, that a failed lookup does *not* write
   a spurious PHI-audit entry, field updates, PHI-audit-on-update, and
   the `changedFields` payload on `patient.updated`.
3. **`AesGcmFieldEncryptor` was unverified** — the class existed but no
   test exercised it. Added `aes-gcm-encryptor.spec.ts` (5 tests) using
   real Node `crypto`: encrypt/decrypt round-trip, ciphertext doesn't
   contain plaintext, IV randomness (same plaintext → different
   ciphertext), wrong-key decryption fails (auth tag check), and a
   32-byte key length guard.
4. **`PhiAccessGuard` was unverified** — the permission/break-glass logic
   had no tests. Added `phi-access.guard.spec.ts` (6 tests): unauthenticated
   request rejected, read/write permission enforcement per HTTP method,
   and the break-glass header path (both that it's allowed and that it
   correctly marks the request for the audit layer).
5. **`any` cleanup (G5):** `patient.controller.ts` and
   `patient-allergy.controller.ts` typed the Express request as `any`.
   Added a narrow `AuthenticatedRequest` interface
   (`services/http.types.ts`) and replaced all 8 occurrences.
   Remaining `any` (17 occurrences) are all at the Prisma-client
   boundary in `prisma-patient.repository.ts` and
   `prisma-support.repositories.ts` — these narrow client interfaces are
   written deliberately loosely so the repositories can be unit-tested
   without generating the real Prisma client; they'd tighten up
   automatically once wired to the real generated `PrismaClient` type in
   the host app. Documented, not hidden.
6. **Test count was wrong in the first MANIFEST.** It claimed "21 tests /
   38 total" — an arithmetic error, not a verification of anything. The
   real, now-verified count is **56** (17 in `his-core` + 39 in
   `his-patient`, see below).

## Test inventory (56 total, all executed, all passing)

`packages/his-core/src/__tests__/`
- `patient-mrn.spec.ts` — 8 tests
- `patient-validator.spec.ts` — 9 tests

`apps/api/test/his-patient/`
- `patient-registration.spec.ts` — 6 tests
- `patient-allergy.spec.ts` — 7 tests
- `phi-audit.spec.ts` — 6 tests
- `patient.service.spec.ts` — 9 tests (new this pass)
- `aes-gcm-encryptor.spec.ts` — 5 tests (new this pass)
- `phi-access.guard.spec.ts` — 6 tests (new this pass)

**Coverage: still not measured as a percentage** — no real Istanbul/nyc
run happened (no real Jest here). Every non-Prisma, non-controller class
in this slice now has direct tests, and the controllers are thin
pass-through layers over tested services, so the untested surface is
small, but I'm not converting that into a coverage number I haven't
actually measured.

## Explicitly still NOT built (unchanged from first pass)

MPI module (duplicate matching/merge), Appointments, OPD, IPD, Clinical
Documentation, Consent modules; `packages/medical-coding` and
`packages/patient-safety`; patient sub-resources beyond allergies
(problems, medications, history, contacts, identifiers, documents,
consents, timeline, dedup, merge); patient search/list endpoint; PHI
anomaly detection job and break-glass post-hoc review workflow; real
Kafka event bus (still a logging placeholder); Facility/Tenancy
integration for MRN facility codes; seed scripts; frontend pages;
`docs/modules/his/*`; ADRs 0326–0350; migration SQL (schema defined, not
migrated — no live Postgres here).

## Quality gates — updated honest status

| Gate | Status |
|---|---|
| G9 PHI access audited | Yes, tested |
| G12 zod on every DTO | Yes, structurally; zod's own runtime validation not exercised by this harness |
| G16 PII encrypted at rest | Yes, AES-256-GCM class built **and now tested**; KMS key management still not built |
| G22 MRN gapless per facility | Yes, tested incl. simulated concurrency |
| G11 permission check every endpoint | Yes, **now tested** via PhiAccessGuard spec |
| G5 no `any` | Controller boundary fixed; 17 remain at the documented Prisma-client boundary |
| G4 coverage >85% | Not measured as a number; qualitatively, all non-Prisma/non-controller logic now has direct tests |
| G7 JSDoc on public methods | Partial |
| G8 OpenAPI per endpoint | Not done |
| G13 RLS respected | Not verified — no RLS policy SQL written |
| G17–G21, G23–G25 | N/A — govern features not in this slice |

## How to verify

Against the real monorepo (once merged):
```
pnpm install
pnpm --filter @erp/his-core test
pnpm --filter @erp/api test his-patient
```

To reproduce this pass's verification without the real monorepo: the
same approach (stub `.d.ts`/`.js` for `@nestjs/common` and `zod`, a small
custom `describe`/`it`/`expect` runner, run with `tsx`) is not included
in this zip since it's throwaway verification tooling, not part of the
deliverable — but every `.spec.ts` file in this zip is standard Jest
syntax and needs no changes to run under real Jest once dependencies are
installed.

## Suggested next slice

Still MPI (Master Patient Index) matching — same reasoning as before,
unchanged by this verification pass.

# MANIFEST — HIS-2 Ancillary Clinical (Pharmacy / Laboratory / Blood Bank / Radiology)

**Status: PARTIAL DELIVERY.** This zip contains real, tested domain-logic
packages for all four ancillary areas. It does **not** contain the
NestJS API modules, Prisma migration, frontend, seed data, or
integration/e2e tests the full HIS-2 brief specifies. Read this whole
file before assuming any capability beyond what's listed under "Built."

---

## 1. What's built (real, compiled, tested)

Four standalone TypeScript packages, each pure domain logic with **no
database, no HTTP, no NestJS dependency** — they're meant to be the
engine that a future `his-pharmacy` / `his-laboratory` / `his-blood-bank`
/ `his-radiology` NestJS module calls into.

| Package | Files | Unit tests | Result |
|---|---|---|---|
| `packages/pharmacy-engine` | 8 source + 6 test | 35 | ✅ all pass |
| `packages/lab-engine` | 11 source + 9 test | 36 | ✅ all pass |
| `packages/blood-bank-engine` | 8 source + 6 test | 32 | ✅ all pass |
| `packages/radiology-engine` | 7 source + 5 test | 24 | ✅ all pass |
| **Total** | | **127** | **✅ 127/127 pass** |

Every source file has a corresponding test file, with the sole exception
of each package's `index.ts` (pure re-exports) and `types.ts` (pure type
declarations) — every file containing actual logic has 1:1 unit test
coverage.

All four packages compile under TypeScript `strict` mode with **zero
errors** and **no `any`**. Verified by running `tsc --noEmit` against
each package's source (excluding test files, which use Node's built-in
`node:test`/`node:assert` and are run via `tsx`, not `tsc`, since
`@types/node` isn't available in this offline environment — see §5).

Every exported function, class, interface, and type alias across all
four packages has a JSDoc comment (G7). Verified with a script that
scans every `export function|class|interface|type` declaration and
confirms an immediately preceding `/** ... */` block; the scan is clean
across all source files, including `types.ts`.

Each package has its own README documenting exactly what it does and, in
a "What's NOT implemented" section, exactly what's simplified, stubbed,
or missing.

## 2. What's NOT built

- **No NestJS API layer.** No controllers, services (beyond the pure
  engine functions), guards, DTOs, jobs, or the `his-pharmacy.module.ts`
  / `his-laboratory.module.ts` / `his-blood-bank.module.ts` /
  `his-radiology.module.ts` NestJS modules described in the brief.
- **No Prisma schema/migration.** `apps/api/prisma/his-ancillary-models.prisma`
  contains only a commented illustrative sketch, not a real schema. No
  migration SQL is included (the brief's
  `apps/api/prisma/migrations/20260128_his_ancillary/migration.sql` path
  does not exist in this delivery). Nothing here has touched a database.
- **No frontend.** No `apps/web/src/app/his/**` pages or
  `apps/web/src/components/his/**` components.
- **No seed data.** No drug formulary, LOINC catalog, reference ranges,
  critical-value table, modality registry, or blood-bank testing seed
  scripts.
- **No integration or e2e tests** (all 127 tests are unit-level, no DB
  required — consistent with the brief's own instruction that
  integration/e2e tests should skip cleanly when `DATABASE_URL` is
  missing, which is the case here since none exist to skip).
- **No events emitted or consumed** (`pharmacy.rx.received`,
  `lab.result.critical`, etc. — none of the ~50 events listed in the
  brief are implemented; there's no event bus integration in this slice).
- **No charge capture / M6 billing integration, no M7 inventory sync.**
- **No drug-interaction or allergy check** wired into dispensing — the
  brief specifies this should wrap the existing `patient-safety` package
  from HIS-1, which wasn't available to inspect or import in this
  session. `pharmacy-engine` does not perform this check; do not treat
  its dose calculator as a complete safety gate.
- **No compounding (IV/TPN) calculators.**
- **No microbiology/histopathology workflow, no reflex-test rule engine.**
- **No analyzer integration** (explicitly a stub in the brief anyway,
  deferred to HIS-3 — consistent, just noting it's absent here too; not
  even a stub file exists for it).
- **No ADR documents** (`docs/adr/0351-*` through `0380-*` in the brief
  are not included).
- **No DICOM/PACS integration** beyond a placeholder UID generator
  (`radiology-engine/dicom-uid.ts`) — also consistent with the brief's own
  "stub for HIS-3" instruction.

## 3. Honesty checklist (direct answers, per the brief's own reminder)

- **Which drug DB loaded? Formulary size?** None. `pharmacy-engine`
  operates on caller-supplied `Drug[]`/`DrugBatch[]` arrays; no formulary
  or drug master data is bundled or persisted in this delivery.
- **Which LOINC codes loaded? (full set is ~90k)** None. `lab-engine`
  validates LOINC-*shaped* codes and expands panels/reference
  ranges/critical values from whatever catalog the caller supplies; no
  actual LOINC table ships with this delivery.
- **Which modalities supported?** Seven are hardcoded in
  `radiology-engine/modality.ts`'s registry — XR, CT, MRI, US, MAMMO,
  FLUORO, NM — each with radiation-use and typical-contrast-use flags,
  covered by `modality.spec.ts`. This is real code, not a seed script,
  but it's a fixed in-memory list, not a configurable/persisted registry.
- **Analyzer integration: stub or real?** Neither — absent entirely from
  this delivery (no file for it at all, unlike the DICOM stub below).
- **PACS/DICOM: stub or real?** Explicit stub, as the brief itself
  specifies ("stub for HIS-3"). `dicom-uid.ts` generates syntactically
  valid but non-registered placeholder UIDs; see its file header.
- **Blood bank: cross-match real or simplified?** Simplified. It's
  ABO/Rh-compatible electronic candidate selection, not a simulation of
  the physical serological cross-match. See §4 for the full caveat.
- **Scope cut? Say exactly what and why.** See §2 and §8 — the full
  NestJS/Prisma/frontend/seed-data/events layer was cut because
  producing ~200 files of that scope as genuinely compiled and tested
  code (rather than plausible-looking scaffolding) wasn't achievable in
  this delivery; the four engine packages are what could be built and
  verified for real.

## 4. Known limitations in what IS built (read before clinical use)

- **`blood-bank-engine/isbt128.ts` is NOT a certified ISBT 128
  implementation.** The real ICCBBA standard uses registered facility
  identification numbers and a specific ISO 7064 check-character
  algorithm. This module is a self-consistent but non-conformant
  encode/decode scheme for internal unit tracking only.
- **`blood-bank-engine/cross-match.ts`** performs ABO/Rh-compatible
  candidate filtering, not a simulation of the physical serological
  cross-match (antibody screen incubated against donor red cells).
- **`blood-bank-engine/deferral-rules.ts`** implements a representative
  subset of donor eligibility criteria (roughly a dozen common checks),
  not the full AABB/FDA donor history questionnaire (which covers dozens
  of additional criteria) and does not substitute for medical director
  judgment.
- **`lab-engine/catalog/loinc-code.ts`** check-digit validation is a
  generic mod-10 checksum for catching transcription errors, not a
  verified implementation of Regenstrief's official LOINC check-digit
  algorithm. A passing check does not mean the code exists in the real
  LOINC database — that requires a loaded LOINC table, which this
  delivery does not include.
- **`radiology-engine/contrast.ts`** eGFR thresholds (hard block <30,
  caution 30-45) reflect commonly cited clinical practice, not a specific
  cited guideline version — confirm against your department's actual
  protocol before use.
- **`blood-bank-engine/transfusion-reaction.ts`** is decision support to
  prioritize the initial workup from reported symptoms; it always
  signals the transfusion must stop and a full investigation must
  proceed regardless of the suggested classification, but the suggested
  classification itself is a heuristic, not a diagnosis.

## 5. Environment / tooling notes

- Built and tested with Node v22.22.2, TypeScript 5.x via the globally
  installed `tsc`.
- `@types/node` was not available in this offline sandbox (no network
  egress), so tests run via `tsx --test` (which transpiles without full
  type-checking) rather than `tsc` + `node --test`. Library source
  (non-test files) was separately verified to compile clean under `tsc
  --strict --noEmit`. If you have network access, run `npm install` in
  each package to get `@types/node` and the full toolchain will type-check
  test files too.
- No `pnpm-workspace.yaml`/root wiring was added or modified, per the
  "do not edit root config" rule — these packages are not yet wired into
  the monorepo's workspace graph. A merge captain will need to add them
  to the workspace's `packages/*` glob (likely already covered if the
  monorepo uses a wildcard) and run install.

## 6. Exact commands

```
cd packages/pharmacy-engine && npm install && npm test
cd packages/lab-engine && npm install && npm test
cd packages/blood-bank-engine && npm install && npm test
cd packages/radiology-engine && npm install && npm test
```

Each `npm test` runs `tsx --test src/__tests__/*.spec.ts`.

Expected output: all tests pass (35 / 36 / 32 / 24 respectively, 127
total), zero failures.

## 7. How to verify this slice in 5 minutes

1. `cd packages/pharmacy-engine && npm install && npm test` — confirm
   35/35 pass, including `dual-sign.spec.ts` (proves controlled
   substances can't be dispensed without a distinct witness) and
   `fefo.spec.ts` (proves earliest-expiry stock is allocated first).
2. `cd packages/blood-bank-engine && npm install && npm test` — confirm
   32/32 pass, including `abo-rh.spec.ts` (proves an O- unit is
   compatible with any recipient and an Rh- recipient only matches Rh-
   donors) and `cross-match.spec.ts`.
3. `cd packages/lab-engine && npm install && npm test` — confirm 36/36
   pass, including `westgard-rules.spec.ts` (proves a 1-3s violation is
   detected from a single out-of-range QC point).
4. Open any package's `README.md` and skim its "What's NOT implemented"
   section — every gap called out there is real, not hedging.
5. Confirm every exported declaration has a JSDoc comment (G7) by
   spot-checking a few files, e.g.
   `packages/pharmacy-engine/src/dispensing/fefo.ts` or
   `packages/blood-bank-engine/src/types.ts`.

## 8. Scope cut — summary

Cut entirely in this pass: NestJS API layer, Prisma schema/migration,
frontend, seed data, events, billing/inventory integration,
interaction/allergy checking, compounding, microbiology/histopathology,
reflex tests, integration/e2e tests, ADR documents, analyzer integration.
Reason: the full brief is a multi-week, 200+ file build; this delivery
prioritizes shipping the safety-critical domain logic as genuinely
correct, tested code over producing a larger volume of unverified
scaffolding.

## 9. Stop condition

Per the brief: **STOP. Do not merge. Do not start HIS-3. Wait for merge
captain.** This delivery does not merge itself and makes no changes
outside the file list below.

---

## File list (this delivery)

```
MANIFEST.md
apps/api/his-ancillary.dependencies.json
apps/api/his-ancillary.env.example
apps/api/prisma/his-ancillary-models.prisma   (illustrative sketch only, not a real schema)
apps/web/his-ancillary.dependencies.json      (placeholder, no frontend code)
docs/modules/his-ancillary/README.md
packages/pharmacy-engine/
  package.json, tsconfig.json, README.md
  src/index.ts, src/types.ts
  src/drug/drug-model.ts
  src/dispensing/fefo.ts, src/dispensing/dose-calculator.ts
  src/controlled/schedule.ts, src/controlled/register.ts, src/controlled/dual-sign.ts
  src/__tests__/*.spec.ts (6 files, 35 tests)
packages/lab-engine/
  package.json, tsconfig.json, README.md
  src/index.ts, src/types.ts
  src/catalog/loinc-code.ts, src/catalog/panel-expander.ts
  src/sample/barcode.ts
  src/results/reference-range.ts, src/results/flag-calculator.ts,
  src/results/critical-value.ts, src/results/delta-check.ts
  src/qc/westgard-rules.ts, src/qc/levey-jennings.ts
  src/__tests__/*.spec.ts (9 files, 36 tests)
packages/blood-bank-engine/
  package.json, tsconfig.json, README.md
  src/index.ts, src/types.ts
  src/abo-rh.ts, src/cross-match.ts, src/component-shelf-life.ts,
  src/deferral-rules.ts, src/isbt128.ts, src/transfusion-reaction.ts
  src/__tests__/*.spec.ts (6 files, 32 tests)
packages/radiology-engine/
  package.json, tsconfig.json, README.md
  src/index.ts, src/types.ts
  src/modality.ts, src/contrast.ts, src/report-template.ts,
  src/prep-instructions.ts, src/dicom-uid.ts
  src/__tests__/*.spec.ts (5 files, 24 tests)
```

No files outside `apps/api/his-ancillary.*`, `apps/api/prisma/his-ancillary-models.prisma`,
`apps/web/his-ancillary.dependencies.json`, `docs/modules/his-ancillary/**`,
and `packages/{pharmacy,lab,blood-bank,radiology}-engine/**` were touched,
per the isolation rules.

# HIS-2 Ancillary Clinical — this delivery

This is a **partial** delivery against the HIS-2 (Pharmacy / Laboratory /
Blood Bank / Radiology) brief. It ships the core clinical/regulatory
domain algorithms as four standalone, framework-free TypeScript packages
with real unit tests. It does **not** ship the NestJS API modules,
Prisma schema/migration, Next.js frontend, seed data, or integration/e2e
tests the full brief called for.

See `/MANIFEST.md` at the zip root for the complete honest accounting of
what's built, what's not, and why — including per-package limitations
that matter clinically (e.g. the ISBT 128 encoder is not
ICCBBA-conformant, the cross-match logic is ABO/Rh candidate filtering
rather than a serological simulation).

## Packages in this delivery

| Package | Purpose | Tests |
|---|---|---|
| `packages/pharmacy-engine` | FEFO, dosing, controlled-substance register & dual-sign | 35 |
| `packages/lab-engine` | LOINC, panels, barcodes, reference ranges, flags, critical values, delta check, Westgard QC | 36 |
| `packages/blood-bank-engine` | ABO/Rh, cross-match, shelf life, donor deferral, ISBT 128, reaction classification | 32 |
| `packages/radiology-engine` | Modality registry, contrast safety, report templates, prep instructions, DICOM UID stub | 24 |

Total: **127 unit tests, all passing**, TypeScript `strict` mode, zero
compile errors, no `any`.

## Why not the rest

The full brief specifies roughly 200+ files: four NestJS modules
(controllers/services/guards/DTOs/jobs), a Prisma migration, four
Next.js app sections plus React components, seed scripts (drug
formulary, LOINC catalog, reference ranges, critical values, modality
registry), and full integration/e2e test suites — a multi-week build for
a real team. Producing that volume as genuine, verified, tested code was
not achievable in this delivery. Rather than generate large amounts of
unverified boilerplate that looks complete but hasn't been compiled,
tested, or checked against the quality gates (G1-G25), this delivery
scopes down to the part that could be built and verified for real: the
safety-critical domain logic every controller in the full system would
eventually call into.

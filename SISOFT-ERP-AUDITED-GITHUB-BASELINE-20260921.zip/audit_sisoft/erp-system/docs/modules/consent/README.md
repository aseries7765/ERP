# Consent module

Status: **partial**. See root MANIFEST.md for full detail.

Built: `consent-proof.logic.ts` + `ConsentProofService` — hash-chained,
append-only consent proof generation and chain verification (G20).
8 passing assertions including tamper detection.

Not built: purpose management, withdrawal service, cookie consent,
marketing consent, dashboard.

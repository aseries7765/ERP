# Multi-currency rules

## Where currency lives

- `Currency` — a GLOBAL catalog (no `tenantId`), ~30 real ISO 4217
  currencies seeded in M2 (`prisma/seed/seed-currencies.ts`). Not RLS-
  protected because it isn't tenant data.
- `Company.baseCurrency` — every company has exactly one, set at
  creation, used as the reporting/functional currency for that entity.
- `ExchangeRate` — tenant-scoped, effective-dated records of one
  currency's rate against another.

## Effective-dated rates (ADR 0014)

`ExchangeRateService.getRate(tenantId, from, to, atDate)` returns the
rate that was EFFECTIVE ON `atDate` — the most recent rate with
`effectiveAt <= atDate`, never a future-dated one. A rate holds constant
from its effective date until a newer one supersedes it; there is no
interpolation between two dated rates.

This is what makes historical accuracy work: a transaction dated January
15th uses whatever rate was in effect on January 15th, even if someone
records a NEW rate (effective January 20th) after the fact. Recording a
new rate never rewrites history for already-effective-dated lookups.

**Same-currency lookups are free** — `getRate(tenantId, 'USD', 'USD',
anyDate)` returns `'1'` immediately, no DB query. Every company's base
currency gets a real `1.0` self-rate row recorded at provisioning anyway
(see `PROVISIONING.md`, step 7), so this short-circuit is a performance
optimization, not a correctness requirement — but it makes `getRate` safe
to call even before that row exists.

**No direct rate recorded? Try the inverse.** If a tenant recorded
`EUR -> USD` but a caller asks for `USD -> EUR`, `getRate` automatically
computes `1 / rate` from the inverse record rather than requiring both
directions to be entered separately.

## What's NOT implemented

**Live rate provider integration.** `EXCHANGE_RATE_PROVIDER` (env) is
empty by default — manual entry only. The spec names
openexchangerates/ECB as example providers "stub only, real provider in
M10." This slice has genuinely no provider integration code at all
(not even a disabled stub) — wiring one is real HTTP-client and
credential-management work that belongs with M10's actual AI/integration
services, not invented here against a provider this codebase has never
called.

**Automatic revaluation.** The spec's "monthly revaluation trigger" is a
Finance (M8) concept — revaluing open balances against a period-end rate
requires Finance's ledger/journal-entry tables, which don't exist yet.

## Adding a currency the system doesn't know

`CurrencyController`'s `POST /v1/currencies` (`CurrencyService.upsert()`)
lets you add/update a row in the global `Currency` catalog directly —
useful for a currency outside the ~30 seeded in M2. Remember this is a
GLOBAL table: adding a currency here makes it available to every tenant,
not just the one that needed it (see `CurrencyService`'s doc comment on
why a per-tenant "custom currency" concept isn't modeled).

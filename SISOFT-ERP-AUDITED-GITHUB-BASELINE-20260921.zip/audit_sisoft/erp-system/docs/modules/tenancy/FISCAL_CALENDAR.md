# Fiscal periods, locking, and calendars

## Fiscal years and periods

Every Company gets a `FiscalYear` (12 `FiscalPeriod`s, one per month) at
provisioning, computed from `FISCAL_YEAR_START_MONTH` (env, 1-12) and the
current date — see `FiscalPeriodService.createYearWithMonthlyPeriods()`
for the exact "which year did the current fiscal year start in" logic.
Additional fiscal years (for the following year, or a company added after
provisioning) go through `POST /v1/fiscal-years`.

## Locking (ADR 0013)

A `FiscalPeriod` has a `status`: `OPEN`, `LOCKED`, or `CLOSED`. Locking
prevents backdated entries — once Finance (M8) exists and posts journal
entries, every post checks `FiscalPeriodService.assertNotLocked()` before
writing. This slice implements and tests the lock/unlock state machine
and the assertion function itself; nothing calls the assertion yet
because there's no journal-entry endpoint to call it from.

**You cannot lock a period that hasn't started yet** — `lock()` checks
`period.startDate > now` and rejects with `FiscalPeriodOverlapError`.
There's nothing to "close" about a period that hasn't begun, and
allowing it would block legitimate advance-setup entries a future module
might reasonably want to permit.

**Unlocking is always an admin action, always audited** — `unlock()`
requires a `reason` string and emits both an audit-queue entry and a
`fiscalperiod.locked` domain event (with `locked: false`), per the
spec's "requires admin + audit" requirement.

## Calendars and holidays

Each tenant gets one default `Calendar` at provisioning, named after its
country code, with `system: "gregorian"` (Hijri/Nepali/Japanese/Buddhist
are valid values but nothing in this slice populates their specific
holiday rules — see the honesty note below). Additional calendars (for a
multi-country tenant, or a religious calendar alongside the civil one)
are created via `POST /v1/calendars` (`CalendarService.createCalendar()`)
— optionally auto-populating that country's holidays in the same call.

### Holiday catalog — an honest, small starting point

`CalendarService`'s `BUILTIN_HOLIDAYS` covers 5 countries (US, GB, PK, IN,
AE) with FIXED-DATE holidays only (no Easter, no lunar-calendar dates,
which need real astronomical/calendrical calculation or a licensed data
source to get right). This is real, working code for those 5 countries —
not a stub — but it is explicitly NOT the "all 250 countries" the
original master spec envisions. Expanding coverage is additive (new
entries in the same lookup table); getting non-fixed-date holidays right
is a separate, larger piece of work best done against a real holiday-data
API rather than approximated here.

## Working days

`CalendarService.workingDaysBetween(start, end, holidays)` is a pure
function — no DB access, takes already-loaded holiday rows — so it's
directly unit-testable (see `calendar.service.spec.ts`). It correctly
handles: weekends (Sat/Sun), fixed-date holidays (matched by exact date),
and recurring holidays (matched by month+day regardless of year).

# Tenancy & Organization (M3 Slice 3.2)

## What this module does

Everything a tenant's organizational structure hangs off: the tenant
itself, its subscription/plan, one or more legal-entity Companies, their
Branches, a hierarchical Department tree with Cost Centers, Locations,
multi-currency + effective-dated Exchange Rates, Fiscal Years/Periods
(with locking), and Calendars/Holidays. Out of scope: RBAC permission
enforcement (Slice 3.3 — this slice only creates baseline Role rows),
Billing/proration math (M6), Custom fields on these entities (Slice 3.9),
Chart of Accounts (Finance, a future business module with no schema yet).

## Data model (how tenant, company, and branch relate)

```mermaid
erDiagram
    Tenant ||--o{ Subscription : has
    Tenant ||--o{ Company : owns
    Company ||--o{ Branch : has
    Company ||--o{ FiscalYear : has
    Branch ||--o{ Department : has
    Branch ||--o{ Location : has
    Department ||--o{ Department : "parent of"
    Department ||--o{ CostCenter : has
    FiscalYear ||--o{ FiscalPeriod : has
    Tenant ||--o{ Calendar : has
    Calendar ||--o{ Holiday : has
    Tenant ||--o{ ExchangeRate : records
```

See `MULTI_COMPANY.md` for when to actually use more than one Company
under a tenant, and what that does and doesn't buy you today.

## Provisioning sequence (high level — full detail in PROVISIONING.md)

```mermaid
sequenceDiagram
    participant Client
    participant TenantController
    participant ProvisioningService
    participant DB as Postgres (Phase 1 transaction)
    participant AuthService

    Client->>TenantController: POST /v1/tenants
    TenantController->>ProvisioningService: provision(input)
    ProvisioningService->>DB: BEGIN
    ProvisioningService->>DB: Tenant, Subscription, Company, Branch,<br/>Departments, CostCenters, ExchangeRate,<br/>FiscalYear+Periods, Calendar+Holidays, Roles
    ProvisioningService->>DB: COMMIT
    ProvisioningService->>AuthService: register(tenantId, email, password)
    AuthService-->>ProvisioningService: adminUserId
    ProvisioningService-->>Client: ProvisioningSummary
```

## Common operations

**Create a tenant** (super-admin only, via `SUPER_ADMIN_API_KEY`):
```bash
curl -X POST http://localhost:3001/v1/tenants \
  -H "x-super-admin-key: $SUPER_ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"Acme Co","slug":"acme","adminEmail":"owner@acme.com","adminPassword":"correct horse battery staple"}'
```

**Add a second company under an existing tenant** (as an authenticated
tenant member):
```bash
curl -X POST http://localhost:3001/v1/companies \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"legalName":"Acme Subsidiary Ltd","countryCode":"GB","baseCurrency":"GBP"}'
```

**Add a branch to a company:**
```bash
curl -X POST http://localhost:3001/v1/companies/$COMPANY_ID/branches \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"code":"LDN","name":"London Office"}'
```

## Troubleshooting: provisioning fails

1. **`Plan "free" not found`** — `prisma/seed/seed-plans.ts` hasn't run.
   Run `pnpm db:seed`.
2. **`uuid_generate_v7 does not exist`** — the M2/M3.1 foundation migration
   sequence hasn't been applied yet; see `prisma/README.md`.
3. **Phase 2 failure (admin user)** — check the logged compensating-
   rollback message; the tenant tree Phase 1 created is automatically
   deleted, and the SAME slug can be retried (see
   `ProvisioningService.provision()`'s idempotency check — a slug with
   zero users is treated as a Phase-2 retry, not a conflict).
4. **RLS-related errors during provisioning** — Phase 1 runs as `tx`
   inside a superuser-or-erp_app transaction depending on which role your
   `DATABASE_URL`/`APP_DATABASE_URL` resolves to; if you see permission
   errors on tables Phase 1 writes to, check `erp_app`'s grants
   (`prisma/raw-sql/03-app-role-grants.sql`) were applied.

# Provisioning

## Ordered steps (Phase 1 — one Postgres transaction)

1. **Tenant** — the root record.
2. **Subscription** — on the plan named by `planCode` (default: env
   `DEFAULT_TENANT_PLAN`, itself defaulting to `free`). Fails loudly if
   that plan code isn't seeded.
3. **Company** — legal name = tenant name; country/currency from input or
   `DEFAULT_TENANT_COUNTRY`/`DEFAULT_TENANT_CURRENCY`.
4. **Branch** — "Head Office", `isHeadOffice: true`.
5. **Departments** — Admin, Finance, Operations (see
   `tenancy.constants.ts`'s `DEFAULT_DEPARTMENTS`), all top-level under
   the Head Office branch.
6. **Cost Centers** — one per department, 1:1.
7. **Exchange rate self-record** — `baseCurrency -> baseCurrency = 1.0`,
   so `ExchangeRateService.getRate()` never needs a same-currency special
   case at the call site.
8. **Fiscal Year + 12 monthly Fiscal Periods** — starting from
   `FISCAL_YEAR_START_MONTH` (env, 1-12), computed relative to the current
   date (see `FiscalPeriodService.createYearWithMonthlyPeriods()`).
9. **Calendar + holidays** — one calendar named after the country code,
   auto-populated from `CalendarService`'s built-in holiday catalog (see
   `CURRENCY_FX.md`'s sibling honesty note in `README.md`'s scope section
   — the holiday catalog is a small, real, HONEST starter set, not all
   250 countries).
10. **Terminology overrides** — explicitly none. Uses system defaults.
11. **Baseline system roles** — 7 roles (owner/admin/manager/accountant/
    hr/sales/viewer), `isSystem: true`, NO permissions attached yet
    (RBAC's job, Slice 3.3).

**Chart of Accounts is not step 12** — the original scope named it, but
Finance (business module 16) has no schema in this codebase yet. Nothing
fakes it.

## Phase 2 (separate — NOT part of the transaction above)

12. **Admin user** — via `AuthService.register()`, reusing the real
    Auth registration flow (password hashing, email-verification token,
    its own audit event) rather than duplicating that logic. See
    `ProvisioningService`'s class doc comment for the full explanation of
    why this can't join Phase 1's transaction (Prisma doesn't support
    nesting one interactive transaction inside another on the same
    client), and what "atomic" actually means as a result.

## Rollback behavior

- **Phase 1 failure** (any step): Postgres rolls back the whole
  transaction automatically. Nothing exists. `ProvisioningFailedError`
  is thrown with the failing step name and the underlying error message.
- **Phase 2 failure**: `ProvisioningService.compensateRollback()`
  hard-deletes everything Phase 1 created, in FK-safe order (children
  before parents). This is a real `DELETE`, not the soft-delete
  convention elsewhere in this codebase (ADR 0005) — safe specifically
  because nothing else can reference a tenant that's milliseconds old and
  never had a working admin account.

## How to re-run for a failed tenant

If Phase 2 failed and the compensating rollback itself somehow didn't run
(e.g. the process crashed mid-rollback — a real, if rare, possibility),
`provision()` called again with the SAME slug detects the existing tenant
has zero `User` rows and retries Phase 2 only (`retryPhase2()`), skipping
Phase 1 entirely rather than erroring on the slug conflict.

## Duration expectations

The spec's target is <5 seconds. Phase 1 is roughly 20 sequential inserts
(3 departments × 2, 12 fiscal periods, ~5 holidays, 7 roles, plus the
fixed records) inside one transaction — on typical hardware this is a
low-hundreds-of-milliseconds operation, not a bottleneck. Phase 2 (Auth's
register — one argon2id hash, a few inserts) is similarly fast. Neither
phase has been benchmarked against a real database in this sandbox (no
live Postgres here) — treat "well under 5 seconds" as an expectation
based on the operation count, not a measured number.

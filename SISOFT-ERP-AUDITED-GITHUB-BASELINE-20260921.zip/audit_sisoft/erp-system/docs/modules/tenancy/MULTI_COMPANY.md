# Multi-company: tenant vs. company vs. branch

## The three levels

- **Tenant** — the customer relationship. One subscription, one billing
  account, one set of users who can log in. Corresponds to "the
  organization that signed up."
- **Company** — a legal entity. A tenant can have exactly one (the common
  case — a single small business) or several (a holding structure).
  Companies each have their own country, base currency, tax ID,
  registration number, fiscal years.
- **Branch** — a physical or operational location of a company. Every
  company gets one ("Head Office") automatically at provisioning;
  additional branches are added as the business actually has additional
  locations.

## Real example: a holding company with 3 subsidiaries

"Acme Holdings" signs up — that's the **Tenant**. It has three legal
subsidiaries: Acme Manufacturing (Germany), Acme Retail (France), Acme
Logistics (Poland). Each is a **Company** under the same tenant, each
with its own `countryCode`/`baseCurrency`/fiscal year. Acme Retail has
shops in Paris and Lyon — those are two **Branches** under the Acme
Retail company.

This is exactly the "multi-company same tenant" scenario ADR 0012
chose to support natively rather than requiring 3 separate tenant
signups (which would mean 3 separate subscriptions, 3 separate user
bases unable to share a login, and no way to see them together at all).

## When NOT to use multi-company

If two businesses genuinely have nothing to do with each other (different
owners, no shared reporting need, no shared user base) — they should be
separate **Tenants**, not companies under one tenant. Multi-company is for
one ownership structure operating through several legal entities, not a
general-purpose "workspace" concept.

## Access control implications (current, honest state)

The spec envisions "user can be granted access to multiple companies,"
implying a dedicated grant table. **That table doesn't exist yet** — see
`CompanyScopeGuard`'s doc comment. Today, any authenticated member of a
tenant can access any company under that tenant (still fully protected
from OTHER tenants' companies by RLS) — there is no per-company
restriction within a tenant in this slice. A user with access to "Acme
Holdings" sees all three subsidiaries' companies, not just the ones
they're supposed to work with. This is a real, flagged gap: fine-grained
per-company access grants are a reasonable Slice 3.3 (RBAC) follow-up,
since "which companies can this role/user see" is fundamentally an
authorization question that module owns.

## Reporting implications

Cross-company consolidated reporting (roll up Acme Manufacturing + Acme
Retail + Acme Logistics into one P&L) is explicitly a Finance concern
(M8) — this slice's schema has no `ConsolidationGroup`/`Intercompany`
tables (those are named in the original master spec's Finance module
list, module 16, not yet built). Nothing here prevents that from being
built later; the Tenant → Company structure is exactly what a future
consolidation feature would query across.

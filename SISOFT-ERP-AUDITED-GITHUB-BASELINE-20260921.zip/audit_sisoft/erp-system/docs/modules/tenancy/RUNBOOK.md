# Tenancy runbook

## Provision a new tenant

```bash
curl -X POST http://localhost:3001/v1/tenants \
  -H "x-super-admin-key: $SUPER_ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Acme Co",
    "slug": "acme",
    "adminEmail": "owner@acme.com",
    "adminPassword": "a real 12+ character password",
    "countryCode": "US",
    "baseCurrency": "USD",
    "planCode": "free"
  }'
```

If this fails, see `PROVISIONING.md`'s troubleshooting section — it
covers the 4 most likely causes (unseeded plan, unapplied migrations,
Phase 2 failure, RLS/grant issues) with specific fixes for each.

## Suspend a tenant

```bash
curl -X POST http://localhost:3001/v1/tenants/$TENANT_ID/suspend \
  -H "Authorization: Bearer $ADMIN_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"reason": "Payment failed — see billing ticket #1234"}'
```

Requires `TenantAdminGuard` (the requester must hold the `owner` or
`admin` system role within that tenant — see that guard's doc comment on
why this is coarser than real RBAC will eventually be). Suspension sets
`Tenant.status = SUSPENDED` and records `suspendedAt`/`suspendedReason` —
it does NOT yet block login at the Auth layer (a real, flagged gap: Auth's
`login()` doesn't currently check tenant status — wiring that check is a
small, cross-module follow-up: `AuthService.login()` would call
`TenantService.get(tenantId)` and check `status !== SUSPENDED` before
issuing tokens).

## Audit a tenant's provisioning

Every provisioning run enqueues one audit event
(`entityType: 'tenant', action: 'CREATE'`) with the FULL
`ProvisioningSummary` as `after` — every id it created, in one place.
Once Slice 3.5's audit consumer exists, this becomes queryable via
`audit_events`; until then, check the BullMQ `audit` queue directly
(Redis) or the application logs, which log each phase's outcome via
`ProvisioningService`'s `Logger`.

## Debugging a stuck/half-provisioned tenant

1. Check whether the tenant has zero `User` rows —
   `SELECT count(*) FROM users WHERE "tenantId" = '<id>'`. Zero means
   Phase 1 succeeded but Phase 2 (admin user) failed and the compensating
   rollback either hasn't run or itself failed.
2. If the tenant row (and its Company/Branch/etc.) still exist with zero
   users, re-running `POST /v1/tenants` with the SAME slug and a valid
   `adminEmail`/`adminPassword` triggers `retryPhase2()` — it reuses the
   existing Phase 1 output and only re-attempts the admin-user creation.
3. If the tenant row is gone entirely, the compensating rollback
   succeeded — provisioning simply failed cleanly and can be retried from
   scratch with the same or a different slug.

## Change a tenant's plan

```bash
# Upgrade (no usage check needed)
curl -X POST http://localhost:3001/v1/subscription/upgrade \
  -H "Authorization: Bearer $ADMIN_ACCESS_TOKEN" -H "Content-Type: application/json" \
  -d '{"planCode": "growth"}'

# Downgrade (BLOCKED if current usage exceeds the new plan's limits —
# see SubscriptionService.downgrade()'s doc comment and
# subscription.service.spec.ts for exactly what's checked)
curl -X POST http://localhost:3001/v1/subscription/downgrade \
  -H "Authorization: Bearer $ADMIN_ACCESS_TOKEN" -H "Content-Type: application/json" \
  -d '{"planCode": "free"}'
```

A blocked downgrade returns `TENANCY_PLAN_LIMIT_EXCEEDED` naming the
specific limit key, its value on the target plan, and the tenant's
current usage — enough to tell the caller exactly what to reduce (or not
downgrade) without a second round trip.

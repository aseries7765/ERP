# Privacy module

Status: **not built**.

DPIA risk-scoring math (`calculateRisk`, `requiresDpoConsultation`) exists
and is tested in `@erp/compliance-engine`'s `risk-matrix.ts` — a real
`dpia.service.ts` should be built on top of that rather than duplicating
the risk math. No such service, no controllers, no PII inventory, no data
flow mapping, no privacy notices exist in this delivery.

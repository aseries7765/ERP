# Fallback Chain — Resolution Priority

`ResolutionService.resolve(key, tenantId, locale)` checks, in order, and
returns on the FIRST hit:

1. **Cache** (Redis) — `terminology:{tenantId}:{locale}:{key}`. A hit skips
   everything below.
2. **Tenant override, exact locale** — `TerminologyOverride` row for
   `(tenantId, key, locale)`.
3. **Tenant override, locale-agnostic** — same table, `locale = null`.
4. **System entry, exact locale** — `TerminologyEntry` for `(key, locale)`.
5. **System entry, locale-agnostic** — `TerminologyEntry` for `(key, '')`.
6. **The key itself** — resolution NEVER throws (G16). If nothing above
   matched, the raw key string is returned so the UI always shows
   *something* recognizable to a developer, rather than blank or an error.

After resolving from any DB level, the result is written back to cache
with a 1-hour TTL before being returned.

## Where did "installed pack override" go?

The original spec describes a 6-level chain with "installed pack override"
as its own level, between tenant overrides and system entries. That level
**is implemented**, but not as a live lookup against pack content at
resolution time. Instead, `PackService.install()` copies every key/locale
pair from the pack's JSON directly into `TerminologyOverride` rows for
that tenant, tagged with `sourcePackId`. So by the time resolution runs,
an installed pack's values are ordinary rows at level 2/3 above —
indistinguishable from a manually-created override except for that tag
(which `PackService.uninstall()` uses to remove exactly the right rows
later, without touching anything the tenant edited by hand).

**Implementation history, disclosed honestly:** an earlier version of this
code queried a separate `TerminologyPackEntry` table directly for that
level. That table was never actually defined in the schema this delivery
ships. Because the query sat inside `resolveFromDb`'s try/catch, the
resulting error was silently swallowed and returned the RAW KEY — instead
of falling through to the system entry — for every key an installed pack
didn't touch, for any tenant with a pack installed. This was caught during
pre-delivery verification (a TypeScript/consistency check across the
codebase, since no live DB was available to catch it by running the
suite) and fixed by removing the redundant/broken lookup. See
`resolution.service.ts`'s class-level comment and the `REGRESSION` tests
in `resolution.spec.ts` / `batch-resolver.spec.ts` for the locked-in fix.

## Worked example

```
key    = "erp.crm.customer.label"
tenant = hospital-A (healthcare pack installed)
locale = "ur"
```

- Installing the healthcare pack created a `TerminologyOverride` row:
  `{ tenantId: hospital-A, key: "erp.crm.customer.label", locale: "ur", value: "مریض", sourcePackId: "healthcare" }`.
- Resolution finds it at level 2 → **returns "مریض"**.

If hospital-A later creates/edits a *manual* override for the same
key/locale, the row is simply updated in place (or a new row created for
a locale the pack didn't cover) — still level 2/3, no special handling
needed to make "manual beats pack" true, because a manual edit to an
existing pack-sourced row already IS the value used.

## Why locale-agnostic tenant overrides exist (level 3)

A tenant that wants "Customer" → "Client" for every locale they support,
without maintaining N per-locale override rows, can create a single
override with `locale: null`. Adding a specific-locale override later for
one locale doesn't require touching the locale-agnostic one — level 2
simply takes priority for that locale only.

# Industry Packs

Packs are **data, not code** — a JSON file mapping terminology keys to
per-locale replacement values. Installing a pack bulk-creates
`TerminologyOverride` rows tagged with `sourcePackId`; uninstalling removes
exactly those rows (manual overrides are untouched).

## Format

```json
{
  "id": "healthcare",
  "name": "Healthcare / Hospital",
  "version": "1.0.0",
  "description": "Terminology for hospitals, clinics, HIS",
  "overrides": {
    "erp.crm.customer.label": { "en": "Patient", "ur": "مریض" },
    "erp.crm.customer.plural": { "en": "Patients", "ur": "مریض" }
  }
}
```

- `id`: stable identifier, used in the URL (`/v1/terminology/packs/:id/install`)
  and stored as `sourcePackId` on created overrides.
- `overrides`: map of `key -> { locale -> value }`. Every key referenced
  must already exist in the system catalog (`TerminologyEntry`) — pack
  install silently skips (and counts as `overridesSkipped`) any key/locale
  pair where the locale isn't enabled for the installing tenant; it does
  NOT skip for unknown keys (packs are trusted, curated content, unlike
  arbitrary imports) — see `PackService.install`.

## Bundled in this delivery (4 of the planned 30)

| id | name | representative renames |
|---|---|---|
| `healthcare` | Healthcare / Hospital | Customer→Patient, staff roles→Doctor/Nurse |
| `retail` | Retail | Customer→Shopper, Order→Sale, Item→SKU |
| `manufacturing` | Manufacturing | Customer→Buyer, Work Order→Production Order |
| `services` | Professional Services | Customer→Client, Order→Engagement |

The remaining 26 industries listed in the original spec
(construction, education, logistics, ngo, real-estate, hospitality,
food-beverage, agriculture, legal, accounting-firm, and others) are **not
included** in this delivery. Adding one is pure data entry: a new
`<id>.pack.json` file following the format above — no code changes to
`PackService` are needed, since it loads every `*.pack.json` in the
`packs/` directory automatically.

## Install / uninstall semantics

- **Install** (`overwriteExisting: false`, default): only creates
  overrides for keys the tenant hasn't already customized. Safe to
  install on top of existing manual work.
- **Install** (`overwriteExisting: true`): overwrites existing overrides
  for keys the pack touches.
- **Preview**: `POST /v1/terminology/packs/:id/preview` shows the diff
  (current value vs. pack value) before committing to install.
- **Uninstall**: removes only rows with `sourcePackId = <packId>`.
  Anything the tenant edited manually (even if it happens to match a
  pack's key) that was **created manually, not via this install**, is
  preserved.

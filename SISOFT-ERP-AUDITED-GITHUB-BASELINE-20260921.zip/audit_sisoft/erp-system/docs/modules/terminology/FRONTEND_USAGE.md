# Frontend Usage — `@erp/terminology`

## Setup

Wrap the part of the app that needs terminology (typically the whole
authenticated app shell) in a provider:

```tsx
import { TerminologyProvider } from '@erp/terminology';

<TerminologyProvider baseUrl="/api" locale={currentLocale} preloadKeys={screenKeys}>
  {children}
</TerminologyProvider>
```

`preloadKeys` should be the known key set for the current screen/route —
this triggers exactly one batch request on mount.

## In components

```tsx
import { T, useTerminology } from '@erp/terminology';

// Declarative
<T k="erp.crm.customer.label" />

// With interpolation
<T k="welcome.message" params={{ name: user.name }} />

// Imperative (e.g. for a toast, a document title, an aria-label)
const { t } = useTerminology();
const label = t('erp.crm.customer.label');
```

## Server-side rendering

```ts
import { resolveServer } from '@erp/terminology';

const labels = await resolveServer(
  ['erp.crm.customer.label', 'erp.sales.order.label'],
  tenantId,
  locale,
  { baseUrl: process.env.API_URL!, authHeaders: forwardedAuthHeaders },
);
```

Server-side and client-side resolution hit the identical
`POST /v1/terminology/resolve` endpoint, so there is never a mismatch
between what SSR renders and what client hydration would compute.

## What this package deliberately does NOT do

- It does not modify any existing `apps/web` component. Wiring
  `<TerminologyProvider>` into the real app shell, and replacing hardcoded
  strings with `<T k="..." />`, is merge-time work — this package only
  ships the primitives.
- It does not use `localStorage`/`sessionStorage` — all caching is
  in-memory per `TerminologyClient` instance, per the artifact/runtime
  constraints noted in this repo's engineering guidelines.

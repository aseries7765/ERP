# Runbook

## First-time setup (after merge)

```bash
pnpm install
pnpm --filter @erp/api prisma migrate deploy   # applies 20260104_terminology_extras
pnpm --filter @erp/api ts-node prisma/seed/terminology/seed-entries.ts
pnpm --filter @erp/api ts-node prisma/seed/terminology/seed-packs.ts   # optional, DB-side pack metadata mirror
```

## "A label isn't updating after I changed an override"

1. Confirm the override actually saved: `GET /v1/terminology/overrides?search=<key>`.
2. Check Redis directly: `redis-cli KEYS "terminology:<tenantId>:*:<key>"` — if a
   stale entry is still there past the mutation, cache invalidation didn't
   fire; check `CacheService` logs for a swallowed Redis error.
3. As a manual fix, `redis-cli DEL` the specific key, or
   `FLUSHDB`-equivalent scoped to the tenant pattern for a bigger hammer.

## "Installing a pack didn't change anything"

- Most likely cause: the tenant already had manual overrides for those
  keys and `overwriteExisting` was left `false` (the default). Use
  `POST /v1/terminology/packs/:id/preview` first to see the diff, then
  re-install with `{ "overwriteExisting": true }` if the manual values
  should be replaced.

## "Resolution is slow"

- Check the Redis hit rate — the resolution path is designed so a warm
  cache means zero DB queries. A consistently cold cache suggests either
  a very short effective TTL somewhere upstream (proxy, CDN) or a bug in
  cache key generation causing a mismatch between write and read.
- For screens, confirm the frontend is using `preloadKeys` /
  `resolveBatch` rather than firing N individual single-key resolves.

## Adding a new industry pack

1. Create `apps/api/src/modules/terminology/packs/<id>.pack.json` following
   the format in `PACKS.md`.
2. Every key referenced must already exist in `TerminologyEntry` — add it
   to the relevant `defaults/*.ts` file first if it doesn't.
3. No code changes needed — `PackService` reads all `*.pack.json` files in
   the directory automatically. Restart the API process to pick up new
   pack files (the pack list is cached in-process after first read).

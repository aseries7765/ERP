# Import / Export Format

## Export

`GET /v1/terminology/export?locale=ur` (locale optional — omit for all locales)

```json
{
  "tenantId": "tenant-A",
  "exportedAt": "2026-09-15T12:00:00.000Z",
  "overrides": [
    { "key": "erp.crm.customer.label", "locale": "ur", "value": "مریضِ خاص" }
  ]
}
```

## Import

`POST /v1/terminology/import`

```json
{
  "mode": "merge",
  "overrides": [
    { "key": "erp.crm.customer.label", "locale": "ur", "value": "مریضِ خاص" }
  ]
}
```

- `mode: "merge"` (default) — upserts each row on top of existing
  overrides. Existing overrides not mentioned in the payload are
  untouched.
- `mode: "replace"` — deletes ALL of the tenant's existing overrides
  first (audited as `terminology.override.import-replace-wipe`), then
  applies the payload from scratch. Use with care — this is a
  destructive operation for anything not included in the import file.
- Rows referencing unknown keys or disabled locales are skipped (counted
  in the response as `skipped`), not treated as a fatal error for the
  whole import.

## Round-trip guarantee

`export()` → `import({ mode: 'merge', overrides: <exported.overrides> })`
on the same tenant is a no-op (all rows already match, so `updated`
counts increment but no values actually change). This is covered by
`import-export.spec.ts`.

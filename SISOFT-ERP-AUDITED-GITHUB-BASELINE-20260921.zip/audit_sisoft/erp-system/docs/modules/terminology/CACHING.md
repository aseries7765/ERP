# Caching Strategy

## Key pattern

```
terminology:{tenantId}:{locale}:{key}
```

TTL: 1 hour (`TERMINOLOGY_CACHE_TTL_SECONDS`).

## What gets cached

Only *resolved* values — the final string after the fallback chain has
run — never raw override/pack/entry rows. This means a cache hit is a
single Redis GET (or MGET for batch), with zero DB round trips.

## Invalidation (deterministic — G17)

| Event | Action |
|---|---|
| Override created / updated / deleted | Delete `terminology:{tenantId}:*:{key}` (all locales for that one key) |
| Pack installed | Delete `terminology:{tenantId}:*` (whole tenant — a pack touches many keys) |
| Pack uninstalled | Delete `terminology:{tenantId}:*` (same reasoning) |
| System entry changed (rare, global) | Delete `terminology:*:*:{key}` (all tenants, all locales, that key) |

Invalidation always happens **synchronously, in the same request** as the
mutation — never via a background job or TTL-only expiry — so an admin who
just renamed a label and refreshes the page immediately sees the new
value. The cache is explicitly documented as best-effort: `CacheService`
swallows and logs Redis errors rather than failing the request, since a
degraded cache should only mean slower reads, never broken reads or
incorrect writes.

## Batch resolution and cache

`BatchResolverService` uses Redis `MGET` for the read side and a
pipelined `MSET` for the write-back side, so preloading 50 keys for a
screen is one Redis round trip in each direction, not 50.

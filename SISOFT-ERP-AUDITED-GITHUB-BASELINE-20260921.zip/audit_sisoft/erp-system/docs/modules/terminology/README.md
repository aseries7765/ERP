# Terminology Engine (M3.6)

Renames every visible label in the ERP — module names, entity names, field
labels, statuses, actions, messages, emails, report titles, nav items —
per tenant, per locale, without touching any database column name or
breaking existing data. This is the mechanism behind "install the
Healthcare pack and 'Customer' becomes 'Patient' everywhere."

## Documents in this folder

- [KEY_NAMING.md](./KEY_NAMING.md) — the `control.*` / `erp.*` key convention
- [FALLBACK_CHAIN.md](./FALLBACK_CHAIN.md) — resolution priority, in detail
- [PACKS.md](./PACKS.md) — industry pack JSON format + bundled pack list
- [CACHING.md](./CACHING.md) — Redis strategy + invalidation rules
- [FRONTEND_USAGE.md](./FRONTEND_USAGE.md) — `useTerminology()` / `<T />` guide
- [IMPORT_EXPORT.md](./IMPORT_EXPORT.md) — JSON import/export format
- [RUNBOOK.md](./RUNBOOK.md) — operational runbook (seeding, cache issues, pack rollout)

## Two namespaces, one engine

- `control.*` — control-plane admin portal labels
- `erp.*` — customer ERP labels
- The same resolution engine serves both, but `TerminologyService` rejects
  cross-namespace resolution based on the request context (see
  `control-erp-isolation.spec.ts`). Control-plane data and ERP terminology
  data are stored per the SaaS amendment: this module operates on
  customer-environment data for `erp.*` keys.

## Core building blocks

| Piece | What it does |
|---|---|
| `TerminologyEntry` | System-default labels — the ultimate fallback |
| `TerminologyOverride` | Tenant-specific renames, per locale |
| `TerminologyPack` (JSON files) | Bundled industry-specific override sets, installable per tenant |
| `ResolutionService` | The single-key fallback chain |
| `BatchResolverService` | The same chain, batched for a whole screen |
| `CacheService` | Redis cache in front of resolution, deterministic invalidation |
| `UsageService` | Sampled usage analytics, feeds future AI suggestions |

## Scope note (read before assuming this is "the" 5000-key catalog)

This delivery ships a working engine with a **representative** default
catalog (~180 keys) and **4** of the 30 planned industry packs
(healthcare, retail, manufacturing, services). See the root `MANIFEST.md`
for the honest accounting of what's reduced and why, and what filling out
the rest looks like (it's data entry in `defaults/*.ts` and new
`packs/*.pack.json` files — no engine changes required).

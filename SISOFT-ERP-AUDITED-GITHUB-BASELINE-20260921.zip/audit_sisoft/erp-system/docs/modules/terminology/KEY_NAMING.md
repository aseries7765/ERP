# Terminology Key Naming Convention

## Shape

```
<namespace>.<module>.<entity>.<field-or-aspect>
```

- **namespace**: `control` (admin portal) or `erp` (customer ERP app).
  Keys with neither prefix (e.g. `welcome.message`) are treated as
  global/shared and resolvable from either context.
- **module**: the owning ERP module, e.g. `crm`, `sales`, `inventory`,
  `hr`, `accounting`, `manufacturing`.
- **entity**: the domain object, e.g. `customer`, `order`, `invoice`.
- **field-or-aspect**: `label`, `plural`, a specific field name, a status
  value, a role name, etc.

## Examples

| Key | Meaning |
|---|---|
| `erp.crm.customer.label` | Singular display name for "Customer" |
| `erp.crm.customer.plural` | Plural display name |
| `erp.hr.employee.role.doctor` | A specific role label within HR |
| `erp.status.approved` | A cross-entity status label |
| `erp.action.approve` | A cross-entity action label |
| `control.tenant.label` | Control-plane label for "Tenant" |

## Rules

1. **Keys are permanent identifiers, not display text.** Renaming what a
   key *resolves to* (via override/pack) never requires changing the key
   itself, any more than renaming a database column's display label
   requires renaming the column.
2. **Never encode a language or a tenant's chosen wording into a key.**
   `erp.crm.patient.label` is wrong even for a healthcare-only build — the
   entity is still `customer` at the key level; `Patient` is what it
   *resolves to* via the healthcare pack.
3. **Cross-cutting labels** (statuses, actions, generic fields) live under
   `erp.status.*`, `erp.action.*`, `erp.field.*` rather than being
   duplicated per entity, so overriding "Approved" once covers every
   entity that uses that status.
4. **New keys must be added to the system catalog before they can be
   overridden.** `OverrideService.create()` throws `UnknownTerminologyKeyError`
   for keys not present in `TerminologyEntry` — this catches typos and
   prevents "phantom" overrides that never resolve to anything.

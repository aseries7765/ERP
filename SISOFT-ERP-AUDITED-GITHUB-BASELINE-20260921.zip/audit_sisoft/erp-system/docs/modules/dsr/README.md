# DSR module (Data Subject Rights)

Status: **partial**. See root MANIFEST.md for full detail.

Built: `@erp/dsr-engine` package (data-finder, data-eraser, 30/90-day
deadline calculator, anonymizer, pseudonymizer, data-exporter, per-Article
workflow map) — fully tested, 19 passing assertions. One NestJS job
(`DsrDeadlineCheckJob`) wires the deadline calculator to scheduled
overdue detection.

Not built: portal/request/response controllers, identity verification
service, the 7 per-Article handler services, dashboard.

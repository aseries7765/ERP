# Control Plane vs. ERP Plane

The SaaS amendment splits every permission into one of two planes:

- **`control.*`** — operations the ERP **vendor's own staff** perform
  across every tenant: provisioning environments, the vendor's own
  billing of tenants, vendor-side support tickets, feature flags,
  platform admin users, issuing cross-plane grants.
- **`erp.*`** — a **tenant's own** business operations, regardless of
  that tenant's industry: finance, sales, HR, and so on, including the
  SaaS-vertical business functions below.

## A distinction worth being explicit about

The prompt's SaaS *industry vertical* role templates (Support, Billing
Admin, Provisioner) are easy to misread as control-plane roles, since
both involve "tenants," "billing," and "provisioning" as words. They are
not: those three roles are for a **tenant whose own business happens to
be a SaaS product** — that tenant's own staff, running that tenant's own
customer support/billing/onboarding, inside the `erp.*` plane
(`erp.crm.support_ticket`, `erp.finance.subscription`,
`erp.admin.customer_account`). That's ordinary business functionality for
that one tenant, symmetrical with how a Manufacturing-vertical tenant
gets `erp.manufacturing.*`. It has nothing to do with this ERP's own
`control.*` operations across *all* tenants. See
`catalog/erp-finance.ts`, `catalog/erp-crm.ts`, and `catalog/erp-admin.ts`
headers for exactly where each SaaS role template's permissions live and
why.

Because of this, `templates/role-templates.ts` deliberately defines **no
`control.*` role templates** — control-plane roles are the vendor's own
internal staff roles, set up once for the vendor's admin console, not
something provisioned per tenant the way industry role templates are.

## Enforcement

- **Assignment time** (`UserRoleService.assign`): computes every plane the
  target user currently has any permission in
  (`PermissionService.planesForUser`) and every plane the role being
  assigned would add. If the role introduces a plane the user doesn't
  already have, the assignment is blocked with `CrossPlaneAccessError`
  and an `rbac.cross_plane.attempted` event is emitted — *unless* the
  caller passes `isExplicitCrossPlaneGrant: true`, and even then only if
  the **caller** holds `control.platform.cross_plane_grant.issue`
  (checked server-side in `UserRoleController`, never trusted from the
  request body alone).
- **A user's very first role assignment never counts as "crossing"** —
  there's no existing plane to cross from yet, so it simply establishes
  the user's home plane(s).
- Once an explicit grant has put a user in both planes, a tenant may still
  want its *own* policy against combining specific roles across that
  boundary — that's an ordinary SoD rule (see the "Cross-plane admin
  overlap" example in `templates/sod-rules.ts`), a second, independent
  layer on top of the hard technical block.

## Delegation

`DelegationService` applies the same rule to delegation: a permission
from plane P can only be delegated to a grantee who already holds *some*
permission in plane P. Interpreted this way — and applied to both planes
symmetrically, not just `control.*` as the prompt's literal wording says
— because a one-directional rule would leave the erp→control direction
unguarded for no stated reason; see `delegation.service.ts`'s file header
for the full reasoning.

# RBAC Runbook

## Verify this slice in about five minutes

This works today, with no database, no Redis, and no `pnpm install` of
new packages — the module boots entirely on its in-memory defaults.

```bash
pnpm install
pnpm --filter @erp/api start:dev
```

Expected: a log line from `RbacModule.onModuleInit` —
`RBAC permission catalog synced: v2026.01.0, 471 permissions` — within a
second or two of boot.

Then, once `zod` and this module's dependencies are actually installed
(see `rbac.dependencies.json` — not yet merged into `package.json`):

```bash
pnpm --filter @erp/api test rbac
```

Expected: the unit spec files under `test/rbac/*.spec.ts` pass. The two
files under `test/rbac/` that need the real Nest test harness
(`permission.guard.spec.ts`) and a real database/app
(`test/rbac/e2e/rbac.e2e-spec.ts`) will run for real here for the first
time — they were written against real Jest/`@nestjs/testing` conventions
but could only be desk-checked, not executed, in the delivery sandbox
(no network access to install `@nestjs/testing`/`supertest`). See
MANIFEST.md for exactly what was and wasn't run before delivery.

## Seeding (first run against a real database)

Order matters — later steps reference keys the earlier ones create:

```bash
pnpm --filter @erp/api exec tsx prisma/seed/seed-permissions.ts
pnpm --filter @erp/api exec tsx prisma/seed/seed-sod-rules.ts
pnpm --filter @erp/api exec tsx prisma/seed/seed-roles.ts --tenant=<tenantId> --industry=healthcare
```

All three are idempotent (safe to re-run): permissions upsert by key,
SoD rules skip by name if already present, roles skip by key if already
present for that tenant.

## Swapping in the real infrastructure (the actual merge task)

Three provider lines in `rbac.module.ts`, nothing else:

```ts
{ provide: RBAC_REPOSITORY, useClass: PrismaRbacRepository }   // was InMemoryRbacRepository
{ provide: RBAC_CACHE_STORE, useClass: RedisCacheStore }        // was InMemoryCacheStore
{ provide: RBAC_EVENT_EMITTER, useClass: BullMqRbacEventEmitter } // was InMemoryEventEmitter
```

`PrismaRbacRepository` doesn't exist yet — writing it against the real M2
schema is the main piece of merge work this delivery couldn't do (no
access to that schema in this session). See
`interfaces/rbac-repository.interface.ts` for the exact method contract
it needs to satisfy, and MANIFEST.md → "Schema assumptions" for the field
mapping notes for each M2 model this module expects to exist.

## Troubleshooting

- **"has no @RequirePermission — denying by default" in logs**: an
  endpoint is missing its decorator (quality gate G11 requires one on
  every endpoint) — add `@RequirePermission('...')`, don't remove the
  guard.
- **A permission change isn't taking effect**: check whether
  `PermissionService.invalidateUserCache`/`invalidateTenantCache` was
  called after the mutation — every service in this module that changes
  roles/groups/delegations already does this, but a direct repository
  write (a manual DB fix, a data migration) will leave stale cache
  entries until the 60-second TTL expires or you invalidate manually.
- **`CrossPlaneAccessError` on a role assignment that should be allowed**:
  either it's a genuine cross-plane assignment (use
  `isExplicitCrossPlaneGrant: true`, which itself requires the caller to
  hold `control.platform.cross_plane_grant.issue`), or the target role's
  permission set is broader than intended and includes a permission in an
  unexpected plane — check the role's `permissionKeys`.
- **`DATABASE_URL` unset**: `test/rbac/e2e/rbac.e2e-spec.ts` skips
  cleanly rather than failing, per the prompt's own instruction.

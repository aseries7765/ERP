# RBAC Module (M3.3)

Role-based access control for the ERP: roles, a generated permission
catalog, groups, CEL-based policies, time-boxed delegation, separation of
duty, field-level permissions, and periodic access review.

## What this module does

- **Roles** — system roles (Owner/Admin/Manager/Accountant/Viewer) plus
  per-tenant custom roles and industry role templates (Healthcare, Retail,
  SaaS, Manufacturing).
- **Permissions** — a catalog of `{namespace}.{module}.{resource}.{action}`
  keys, generated from resource×action matrices (see
  [PERMISSIONS_CATALOG.md](./PERMISSIONS_CATALOG.md)), split into a
  `control.*` plane (this ERP's own vendor operations) and an `erp.*`
  plane (each tenant's own business data) — see
  [CONTROL_VS_ERP.md](./CONTROL_VS_ERP.md).
- **Groups** — permission sets a user inherits by membership.
- **Policies** — tenant-editable CEL guard expressions
  (see [CEL_RULES.md](./CEL_RULES.md)).
- **Delegation** — time-boxed, reasoned, audited permission grants between
  users.
- **Separation of duty (SoD)** — role-pair conflict rules, enforced at
  role-assignment time and, for a specific self-approval pattern, at
  action time.
- **Field-level permissions** — hides specific fields (e.g. salary) from
  roles not on that field's allowlist.
- **Access review** — periodic per-role attestation with a keep/revoke
  decision per item.

## Module layout

```
services/     business logic (framework-free where possible — see below)
guards/       PermissionGuard, SodGuard, FieldLevelGuard
decorators/   @RequirePermission, @HideField, @AllowIf
controllers/  the /v1/rbac/* REST API
catalog/      the generated permission catalog
templates/    role templates + default SoD rules
dto/          zod schemas + validation pipe
events/       typed event payload shapes
interfaces/   ports this module depends on (repository, cache, events)
errors/       typed error hierarchy
```

## A note on how this was built (read MANIFEST.md first)

This module was built in a sandboxed session with **no access to the real
M2 Prisma schema and no network access**. Every service is written
against `interfaces/rbac-repository.interface.ts` (a plain TypeScript
port) rather than PrismaClient directly, with a complete in-memory
reference implementation (`services/in-memory-rbac.repository.ts`) — the
same pattern for the cache (`CacheStore`) and event emitter
(`RbacEventEmitter`). This made the service layer's actual logic
genuinely unit-testable in this sandbox (120 tests, all passing — see
MANIFEST.md for exactly which ones and how they were run), at the cost of
one real merge task: implement `PrismaRbacRepository`,
`RedisCacheStore`, and `BullMqRbacEventEmitter` against the real
infrastructure and swap three provider lines in `rbac.module.ts`. Nothing
else changes.

## Quick start (against the in-memory defaults, no DB required)

```bash
pnpm install
pnpm --filter @erp/api start:dev
# RbacModule.onModuleInit syncs the permission catalog automatically.
```

See [RUNBOOK.md](./RUNBOOK.md) for seeding roles/SoD rules and for how to
verify this module in about five minutes.

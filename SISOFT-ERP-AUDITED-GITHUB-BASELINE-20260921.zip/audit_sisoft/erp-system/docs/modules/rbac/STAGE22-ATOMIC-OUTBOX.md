# RBAC Stage 22 — Atomic Mutation + Outbox Boundary

## Goal

Close the reliability gap identified in Stage 21: a production RBAC mutation and its durable `event_outbox` row must commit or roll back together.

## Implementation

- `PrismaRbacRepository` now exposes `withTenantTransaction(tenantId, userId, work)`.
- The callback receives a repository bound to the exact Prisma transaction and a transaction-bound outbox writer.
- `BullMqRbacEventEmitter` exposes `emitInTransaction()` and writes directly to that outbox writer.
- `atomicRbacMutation()` provides a framework-free service helper and retains a legacy fallback for in-memory test implementations.
- `RoleService` create/update/delete/permission grant/revoke now use the atomic path in production.
- The existing post-commit queue dispatcher remains responsible for delivery to BullMQ.

## Failure semantics

If the RBAC mutation throws, the Prisma transaction rolls back and no outbox row is committed. If the database commits, the outbox row is durable and can be retried independently by the dispatcher.

## Scope

Stage 22 migrates the RoleService mutation surface first because it exercises role creation, updates, deletion, and permission edge operations. Other RBAC mutation services remain on the existing emitter contract and are queued for the next atomic-migration stage.

## Verification

Static verification checks the transaction-bound repository, transaction-aware emitter, atomic helper, RoleService adoption, and structural syntax. Runtime PostgreSQL/Prisma verification requires the missing project dependencies and database service.

# RBAC Stage 23 — Atomic Mutation Coverage

## Objective

Extend the Stage 22 transaction-aware mutation + outbox boundary from `RoleService` to the remaining RBAC services that already emit durable domain events.

## Implemented

The following event-bearing mutations now use `atomicRbacMutation()`:

- `UserRoleService.assign`
- `UserRoleService.revoke`
- `GroupService.addMember`
- `GroupService.removeMember`
- `PolicyService.create`
- `PolicyService.update`
- `DelegationService.create`
- `DelegationService.revoke`
- `SodService.createRule` for tenant-scoped rules
- `AccessReviewService.create`
- `AccessReviewService.submit`

The cache invalidations remain after the successful transaction. This avoids invalidating a cache for a mutation that subsequently rolls back.

## Deliberate boundaries

Some repository mutations currently have no corresponding RBAC event constant and therefore were not given invented event semantics merely to make a static gate green. Examples include group create/update/delete, policy delete, and SoD rule delete.

Global SoD rule creation remains on the existing non-tenant transaction path because the current transaction boundary is tenant-scoped and the global rule has no tenant ID.

SoD violation recording during role-assignment prechecks remains a separate operation. Blocking violations occur before the assignment transaction; non-blocking violation records are intentionally observational and are not used to authorize the assignment.

## Security / consistency properties

1. Event-bearing mutation + outbox append commit in one PostgreSQL transaction when the production transactional repository/emitter are active.
2. Cache invalidation occurs only after the mutation transaction succeeds.
3. Test/in-memory implementations retain the fallback behavior of `atomicRbacMutation()`.
4. No new fake event types or placeholder persistence paths were introduced.

## Verification

Static verification is provided by `scripts/verify-rbac-stage23.sh`.

Runtime PostgreSQL/Prisma/BullMQ verification is not claimed until dependencies and services are available.

# Healthcare Roles

Five role templates back the "future HIS" module
(`catalog/healthcare.ts`, `erp.healthcare.*`):

| Role | Can | Cannot |
|---|---|---|
| **Doctor** | Read/update patients, create/read/update clinical notes, create/read/approve prescriptions, create/read lab orders, read lab results, read/update appointments | Dispense prescriptions |
| **Nurse** | Read/update patients, create/read/update clinical notes, full appointment CRUD + check-in, create/collect lab orders, full immunization records | Approve or dispense prescriptions |
| **Pharmacist** | Read patients, read/approve/dispense prescriptions | Everything else — no clinical notes, no lab access |
| **Lab Tech** | Read patients, read/update/collect-sample lab orders, create/update/release lab results | Prescriptions, clinical notes, appointments |
| **Reception** | Create/read/update patients, full appointment CRUD + check-in/cancel, create/read insurance claims | **No clinical data at all** — no clinical notes, prescriptions, lab orders, or lab results |

## Field-level PII

Every resource in `catalog/healthcare.ts` is flagged `isPiiSensitive:
true`. As documented on `erp-hr.ts` and in `FieldPermissionService`, that
flag identifies which resources need `FieldPermissionRule` rows seeded —
it isn't itself an access control. HIPAA-readiness means seeding
per-field rules for the specific fields that need narrower visibility
than the resource-level permission already provides (e.g. a field on
`patient` that only the treating clinician, not all Reception staff,
should see) — do that via `FieldPermissionService.upsertRule` per tenant,
not by editing the catalog.

## The one seeded SoD rule

`templates/sod-rules.ts` seeds exactly the conflict the M3.3 prompt names
directly: **a user cannot hold both `healthcare.doctor` and
`healthcare.pharmacist`** — the person who prescribes shouldn't also be
the one who dispenses. Severity `block` (not `warn`) — this one has a
real compliance/safety rationale, not just a process preference.

`healthcare-role-templates.spec.ts` verifies this rule references role
keys that actually exist in the templates above (a rule pointing at a
role key that doesn't exist would silently never fire), and that it fires
correctly for the doctor+pharmacist combination without false-positiving
on either role alone.

# Permission Catalog

## Key format

```
{namespace}.{module}.{resource}.{action}
```

Examples from the M3.3 prompt: `erp.finance.journal.create`,
`control.tenant.suspend`.

**Ambiguity found in the source prompt:** the prompt states this format as
always 4 segments, but its own `control.tenant.suspend` example has only
3 (no separate module segment). `services/permission-key.utils.ts`
accepts both: 3 segments (`{namespace}.{resource}.{action}`, module and
resource collapse to the same value) and 4+ segments
(`{namespace}.{module}.{resource}.{action}`, with 5+ supporting a nested
resource like `erp.hr.employee.address.update`). In practice control-plane
permissions tend to use the 3-segment form and ERP permissions the
4-segment form, but neither is enforced — pick whichever is clearest for
a given permission.

## Namespaces

- `control.*` — the ERP **vendor's own** operations across all tenants
  (provisioning, vendor-side billing, vendor support, platform admin).
  See [CONTROL_VS_ERP.md](./CONTROL_VS_ERP.md).
- `erp.*` — a **tenant's own** business data and operations, whatever
  industry that tenant is in.

## Generated, not hand-typed

`catalog/builder.ts` generates every permission from a resource×action
matrix (`buildModulePermissions(namespace, module, resources)`) rather
than each one being a hand-typed literal. Each `catalog/erp-*.ts` file is
just a resource list plus a call to that builder. This matters for two
reasons:

1. **Consistency** — every resource in a module gets the same action set
   and exact key shape; a 2,000-line hand-typed catalog will drift.
2. **Honesty about what this session could know** — it doesn't have M2's
   real 83 model names, so every resource list below is an illustrative,
   standard-ERP name, not necessarily the tenant's actual schema. Because
   generation is matrix-driven, replacing the illustrative resource lists
   with the real M2 model names is "edit one array per module," not
   "rewrite hundreds of permission entries by hand."

## Current size (see MANIFEST.md for exact test-verified counts)

**471 permissions** as delivered: 40 `control.*`, 431 `erp.*` across 12
ERP modules (core, finance, sales, purchase, inventory, hr, manufacturing,
projects, crm, reports, admin, healthcare) plus 5 control-plane modules
(tenant, billing, provisioning, support, platform).

The prompt asks for "~2,000+ entries." This delivery does not pad the
resource lists to hit that number artificially — 471 is what the
generator produces from a reasonable, real resource list per module. The
generator scales linearly: adding the tenant's actual full resource list
(the real M2 model set, likely 80+ models across these same modules) will
comfortably clear 2,000 without any code change, only data.

## PII flag

`ResourceSpec.isPiiSensitive` marks a resource (not a specific field) as
one that plausibly carries personal data — currently every resource in
`hr`, `healthcare`, and the CRM `contact` resource. It's a signal for
which resources need `FieldPermissionRule` rows seeded (see
`FieldPermissionService`), not a permission-level access control by
itself; the actual per-field allow list lives in `FieldPermissionRule`.

## Versioning

`PERMISSION_CATALOG_VERSION` in `rbac.constants.ts` — bump it whenever any
`catalog/*.ts` file's shape changes. `PermissionCatalogService.syncCatalog()`
upserts the full catalog and records this version; `GET
/v1/rbac/permissions/catalog-version` reports it.

# Role Templates

`templates/role-templates.ts` defines two kinds of role template,
installed via `prisma/seed/seed-roles.ts`:

## System roles

Installed for every tenant regardless of industry. Derived from the
catalog by module/action filters (`permsByModule`) so they automatically
track the catalog as it grows, rather than needing a hand-maintained list
that drifts:

| Role | Scope |
|---|---|
| Owner | Every `erp.*` permission |
| Admin | Every `erp.*` permission except a small owner-only denylist (payroll approval, fixed-asset disposal, bank account deletion) |
| Manager | Full read/write on sales, purchase, inventory, projects, CRM; read-only on core, finance, hr, reports |
| Accountant | Full finance module + core + reports; read-only on sales, purchase, inventory |
| Viewer | Read-only on everything |

## Industry roles

Installed in addition to system roles when a tenant's industry vertical
is set at provisioning. Unlike system roles, these are **deliberately
narrow, explicit permission lists** rather than module filters — a
Doctor role shouldn't silently gain permissions because someone later adds
a new healthcare resource without deciding who should have it.

- **Healthcare** — Doctor, Nurse, Pharmacist, Lab Tech, Reception. See
  [HEALTHCARE_ROLES.md](./HEALTHCARE_ROLES.md) for the detail and the
  Doctor/Pharmacist SoD rule.
- **Retail** — Cashier, Store Manager, Inventory Clerk.
- **SaaS** — Support, Billing Admin, Provisioner (see
  [CONTROL_VS_ERP.md](./CONTROL_VS_ERP.md) for why these are `erp.*`
  roles, not `control.*` ones, despite the name overlap with vendor-side
  concepts).
- **Manufacturing** — Production Manager, QC Inspector, Machine Operator.

`roleTemplatesForVertical(vertical)` returns system roles plus only that
vertical's industry roles — what `seed-roles.ts` installs for a given
tenant.

## Extending

Add a new `RoleTemplateDef` to the relevant array in
`templates/role-templates.ts`. If it's an industry role, list its
permission keys explicitly (via `buildPermissionKey`, which validates the
key format) rather than a broad module filter, for the reason above.

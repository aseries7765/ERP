# CEL Policy Rules

Tenant-defined conditional rules — e.g.
`amount > 10000 && user.role == 'manager'` — evaluated by
`CelEvaluatorService`.

## Why a hand-rolled evaluator instead of a CEL library

The prompt suggests `cel-js or equivalent`. This session has no network
access to evaluate or install any third-party package, so a real
correctness/security review of a specific library wasn't possible here —
and a sandboxed expression evaluator is exactly the kind of dependency
that deserves that review before it gates access decisions. Rather than
either blocking on that or shipping an unreviewed dependency,
`services/cel-evaluator.service.ts` is a small, hand-written tokenizer,
recursive-descent parser, and tree-walking evaluator over a **deliberately
restricted grammar** with no function-call or assignment syntax at all —
so there is no code path that can turn expression text into arbitrary
executable code, by construction rather than by blocklist. It has 27
passing tests in this delivery, including explicit sandbox-escape
attempts (see MANIFEST.md).

**If full CEL-spec compliance becomes a real requirement** (macros like
`has()`/`all()`/`exists()`, maps, timestamps, string functions), evaluate
a maintained library instead of extending this by hand indefinitely — at
that point you have real infrastructure and time to properly audit a
dependency, which this delivery session didn't.

## Supported grammar

- Literals: numbers, strings (`'...'` or `"..."`), `true`/`false`, `null`
- List literals: `[1, 2, 3]`
- Dotted property access: `user.profile.department`
- Unary: `!`, `-`
- Arithmetic: `+ - * / %` (string `+` concatenates)
- Comparison: `== != < <= > >=`
- Boolean: `&&`, `||` — **strict**: both operands must already be
  booleans (`1 && true` is a type error, unlike JS truthiness)
- Membership: `x in [a, b, c]` or `x in someMap`
- Grouping: `(...)`

## Not supported (on purpose)

Function calls, CEL macros, map literals, string functions,
timestamp/duration types. None of this module's actual use cases need
them; each one added is attack surface to review.

## Missing fields

A property that isn't present on the context object evaluates to
`undefined` rather than throwing (a deliberate deviation from strict CEL,
which would error) — and `undefined == null` evaluates `true`. This
subset has no `has()` macro to guard optional fields with, so a rule like
`user.department == 'sales'` needs to keep working even when
`department` isn't set for every user, rather than throwing on every
evaluation for users without it.

## Limits (rbac.constants.ts)

| Limit | Value | Purpose |
|---|---|---|
| `CEL_EVAL_TIMEOUT_MS` | 50ms | Wall-clock budget per evaluation |
| `CEL_MAX_NODES_VISITED` | 5,000 | Bounds pathologically large expressions |
| `CEL_MAX_EXPRESSION_LENGTH` | 2,000 chars | Rejected before parsing |
| Parse depth | 100 | Prevents stack overflow on deeply nested input |

**Timeout honesty note:** `Date.now()` has ~1ms resolution and this
evaluator has no loops (bounded AST from bounded input), so at the real
50ms operating point the timeout is comfortably enforced — but a
timeout *smaller than the clock's resolution* isn't guaranteed to fire on
every run (see the comment on the corresponding test in
`cel-evaluator.spec.ts`). This doesn't matter at 50ms; it would matter if
someone later lowers the default to single-digit milliseconds.

## Security testing performed

`cel-evaluator.spec.ts` includes explicit attempts to: resolve
`__proto__`/`constructor`/`prototype`, use JS call syntax to reach
`process`, use an assignment operator for prototype pollution, and pass a
SQL-injection-shaped string through as a literal. All are inert — the
call/assignment attempts are parse errors (no such grammar exists), and
the forbidden-property attempts throw `CelForbiddenPropertyError`. One
real bug was found and fixed by this testing: the tokenizer's keyword
lookup used a plain object literal, and `KEYWORDS['constructor']` /
`KEYWORDS['__proto__']` resolved to real JS objects (not `undefined`) via
the object's own inherited prototype chain — the exact bug class this
evaluator's design is meant to prevent, just in the host implementation
instead of the sandboxed language. Fixed by switching to `Map`. See
MANIFEST.md → "Bugs the tests actually caught" for the full account.

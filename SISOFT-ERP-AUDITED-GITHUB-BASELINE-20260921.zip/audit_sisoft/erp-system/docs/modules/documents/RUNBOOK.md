# Runbook

## "A user says their upload failed silently"

1. Check application logs for `UploadService` warnings — every
   validation/scan rejection logs a `warn` with the tenant ID and
   specific `DocumentsError` subclass (`FileTooLargeError`,
   `UnsupportedMimeTypeError`, `VirusDetectedError`, etc.) before
   re-throwing. The HTTP status code on the response maps 1:1 to the
   error class via `DocumentsError.httpStatus`.
2. If the error was `VirusScanTimeoutError`, check clamd health:
   `echo PING | nc $DOCS_CLAMAV_HOST $DOCS_CLAMAV_PORT` should reply
   `PONG`. A hung/overloaded clamd is the most common cause.

## "Restore a previous version"

`POST /v1/documents/:id/versions/:versionNumber/restore`. This is
non-destructive — it creates a **new** version copying the target's
content pointer. If the wrong version got restored, just restore again
targeting a different version number; nothing is ever lost.

## "A file seems to be duplicated in storage but I expected dedup"

Check `BlobRef` for the file's hash within that tenant. Remember dedup
is **per-tenant** by design (see DEDUPLICATION.md) — two different
tenants uploading the same file is expected to produce two blobs, not a
bug.

## "GDPR erasure didn't remove a document"

Check `LegalHold` for that document ID — an active hold is the only
thing that blocks erasure, and `GdprService.erase`'s response includes a
`blockedByLegalHold` array listing exactly which documents were skipped
and why.

## "Debugging a stuck share link"

`FileShare.revokedAt`, `.expiresAt`, `.downloadCount` vs
`.downloadLimit`, and `.passwordHash` (non-null = password required) are
the four gates checked by `ShareService.assertAccessible`, in that
order. Query the row directly to see which gate is failing.

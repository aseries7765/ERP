# Deduplication

Content-addressed storage: a file's storage key is `sha256` of its
plaintext bytes, scoped per tenant: `{tenantId}/{hash[0:2]}/{hash}`.
The 2-character prefix directory avoids millions of files in one flat
S3/MinIO "directory," a common object-store performance pitfall.

## Refcounting

`BlobRef(tenantId, hash) -> refCount` (see `documents-models.prisma`)
tracks how many `DocumentVersion` rows point at a given blob.
`DocumentService` increments on every upload/version/restore and
decrements on delete; `CleanupService.cleanupOrphanBlobs` sweeps blobs
whose refcount hits zero.

## Cross-tenant behavior

Hashes are **never** shared across tenants — even if two tenants upload
byte-identical files, they get separate storage keys and separate
refcounts, because `storageKeyFor` includes `tenantId`. This is
intentional: per-tenant encryption keys (see STORAGE.md) mean the
*ciphertext* would differ per tenant anyway, but keeping the plan
explicit avoids any accidental sharing of even hash metadata across
tenant boundaries.

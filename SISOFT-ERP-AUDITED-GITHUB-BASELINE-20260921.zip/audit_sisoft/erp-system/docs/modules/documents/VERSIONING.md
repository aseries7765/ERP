# Versioning

`services/version.service.ts` is append-only: `createNextVersion` always
inserts a new row with `versionNumber = latest + 1`. Nothing ever
`UPDATE`s or `DELETE`s an existing `DocumentVersion` row (short of a
GDPR erasure, which removes all versions for a document deliberately).

## Restore

`restore(documentId, targetVersionNumber, restoredBy)` creates a **new**
version whose `hash`/`storageKey` copy the target version's — it never
rewinds by mutating history. This keeps the audit trail intact: you can
always see that "version 5 was a restore of version 2, done by X at Y."

## Why this matters for dedup

Because restore copies a `hash` rather than re-uploading bytes, restoring
an old version does not create a new blob or affect the dedup refcount
beyond incrementing it once for the new version row (handled by
`DocumentService.restoreVersion`, wired at merge time to also bump
`BlobRef.refCount`).

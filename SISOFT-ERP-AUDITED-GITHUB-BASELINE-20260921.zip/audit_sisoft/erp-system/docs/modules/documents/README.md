# Documents & File Manager (M3.8)

Metadata-in-DB, bytes-in-object-storage document management for the ERP
platform: folders, versioning, tagging, time-boxed sharing, e-signature,
OCR, deduplication, legal hold, and GDPR erasure/portability.

## Module layout

```
apps/api/src/modules/documents/
├── controllers/   REST endpoints (documents, folders, shares, signatures, ocr, gdpr)
├── services/      business logic (document, version, upload, download, ...)
├── storage/       pluggable MinIO/S3/local adapters + tenant environment resolver
├── virus-scan/    pluggable ClamAV/VirusTotal scanners
├── jobs/          async processors: OCR, virus re-scan, thumbnails, cleanup, retention
├── guards/        RBAC + legal-hold + share-token access control
├── dto/           zod schemas for every mutating endpoint
└── events/        typed event payloads emitted to "documents-events" + "audit"
```

## Key design decisions

See `docs/adr/0039` through `0042` for the reasoning behind:
storage backend choice, hash-addressed deduplication, per-tenant
encryption keys, and the e-signature audit trail model.

## Related docs

- [STORAGE.md](./STORAGE.md) — adapters, per-tenant environments, encryption
- [VERSIONING.md](./VERSIONING.md) — immutable version history
- [DEDUPLICATION.md](./DEDUPLICATION.md) — content-addressed storage
- [VIRUS_SCAN.md](./VIRUS_SCAN.md) — ClamAV / VirusTotal
- [SHARING.md](./SHARING.md) — time-boxed links
- [ESIGN.md](./ESIGN.md) — signature workflow + audit trail
- [OCR.md](./OCR.md) — text/field extraction
- [GDPR.md](./GDPR.md) — erasure + portability
- [LEGAL_HOLD.md](./LEGAL_HOLD.md)
- [RUNBOOK.md](./RUNBOOK.md) — operational debugging

## Status

This is a pre-merge, standalone slice. See `MANIFEST.md` at the zip root
for exactly what's wired vs. what needs the merge captain's attention.

# Sharing

`POST /v1/shares` creates a `FileShare` with an expiry (hard capped at
30 days server-side, see `SHARE_TOKEN_MAX_TTL_SECONDS`), optional
password, optional download limit, and view/download permission flags.
The response includes a signed JWT `token` embedding only the share ID —
all actual state (expiry, revocation, remaining downloads, password
check) lives in the DB and is re-checked on every access via
`ShareService.assertAccessible`, so revoking a share invalidates
outstanding links immediately without needing to track/blacklist JWTs.

## Public access endpoint

`GET /v1/shares/:token` requires no platform authentication —
`ShareTokenGuard` verifies the JWT signature and attaches `shareId` to
the request; the controller then calls `assertAccessible` for the real
state checks (expiry/revocation/password/limit) before returning
anything.

## Access logging

Every view and download is recorded via `ShareAccessLog` (IP + action +
timestamp) — used for both security auditing and satisfying "who
accessed this document" questions in incident response.

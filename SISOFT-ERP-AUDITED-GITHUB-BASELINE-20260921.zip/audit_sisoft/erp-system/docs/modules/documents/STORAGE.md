# Storage

## Adapters

`storage/storage.interface.ts` defines `StorageAdapter`. Three real
implementations ship in this module:

| Adapter | Use case |
|---|---|
| `MinioAdapter` | Default, self-hosted (per AMENDMENT.md #1, lives in the customer's own environment) |
| `S3Adapter` | Enterprise customers on AWS |
| `LocalAdapter` | Dev only; guarded behind `NODE_ENV=development` + `DOCS_ALLOW_LOCAL_STORAGE=true` |

An `AzureBlobAdapter` was scoped in the original file list but **cut**
from this delivery for time — see `MANIFEST.md` "Known limitations".
Adding it is a matter of implementing the same `StorageAdapter`
interface against `@azure/storage-blob`.

## Per-tenant environments

`storage/tenant-environment.provider.ts` resolves which adapter/config
to use for a given `tenantId`. The shipped `EnvVarTenantEnvironmentProvider`
is a **dev fallback** — a single shared MinIO instance from env vars. It
does **not** implement true per-tenant isolated environments as described
in AMENDMENT.md #1, because the tenant-environment registry is a
control-plane concern outside this module's scope. Replace this provider
at merge time; the `TenantEnvironmentProvider` interface is the seam.

## Encryption

All bytes are AES-256-GCM encrypted (`services/encryption.service.ts`)
**before** they reach any storage adapter — adapters only ever see
opaque ciphertext blobs (`content-type: application/octet-stream`).
Keys are derived per-tenant from a master key + tenant ID + key version,
supporting rotation (old versions still decrypt). BYOK is supported by
passing a `masterKeyOverride` fetched from the tenant's own KMS/vault —
that integration itself is out of scope here (flagged in MANIFEST.md).

## Signed URLs

Every adapter's `getSignedDownloadUrl` clamps its TTL to
`SIGNED_URL_MAX_TTL_SECONDS` (24h, per gate G18) regardless of what's
requested.

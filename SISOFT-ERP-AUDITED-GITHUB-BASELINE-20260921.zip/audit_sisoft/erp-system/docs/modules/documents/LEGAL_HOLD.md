# Legal hold

`services/legal-hold.service.ts` + `guards/legal-hold.guard.ts`.

A document under an active `LegalHold` cannot be deleted through any
path in this module:
- `DELETE /v1/documents/:id` — blocked by `LegalHoldGuard` at the HTTP
  layer AND by an explicit check inside `DocumentService.delete`
  (belt-and-suspenders, since this is compliance-critical).
- Retention policy expiry (`jobs/retention.job.ts`) — skips held
  documents entirely, logging each skip.
- GDPR erasure (`services/gdpr.service.ts`) — reports held documents in
  `blockedByLegalHold` instead of erasing them.

Only an explicit `release()` call by an authorized user clears the hold.
Multiple overlapping holds on the same document are not modeled in v1
(a document is either held or not) — if your legal/compliance team needs
independently-trackable concurrent holds with separate release
conditions, that's a schema extension to `LegalHold` at merge time.

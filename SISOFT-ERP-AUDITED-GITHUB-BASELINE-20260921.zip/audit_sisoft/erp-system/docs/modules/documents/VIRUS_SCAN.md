# Virus scanning

Mandatory on every upload (gate G17). `services/virus-scan.service.ts`
wraps a pluggable `VirusScanner` (`virus-scan/scanner.interface.ts`) and
fails **closed**: a scanner error or timeout is treated as "not safe,"
never silently treated as clean.

## ClamAV (default)

`virus-scan/clamav.scanner.ts` speaks clamd's `INSTREAM` protocol over
a raw TCP socket — no extra client library dependency. Requires a
running `clamd` daemon reachable at `DOCS_CLAMAV_HOST:DOCS_CLAMAV_PORT`
(bringing up that daemon in `docker-compose.yml` is outside this
module's isolation rules — flagged in `MANIFEST.md`).

## VirusTotal (pluggable alternative)

`virus-scan/virustotal.scanner.ts` checks the file's SHA-256 against
VirusTotal's hash database first (fast, no upload needed for known
files), falling back to upload+poll for unseen files. **Privacy note:**
this sends file bytes to a third party for unseen files — only enable
for tenants who've explicitly consented, and prefer it as an async
*re-scan* (see `jobs/virus-scan.job.ts`) rather than the synchronous
upload-blocking scan.

## Explicit skip (rare, audited)

`allowSkipForTenant` + `skipRequested` must **both** be true to bypass
scanning — a single flag isn't enough. Any real skip must be logged and
the caller is responsible for auditing it (the service logs a warning
but does not itself write to the audit log, since it doesn't own an
audit client — that's wired in at the controller/interceptor layer).

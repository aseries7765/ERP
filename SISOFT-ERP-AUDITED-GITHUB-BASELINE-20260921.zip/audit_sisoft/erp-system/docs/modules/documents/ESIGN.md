# E-signature

`services/signature.service.ts`. A `SignatureRequest` is created against
a specific document **hash** (`documentHashAtRequest`) — if the
underlying document changes after signatures are requested (e.g. a new
version is uploaded), the signature is still cryptographically bound to
the exact bytes that existed at request time, so it can never be
silently re-purposed to "cover" a different document.

## Signer links

Each signer gets a unique, short-lived JWT (not a platform session —
external signers have no account). The token embeds `{requestId,
signerId}` and is verified fresh on every `sign`/`decline` call.

## Sequential vs. parallel signing

`order: 0` on every signer means "no ordering enforced" (parallel).
Setting positive, distinct `order` values enforces that lower orders
must sign before higher ones can — `SignatureService.sign` checks this
and throws a descriptive error if a signer tries to jump the queue.

## Audit trail

Every signature record captures: signer name/email, IP, user agent,
exact timestamp, and a `signatureHash = SHA256(documentHash + signerId +
timestampISO)`. This hash is immutable and independently recomputable —
anyone with the original document hash, signer ID, and timestamp can
verify a signature record hasn't been tampered with.

## Decline semantics

Any signer declining immediately cancels the whole request (matches the
prompt's spec: "any signer can decline → request cancelled"), rather
than just removing that one signer and continuing.

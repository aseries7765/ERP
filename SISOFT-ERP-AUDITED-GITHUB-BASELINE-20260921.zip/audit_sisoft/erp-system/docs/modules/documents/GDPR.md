# GDPR

## Right to erasure

`POST /v1/documents/gdpr/erasure` → `GdprService.erase`. For every
document linked to the subject user: deletes all `DocumentVersion`,
`FileShare`, `Signature`/`SignatureRequest`, `OcrResult`, and `FileTag`
associations, then frees the underlying storage blob(s) (respecting
refcounts — a blob shared with another tenant's... no, blobs are never
cross-tenant, but a blob could still be referenced by a *different
document* of the same user via dedup, so freeing only happens when the
refcount hits zero).

**Legal hold always wins** (AMENDMENT.md #6): a held document is
skipped, not force-deleted, and reported back in the `blockedByLegalHold`
array so the erasure request can be tracked to completion once the hold
lifts. This is a deliberate compliance choice — the erasure request
completes for everything it *can* erase and clearly reports what it
couldn't.

An erasure proof (which document IDs were erased, when, under which
request ID) is written for audit purposes via `writeErasureProof`.

## Right to portability

`POST /v1/documents/gdpr/portability` → `GdprService.prepareExport`
returns the manifest of files to include; actual ZIP assembly + signed
URL issuance (max 24h per G18) happens in a queued job using
`archiver` (see `documents.dependencies.json`) — kept out of the
synchronous request path since export can involve large volumes of data.

# OCR

`services/ocr.service.ts` uses `tesseract.js` for text recognition, then
a small regex pass (`extractFields`) for a handful of common invoice/
document fields (invoice number, date, total). This is a genuine,
working baseline — not a stub — but intentionally narrow: real
AI-assisted field extraction is explicitly scoped to M10 per the
project prompt.

## Async by design

OCR runs as a queued job (`jobs/ocr.job.ts`), triggered via
`POST /v1/documents/:id/ocr` and polled via `GET /v1/documents/:id/ocr`.
Results are persisted to `OcrResult` and indexed with a Postgres GIN
full-text index (`idx_ocr_results_text_fts` in the migration) so
"searchable via full-text index" works out of the box with a plain
`to_tsquery` search — no separate search engine needed for v1.

## Known limitation

`tesseract.js` downloads language trained-data over the network on
first use by default. For offline/air-gapped deployments, vendor the
`.traineddata` file and point `TESSDATA_PREFIX` at it (see
`documents.env.example`). This module's own test suite mocks the
network-dependent recognition call and only exercises the regex field
extraction logic — see `MANIFEST.md` "Test results" for the honest
breakdown of what is and isn't verified.

# Stage 16 — Workspace & Dependency Integration

## Implemented
- Merged all existing `apps/api/*.dependencies.json` manifests into `apps/api/package.json` without overwriting existing foundation versions.
- Added direct runtime dependencies required by source imports: Nest JWT/passport/throttler/mapped-types, WebAuthn packages, Temporal client, argon2, class-validator, ioredis, nodemailer, otplib, passport-jwt, qrcode, web-push, and express.
- Added a deterministic dependency/import coverage verifier at `scripts/verify-dependency-integration-stage16.sh`.

## Verification status
- External import-to-manifest coverage can be checked statically.
- Six referenced `@erp/*` workspace packages currently have no package source in this extracted workspace: `@erp/dsr-engine`, `@erp/payroll-country-plugins`, `@erp/query-builder`, `@erp/security`, `@erp/shared-types`, `@erp/workflow-engine`.
- Those packages must be recovered from their authoritative prior module deliveries or implemented as real packages before `pnpm install/build` can be considered production-ready.
- No fake package stubs were created.
- Runtime installation/build/database verification remains pending because pnpm/dependencies/database are unavailable in this environment.

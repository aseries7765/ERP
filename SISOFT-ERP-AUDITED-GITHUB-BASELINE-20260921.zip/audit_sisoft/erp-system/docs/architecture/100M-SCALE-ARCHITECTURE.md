# 100M+ Scale Architecture

Status: DESIGN DOCUMENT — describes the credible path to 100M+ scale using what already exists in this codebase. It is not a claim that 100M scale has been built, load-tested, or deployed. No load test evidence exists in any supplied archive.

## What the codebase already has toward this
- Stateless API design in `apps/api` (NestJS, JWT-based auth, no server-side session state observed in the merged tree).
- `packages/cloud-provider` + `packages/cloud-provider-oracle`: an infrastructure-provider abstraction layer already exists (not just a plan) — see Decision 4 in MERGE-DECISIONS.md for what's implemented vs. stubbed.
- `packages/provisioning-engine`, `packages/control-plane-client`: control-plane primitives for tenant/ERP-instance lifecycle already exist as packages.
- `packages/deployment-engine`, `packages/version-engine`, `packages/canary-engine`: deployment/rollout primitives exist.
- `infra/helm/charts/api`: a Helm chart exists for the API — horizontal pod scaling is an infrastructure decision at deploy time, not a code change.
- `prisma/schema.prisma` tenant-scoped models (193 total) with `tenantId` columns and (per docs/db/RLS.md, inherited from Lineage A) PostgreSQL RLS policies as the tenant isolation mechanism.
- BullMQ/Redis-based outbox pattern (`EventOutbox`, `EventDelivery` — tracked, migrated models per Stage 40's inventory) for async processing.

## Tier model (design, not yet implemented at Tier 3/4)
| Tier | Target | Status in this codebase |
|---|---|---|
| Tier 1 — single cluster | Small/medium deployment: 1 Postgres + Redis + workers | Achievable with what exists today, pending the BLOCKED runtime verifications in STAGE-RECONCILIATION.md |
| Tier 2 — read replicas + partitioning | Large multi-tenant | Not implemented — no partitioning strategy or read-replica routing found in the merged tree |
| Tier 3 — shard/region routing | Very large | `control-plane-client`/`provisioning-engine` provide the hook points, but no shard-routing logic was found |
| Tier 4 — 100M+ ecosystem | Multiple clusters/regions | Not implemented — control-plane services described here are client libraries and provisioning primitives, not a running control-plane service |

## Honest gap list
- No sharding or tenant-to-shard placement logic exists in code.
- No read-replica-aware query routing exists in the Prisma/NestJS layer.
- No load test results exist (docs/launch/LOAD_TEST_RESULTS.md, inherited from Lineage A, predates this merge and predates the Stage 40 reconstruction — treat its numbers as historical/unverified against the current merged tree).
- The database currently targets a single PostgreSQL instance (per every Stage 41-61 doc). Sharding is a Tier 3+ concern not yet built.

## Update (Stages 63-71, merged 2026-09-19)
Stages 63-71 now provide static, gate-verified **design contracts** for exactly the Tier 2-4 gaps above: distributed rate limiting/backpressure (63), capacity/autoscaling/multi-region workload classes (64), shard routing/tenant placement (65), cross-shard consistency/idempotency via saga pattern (66), global control plane/tenant lifecycle (67), global identity federation (68), global authorization policy distribution (69), global config/feature flags (70), global secrets/key management (71). Every one of these passed its own STATIC PASS gate in this merge (see STAGE-RECONCILIATION.md) and every one is explicitly runtime BLOCKED — they are policy/architecture documents plus JSON policy schemas in `config/`, not executable sharding or control-plane code. The gap list above is otherwise unchanged: no actual sharding, replica routing, or load-tested capacity exists in the codebase yet. What's new is that the path from Tier 1 to Tier 3/4 now has a written, internally-consistent contract to implement against, rather than nothing.

## Recommended next step
Do not build Tier 3/4 infrastructure speculatively (project rule §22). The concrete next step is finishing Tier 1 runtime verification (the BLOCKED items in STAGE-RECONCILIATION.md) against a real disposable PostgreSQL/Redis environment before any partitioning work starts.

# Multi-ERP / Multi-Company Control Plane

Status: DESIGN DOCUMENT grounded in what exists in the merged tree, not a description of a running system.

## Control plane vs data plane, as implemented
- **Control plane candidates** (packages, not a deployed service): `control-plane-client`, `provisioning-engine`, `deployment-engine`, `version-engine`, `canary-engine`, `billing-engine`/`m6-billing-invoicing-core` (subscription/usage), `cloud-provider` + `cloud-provider-oracle` (infrastructure abstraction).
- **Data plane**: `apps/api/src/modules/{finance,hr,payroll,inventory,projects,purchase,sales,manufacturing,crm,billing,compliance,...}` — the actual ERP business modules, all tenant-scoped through the shared `tenants`/`companies` foundation models (Stage 40's foundation candidates: tenants, users, roles, permissions, groups, policies, delegations, cost_centers).

## Existing model
`docs/modules/tenancy/MULTI_COMPANY.md` and `docs/modules/tenancy/PROVISIONING.md` (inherited unchanged from Lineage A into this merge — 0 conflicts found) already describe the Customer -> Subscription -> ERP Instance -> Tenant -> Users chain referenced in the original brief. This merge did not need to invent that model; it already existed and was carried forward.

## Provider abstraction
`packages/cloud-provider` defines the abstraction; `packages/cloud-provider-oracle` is the one concrete implementation present. AWS/Azure/GCP/private implementations are NOT present in any supplied archive — only the Oracle adapter and the abstraction interface exist. Adding another provider is additive (new package implementing the same interface), not a rewrite of the ERP modules — confirmed by inspecting that `apps/api` modules do not import `cloud-provider-oracle` directly (grep found no such references), meaning the abstraction boundary is intact in the current tree.

## Gap list
- No control-plane HTTP service was found — `control-plane-client` is a client library; the server it talks to is not part of any supplied archive.
- Feature-entitlement enforcement at the API-request level was not verified to exist (would need a code-level audit of `apps/api` guards, not done this pass).
- No evidence of a real multi-region deployment configuration beyond the single Helm chart in `infra/helm/charts/api`.

## Update (Stages 67-71, merged 2026-09-19)
Stage 67 now provides a static, gate-verified design contract for exactly the "no control-plane HTTP service" gap above: explicit control-plane/data-plane boundary, tenant lifecycle state machine, and the rule that control-plane commands must carry authenticated tenant context and cannot bypass data-plane RLS/authorization/shard routing. Stages 68-71 layer on identity federation (OIDC/SAML), authorization policy distribution, global config/feature flags, and secrets/key management — the remaining pieces a real control-plane service would need. All five passed their own STATIC PASS gates (STAGE-RECONCILIATION.md) and are explicitly runtime BLOCKED. This is still a contract, not a running service: the "no control-plane HTTP service" and "no multi-region deployment config" gaps above remain literally true. What changed is that `control-plane-client` (the package already noted as existing in the previous version of this doc) now has a written specification for the server it should eventually talk to.

# PCI-DSS Controls (if cardholder data is ever handled directly)

**Recommended approach: don't handle raw card data at all.** Use a
PCI-compliant processor (Stripe, etc.) with tokenization/hosted
fields, so cardholder data never touches this application's servers.
This dramatically reduces PCI scope (SAQ A vs. the much heavier SAQ D).

If that's the architecture (most likely, given S4 Billing is listed
as a separate module in this project):

| Requirement | Applicability |
|---|---|
| Req 1-2: Network security | Reduced scope — only the redirect/tokenization flow, not full cardholder data environment |
| Req 3: Protect stored cardholder data | N/A if never stored — verify S4 never logs/stores raw PANs |
| Req 4: Encrypt transmission | TLS to the processor's hosted fields |
| Req 6: Secure development | SAST/dependency scanning already covers general secure-dev requirements |
| Req 10: Logging | Standard audit logging (M3.5) |
| Req 11: Regular testing | Pen test program (PEN_TEST_PLAN.md) |

`maskCardNumber()` (`packages/security/src/masking/pii-masker.ts`) is
provided for the narrow case of displaying a card's last 4 digits in
support tooling — it is not a substitute for never storing/logging the
full PAN in the first place.

## Status
This document assumes a tokenized/hosted-fields architecture (S4's
responsibility to confirm) and hasn't been validated against S4's
actual implementation, since that's outside this module's isolated
scope. `tools/security/compliance/pci-scan.sh` provides a basic
TLS-config self-check, explicitly not a substitute for an actual PCI
ASV scan.

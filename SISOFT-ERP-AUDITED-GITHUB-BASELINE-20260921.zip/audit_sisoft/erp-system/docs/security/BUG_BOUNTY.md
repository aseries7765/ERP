# Bug Bounty Program

## Planned structure (per M15 spec)
- **Platform**: HackerOne (or a self-hosted disclosure form if budget
  doesn't support a managed platform initially).
- **Scope**: production only, never staging (staging data isn't
  representative and testing there doesn't validate real-world risk;
  it also avoids researchers needing separate staging credentials).
- **Rewards**: Critical $5,000 / High $2,000 / Medium $500 / Low $100.
- **Response SLA**: 48h to triage a new report, 7 days to fix
  HIGH-or-above findings (matching the general vulnerability SLA in
  VULNERABILITY_MANAGEMENT.md).
- **Hall of fame**: public recognition page for researchers (opt-in).

## Current status: NOT LAUNCHED

Launching a bug bounty program before the product is stable invites
noise the team can't handle, and before the pre-launch pen test is
clean, it's redundant with paid testing that's more targeted. Sequence:
1. Pass the pre-launch external pen test.
2. Launch on HackerOne in a **private/invite-only** capacity first
   (curated researchers) to work out the triage process.
3. Open to public bounty after 1-2 clean cycles of the private
   program.

## See also
`docs/security/DISCLOSURE_POLICY.md` for the general vulnerability
disclosure policy that applies even before a paid bounty program
exists — researchers should always have a clear, safe way to report
issues.

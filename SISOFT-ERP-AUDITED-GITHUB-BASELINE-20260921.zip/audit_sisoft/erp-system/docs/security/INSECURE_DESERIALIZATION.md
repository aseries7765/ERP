# Insecure Deserialization Prevention

## Guidance

- Never use `eval()`, `Function()`, or `node-serialize`-style
  deserializers on user input — banned by Semgrep rule `no-eval`.
- `JSON.parse` is safe against code execution (unlike some other
  language's native serialization formats) but should still validate
  the parsed shape against a schema (e.g., zod/class-validator DTOs)
  before use — don't trust parsed JSON structure blindly.
- If any module needs to serialize complex objects (e.g., job queue
  payloads), prefer JSON with explicit versioned schemas over
  language-native serialization (Python `pickle`, Java
  `ObjectInputStream`) which can lead to remote code execution if an
  attacker controls the serialized bytes.
- The AI module (`apps/ai/security.py`) should specifically avoid
  deserializing model outputs as executable code — output sanitization
  is listed as in scope there (see MANIFEST.md for implementation
  status).

## Status: guidance only, no deserialization vulnerabilities to fix in
this isolated slice (no custom deserialization logic was introduced).

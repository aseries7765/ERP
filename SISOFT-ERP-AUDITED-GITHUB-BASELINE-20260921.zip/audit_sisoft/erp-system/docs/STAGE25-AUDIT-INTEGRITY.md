# Stage 25 — Audit Integrity, Query & Operational Verification

## Scope
This stage completes the operational audit surface after Stage 24 durable consumers.

## Implemented
- Durable generic `AuditService.record()` writes audit intent to `EventOutbox`.
- Domain-style action names normalize to the fixed `AuditAction` enum.
- Tenant-scoped audit event listing with bounded page size and filters.
- Tenant-scoped activity-log listing.
- Single audit-event lookup.
- Full tenant hash-chain verification in bounded batches.
- Verification recomputes each row hash and validates the previous-hash link.
- Verification reports the first broken row and does not modify evidence.
- Outbox routing distinguishes audit-only events from RBAC domain events.

## Retention / forensic policy
`AuditEvent` remains append-only. This stage does not add deletion, anonymization, or destructive retention. Future archival must preserve legal holds and independent integrity verification.

## Security
Audit APIs require `erp.core.audit_trail.read` through the existing RBAC `PermissionGuard`. Queries execute through tenant context, so application-level tenant scoping and database RLS remain aligned.

## Verification limitation
Static verification is performed in the extracted workspace. Runtime Prisma/PostgreSQL/Redis/BullMQ verification requires the actual dependency and service environment and is therefore not claimed here.

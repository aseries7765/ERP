# 0208: Session Hardening (Rotation, Timeouts)

## Status
Accepted

## Context
Long-lived, non-rotating sessions increase the window of opportunity
for session hijacking and make fixation attacks possible.

## Decision
Rotate session ID on login and on privilege change; enforce a 15-minute
idle timeout and an 8-hour absolute timeout regardless of activity;
256-bit CSPRNG session IDs.

## Consequences
- Meaningfully limits the impact of a leaked session token (short
  windows, mandatory rotation on privilege escalation).
- 15-minute idle timeout may feel aggressive for some workflows —
  worth revisiting per user-experience feedback post-launch, but
  chosen as the safer default per the M15 spec's explicit target.
- Concurrent-session limits and device binding, also called for in the
  spec, are NOT implemented in this delivery (see SESSION_MANAGEMENT.md)
  — this ADR covers what was built, not the full original scope.

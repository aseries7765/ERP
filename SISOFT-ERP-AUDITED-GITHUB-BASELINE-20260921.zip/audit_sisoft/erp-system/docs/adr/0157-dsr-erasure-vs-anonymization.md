# ADR 0157: DSR erasure vs anonymization classification

## Status
Accepted (logic implemented and tested; per-Article handler wiring not built — see MANIFEST.md)

## Context
GDPR Article 17(3) provides exceptions to the right to erasure, including
compliance with a legal obligation. Some data (e.g. invoices) must be
retained for tax/audit purposes but the erasure request is still, in
spirit, about removing personal linkage.

## Decision
Three-way classification (`classifyForErasure` in `@erp/dsr-engine`):
- `legalBasis === 'legal_obligation'` OR explicit `retentionRequired` flag
  → **retain** (soft-marked erased, not deleted)
- `legalBasis === 'contract'` → **anonymize** (PII stripped, record kept)
- everything else → **erasable** (hard delete)

## Consequences
Every module's data-finder adapter must correctly tag records with
`legalBasis` and `retentionRequired` — a missing or wrong tag on a new
module's adapter silently over- or under-erases data. This is a review
checklist item for anyone adding a new DataFinderAdapter.

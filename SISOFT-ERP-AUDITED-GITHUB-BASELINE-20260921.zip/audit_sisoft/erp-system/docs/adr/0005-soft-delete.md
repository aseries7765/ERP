# ADR 0005: Soft delete by default

## Status
Accepted.

## Context

The master spec (A9) requires soft delete everywhere, with hard delete
reserved for a separate, explicit GDPR-erasure job. ERPs specifically need
this: a deleted sales order, employee, or journal entry is frequently
still referenced by historical reports, audit trails, and other records'
foreign keys — actually removing the row breaks all of that.

## Decision

Every tenant-scoped table (except append-only logs, which are never
"deleted" at all — see `docs/db/SCHEMA.md`) has a nullable `deletedAt`
timestamp. "Deleted" means `deletedAt IS NOT NULL`; the row still
physically exists. `.delete()`/`.deleteMany()` are never called from
application code — see `apps/api/src/prisma/base-tenant.repository.ts`,
whose `softDelete()`/`softDeleteMany()` methods are the only delete path
every module's repository is meant to expose.

## Rationale

- **Referential integrity for history.** A soft-deleted employee can
  still be looked up by an old payslip's foreign key. A hard delete would
  either cascade (destroying the payslip too) or orphan the reference.
- **Undo.** U13 in the master spec requires undo for destructive actions
  in the UI — trivial to implement against a soft-delete column
  (`UPDATE ... SET deletedAt = NULL`), effectively impossible to implement
  against an actual `DELETE`.
- **Audit trail completeness.** `audit_events` records the mutation, but a
  hard-deleted row's `before` state is the only place its data would
  survive at all if the row itself is gone. Soft delete means the row
  itself remains as a second, independent record of what existed.

## Why this isn't enforced via a Prisma Client Extension

An earlier draft of `tenant-scoping.extension.ts` tried to intercept
`delete`/`deleteMany` at the query-extension level and rewrite them into
an `update`. This doesn't work: Prisma Client Extensions'
`$allOperations` hook can rewrite an operation's *arguments*, but the
`query()` callback always executes the *original* operation — there's no
supported way to redirect `delete` into `update` mid-flight from inside
that hook. (See the comment block at the top of
`tenant-scoping.extension.ts` for the fuller explanation; this was caught
and fixed before shipping, not discovered afterward.)

The actual enforcement point is `BaseTenantRepository`: every module's
concrete repository extends it, inherits `softDelete()`, and — by
convention plus (eventually) a lint rule — never calls the underlying
Prisma delegate's `.delete()`/`.deleteMany()` directly. This is the same
approach Prisma's own documentation recommends for implementing soft
delete as of Prisma 5.

## Consequences

- Every default list/find query must explicitly filter `deletedAt: null`
  (see `BaseTenantRepository.findActive()`/`findActiveById()`) —
  forgetting this filter in a hand-written query means soft-deleted rows
  reappear. This is a real, ongoing discipline requirement that soft
  delete trades for the benefits above; `softDelete.test.ts` documents
  the expected pattern but can't prevent every future query from omitting
  the filter.
- A real GDPR right-to-erasure request needs an actual hard-delete job —
  intentionally a separate, explicit code path outside
  `BaseTenantRepository`, scoped to Compliance Center (module 24, a future
  business-module milestone), not something soft delete provides for
  free.

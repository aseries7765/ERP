# 0207: MFA Enforcement for Admin and Control-Plane Actions

## Status
Accepted

## Context
MFA (TOTP/WebAuthn) exists per M3.1 but is opt-in by default for
regular users. Admin and control-plane actions carry disproportionate
blast radius if the account is compromised, warranting mandatory
enforcement.

## Decision
`MfaRequiredGuard` blocks any route tagged `@RequireMfa()` unless the
current session completed MFA after the session itself started
(prevents reuse of a stale pre-MFA session token). Apply this tag to
all `/v1/security/*` endpoints and any other admin-role action.

## Consequences
- Admin/control-plane accounts must complete MFA every session, adding
  minor friction in exchange for meaningfully reducing account-
  takeover impact on the highest-privilege accounts.
- Requires session state to actually track `mfaVerifiedAt` accurately
  — depends on M3.1's MFA flow setting this correctly; not
  independently verified against a live M3.1 implementation in this
  isolated module.

# ADR-0050: Immutable version rows, instance-pinned execution

## Status
Accepted and implemented (`services/version.service.ts`,
`workflow_versions` table, `WorkflowInstance.versionId` FK).

## Context
G18 requires publishing a new version never breaks a running instance.

## Decision
`WorkflowVersion` rows are created once and never updated
(`publish()` always inserts, never updates). Every `WorkflowInstance`
stores the exact `versionId`/`version` it started with and resumes
against that row's `graphJson` for its entire lifetime, even after
newer versions are published. New triggers and manual starts always
resolve to `MAX(version) WHERE status = PUBLISHED`.

## Consequences
- Old versions accumulate indefinitely unless a retention policy prunes
  `WorkflowVersion` rows with no remaining referencing instances — not
  built in this delivery (documented gap, low priority: JSONB rows are
  cheap relative to instance/task/log volume).
- The restart-survival test in
  `packages/workflow-engine/src/__tests__/executor.spec.ts` exercises
  the exact rehydrate-from-frozen-JSON mechanism this ADR depends on.

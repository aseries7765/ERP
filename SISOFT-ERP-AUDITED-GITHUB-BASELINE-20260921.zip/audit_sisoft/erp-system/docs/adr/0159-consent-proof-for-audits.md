# ADR 0159: Consent proof immutability

## Status
Accepted (logic implemented and tested; DB-level enforcement not applied — see MANIFEST.md)

## Context
Article 7(1) requires the controller to be able to demonstrate that the
subject consented. Regulators may audit this years later, so the proof
must be tamper-evident, not just "we have a log."

## Decision
Two-layer immutability:
1. **Architectural**: withdrawal is a new INSERT (action='withdrawn'),
   never an UPDATE of the original grant row.
2. **Cryptographic**: each record hashes its own fields plus the previous
   record's hash for the same subject+purpose (hash chain). `verifyChain`
   recomputes every hash and checks linkage; any post-hoc edit to any
   field of any record breaks verification from that point forward.

## Consequences
This is app-layer tamper-evidence, not tamper-prevention. Production
deployment should also revoke UPDATE/DELETE grants on the ConsentRecord
table for the application's database role (documented in
migration.sql but not applied anywhere real in this delivery).

# ADR 0010: MFA backup codes are hashed at rest, shown once

## Status
Accepted.

## Context

TOTP-based MFA needs a recovery mechanism for the common case of a user
losing their authenticator device. The standard approach is a set of
single-use backup codes generated at enrollment time. These codes are
functionally equivalent to a password for authentication purposes.

## Decision

10 backup codes, 8 characters each, generated from an alphabet excluding
visually-ambiguous characters (0/O, 1/I). Each is hashed (SHA-256) before
storage, as a separate `MfaMethod` row with `type=BACKUP_CODES`. The
plaintext codes are returned to the caller exactly once, at generation
time (`beginEnrollment`/`regenerateBackupCodes`), and never again — the
API has no "view my backup codes" endpoint, by design.

## Rationale

- **Hashed, not encrypted, unlike the TOTP secret itself.** The TOTP
  secret must be DECRYPTED to generate/check codes — it's used
  bidirectionally. A backup code is only ever COMPARED against a
  presented value — one-way hashing (like passwords) is the correct,
  simpler primitive here, and means a database leak doesn't expose usable
  backup codes any more than it exposes usable passwords.
- **One row per code (not one row with an array/JSON blob of all 10)**
  matches the existing `MfaMethod` table shape exactly (same columns as
  the TOTP row) and makes single-use consumption a plain `DELETE` of one
  row rather than an update-in-place on a JSON array, which is simpler to
  reason about and matches the "each code is independently a secret"
  mental model.
- **Shown once, never retrievable again** — the same principle as API
  keys (ADR 0011) and the TOTP QR code itself: if the server could show
  you your backup codes again later, so could anyone who compromised the
  server or an admin session, which defeats the point of them being a
  recovery-of-last-resort mechanism independent of ongoing server trust.

## Consequences

- A user who loses both their authenticator AND their saved backup codes
  has no self-service recovery path in this slice — account recovery in
  that case is a support/admin operation outside what M3.1 builds
  (a future slice's concern, likely tied to whatever admin tooling
  Slice 3.3's RBAC work introduces).
- Regenerating backup codes invalidates all previous ones immediately
  (`regenerateBackupCodes` deletes existing `BACKUP_CODES` rows before
  creating new ones) — a user who regenerates and doesn't save the new
  set has effectively locked themselves into the same "no backup codes"
  state as never having any, just as a matter of not writing them down.

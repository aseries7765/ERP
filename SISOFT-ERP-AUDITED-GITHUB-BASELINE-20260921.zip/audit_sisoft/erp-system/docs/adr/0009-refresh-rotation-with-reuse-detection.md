# ADR 0009: Refresh token rotation with reuse detection

## Status
Accepted.

## Context

A long-lived refresh token (7 days default) is a high-value target if
stolen — far more valuable than a 15-minute access token. Two common
mitigation strategies exist: (a) a single long-lived refresh token that's
simply checked against the DB each time (no rotation), or (b) rotating
refresh tokens — every use of a refresh token retires it and issues a
new one — combined with reuse detection to catch theft.

## Decision

Every refresh belonging to the same login (a "rotation family",
identified by `familyId`) forms a chain: presenting refresh token N
retires it and issues N+1 in the same family. If token N is EVER
presented again after being retired, this is treated as proof the family
is compromised, and the entire family is revoked immediately.

## Rationale

- **Detects theft, not just prevents indefinite reuse.** Without
  rotation, a stolen refresh token is simply usable by the attacker for
  its full 7-day lifetime with no way to distinguish attacker traffic
  from legitimate traffic. With rotation, the FIRST party (attacker or
  legitimate user) to present token N gets a valid N+1; the SECOND party
  to present token N (now retired) triggers detection — this is a
  real, actionable signal that theft occurred, not just a best-effort
  reduction in exposure window.
- **Revoking the whole family, not just the reused token, is the
  correct response.** If token N was stolen, the attacker's session
  (which has now been issued N+1 the FIRST time N was presented, if the
  attacker won the race) is indistinguishable at the DB level from the
  legitimate user's session at that point — the family itself must be
  considered compromised, not just the specific token that got reused.
- **`familyId` is per-login, not per-user.** Revoking a compromised
  family logs out only the sessions descended from that specific login,
  not every device the user is logged in on — an attacker who steals one
  session's refresh token doesn't get to force a global logout as a side
  effect of triggering detection (which would itself be a minor DoS
  vector if it applied user-wide).

## Consequences

- A genuine race condition exists: if both a legitimate client and an
  attacker present the SAME refresh token nearly simultaneously (e.g.
  network retry logic re-sending token N right as the server is
  processing a first request for N), one gets N+1 and the other
  legitimately triggers "reuse detected" and gets logged out along with
  the real attacker (if there is one) — this is an accepted false-
  positive cost of the security property, not a bug. Client retry logic
  should avoid blindly re-sending a refresh request that may have
  already succeeded server-side.
- Every refresh token still needs storing (hashed) and looking up by
  hash on every refresh call — this is a DB round trip rotation-based
  designs require that a non-rotating "just check a signature" scheme
  wouldn't, an accepted cost given refresh tokens aren't on the hot path
  the way access-token verification is (every request vs. once per
  ~15 minutes).

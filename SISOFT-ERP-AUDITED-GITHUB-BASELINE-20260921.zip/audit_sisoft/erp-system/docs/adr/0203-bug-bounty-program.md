# 0203: Bug Bounty Program — Staged Rollout, Not Day-One Public

## Status
Accepted

## Context
Launching a public bug bounty immediately at product launch risks
overwhelming the team with low-quality reports before the triage
process is proven, and is redundant with the required pre-launch pen
test.

## Decision
Sequence: pass the pre-launch external pen test first → launch a
private/invite-only bounty on HackerOne (or similar) → open to public
after 1-2 clean private cycles. Reward tiers: Critical $5,000 / High
$2,000 / Medium $500 / Low $100. Production scope only, never staging.

## Consequences
- Delays public bounty availability, but reduces the risk of an
  unmanageable flood of reports before the team has practiced the
  triage workflow.
- Production-only scope means researchers test against real (if
  synthetic-account) data — requires care that test accounts are
  clearly isolated from real customer tenants.

# ADR 0006: Optimistic locking via a `version` column

## Status
Accepted.

## Context

The master spec (A8) requires optimistic locking on every entity: two
users editing the same record concurrently should not silently
last-write-wins overwrite each other's changes. The alternative,
pessimistic locking (`SELECT ... FOR UPDATE`), would require holding a
database row lock for the entire duration a user has a record open in a
UI form — unworkable for a web application where "open in a form" can
last minutes and the user might never submit at all.

## Decision

Every mutable tenant-scoped table has an integer `version` column,
starting at 1. A DB trigger (`touch_updated_at_and_version` in
`prisma/raw-sql/02-rls-and-triggers.sql`) increments it — and bumps
`updatedAt` — on every `UPDATE`, unconditionally, as a single source of
truth. A service that wants optimistic-lock protection includes the
client's last-known version in its `UPDATE ... WHERE id = ? AND version =
?`, and checks whether any row was actually affected:

```ts
const result = await tx.someModel.updateMany({
  where: { id, version: expectedVersion },
  data: { ...changes },
});
if (result.count === 0) {
  throw new ConflictException('This record was changed by someone else — reload and try again.');
}
```

`optimisticLock.test.ts` proves both halves of this: a stale `version` in
the `WHERE` clause affects zero rows (the conflict case), and the current
`version` affects exactly one row.

## Rationale

- **The trigger is the single source of truth for incrementing.** An
  earlier design considered incrementing `version` in application code
  (in the Prisma tenant-scoping extension) as well as via the trigger.
  Rejected: two independent places incrementing the same counter invites
  drift if they're ever out of sync (one path forgets, or the extension
  and a raw SQL update disagree about whose job it is). The DB trigger
  fires on every `UPDATE` however it's issued — via Prisma, via a raw SQL
  migration touching data, via a future non-Prisma service — so it's the
  only place that can't be bypassed by construction.
- **Application code owns the actual conflict *decision*.** The DB
  guarantees the counter is accurate; only a service layer with business
  context can decide what "conflict" should mean for a given entity (some
  fields might be safe to merge rather than reject outright). This ADR
  and its trigger deliberately don't make that decision — see the note in
  `optimisticLock.test.ts` explaining there's no generic "update service"
  in M2 to bake a conflict policy into yet.

## Consequences

- Every business-module service (M5+) that performs an update needs to
  read the current `version` before writing and pass it back in the
  `WHERE` clause — this is a pattern each module's service layer must
  apply consistently; nothing at the schema or trigger level forces a
  caller to check it (a plain `update({ where: { id } })` with no version
  in the `WHERE` clause will succeed and silently overwrite regardless of
  version — the protection only exists where a caller opts into it by
  including `version` in the filter).
- Clients (the frontend) need to carry the `version` value from whatever
  they last fetched and resubmit it with their update request, which is a
  real API contract requirement for every business-module endpoint that
  will need documenting when those endpoints exist.

# 0196: Secrets in Vault + HSM, Never Plaintext

## Status
Accepted

## Context
The amendment requires the control plane to be the highest-security
tier, including HSM-backed key storage, while customer environments
need independent, contained security postures.

## Decision
- All application secrets (DB credentials, API keys, encryption keys)
  live in HashiCorp Vault, retrieved at runtime via Kubernetes-native
  auth for services and OIDC for human operators.
- Control-plane cryptographic keys specifically use HSM (AWS CloudHSM/
  Azure Managed HSM, per cloud provider) rather than Vault's software
  Transit engine, per the amendment's "highest security" requirement.
- Customer environments use Vault only, unless a specific enterprise
  contract requires dedicated HSM.

## Consequences
- No secret ever appears in source code, image layers, or env var
  defaults — enforced by secret-scanning (gitleaks/trufflehog) in CI
  and pre-commit.
- HSM adds operational complexity (manual cluster activation, higher
  cost) — scoped narrowly to control-plane keys specifically, not
  applied everywhere, to keep this proportionate.
- Requires the actual Vault client wiring in application code, which
  is a known gap in this delivery (see MANIFEST.md) — policies and
  auth config are ready, the runtime integration is not yet built.

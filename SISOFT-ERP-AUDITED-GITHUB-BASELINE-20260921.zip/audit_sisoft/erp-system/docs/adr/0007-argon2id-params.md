# ADR 0007: argon2id for password hashing, with configurable cost params

## Status
Accepted.

## Context

The master spec (S9) requires Argon2id password hashing. Argon2 has three
tunable cost parameters — memory, time (iterations), and parallelism —
and the "right" values depend on the deployment's actual hardware, which
this codebase cannot know in advance.

## Decision

Use `argon2id` (the hybrid variant — resistant to both GPU cracking and
side-channel attacks, unlike pure `argon2i` or `argon2d`) via the
`argon2` npm package (native bindings, not a pure-JS fallback). Default
cost parameters: memory 19456 KiB (~19 MB), time cost 2, parallelism 1 —
OWASP's current baseline recommendation for interactive login — but every
value is read from `ARGON2_MEMORY_KIB`/`ARGON2_TIME_COST`/
`ARGON2_PARALLELISM` env vars, not hardcoded.

## Rationale

- **argon2id over bcrypt/scrypt**: Argon2 won the Password Hashing
  Competition and is the current OWASP recommendation; bcrypt's fixed
  memory cost makes it comparatively weaker against modern GPU attacks
  at equivalent wall-clock hashing time.
- **Configurable, not fixed, cost params**: this codebase runs anywhere
  from a $20/month single-VPS deployment to a dedicated Kubernetes
  cluster (master spec's Tier 0 through Tier 4 budget ranges) — a cost
  setting tuned for enterprise hardware could make login unacceptably
  slow on a small VPS, and a setting tuned for a small VPS wastes
  available security margin on bigger hardware. Making this an env var
  lets each deployment tune it (and re-tune it) without a code change.
- **Minimum 12-char password length + a starter common-password
  denylist** (not just the hash algorithm) — an attacker who obtains a
  hash still benefits from Argon2id's cost only up to the point the
  underlying password was actually crackable at all; weak passwords stay
  weak regardless of hash cost.

## Consequences

- Higher `ARGON2_MEMORY_KIB`/`ARGON2_TIME_COST` directly increases login
  latency and server memory pressure under concurrent login load —
  operators must actually load-test their chosen values against their
  real hardware, not just copy OWASP's baseline blindly (which is a
  starting point, not a guarantee for every deployment).
- Changing these values does NOT invalidate existing password hashes —
  argon2's hash output encodes its own parameters, so `argon2.verify()`
  works against a hash created with different settings; only NEW hashes
  use the current env values. No migration is needed to change cost
  params going forward.
- The common-password denylist shipped in this slice
  (`auth.constants.ts`) is a small, illustrative starter set, not the
  full "top 10k" list the spec envisions — see that file's comment for
  why, and the follow-up needed to wire a real one.

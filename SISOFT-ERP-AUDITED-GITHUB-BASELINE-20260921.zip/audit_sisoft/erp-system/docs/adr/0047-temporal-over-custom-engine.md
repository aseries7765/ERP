# ADR-0047: Temporal over a fully custom durable executor

## Status
Accepted (design), unverified in this delivery — see MANIFEST.md.

## Context
Workflow instances must survive API restarts (G17) and run for days/
weeks (SLA-driven approvals). Building durability from scratch means
reimplementing crash-safe checkpointing, retries, and timers — Temporal
already solves this class of problem.

## Decision
Use Temporal.io as the primary durable-execution engine, with the
DB-backed `InProcessEngine` as a documented fallback when
`TEMPORAL_ADDRESS` is unset, per the amendment's own instruction. Both
implementations sit behind one `WorkflowEngine` interface
(`engine/engine.interface.ts`) and share the same step-dispatch core
(`@erp/workflow-engine`'s `runToNextPause`), so the choice of backend
doesn't change step semantics.

## Consequences
- `TemporalEngine` could not be built against the real `@temporalio/*`
  SDK in this delivery (no network access in the build sandbox) — it's
  a reviewed design sketch that throws on every method, not working
  code. `InProcessEngine` is what actually runs.
- Because both implementations share `runToNextPause`, migrating to a
  verified Temporal adapter later is a bounded change (wrap the same
  function in activities), not a rewrite.

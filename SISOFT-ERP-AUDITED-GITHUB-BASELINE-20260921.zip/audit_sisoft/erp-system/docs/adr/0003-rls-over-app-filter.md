# ADR 0003: Row-Level Security over application-level tenant filtering

## Status
Accepted.

## Context

Given shared-schema multi-tenancy (ADR 0002), tenant isolation has to be
enforced *somewhere*. The two options: (a) discipline in application
code — every repository method remembers to add `WHERE tenantId = ?`; or
(b) Postgres Row-Level Security, where the database itself refuses to
return or mutate rows outside the current tenant, regardless of what the
query asked for.

## Decision

RLS is the enforcement of last resort and the one this project actually
trusts. Application-level filtering (the `tenant-scoping.extension.ts`
Prisma Client extension) exists too, but as defense-in-depth and
better-error-messages, not as the real security boundary.

## Rationale

- **A missed `WHERE` clause in app code is a silent, exploitable bug.** In
  a codebase this large (24 modules, many contributors over 18–36 months
  per the master spec's own timeline), the question isn't whether someone
  eventually forgets a tenant filter — it's when, and whether it's caught
  in review or in production. RLS makes the failure mode "the query
  returns zero rows" instead of "the query returns another tenant's
  rows".
- **RLS survives raw SQL, ORM changes, and future services.** If a future
  reporting service, a database console session, an ad-hoc script, or a
  completely different ORM ever touches this database, application-level
  filtering built into one Prisma extension does nothing for it. A DB-
  level policy applies no matter what's connecting.
- **The failure mode is safe by default.** Section `docs/db/RLS.md`
  explains the actual mechanism: `tenantId = get_current_tenant()` where
  the right-hand side is `NULL` when unset, and `x = NULL` is never
  `TRUE` — so forgetting to set context fails closed (zero rows), not
  open (all rows).

## Why the application-level extension exists anyway

Two reasons, neither of which is "because we don't trust RLS":

1. **Better failure messages during development.** RLS silently returning
   zero rows looks identical to "this record doesn't exist" — genuinely
   confusing to debug. The extension throws an explicit error naming the
   model and operation when tenant context is missing, well before the
   query would even reach Postgres.
2. **Convenience.** Auto-filling `tenantId`/`createdBy`/`updatedBy` on
   create saves every future service from repeating that boilerplate.
   This is ergonomics, not security — RLS's `WITH CHECK` behavior (see
   `docs/db/RLS.md`) would reject a wrong `tenantId` on insert regardless
   of whether the extension caught it first.

## Consequences

- The application connects as a non-superuser, non-`BYPASSRLS` role
  (`erp_app`) — see ADR 0002's operational note and
  `docs/db/MULTI_TENANCY.md`'s role-split section. This ADR's guarantee
  is void if the app ever connects as a role that bypasses RLS; that's
  why `test-db.helper.ts` refuses to run the RLS test suite against
  anything but `APP_DATABASE_URL`.
- Legitimate cross-tenant access (platform-admin tooling) needs an
  explicit, logged bypass path (`PrismaService.withBypassRls()`) rather
  than simply not filtering — see `docs/db/RLS.md`'s bypass section.

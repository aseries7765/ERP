# 0195: SSRF Prevention via URL Allowlist

## Status
Accepted

## Context
Features that make outbound HTTP requests based on user input
(webhook targets, "import from URL" features) are a classic SSRF
vector, especially dangerous in cloud environments with a metadata
endpoint (169.254.169.254) that can leak credentials.

## Decision
Require every such outbound call to pass through `checkOutboundUrl()`:
HTTPS-only, hostname must be in an explicit allowlist, and any literal
IP is checked against RFC1918/link-local/loopback ranges and the cloud
metadata IP specifically.

## Consequences
- Outbound integrations require an allowlist entry — slightly more
  friction when adding a new legitimate integration, in exchange for
  closing off the SSRF vector by default (deny-by-default posture).
- Does NOT protect against DNS rebinding on its own (see SSRF.md) —
  connect-time IP pinning still needs to be added at the HTTP client
  level, tracked as a follow-up.
- Chosen over a blocklist approach (block known-bad hosts) because
  allowlists are the only sound default for this class of risk.

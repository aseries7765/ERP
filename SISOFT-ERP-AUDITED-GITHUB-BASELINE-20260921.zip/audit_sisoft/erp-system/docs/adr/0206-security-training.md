# 0206: Mandatory Security Training Curriculum

## Status
Accepted

## Context
Many security incidents stem from preventable human error (committed
secrets, phishing, unsafe handling of sensitive data) rather than
sophisticated attacks. Technical controls alone don't address this.

## Decision
Require baseline secure-coding and secrets-hygiene training for all
engineers, incident-response playbook familiarity for on-call
engineers specifically, and break-glass procedure training for anyone
with control-plane admin access.

## Consequences
- Reduces the likelihood of preventable incidents (committed secrets,
  social-engineering susceptibility).
- Training completion needs to be tracked (feeds SOC 2 evidence) —
  no tracking system is built in this delivery; this is a curriculum
  outline, not a delivered LMS integration.

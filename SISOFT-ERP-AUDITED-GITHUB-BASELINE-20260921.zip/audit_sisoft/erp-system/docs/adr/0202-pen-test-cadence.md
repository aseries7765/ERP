# 0202: Pen Test Cadence — Internal Semi-Annual, External Annual

## Status
Accepted

## Context
Continuous automated scanning (SAST/DAST/SCA) catches known
vulnerability classes but misses business-logic flaws and novel attack
chains that require a human tester's creativity.

## Decision
Internal (in-house) pen test every 6 months using the methodology and
checklists in `tools/pentest/`. External (third-party) pen test
annually, plus once specifically before initial launch, with broader
scope including social engineering.

## Consequences
- Provides regular, structured human-driven testing beyond what
  automation catches, at a predictable cadence.
- External annual testing has a real cost (vendor fees) — budgeted as
  an ongoing operational expense, not a one-time launch cost.
- The pre-launch external test is a hard gate (G10) — launch should
  not proceed without it, per LAUNCH_CHECKLIST.md.

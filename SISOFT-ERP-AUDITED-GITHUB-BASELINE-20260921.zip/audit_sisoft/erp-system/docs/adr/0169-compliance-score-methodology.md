# ADR 0169: Compliance score methodology

## Status
Accepted (implemented and tested)

## Context
Need a single 0-100 number per framework that reflects implementation
progress, testing coverage, control effectiveness, and open regulatory
risk (findings), without any single dimension dominating unfairly.

## Decision
Base score (0-100) = 40% control-implementation-rate + 30%
control-testing-rate + 30% average-control-effectiveness. Open findings
then apply a *separate* deduction of up to 10 additional points, scaled
by severity-weighted finding count, saturating at 20 severity-weighted
points (e.g. 5 critical findings, weight 4 each). This keeps the base
score's own weights summing cleanly to 100 and the findings penalty as a
bounded adjustment on top, rather than folding the penalty into the same
weighted sum (an earlier draft did this and had a bug — see MANIFEST.md —
where the weights summed to only 90, capping the maximum achievable score
at 90 even for a perfectly compliant framework).

## Consequences
A framework with zero controls returns a score of 0, not undefined/NaN —
callers don't need a null check. Scores are always in [0, 100].

# ADR 0011: API keys shown in plaintext exactly once

## Status
Accepted.

## Context

Machine-client API keys need to be presentable by the client on every
request (unlike a password, which is only sent once per login to
establish a session). This means the plaintext key must be memorable/
storable by the client, but the server still needs a way to verify a
presented key without being able to leak the original value if the
database is compromised.

## Decision

`ApiKeyService.create()` returns `{ id, plainKey, prefix }` — `plainKey`
is the actual usable credential, generated as
`erp_<env>_<32 random bytes base64url>`, and is NEVER stored anywhere.
Only `keyHash` (SHA-256 of the plaintext) and `keyPrefix` (the first 8
characters of the PLAINTEXT, for display/recognition) are persisted.
`list()`'s Prisma query doesn't select `keyHash` at all — it structurally
cannot leak it, not just by convention.

## Rationale

- **`<env>` segment in the key format** (`erp_live_...` vs `erp_test_...`)
  lets a leaked key be immediately triaged by severity in a log line or
  incident report without decoding or looking anything up — a small but
  real operational win borrowed from the same pattern Stripe and similar
  API-key-issuing services use.
- **`keyPrefix` stored separately from `keyHash`** solves a real UX
  problem: a user with 5 API keys named "CI", "staging", "prod-1" etc.
  needs to visually distinguish them in a list without the server ever
  re-exposing the full key. Deriving a "prefix" from the HASH (an
  earlier draft of this code did this) doesn't work for that purpose —
  a hash's first 8 characters are meaningless to a human recognizing
  their own key. Storing the plaintext's actual prefix separately (never
  the full plaintext) is a deliberate additional column
  (`ApiKey.keyPrefix`, added this slice) purely for this UX reason.
- **No "regenerate in place" operation** — see RUNBOOK.md's key-rotation
  procedure. Create-new-then-revoke-old is simpler to reason about and
  avoids ever needing to hold or re-derive a plaintext value after
  initial creation.

## Consequences

- A user who loses a freshly-created key before copying it down has no
  recovery — they must revoke it and create a new one. This is the
  correct, expected tradeoff (the alternative is storing something that
  makes the plaintext recoverable, which defeats hashing it at all).
- `scopes` are stored and returned but NOT YET enforced against any
  action (no authorization layer exists until RBAC, Slice 3.3) — flagged
  explicitly in `THREAT_MODEL.md`'s API-keys section as a current,
  real limitation rather than a solved problem.

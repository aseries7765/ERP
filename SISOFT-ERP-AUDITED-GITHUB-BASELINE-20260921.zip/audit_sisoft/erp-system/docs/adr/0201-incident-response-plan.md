# 0201: Incident Response Process and Roles

## Status
Accepted

## Context
Without a predefined process, incident response tends to be ad hoc,
slower, and prone to missing regulatory notification deadlines (GDPR
72h, HIPAA's own timeline).

## Decision
Adopt a standard six-phase process (detect, triage, contain, eradicate,
recover, review) with four defined roles (Incident Commander,
Communications Lead, Technical Lead, Scribe), documented in
INCIDENT_RESPONSE.md, with scenario-specific playbooks for the most
likely incident types.

## Consequences
- Gives responders a clear structure to fall back on under pressure,
  rather than inventing process during an active incident.
- Requires role coverage on the on-call rotation (someone able to act
  as IC at any hour) — an organizational commitment beyond this
  module's code.
- The process is documented but not automated — no code enforces phase
  transitions or role assignment; the `SecurityIncident` Prisma model
  provides a place to record state, but the state-machine service
  itself isn't built (see MANIFEST.md).

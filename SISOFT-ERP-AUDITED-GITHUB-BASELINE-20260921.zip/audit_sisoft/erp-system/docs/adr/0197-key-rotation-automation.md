# 0197: Automated Key Rotation with Dual-Key Grace Periods

## Status
Accepted

## Context
Static, never-rotated keys are a common finding in security audits
and increase blast radius if a key is ever compromised without
detection.

## Decision
Rotate JWT signing keys, encryption keys, and DB credentials on a
90-day cadence (60 days for TLS certs, via cert-manager). Use a
dual-key grace period: the new key is used for new operations
immediately, while the old key remains valid for decrypt/verify until
all data encrypted under it has been re-encrypted.

## Consequences
- Rotation doesn't require a "flag day" cutover that risks breaking
  in-flight operations — smoother rollout.
- Requires tracking key versions (`KeyRotationTracker`) and knowing
  when it's safe to fully retire an old key (all ciphertext migrated).
- The actual scheduled rotation jobs and re-encryption pipeline are
  not implemented in this delivery — only the tracking state machine
  is; see KEY_ROTATION.md.

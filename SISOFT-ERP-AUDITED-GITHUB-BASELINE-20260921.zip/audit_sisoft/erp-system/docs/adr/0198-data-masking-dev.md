# 0198: Data Masking in Dev/Staging Environments

## Status
Proposed (not yet implemented)

## Context
Copying production data to dev/staging for debugging/testing is
common practice but risks exposing real customer PII/PHI to a broader
set of engineers and a less-hardened environment.

## Decision
Any production-to-staging data copy must pass through a masking
pipeline that replaces PII/PHI fields with synthetic-but-realistic
values before the copy is usable in staging.

## Consequences
- Removes a large class of accidental-exposure risk (engineer laptop
  with a staging DB dump, less-monitored staging environment).
- Requires building the actual masking pipeline, which depends on
  knowing the full schema across all business modules — not built in
  this isolated slice (see DATA_MASKING.md). Marked "Proposed" rather
  than "Accepted" for this reason — implementation ownership needs to
  be assigned to whoever owns the staging data-refresh process.

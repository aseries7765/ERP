# ADR-0049: Script actions require true V8-isolate sandboxing

## Status
Accepted (design); NOT implemented as working code in this delivery —
see MANIFEST.md and SECURITY.md.

## Context
G16 requires the script action be "truly isolated — no exceptions": no
`require`/`import`, no ambient globals, no filesystem, no network,
100ms timeout. Node's built-in `vm` module shares the host process's V8
heap and global object prototype chain and is explicitly documented by
Node itself as NOT a security boundary. `eval()`/`new Function()` are
equivalently unsafe.

## Decision
Require `isolated-vm` (true separate V8 isolates) for the script
action. `apps/api/workflow.dependencies.json` lists it as a required
new dependency for the merge captain to install.

## Consequences
`isolated-vm` could not be installed in the build sandbox (no network
access), so `action.service.ts#script` currently throws a clear error
naming this constraint rather than shipping a `vm`-based fallback that
would silently violate G16. This is a real scope cut, not an oversight
— see MANIFEST.md "Known limitations."

# 0191: Zero-Trust Architecture

## Status
Accepted

## Context
The SaaS amendment introduces a control plane that can orchestrate
isolated customer environments. Network-perimeter-based trust ("inside
the VPC = trusted") is insufficient once the platform itself has this
much blast-radius potential if compromised.

## Decision
Adopt zero-trust principles: no implicit trust from network location,
mTLS between control plane and customer environments, least-privilege
Vault policies per service, and per-request (not per-session-only)
validation of authorization state.

## Consequences
- Every service-to-service call needs its own identity and auth, not
  just "it's on the internal network" — more upfront complexity.
- Compromise of one component doesn't automatically grant access to
  others, containing blast radius as required by the amendment.
- Depends on M14's service mesh (Istio) for mTLS enforcement — this
  module documents the requirement but doesn't implement the mesh.

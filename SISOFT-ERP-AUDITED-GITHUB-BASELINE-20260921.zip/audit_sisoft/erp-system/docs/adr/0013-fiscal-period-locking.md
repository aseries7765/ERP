# ADR 0013: Fiscal periods lock explicitly, independent of Finance's own schema

## Status
Accepted.

## Context

Financial audit integrity requires that once a period is "closed" in the
accounting sense, no one can backdate a new entry into it without an
explicit, logged, admin-level override. This control conceptually
belongs to Finance (module 16), but Finance's own schema (journal
entries, the general ledger) doesn't exist yet — this slice only owns
Tenancy's schema (FiscalYear/FiscalPeriod).

## Decision

`FiscalPeriod.status` (`OPEN`/`LOCKED`/`CLOSED`) and the lock/unlock
state machine live in Tenancy now, built and tested as real, working
logic — not deferred as a stub waiting for Finance. `assertNotLocked()`
is the enforcement primitive Finance will call before posting anything
dated within a period; this slice implements and unit-tests that
function even though nothing calls it in anger yet.

## Rationale

- **The lock STATE is a Tenancy concern; the ENFORCEMENT is a Finance
  concern** — a fiscal period existing and having a lock status doesn't
  require journal entries to exist first. Building the state machine now
  means Finance's eventual journal-entry service has a real, tested
  dependency to call rather than needing to build its own period-locking
  logic duplicated across modules.
- **Cannot lock a future period** — locking is meant to close off a
  period that's ended (or is ending); locking a period that hasn't
  started yet has no accounting meaning and would block legitimate
  advance-dated setup entries. This is enforced in code
  (`FiscalPeriodService.lock()` checks `startDate > now`), not left as a
  documentation-only rule a future caller might forget.
- **Unlock always requires a reason and is always audited** — an
  unlocked, previously-closed period is exactly the scenario where "who
  did this and why" matters most (a genuine correction vs. someone
  hiding a backdated adjustment). The `reason` parameter is required at
  the type level (`UnlockFiscalPeriodDto`), not optional.

## Consequences

- Until Finance actually calls `assertNotLocked()` from a real
  journal-entry endpoint, LOCKING A PERIOD HAS NO ENFORCED EFFECT on
  anything — it's a real, correctly-implemented state that nothing
  currently checks. This is explicitly not the same as "locking doesn't
  work" — the mechanism is real and tested
  (`fiscal-period.service.spec.ts`); it simply has no caller yet, the
  same honest situation as Auth's rate-limited endpoints having no
  traffic to rate-limit before a frontend exists.
- Every future module that writes anything with a fiscal-period-relevant
  date (not just Finance — Payroll, Projects, anything with a "posting
  date") should consider calling `assertNotLocked()` too, not just
  Finance narrowly — this ADR's scope is the mechanism, not a closed list
  of callers.

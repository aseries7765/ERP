# ADR 0015: Department tree uses a recursive CTE, not nested sets

## Status
Accepted.

## Context

`Department` is a self-referencing hierarchy (via `parentId`) that needs
three query patterns: get the full tree (or a subtree), get a node's
ancestors, get a node's descendants. Two well-known approaches exist:
(a) a recursive query (Postgres `WITH RECURSIVE`) over a plain
adjacency-list (`parentId`) column, or (b) a nested-set model (storing
precomputed `left`/`right` bounds that encode the whole tree's shape in
each row).

## Decision

Adjacency list (`Department.parentId`, already the M2 schema's shape) +
`WITH RECURSIVE` CTEs in `OrgTreeService`, with a Redis cache (5-minute
TTL, actively invalidated on every `department.changed` event) sitting in
front of the expensive recursive query.

## Rationale

- **Nested sets make writes expensive; this tree is write-light,
  read-heavy, but not read-CONSTANT.** Nested sets excel when the tree
  is read far more often than written and reads must avoid recursion
  entirely (e.g., rendering a huge, deep category tree on every page
  load with no caching layer available). Moving a subtree in a nested-set
  model requires recalculating `left`/`right` for every node in and
  after the moved subtree — a department move here is a single
  `UPDATE ... SET "parentId" = ?` in the adjacency-list model, with all
  the cycle-detection complexity already isolated in
  `DepartmentService.move()`'s application-level walk.
- **A cache in front of a recursive CTE captures nested-sets' main
  advantage (fast reads) without its write-complexity cost.** A
  department tree changes rarely relative to how often it's read (org
  charts, dropdown pickers, permission-scope checks) — cache invalidation
  tied to an actual `department.changed` event (not a blind TTL) means
  cached reads are correct, not just fast, and writes stay simple.
- **Postgres handles recursive CTEs well** at the row counts an org chart
  actually has (hundreds to low thousands of departments per tenant, not
  millions) — this isn't a case where nested sets' write complexity is
  bought back by a read-performance requirement adjacency-list-plus-cache
  can't also meet.

## Consequences

- Every `getTree()` call is either a cache hit (fast) or a full recursive
  CTE scan (adequate at real org-chart scale, not benchmarked against a
  live database in this sandbox — see the M3.2 session's standing
  caveat that nothing here has executed against real Postgres yet).
- Cache invalidation is by `tenantId` prefix (`orgtree:<tenantId>:*`),
  not per-node — any department change in a tenant invalidates that
  tenant's ENTIRE cached tree, not just the affected subtree. This is a
  deliberate simplification: partial invalidation (only the affected
  root's cached entries) would need tracking which cached queries
  actually included the changed node, which is real additional
  complexity for a cache with a 5-minute TTL and department changes that
  are rare events, not a hot path.
- If a tenant's department count ever grows large enough that the
  recursive CTE itself (not just cache misses) becomes slow, the fix is
  adding an index-friendly materialized-path column ALONGSIDE the
  adjacency list (not replacing it) — a real future option, not
  pre-built here without evidence it's needed.

# 0204: SBOM Generation and SLSA Provenance Target

## Status
Accepted (SBOM), Deferred (SLSA Level 3)

## Context
Supply-chain attacks (compromised dependencies, compromised build
pipelines) are increasingly common; the org needs both visibility
(what's actually in our software) and provenance (proof of how it was
built).

## Decision
Generate an SPDX-format SBOM via Syft on every build, published as a
CI artifact and matched against known vulnerabilities via Grype. Sign
container images with Cosign (keyless, tied to CI's OIDC identity).
Target SLSA Level 3 provenance as a longer-term goal.

## Consequences
- SBOM gives fast "are we affected" answers during a supply-chain
  incident (see IR_PLAYBOOKS/supply-chain.md).
- SLSA Level 3 specifically requires a dedicated reusable-workflow
  integration (`slsa-framework/slsa-github-generator`) not built in
  this delivery — deferred, tracked as a real gap (see SLSA.md), not
  claimed as done.
- Cosign signing without a corresponding admission-control policy that
  verifies signatures at deploy time provides less protection than
  intended — that enforcement piece is also not yet built.

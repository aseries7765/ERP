# 0192: Security Headers via Nonce-Based CSP

## Status
Accepted

## Context
Content-Security-Policy needs to block inline script injection (XSS)
without breaking legitimate server-rendered inline scripts, and
without resorting to `unsafe-inline`, which defeats the purpose.

## Decision
Generate a cryptographically random nonce per request
(`SecurityHeadersMiddleware`), include it in the CSP `script-src`/
`style-src` directives, and require any legitimate inline script/style
to carry the matching `nonce` attribute.

## Consequences
- Any inline script without the correct nonce (including an
  attacker-injected one) is blocked by the browser.
- Server-rendered pages must thread the nonce through to any inline
  `<script>` tags they emit (`res.locals.cspNonce`) — a small
  integration cost for whichever templating/SSR layer exists.
- CSP is deployed in enforcing mode by default; `CSP_REPORT_ONLY` env
  var allows a report-only rollout period if needed when first
  enabling this on an existing app with unaudited inline scripts.

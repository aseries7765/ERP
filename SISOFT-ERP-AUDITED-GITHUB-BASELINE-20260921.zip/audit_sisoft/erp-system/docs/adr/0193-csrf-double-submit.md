# 0193: CSRF via Double-Submit Cookie (HMAC-Bound)

## Status
Accepted

## Context
Need CSRF protection that's stateless (no server-side token storage,
for horizontal scalability) but still resistant to token theft/replay
across sessions.

## Decision
Double-submit cookie pattern where the token is `nonce.HMAC(sessionId
+ nonce, serverSecret)`. Verified by checking cookie === header AND
re-deriving the HMAC against the current session ID.

## Consequences
- No server-side token storage needed (stateless, scales horizontally).
- A token can't be replayed against a different session, unlike a
  naive double-submit implementation that just compares cookie to
  header without binding to session identity.
- Requires `CSRF_SECRET` to be a real secret managed via Vault, not a
  weak default — documented in `security.env.example`.
- SameSite=Strict on the cookie is a prerequisite; this doesn't
  replace that setting, it supplements it for defense in depth (e.g.
  against SameSite=Lax browsers/edge cases).

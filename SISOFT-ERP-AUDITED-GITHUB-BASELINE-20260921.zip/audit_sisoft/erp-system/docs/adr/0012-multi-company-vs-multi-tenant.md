# ADR 0012: Company is a separate level from Tenant (multi-company-per-tenant)

## Status
Accepted.

## Context

A tenant signing up might be a single small business (one legal entity)
or a holding structure with several subsidiaries that need to share
users, billing, and a login, but keep separate books, tax IDs, and fiscal
years. The system needs to decide whether "company" is the same concept
as "tenant," or a distinct level underneath it.

## Decision

`Company` is a separate model from `Tenant`, with a `tenantId` foreign
key — a tenant has one-to-many companies. Provisioning always creates
exactly one company (named after the tenant) automatically; additional
companies are an explicit, later action.

## Rationale

- **One subscription, several legal entities** is a real, common business
  shape (see `MULTI_COMPANY.md`'s holding-company example) that "tenant =
  company" cannot express without either (a) forcing 3 separate tenant
  signups for one business relationship, fragmenting billing and login,
  or (b) cramming multiple legal entities' data into one company record,
  losing the separate tax ID/fiscal year/base currency each legal entity
  actually needs.
- **RLS isolation is at the tenant level, not the company level** — this
  was already decided in ADR 0002/0003 (M2). Company being a child of
  Tenant means multi-company tenants get correct cross-company visibility
  for free (same `tenantId`, same RLS policy) without needing a SEPARATE
  isolation mechanism between companies within one tenant.
- **This also fixed a real bug in an earlier field.** `Tenant.status` was
  typed as `UserStatus` through M2 — a reused enum whose
  `PENDING_VERIFICATION` value makes no sense for a tenant. This slice
  replaced it with a dedicated `TenantStatus` enum
  (`ACTIVE`/`SUSPENDED`/`ARCHIVED`) plus `suspendedAt`/`suspendedReason`/
  `archivedAt` fields — caught while building `TenantService`, fixed
  rather than worked around, and noted here because it's the same kind of
  "found a schema gap mid-slice, fixed it with a migration note" pattern
  this project has followed since M2.

## Consequences

- Per-company access control (a user granted access to SOME but not all
  companies under a tenant) has no dedicated grant table yet — flagged
  explicitly in `MULTI_COMPANY.md` and `CompanyScopeGuard`'s doc comment
  as a real, current gap rather than solved by this ADR. RLS protects
  cross-TENANT access; it does nothing for cross-COMPANY access within
  one tenant, by design (they share a `tenantId`).
- Every company-scoped resource (Branch, FiscalYear, Department via
  Branch) carries its own `companyId` or `branchId`, not just `tenantId`
  — this is what lets future consolidated reporting (M8) roll up multiple
  companies' data without ambiguity about which company a given
  Department or FiscalYear belongs to.

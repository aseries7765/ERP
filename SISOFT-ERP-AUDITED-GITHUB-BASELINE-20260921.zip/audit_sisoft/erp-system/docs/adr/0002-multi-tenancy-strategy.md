# ADR 0002: Shared schema + `tenantId` + RLS for multi-tenancy

## Status
Accepted for the default tier; see "Future tiers" below for the escape
hatch the master spec also requires.

## Context

The master spec requires supporting tenants from a single solo user up to
enterprise groups with 10,000+ legal entities, and names four possible
multi-tenancy models: shared schema with a tenant column, schema-per-
tenant, database-per-tenant, and cluster-per-tenant (for regulated
industries). Only one of these can be the *default* architecture that
every one of the 83 foundation tables is built against from day one.

## Decision

Default: **shared schema, every tenant-scoped table has a `tenantId`
column, isolation enforced by Postgres Row-Level Security** — not by
application code remembering to add `WHERE tenantId = ?` to every query.

## Rationale

- **One codebase, one migration history, one connection pool** for the
  overwhelming majority of tenants (SMB/mid-market), which is the
  majority of the target market per the master spec's own Q3 answer.
  Schema-per-tenant or DB-per-tenant multiplies migration and connection-
  pool operational complexity by the tenant count — appropriate for a
  handful of enterprise/regulated tenants, not for tenant #1 through
  #10,000.
- **RLS over "always remember the WHERE clause" (see ADR 0003)** because
  the cost of one missed filter in application code, across a system this
  large with many future contributors, is a cross-tenant data leak — the
  master spec explicitly requires this to be a DB-level guarantee, not an
  app-level convention ("R13: EVERY tenant-scoped query MUST include
  tenant_id filter (enforced by middleware + DB policy)").
- **Every unique constraint and foreign key includes `tenantId`**
  (`schema.prisma`'s base convention), not just the WHERE clause on reads
  — this is what actually prevents a foreign key from pointing at another
  tenant's row in the first place, independent of RLS.

## Consequences

- Every tenant-scoped table needs a `tenantId` column, an index on it, and
  an RLS policy — done once, generically, in
  `prisma/raw-sql/02-rls-and-triggers.sql`'s dynamic `DO` loop rather than
  hand-repeated 83 times.
- Queries need a transaction-scoped `app.current_tenant` setting to work
  at all under RLS — see `docs/db/MULTI_TENANCY.md` for the full
  request-to-DB path. This adds one `set_config()` call per transaction
  compared to a bare application-level filter, which is a negligible cost
  next to the correctness guarantee it buys.
- A noisy-neighbor tenant with a huge dataset shares the same tables (and
  therefore the same indexes, the same autovacuum schedule) as every
  other tenant on the shared tier. Partitioning by `tenantId` (hash) for
  specific high-row-count tables was named in the original scope and is
  explicitly deferred — see `docs/db/MIGRATION_GUIDE.md`'s "not set up
  yet" section — rather than implemented without a real database to
  verify partition behavior against.

## Future tiers (not built in M2, but this decision doesn't block them)

The master spec's Q3 answer names schema-per-tenant, DB-per-tenant, and
cluster-per-tenant as upgrade paths for mid-market/enterprise/regulated
tenants respectively. Nothing in this ADR precludes adding those later:
the `tenantId` column and RLS policy remain correct even for a tenant that
gets migrated to its own schema or database — the isolation guarantee is
additive, not replaced. That migration path (moving one tenant's rows out
of the shared tables into a dedicated schema) is real, non-trivial work
that has an actual customer to design around when it's needed, not a
speculative feature to half-build now.

# ADR 0162: Data residency enforcement

## Status
Accepted (logic implemented and tested; Prisma middleware integration not built — see MANIFEST.md)

## Context
G19 requires residency enforcement at the data layer, not just at the
API/controller layer, so a background job or internal service call can't
bypass it.

## Decision
`checkResidency` is a pure, synchronous function with no I/O, designed to
be cheap enough to call from a Prisma middleware on every write that
targets a region-scoped resource, not just from a controller guard.
Precedence order: tenant mismatch → deny; region in allow-list → allow;
matching pre-approved exception → allow; `crossBorderAllowed` policy flag
→ allow; otherwise → deny with a human-readable reason.

## Consequences
No Prisma middleware was actually wired in this delivery — the function
exists and is tested, but nothing calls it from a real data-access path
yet. This is the single highest-risk gap in this delivery relative to
G19's "must be enforced at the data layer" requirement.

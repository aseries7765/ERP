# ADR 0008: RS256 (asymmetric) over HS256 (symmetric) for access tokens

## Status
Accepted.

## Context

JWTs can be signed with a symmetric algorithm (HS256 — one shared secret
both signs and verifies) or asymmetric (RS256 — a private key signs, a
separate public key verifies). The master spec's own M3.1 scope
explicitly calls for RS256 "so future services verify without the
signing key."

## Decision

Access tokens are signed RS256. `JWT_PRIVATE_KEY` exists only where
tokens are ISSUED (this API service); `JWT_PUBLIC_KEY` is what
`JwtStrategy`/`TokenService.verifyAccessToken` actually use to verify,
and is safe to distribute to any other service that needs to check a
token's validity.

## Rationale

- **Future microservices verify without holding a secret that could
  forge tokens.** The master spec's own architecture (A1) allows
  microservices "where justified" — AI service, PDF/report generation,
  etc. Any of those, once they exist, need to verify an incoming
  request's JWT. With HS256, giving them that ability means giving them
  the SAME secret used to issue tokens — any one of those services being
  compromised lets an attacker forge valid tokens for any user, in any
  tenant. With RS256, they get only the public key: enough to verify,
  useless for forging.
- **Key compromise blast radius is smaller.** A leaked public key is a
  non-event. A leaked HS256 shared secret is a full compromise requiring
  immediate rotation and invalidation of every issued token.

## Consequences

- Slightly larger token size and slower verification than HS256 (RSA
  signature verification costs more CPU than HMAC) — negligible at this
  system's actual expected request volumes, and irrelevant next to the
  security property gained.
- Key management is now a two-file problem (private + public) instead of
  one shared secret — `.env.example` documents generation; `RUNBOOK.md`
  documents rotation.
- If a future need arises for many services to ISSUE tokens (not just
  verify them) independently, each would need its own keypair, or a
  shared private key re-introduces the same blast-radius problem RS256
  was chosen to avoid — worth revisiting with a proper JWKS/multi-issuer
  design at that point rather than pre-building it speculatively now.

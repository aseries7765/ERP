# ADR 0154: Breach 72h notification workflow

## Status
Accepted (logic implemented and tested; NestJS wiring unverified — see MANIFEST.md)

## Context
GDPR Article 33 requires notifying the supervisory authority within 72
hours of the controller becoming aware of a personal data breach, unless
unlikely to result in risk to individuals. Article 34 requires notifying
affected individuals without undue delay if the breach is high-risk.

## Decision
- The clock starts at an explicit `awareAt` timestamp, not incident
  creation time — awareness can lag discovery.
- Alert escalation at 24h/48h/60h remaining-to-elapsed thresholds, plus a
  terminal `72h_missed` state, computed by a pure function
  (`evaluateBreachTimer`) with no side effects.
- Alert de-duplication (`nextAlertToSend`) compares against the last
  alert level actually sent, so a job that runs more often than the
  alert cadence doesn't spam duplicate notifications, while still
  allowing escalation to a higher level immediately.
- Once the DPA is notified, no further alerts fire even past 72h,
  since the substantive violation (failure to notify) no longer applies.

## Consequences
The job (`jobs/breach-deadline.job.ts`, not built in this delivery) must
run frequently enough (recommended hourly) to catch each threshold — a
daily job would miss the 24h/48h/60h escalation points entirely.

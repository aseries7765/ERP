# 0209: Chaos Engineering — Staging First, Documented Game Days

## Status
Accepted

## Context
Claims about system resilience (auto-restart, failover times) are
worthless without actually testing them under controlled failure
conditions.

## Decision
Define Litmus ChaosEngine experiments for the failure modes most
relevant to this platform (pod kill, network latency/partition,
resource stress, DB/Redis failover, simulated region failure). Require
every experiment to run in staging first, with team awareness, before
any production game day, and require results to be recorded (not just
"we ran it, seemed fine").

## Consequences
- Provides real evidence for resilience claims once actually executed
  — a documented weakness compared to just asserting "the system
  self-heals."
- Requires cluster access and team coordination — genuinely running
  these experiments is future work; this delivery provides the
  experiment definitions and the runner/results template, not
  executed results (see CHAOS_TEST_RESULTS.md).

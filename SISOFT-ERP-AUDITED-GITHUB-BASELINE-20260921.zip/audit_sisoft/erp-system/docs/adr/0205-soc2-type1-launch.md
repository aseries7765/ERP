# 0205: SOC 2 Type I at Launch, Type II at 6 Months

## Status
Accepted

## Context
Enterprise customers increasingly require SOC 2 evidence before
signing. A Type II report (evidence over a period, typically 6-12
months) can't exist before the system has been operating that long,
but a Type I report (point-in-time control design assessment) can be
pursued around launch.

## Decision
Target SOC 2 Type I readiness at launch, engage an accredited firm for
the Type I audit, then accumulate the operating-effectiveness evidence
needed for a Type II report at the 6-month mark.

## Consequences
- Type I alone is a weaker signal to customers than Type II but is
  achievable on a launch timeline.
- Requires ongoing evidence collection from day one (access reviews,
  change logs, incident records) to be ready for Type II — the
  automation for this (`soc2-evidence.service.ts`) is **not built** in
  this delivery; manual evidence collection will be needed as an
  interim measure.

# 0199: Brute-Force Protection: Dual Account + IP Tracking

## Status
Accepted

## Context
Account-only lockout (5 attempts/15min) is vulnerable to an attacker
spreading attempts across many accounts from one source to avoid
per-account limits reaching a level that triggers detection; IP-only
limiting risks locking out legitimate users behind a shared corporate
NAT/VPN if one user mistypes repeatedly.

## Decision
Track both independently: 5 failed attempts/15min locks a specific
account; 20 failed attempts/15min from one IP blocks that IP
regardless of which accounts were targeted. Progressive delay
(1s/2s/4s.../30s cap) applies before either hard limit triggers.

## Consequences
- Catches credential-stuffing (many accounts, one source) via the IP
  limit, and catches targeted brute-force (one account) via the
  account limit — complementary coverage.
- The reference implementation is in-memory/single-process; production
  requires a Redis-backed version for correctness across multiple API
  pods (documented gap, not implemented here).

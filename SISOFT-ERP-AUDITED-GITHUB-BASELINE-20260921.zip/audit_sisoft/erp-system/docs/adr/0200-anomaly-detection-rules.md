# 0200: Heuristic Anomaly Detection Rules

## Status
Accepted (heuristics), Proposed (production wiring)

## Context
Perimeter/auth controls alone don't catch a compromised-but-valid
credential being used anomalously (impossible travel, odd hours, mass
export). Detecting this requires behavioral heuristics, not just
access control.

## Decision
Implement three initial heuristics: impossible travel (implied speed
between two logins exceeds physical limits), unusual login time
(statistically rare hour for that specific user, given sufficient
history), and the existing brute-force detector as a fourth signal
source. Each produces an `AnomalySignal` with a score, intended to
trigger step-up authentication (re-require MFA) rather than an
automatic hard block, to limit false-positive user disruption.

## Consequences
- Heuristics are simple and explainable (important for support/
  security-team trust in the signal) rather than an opaque ML model,
  at the cost of being less sophisticated than a full UEBA system.
- Unusual-time detection requires per-user history (minimum 10 samples
  before it activates) — cold-start users get no signal from this
  heuristic until they have login history.
- Wiring these into an actual step-up-auth flow and a live event
  pipeline is **not implemented** in this slice — the pure detection
  functions exist and are tested; the "what happens when triggered"
  integration does not.

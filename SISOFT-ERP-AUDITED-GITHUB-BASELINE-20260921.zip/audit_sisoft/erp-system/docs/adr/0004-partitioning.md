# ADR 0004: Partitioning strategy

## Status
**Proposed, not implemented.** This ADR records the intended design so the
decision isn't lost, and is explicit about what's deferred and why —
see `docs/db/MIGRATION_GUIDE.md`'s "not set up yet" section for the same
caveat in operational terms.

## Context

The original M2 scope calls for monthly range partitioning on high-write,
high-volume tables (`audit_events`, `activity_logs`, `access_logs`,
`notification_deliveries`, and similar log-shaped tables), and optional
hash partitioning by `tenantId` on tables expected to exceed 100M rows for
a single large tenant (`employees`, `items` once Inventory exists, etc.).

## Intended decision (for when this is actually implemented)

- **Range partition by `createdAt`, monthly**, on append-only log tables.
  These tables are insert-only and queried predominantly by recent date
  range (audit lookups, activity feeds), which is exactly the access
  pattern range partitioning optimizes: old partitions can be detached and
  archived to cold storage (S3/Glacier-equivalent) instead of `DELETE`d,
  and queries scoped to "last 30 days" only ever touch one or two
  partitions instead of scanning the whole table.
- **Hash partition by `tenantId`**, only for specific tables that cross a
  measured row-count threshold for a single tenant — not applied
  speculatively to every table. Hash partitioning trades query planning
  simplicity for write distribution across partitions; it's the right
  tool only once a table is actually large enough that partition pruning
  meaningfully helps, which none of the 83 foundation tables are yet.

## Why this isn't implemented in M2

Partitioning is DDL that has to be verified against a real, running
Postgres to get right: partition bound syntax, a scheduled job to
pre-create future monthly partitions before they're needed (a range-
partitioned table with no partition for "next month" rejects inserts for
next month, which is a production outage waiting to happen if the job
that creates new partitions ever fails silently), and — for any table that
already has data — a non-trivial migration to convert an existing
unpartitioned table into a partitioned one without downtime (Postgres
doesn't support this in-place; it requires creating a new partitioned
table, backfilling, and swapping).

This sandbox has no live Postgres to write that migration against and
confirm it actually applies cleanly, confirm partition pruning is
happening (`EXPLAIN ANALYZE`, not an assertion), or confirm the
partition-creation job's failure mode is safe. Asserting DDL like this
without that verification would be exactly the "unverified wall of
speculative SQL" this project has otherwise tried hard to avoid — see the
M1/M2 session notes for other places the same principle applied (the
`prisma migrate dev` vs. hand-authored-migration-folder decision, and the
`erp_app` vs. superuser role catch, were both the same judgment call made
the other way once verification was possible in-conversation; this one
genuinely isn't, without a database).

## Revisit trigger

Implement this ADR for real once any of the following happens: (a) a
foundation-module log table's row count starts making `audit.test.ts`-
style queries measurably slow in a real environment, (b) a business
module (M5+) introduces a table the master spec's own SLOs suggest will
cross the 100M-row mark, or (c) before production launch regardless,
since `audit_events` is unbounded by nature and needs *some* retention/
archival story before real traffic hits it.

# ADR 0014: Exchange rates are effective-dated, not a single current value

## Status
Accepted.

## Context

A multi-currency ERP needs to convert amounts between currencies for
both current operations (today's exchange rate) and historical reporting
(what was a transaction from 3 months ago worth in the base currency, AT
THE TIME it happened). A naive design — one row per currency pair,
overwritten whenever the rate changes — cannot answer the second
question correctly once the rate has moved.

## Decision

`ExchangeRate` rows are never updated in place; each rate change is a NEW
row with its own `effectiveAt` timestamp. `ExchangeRateService.getRate()`
always takes an `atDate` parameter and returns the rate effective ON that
date — the most recent row with `effectiveAt <= atDate` — never a
future-dated rate relative to the query date.

## Rationale

- **Historical accuracy is not optional in accounting software.** A
  January transaction converted at January's rate must STAY converted at
  January's rate even after February's rate is recorded — restating past
  transactions every time a new rate arrives would silently corrupt
  historical financial reports. Effective-dating is the standard,
  correct pattern for exactly this requirement (the same principle
  behind why `FiscalPeriod`s lock, ADR 0013 — protecting historical
  integrity from retroactive changes).
- **No interpolation between dated rates.** A rate holds constant from
  its effective date until explicitly superseded — this is simpler and
  more auditable than interpolating between two known points, and
  matches how businesses actually record rates (a specific rate decided
  on a specific date, not a continuous curve).
- **Inverse-rate fallback** (`getRate` tries `B->A` and inverts if only
  that direction was recorded) reduces the data-entry burden without
  compromising correctness — `1/rate` from a real recorded rate is exact,
  not an approximation.

## Consequences

- Every rate change grows the `ExchangeRate` table rather than updating
  in place — this is intentional (the append-only-for-history pattern
  this codebase also uses for `AuditEvent`, `LoginAttempt`, etc.), and is
  a small table in absolute terms (one row per currency-pair change, not
  per transaction).
- Callers MUST pass the correct `atDate` for their use case — a service
  that always passes `new Date()` (today) for what should be a
  transaction's own historical date would silently get today's rate
  instead of the historically-correct one. This is a real contract
  Finance (M8) and any other rate-consuming module needs to honor
  correctly when it's built; nothing in this slice's schema can enforce
  "you passed the right date" at compile time.

# ADR 0161: Legal hold override

## Status
Accepted (logic implemented and tested; retention-executor integration not built — see MANIFEST.md)

## Context
A legal hold must block both scheduled retention deletion and DSR
erasure requests, even though those are two entirely separate code
paths. If each path independently reimplements the hold check, someone
adding a third deletion path later can easily forget it.

## Decision
Single function, `isBlockedByHold`, is the only place hold-matching logic
lives. Both callers (retention-executor and the erasure handler — neither
built yet, see MANIFEST) are required to call
`LegalHoldEnforcerService.assertNotBlocked` before any delete/anonymize
operation, which throws rather than returning a boolean, so a caller
can't accidentally ignore the result.

Scope matching: a hold with no `dataTypes`/`userIds`/`entities`/
`dateRange` filter applies to everything (broadest possible hold); each
populated dimension narrows the match, and all populated dimensions must
match simultaneously (AND, not OR).

## Consequences
A hold applied too broadly (e.g. accidentally omitting all scope filters)
blocks all deletion tenant-wide. No safeguard against this exists yet
beyond code review of hold-creation requests.

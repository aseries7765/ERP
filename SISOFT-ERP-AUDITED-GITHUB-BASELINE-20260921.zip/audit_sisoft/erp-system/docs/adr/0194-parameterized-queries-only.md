# 0194: Parameterized Queries Only — Ban Raw SQL String Building

## Status
Accepted

## Context
SQL injection remains one of the highest-impact vulnerability classes.
Prisma's query builder is parameterized by default, but `$queryRawUnsafe`/
`$executeRawUnsafe` exist as an escape hatch that bypasses this safety.

## Decision
Ban `$queryRawUnsafe`/`$executeRawUnsafe` outright via a Semgrep CI
rule (`no-query-raw-unsafe`). Any raw SQL must use `$queryRaw`/
`$executeRaw` with tagged template literals, which Prisma parameterizes
correctly.

## Consequences
- CI fails the build on any use of the unsafe variants — a hard gate,
  not just a lint warning.
- Legitimate need for dynamic SQL (rare) requires an explicit,
  reviewed exception process rather than silent bypass.
- Doesn't guarantee zero injection risk on its own — the query builder
  (M12) and any future raw SQL still need code review; this is one
  layer, verified further by pen testing (sqlmap) pre-launch.

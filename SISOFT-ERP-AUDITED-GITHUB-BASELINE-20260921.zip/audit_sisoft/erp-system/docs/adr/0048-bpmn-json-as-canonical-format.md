# ADR-0048: Simplified BPMN-JSON as the canonical workflow format

## Status
Accepted and implemented (`@erp/workflow-engine/src/types.ts`, unit-
tested).

## Context
Full BPMN 2.0 XML is a large, mostly-unused-in-practice spec. The
amendment asks for "JSON BPMN 2.0" — read here as "BPMN-inspired
concepts, JSON serialization," matching the worked PO-approval example
in the original spec verbatim.

## Decision
Define a small closed set of step types (start/condition/approval/
action/wait/parallel/sub-workflow/end) as a discriminated union, stored
as plain JSON in `WorkflowVersion.graphJson` (JSONB column). No XML
import/export is provided.

## Consequences
- Simpler to validate, execute, and render in the designer than real
  BPMN XML.
- Not interoperable with external BPMN tooling (Camunda, etc.) without
  a translation layer, which is out of scope for M3.10.

# Seeds

## What exists today (M2 foundation slice)

| Script | What it does | Idempotent via |
|---|---|---|
| `prisma/seed/seed-plans.ts` | 4 subscription plans: Free, Starter, Growth, Enterprise | `upsert` on `plans.code` |
| `prisma/seed/seed-currencies.ts` | ~30 real ISO 4217 currencies covering the Tier-1 countries from the master spec's Q2 answer | `upsert` on `currencies.code` |
| `prisma/seed/seed-demo-tenant.ts` | One demo `Tenant` + `Company` + `Branch` + 7 system roles (Owner/Admin/Manager/Accountant/HR/Sales/Viewer) | checks for existing `slug: "demo"` tenant first; short-circuits if found |
| `prisma/seed/index.ts` | Orchestrates the above; entrypoint for `pnpm db:seed` | — |

Run: `pnpm db:seed`. Include the demo tenant with `SEED_DEMO=true pnpm db:seed`.

## What's explicitly NOT included yet

The original M2 scope named substantially more seed scripts than this
slice delivers — countries (250), the full currency list (~180),
languages (7000+), timezones (all IANA zones), the full ~2000-permission
catalog, per-country charts of accounts, tax codes, units of measure,
industry-pack metadata, compliance-framework control catalogs, and AI
prompt templates. These are real data-entry and modeling work, not schema
work — most of them (permissions, COA templates, tax codes) don't have
anywhere meaningful to seed *into* until the business modules that define
those permissions/accounts/tax rules exist (M5+). Listing 2000 permission
codes for modules that don't have controllers yet would be inventing
data, not seeding it. They're deferred to whichever milestone actually
introduces the thing being seeded, and should be added incrementally at
that point rather than as a wall of placeholder data now.

## Why these are safe to run repeatedly

- `seedPlans`/`seedCurrencies` use `prisma.upsert()` keyed on a natural
  unique column (`code`). Running twice writes the same 4 (or ~30) rows
  both times — `seeds.test.ts` asserts the row count doesn't change on a
  second run.
- `seedDemoTenant` explicitly checks for an existing tenant with
  `slug: "demo"` before creating anything, and returns early
  (`created: false`) if found — it does not rely on a database-level
  unique-constraint catch, so it never throws on a second run.

## Why demo data needs `SEED_DEMO=true`

`seed-demo-tenant.ts` creates a `Tenant` row that looks exactly like a
real customer's, just named "Demo Tenant" — nothing distinguishes it from
production data at the schema level. Requiring an explicit environment
variable is the actual safety mechanism (per the original requirement
that seeds "never run in production automatically"), not a naming
convention that could be typo'd around. `prisma/seed/index.ts` checks this
flag and prints which path it took either way, so a `pnpm db:seed` run's
output tells you honestly whether the demo tenant was included.

## Adding a new seed

1. Write `prisma/seed/seed-<name>.ts` exporting an async function that
   takes a `PrismaClient` and returns a count (see `seed-plans.ts` for the
   shape).
2. Use `upsert` (or an explicit existence check, for anything without a
   natural unique key — see `seed-demo-tenant.ts`) so it's safe to re-run.
3. Import and call it from `prisma/seed/index.ts`.
4. Add a corresponding case to `apps/api/test/db/seeds.test.ts` proving the
   second run doesn't duplicate rows.

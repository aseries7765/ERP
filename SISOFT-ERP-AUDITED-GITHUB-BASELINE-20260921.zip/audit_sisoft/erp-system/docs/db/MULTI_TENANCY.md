# Multi-tenancy: how isolation works end-to-end

This system uses **shared schema + `tenantId` + Postgres Row-Level
Security**, per ADR 0002. Every tenant's data lives in the same tables as
every other tenant's; a Postgres-enforced policy, not application code
alone, decides which rows a given connection can see.

## The three layers, in order of trust

1. **Database RLS (source of truth).** Every table with a `tenantId`
   column has `ENABLE ROW LEVEL SECURITY` + `FORCE ROW LEVEL SECURITY` and
   a `tenant_isolation` policy comparing `tenantId` against
   `get_current_tenant()` (`prisma/raw-sql/02-rls-and-triggers.sql`). If
   this layer is wrong, nothing else matters — this is why `rls.test.ts`
   connects as the same non-superuser role the app uses, not a superuser
   that would bypass it silently.

2. **The `erp_app` role.** The application connects to Postgres as
   `erp_app`, a role with `NOSUPERUSER NOBYPASSRLS`
   (`infra/postgres/init.sql`). Migrations and seeds run as `erp`, a
   superuser — this split is deliberate (least privilege, master spec
   S20): a bug in application code cannot escalate into an RLS bypass,
   because the DB role it's running as is structurally incapable of one.

3. **The Prisma tenant-scoping extension (defense-in-depth).**
   `apps/api/src/prisma/tenant-scoping.extension.ts` refuses to even issue
   a query against a tenant-scoped model if no tenant is set in
   `TenantContextService`, and auto-fills `tenantId`/`createdBy`/`updatedBy`
   on create. This exists so a missing-tenant bug fails LOUDLY at the
   application layer (a thrown error) instead of relying solely on RLS
   silently returning zero rows — better error messages during development,
   same actual security guarantee either way.

## The request → DB round trip

```
HTTP request
  → TenantContextMiddleware reads x-tenant-id header (interim — M3 auth
    replaces this with a verified JWT claim) and calls
    TenantContextService.run({ tenantId, userId }, next)
  → downstream code calls prisma.withTenant(tenantId, async (tx) => { ... })
  → withTenant opens a transaction, runs
    SELECT set_config('app.current_tenant', tenantId, true)
    (parameterized — not string-interpolated — see prisma.service.ts)
  → every query inside that transaction is now subject to RLS using that
    tenant id, AND subject to the tenant-scoping extension using the same
    id from AsyncLocalStorage
  → transaction commits; app.current_tenant reverts to unset (SET LOCAL is
    transaction-scoped) — the next transaction starts with no context and
    must set it again
```

## Why `SET LOCAL`/`set_config(..., true)` instead of a per-connection setting

Connection pooling (PgBouncer in front of Postgres, or Prisma's own pool)
means the physical connection your next query runs on may not be the one
your last query ran on. A transaction-scoped setting
(`set_config(..., is_local => true)`) is safe under pooling because it's
tied to the transaction, not the connection — this is why `withTenant`
wraps everything in `$transaction` rather than calling `set_config` as a
one-off statement before separate queries.

**PgBouncer note:** if you put PgBouncer in *transaction pooling* mode in
front of this database, add `?pgbouncer=true` to the connection string —
it disables Prisma's prepared-statement caching, which transaction-mode
pooling can't support (session-mode pooling doesn't need this flag, but
loses some of PgBouncer's connection-reuse benefit).

## Global (non-tenant-scoped) tables

`Currency` and `Permission` are shared platform reference data — no
`tenantId`, no RLS. `FeatureFlag`, `SystemEvent`, and `TerminologyPack`
have an *optional* `tenantId` (nullable) because they're meaningful both
as platform-wide defaults and as tenant-specific overrides.

## Known gap in this milestone

`TenantContextMiddleware` currently trusts an `x-tenant-id` header. That
is explicitly a placeholder — see the comment at the top of
`tenant-context.middleware.ts` — so that M2's tenant-scoped Prisma layer
has something real to run against before Auth (M3) exists. Do not treat
this as the final tenant-resolution story; a caller can claim any tenant
id via the header today. M3 replaces this with resolution from a verified,
signed JWT.

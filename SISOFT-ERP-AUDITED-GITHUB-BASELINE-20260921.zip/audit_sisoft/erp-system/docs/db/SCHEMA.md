# Schema reference — Foundation Modules (01–10)

Scope note: this covers the 83 models in `prisma/schema.prisma` as of M2.
Business modules (11–24) are a separate future slice — see
`README-M2.md` for why. This document is organized by module, matching the
comment blocks in `schema.prisma` itself; if the two ever disagree, the
schema file is authoritative and this file is stale (check `git log` on
`schema.prisma` first).

## Base convention (applies to every tenant-scoped table unless noted)

| Column | Type | Purpose |
|---|---|---|
| `id` | `uuid` | Primary key, `uuid_generate_v7()` — sortable by creation time (ADR 0001) |
| `tenantId` | `uuid` | Tenant isolation key — indexed, part of every natural-key unique constraint |
| `createdAt` | `timestamp` | Set once, on insert |
| `updatedAt` | `timestamp` | Bumped by the DB trigger on every UPDATE (migration 02) |
| `createdBy` / `updatedBy` | `uuid` | Actor — the user or system id that made the change |
| `deletedAt` | `timestamp?` | Soft delete marker (ADR 0005) — `NULL` means active |
| `version` | `int` | Optimistic lock (ADR 0006), bumped by the same trigger as `updatedAt` |
| `metadata` | `jsonb?` | Tenant-defined custom data that doesn't need its own column |

**Deliberate exceptions:** append-only log tables (`audit_events`,
`activity_logs`, `change_logs`, `access_logs`, `system_events`,
`login_attempts`, `refresh_tokens`, `notification_deliveries`, `digests`,
`terminology_usages`, `workflow_logs`, and similar) never get updated in
place, so they have `createdAt` only — no `updatedAt`, `version`, or
`deletedAt`. Settings tables (`tenant_settings`, `user_settings`,
`branch_settings`) are the opposite: only `updatedAt`, no `createdAt` — a
setting's history is its changes, not its creation moment. `schema.test.ts`
encodes these exceptions explicitly rather than asserting a uniform shape
that isn't true of this schema.

## Module 02 — Tenancy & Organization

The root of the tenant hierarchy — every other tenant-scoped table's
`tenantId` ultimately points at a row in `tenants`.

| Table | Purpose | Key relationships |
|---|---|---|
| `tenants` | The tenant registry itself. Has NO `tenantId` column — it IS the tenant. | 1—N `subscriptions`, `companies` |
| `plans` | Global (not tenant-scoped) catalog: Free/Starter/Growth/Enterprise/Custom | referenced by `subscriptions` |
| `subscriptions` | A tenant's current plan + seat count + billing status | belongs to `tenants`, `plans` |
| `currencies` | Global ISO 4217 reference data (code is the PK, e.g. `USD`) | referenced by `companies.baseCurrency`, `exchange_rates` |
| `exchange_rates` | Tenant-recorded FX rate at a point in time | scoped to `tenants` |
| `companies` | A legal entity within a tenant (a tenant can have several) | 1—N `branches`, `fiscal_years`, `addresses` |
| `branches` | A physical/legal branch of a company | 1—N `departments`, `locations` |
| `departments` | Org unit within a branch, self-referencing (`parentId`) for hierarchy | 1—N `cost_centers` |
| `cost_centers` | Financial cost-allocation unit under a department | used by Finance module (M8, future) |
| `locations` | A named place under a branch (warehouse, office) with its own timezone | |
| `addresses` | Postal address, typed (`REGISTERED`/`BILLING`/`SHIPPING`/`BRANCH`/`OTHER`) | belongs to `companies` |
| `fiscal_years` / `fiscal_periods` | Accounting calendar, with period-level `OPEN`/`CLOSED`/`LOCKED` status | belongs to `companies` |
| `calendars` | Which calendar system a tenant uses (Gregorian/Hijri/Nepali/etc.) | |

## Module 01 — Auth & Identity

| Table | Purpose |
|---|---|
| `users` | Login identity. `passwordHash` is nullable for SSO-only accounts (Keycloak/OIDC lands in M3). |
| `sessions` | Active login sessions, tied to a `device` |
| `devices` | Known devices per user, with a `fingerprint` unique per user |
| `api_keys` | Machine credentials — only the **hash** is stored (S16/S9), never the raw key |
| `mfa_methods` | TOTP/SMS/EMAIL/WEBAUTHN/BACKUP_CODES, secret encrypted at rest |
| `webauthn_credentials` | Passkey/security-key public keys |
| `password_resets` / `email_verifications` | One-time token flows, token stored as a hash |
| `login_attempts` | Every login attempt, success or failure — feeds account-lockout logic (S7) |
| `refresh_tokens` | Rotating refresh tokens with a `familyId` for reuse-detection revocation |

## Module 03 — RBAC + Permission Tracking

| Table | Purpose |
|---|---|
| `roles` | Tenant-defined roles (system-seeded ones have `isSystem = true`) |
| `permissions` | GLOBAL catalog (not tenant-scoped) — e.g. `sales.order.create` |
| `role_permissions` | Grants a permission to a role, with an `ALLOW`/`DENY` effect (explicit deny wins — supports Separation of Duties) |
| `user_roles` | Assigns a role to a user, optionally scoped to a branch/department |
| `groups` / `group_members` | Simple user grouping, independent of roles |
| `policies` | Tenant-authored CEL expressions for fine-grained rules (evaluated app-side) |
| `delegations` | Temporary role delegation from one user to another |
| `separation_of_duty_rules` | Declares two roles that must never be held by the same user simultaneously |
| `access_reviews` | Quarterly access-review records (SOC 2 requirement) |

## Module 04 — User & Employee Master

| Table | Purpose |
|---|---|
| `user_profiles` | Display info for a `User` (1:1) — name, avatar, locale, timezone |
| `employees` | HR record, may or may not have a linked `User` login |
| `employments` | An employee's employment history (position, department, type, dates) |
| `positions` / `job_grades` | Job title catalog and its associated pay grade |
| `teams` / `team_members` | Ad-hoc team grouping of employees |
| `contacts` | Standalone contact records (not necessarily an employee) |
| `emergency_contacts` | Per-employee emergency contact info |
| `certifications` | Employee certifications with issue/expiry dates |

## Module 05 — Audit & Activity Log

| Table | Purpose |
|---|---|
| `audit_events` | Append-only, hash-chained (ADR + `docs/db/RLS.md`'s audit section). DB triggers physically forbid UPDATE/DELETE. |
| `activity_logs` | Human-readable activity feed ("created", "commented", "closed") |
| `change_logs` | Field-level before/after diff log |
| `access_logs` | HTTP-level access log (resource, method, status code) |
| `system_events` | Platform-level events, tenant-optional (`tenantId` nullable) |

## Module 06 — Notifications

| Table | Purpose |
|---|---|
| `notification_templates` | Handlebars templates per channel + locale |
| `notifications` | In-app notification content, read/unread |
| `notification_preferences` | Per-user opt-in/out per channel + category |
| `notification_channels` | Tenant's configured provider (SMTP/Twilio/FCM/webhook) — config only, secrets live in Vault |
| `notification_deliveries` | Delivery attempt log per notification per channel |
| `digests` | Daily/weekly rollup delivery tracking |

## Module 07 — Documents & File Manager

File **bytes** are never stored here — only metadata. Actual bytes live in
MinIO/S3, referenced by `storageKey`.

| Table | Purpose |
|---|---|
| `folders` | Hierarchical folder structure (self-referencing `parentId`) |
| `documents` | File metadata: mime type, size, storage key, virus-scan flag |
| `document_versions` | Version history per document |
| `file_tags` / `file_shares` | Tagging and sharing metadata |
| `signature_requests` / `signatures` | E-signature workflow tracking |
| `ocr_results` | Extracted text/fields from a scanned document (1:1 with `documents`) |

## Module 08 — Settings & Customization

| Table | Purpose |
|---|---|
| `tenant_settings` / `user_settings` / `branch_settings` | Key-value settings at each scope |
| `feature_flags` | Platform or per-tenant flag, with rollout percentage |
| `custom_fields` / `custom_field_values` | Tenant-defined fields on any entity type, without schema changes |
| `form_schemas` / `form_instances` | JSON-Schema-driven dynamic forms and their submitted data |

## Module 09 — Terminology Engine

| Table | Purpose |
|---|---|
| `terminology_packs` | A named set of terminology (platform-shipped or tenant-specific) |
| `terminology_entries` | Default label per key per locale within a pack |
| `terminology_overrides` | A tenant's override of a specific entry |
| `terminology_usages` | Resolution log — what label was actually shown, when |

## Module 10 — Workflow Automation

| Table | Purpose |
|---|---|
| `workflows` | A named automation attached to an entity type |
| `workflow_versions` | Versioned BPMN 2.0 JSON definition |
| `workflow_steps` | Individual step within a version (approval/action/condition/wait) |
| `workflow_instances` | A running/completed execution of a workflow against a specific entity |
| `workflow_tasks` | An individual assignee task within an instance |
| `workflow_triggers` | Event + CEL condition that starts a workflow |
| `workflow_actions` | Reusable action definitions (send_notification, call_webhook, etc.) |
| `workflow_logs` | Execution log per instance |

## Where the full ER diagram is

A rendered Mermaid ER diagram per module was scoped for this milestone but
not completed in this pass — see the M2 completion summary for exactly
what's deferred and why. The table-by-module breakdown above plus
`schema.prisma`'s own relation declarations are sufficient to reconstruct
one; regenerating it mechanically (e.g. via `prisma-erd-generator`) once
`pnpm install` has run is lower-risk than a hand-drawn diagram I can't
validate against the real schema in this sandbox.

# Schema Integration — Stage 15

**Date:** 2026-09-17

## Objective

Turn the current Prisma workspace into an explicitly governed single-schema
integration point, while preventing older module fragments from being merged
when they conflict with the established foundation.

## Result

- `prisma/schema.prisma` contains **187 unique models**.
- All non-conflicting `*-models.prisma` declarations under the workspace are
  represented in the merged schema.
- The legacy workflow fragment is intentionally not concatenated because it
  defines a second workflow architecture (`WorkflowDefinition`,
  `WorkflowVersion`, `WorkflowInstance`, etc.) that conflicts with the existing
  foundation workflow models. The foundation workflow remains authoritative.
- Duplicate model names, duplicate model fields, and duplicate model-level
  attributes are checked by the Stage 15 verification script.
- The schema header was corrected so it no longer describes the file as an
  M2-only foundation schema.

## Verification

Run:

```bash
bash scripts/verify-schema-integrity-stage15.sh
```

Expected static result:

```text
Merged schema models: 187 (unique)
Model-fragment declarations checked: 30
Workflow conflicting fragments: intentionally excluded (foundation schema retained)
Model/field/attribute uniqueness: PASS
ERP Stage 15 schema integrity: PASS
```

## Runtime limitation

This stage does **not** claim `prisma validate`, migration execution, database
connectivity, or generated-client compilation as PASS. The current sandbox has
no installed project dependencies and no PostgreSQL service. Those checks must
run in a fully provisioned development/CI environment.

## Integration rule going forward

A new module schema fragment must either:

1. be merged into `prisma/schema.prisma` after collision/relation review; or
2. be explicitly recorded as intentionally excluded because an existing
   authoritative model already represents that domain.

Blind concatenation is prohibited.

# Row-Level Security reference

## Policy shape

Every table with a `tenantId` column gets exactly this (applied by a `DO`
loop in `prisma/raw-sql/02-rls-and-triggers.sql`, not written out 83 times
by hand):

```sql
ALTER TABLE <table> ENABLE ROW LEVEL SECURITY;
ALTER TABLE <table> FORCE ROW LEVEL SECURITY;  -- applies even to the table owner

CREATE POLICY tenant_isolation ON <table>
  USING ("tenantId" = get_current_tenant());
```

`get_current_tenant()` reads the transaction-local setting
`app.current_tenant` (see `docs/db/MULTI_TENANCY.md` for how that gets
set). If it's unset, `get_current_tenant()` returns `NULL`, and
`"tenantId" = NULL` is never `TRUE` in SQL three-valued logic — so an
unset-context query returns **zero rows**, not all rows. That's the
single most important property this whole design rests on, and it's what
`rls.test.ts`'s "a query with NO tenant context set returns zero rows"
case exists to prove.

Because no `FOR` clause is given, the policy applies to `ALL` commands
(`SELECT`/`INSERT`/`UPDATE`/`DELETE`). Because no separate `WITH CHECK` is
given, Postgres uses the same `USING` expression as the check for
`INSERT`/`UPDATE` — so you cannot insert a row claiming a `tenantId` other
than the one currently set in context, either. This is why
`test-db.helper.ts`'s `createTenantWithCompany` has to `set_config` to the
tenant's own id **before** inserting its `Company` row, inside the same
transaction — inserting with no context set, or the wrong tenant's context
set, is correctly rejected.

## Why `FORCE ROW LEVEL SECURITY` matters

Without `FORCE`, RLS does not apply to the table's owner — and by default,
the role that ran the migration (`erp`, a superuser in local dev per
`infra/postgres/init.sql`) owns every table it creates. `FORCE` closes that
hole for any non-superuser owner. It does **not** help against a
superuser connection, though — superusers and roles with the `BYPASSRLS`
attribute bypass RLS unconditionally, `FORCE` or not. That's the actual
reason the app runs as `erp_app` (`NOSUPERUSER NOBYPASSRLS`) rather than as
`erp` — see `MULTI_TENANCY.md`'s role-split section.

## The platform-admin bypass path

`erp_platform_admin` (`BYPASSRLS`, created in migration 02) exists for
legitimate cross-tenant platform tooling. Nothing in application code
connects as this role directly; `PrismaService.withBypassRls()` is the
only sanctioned entry point, and every call logs its `reason` argument
before running — there is no silent bypass. Bypassing RLS this way still
requires the underlying DB connection to actually be `erp_platform_admin`;
setting `bypassRls: true` in `TenantContextService` alone only skips the
*application-layer* check in `tenant-scoping.extension.ts` — it does
nothing to Postgres's enforcement if the connection is still `erp_app`.

## The audit-log exception: append-only, not tenant-filtered-only

`audit_events` gets the same `tenant_isolation` policy as everything else,
**plus** two triggers that unconditionally reject `UPDATE` and `DELETE`
regardless of role or RLS context:

```sql
CREATE TRIGGER trg_audit_no_update BEFORE UPDATE ON audit_events
  FOR EACH ROW EXECUTE FUNCTION reject_audit_mutation();
CREATE TRIGGER trg_audit_no_delete BEFORE DELETE ON audit_events
  FOR EACH ROW EXECUTE FUNCTION reject_audit_mutation();
```

`03-app-role-grants.sql` additionally revokes `UPDATE`/`DELETE` on
`audit_events` from `erp_app` at the grant level — belt-and-suspenders on
top of the trigger, so even a future refactor that somehow calls
`.update()`/`.delete()` on this table fails at the permissions layer before
it would even reach the trigger.

The hash chain itself (`audit_hash(prev_hash, row_data)`) is a pure SQL
function — deterministic, so the same `(prev_hash, row_data)` pair always
produces the same hash (`audit.test.ts` asserts this), and any tampering
with a historical row's data breaks every hash computed after it, because
each row's hash folds in the previous row's hash.

## How to test RLS is actually enforced (not just declared)

Run `pnpm test:db` with `APP_DATABASE_URL` pointed at the `erp_app` role —
**not** the migration superuser. `test-db.helper.ts`'s
`createTestPrismaClient()` throws immediately if `APP_DATABASE_URL` isn't
set, specifically to prevent someone from accidentally running this suite
as a superuser and getting a false "RLS works" result (every assertion
would trivially pass because RLS wouldn't even be active on that
connection).

## Adding RLS to a new tenant-scoped table (M5+)

You don't need to hand-write a policy. The `DO` loop in migration 02
already finds every table with a `tenantId` column automatically — if
that loop is re-run (or its logic is repeated in a later migration) after
a new business-module migration adds tables, they're covered. The
per-table trigger list in the same file's step 2, however, **is** an
explicit array — add the new table's name to it if it needs the
`updatedAt`/`version` auto-bump behavior (skip it if the table is another
append-only log, per `SCHEMA.md`'s base-convention exceptions).

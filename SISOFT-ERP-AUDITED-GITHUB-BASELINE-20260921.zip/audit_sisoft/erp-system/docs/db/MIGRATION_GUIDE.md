# How to add a migration safely

## The two kinds of migration in this project

**1. Schema-driven (the normal case).** You change `prisma/schema.prisma`
(add a model, add a field, change a relation), then let Prisma generate
the migration by diffing against the database:

```bash
pnpm db:migrate
# prompts for a migration name — use a short, present-tense description,
# e.g. "add_sales_order" or "add_employee_bank_details"
```

This is safe, reviewable (Prisma shows you the generated SQL before
applying), and is how the vast majority of changes in this project should
happen. Don't hand-write `CREATE TABLE`/`ALTER TABLE` SQL yourself when the
change is expressible in `schema.prisma` — let Prisma generate it, then
review the diff.

**2. Hand-written raw SQL (the exception).** Prisma has no concept of Row-
Level Security policies, custom Postgres functions, triggers, or table
partitioning. Anything in those categories has to be written by hand and
folded into a migration via `--create-only`:

```bash
pnpm --filter @erp/api exec prisma migrate dev --create-only --name <description> --schema ../../prisma/schema.prisma
# edit the generated (empty) migration.sql, add your raw SQL
pnpm db:migrate   # applies it
```

This project's own RLS/trigger/function SQL
(`prisma/raw-sql/01-uuid-v7-function.sql`,
`02-rls-and-triggers.sql`, `03-app-role-grants.sql`) was written this way
— see the comment block at the top of `01-uuid-v7-function.sql` for the
exact step-by-step this repo's own foundation migration needs, including
why the ordering (function → tables → RLS/triggers → grants) matters.

## Before you write a migration

- [ ] Does this change need a corresponding RLS policy? (New tenant-scoped
      table → yes, but the RLS-enabling `DO` loop in migration 02 finds
      tables by their `tenantId` column automatically at the time it
      runs — re-running that loop's logic, or including it again in your
      new migration, covers new tables without hand-writing a new policy
      per table.)
- [ ] Does this table need the `updatedAt`/`version` auto-bump trigger?
      (See `docs/db/SCHEMA.md`'s base-convention exceptions — append-only
      log tables deliberately skip this.)
- [ ] Does `erp_app` need a grant on the new table? Not if you're relying
      on `ALTER DEFAULT PRIVILEGES` from `03-app-role-grants.sql` — that
      already covers future tables created by `prisma migrate`
      automatically. Only re-run a manual `GRANT` if you created a table
      via raw SQL outside Prisma's own migration mechanism.
- [ ] Is every new column following the base convention in
      `SCHEMA.md`, or is a deliberate exception documented in a comment?
- [ ] Every unique constraint on a tenant-scoped table includes
      `tenantId` — a bare `@unique` on a natural key (an order number, an
      employee code) will collide across tenants.
- [ ] Every foreign key on a tenant-scoped table needs an index — Postgres
      does NOT auto-index foreign keys (unlike the primary key side).

## Reversibility

`prisma migrate dev`'s generated migrations are forward-only by default;
Prisma does not generate a "down" migration automatically. For schema-
driven changes, the practical rollback is `prisma migrate resolve` plus a
new forward migration that reverts the change — treat migrations as an
append-only log, not something you edit after it's been applied anywhere
outside your own local machine. For hand-written raw SQL migrations
(RLS/triggers/functions), write the down statements as a commented block
at the bottom of the file (see the bottom of `02-rls-and-triggers.sql` for
the pattern) — commented rather than executed automatically, because
running triggers/policy drops in production without a deliberate decision
is exactly the kind of "reversible in theory, dangerous in practice" trap
this convention exists to avoid.

## Testing a migration before it's real

`prisma migrate dev` uses a disposable **shadow database** to verify a
migration applies cleanly before touching your real dev database — this
is automatic, you don't configure it unless your Postgres user can't
create databases (in which case set `shadowDatabaseUrl` in the datasource
block). If `migrate dev` fails, your dev database is untouched.

For CI / ephemeral test databases, this project uses `prisma db push`
instead of the migration history (see `.github/workflows/ci.yml`) — `db
push` syncs the schema directly without creating migration files, which
is the right tool for a database that's destroyed after the test run
anyway. Never use `db push` against a database with real data; it can
silently accept destructive changes that `migrate dev` would have warned
you about.

## What this project has NOT set up yet

Table partitioning (the master spec's original ask: monthly range
partitions on `audit_events`, `activity_logs`, `notification_deliveries`,
etc.) is real, non-trivial Postgres DDL that needs to be verified against
an actual running Postgres to get right — partition bounds, a scheduled
job to pre-create future partitions, and a migration story for converting
an already-populated table into a partitioned one are all things this
sandbox cannot verify without a live database. It's deferred, not
skipped silently: when it's tackled, it belongs in its own dedicated pass
with real `EXPLAIN ANALYZE` output, not asserted-but-unverified DDL.

#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts-verify-stage63.py"

required=(
  STAGE63_API_BASE_URL
  STAGE63_REDIS_URL
  STAGE63_QUEUE_VERIFY_COMMAND
  STAGE63_RATE_LIMIT_VERIFY_COMMAND
  STAGE63_BACKPRESSURE_VERIFY_COMMAND
  STAGE63_CAPACITY_EVIDENCE_COMMAND
)
missing=()
for v in "${required[@]}"; do
  [[ -n "${!v:-}" ]] || missing+=("$v")
done

if (( ${#missing[@]} > 0 )); then
  echo "STAGE63 RUNTIME BLOCKED: missing ${missing[*]}"
  exit 2
fi

command -v curl >/dev/null || { echo "STAGE63 RUNTIME BLOCKED: curl unavailable"; exit 2; }
command -v redis-cli >/dev/null || { echo "STAGE63 RUNTIME BLOCKED: redis-cli unavailable"; exit 2; }

if ! curl --fail --silent --show-error --max-time 10 "$STAGE63_API_BASE_URL/health/ready" >/dev/null; then
  echo "STAGE63 RUNTIME BLOCKED: API readiness failed"
  exit 2
fi

if ! redis-cli -u "$STAGE63_REDIS_URL" ping | grep -qx PONG; then
  echo "STAGE63 RUNTIME BLOCKED: Redis PING failed"
  exit 2
fi

bash -lc "$STAGE63_RATE_LIMIT_VERIFY_COMMAND"
bash -lc "$STAGE63_BACKPRESSURE_VERIFY_COMMAND"
bash -lc "$STAGE63_QUEUE_VERIFY_COMMAND"
bash -lc "$STAGE63_CAPACITY_EVIDENCE_COMMAND"

echo "STAGE63 RUNTIME PASS"

# Stage 24 — Durable Event Consumers & Audit Persistence

Implemented real BullMQ consumers for the durable outbox paths.

## Audit consumer
- Persists `AuditEvent` rows.
- Uses a tenant-scoped PostgreSQL advisory transaction lock before reading the prior hash.
- Computes a deterministic SHA-256 row hash from canonicalized audit fields plus `prevHash`.
- Records an `EventDelivery` marker for idempotent outbox delivery.

## RBAC event consumer
- Persists processed RBAC events into `ActivityLog`.
- Records an `EventDelivery` marker.
- Duplicate queue retries therefore do not create duplicate activity rows.

## Delivery idempotency
`EventDelivery` is unique on `(outboxId, target)` and tenant-scoped with RLS.

## Verification limitation
Static checks pass. Runtime verification requires PostgreSQL, Redis, generated Prisma client, installed dependencies, and active BullMQ workers.

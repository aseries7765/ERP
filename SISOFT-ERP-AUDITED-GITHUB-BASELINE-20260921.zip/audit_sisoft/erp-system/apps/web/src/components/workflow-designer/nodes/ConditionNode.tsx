import React from 'react';
import type { WorkflowStep } from '@erp/workflow-engine';

type Step = Extract<WorkflowStep, { type: 'condition' }>;

export function ConditionNode({ step, x, y, selected, onClick }: { step: Step; x: number; y: number; selected?: boolean; onClick?: () => void }) {
  return (
    <g transform={`translate(${x},${y})`} onClick={onClick} style={{ cursor: 'pointer' }}>
      <polygon points="0,-32 60,0 0,32 -60,0" fill="#6366f1" stroke={selected ? '#0f172a' : 'none'} strokeWidth={2} />
      <text textAnchor="middle" dy={5} fill="white" fontSize={9}>{step.expression}</text>
    </g>
  );
}

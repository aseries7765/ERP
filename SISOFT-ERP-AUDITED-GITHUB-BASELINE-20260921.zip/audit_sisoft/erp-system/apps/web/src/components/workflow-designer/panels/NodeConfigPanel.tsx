import React from 'react';
import type { WorkflowStep } from '@erp/workflow-engine';

/**
 * Generic property editor — deliberately un-opinionated per step type (a
 * real implementation would branch to a per-type form, e.g. an assignee
 * picker wired to RBAC's role list for approval steps). This version
 * edits the handful of common fields as raw text so the panel is at
 * least usable end-to-end without pulling in a form library.
 */
export function NodeConfigPanel({ step, onChange }: { step: WorkflowStep | null; onChange: (patch: Partial<WorkflowStep>) => void }) {
  if (!step) return <div style={{ padding: 12, width: 260, color: '#94a3b8', fontSize: 12 }}>Select a node to edit its properties.</div>;
  return (
    <div style={{ padding: 12, width: 260, borderLeft: '1px solid #e2e8f0' }}>
      <div style={{ fontSize: 11, color: '#64748b', marginBottom: 8 }}>{step.type.toUpperCase()} · {step.id}</div>
      {'expression' in step && (
        <>
          <label style={{ fontSize: 11, color: '#64748b' }}>Condition (CEL)</label>
          <input
            value={(step as any).expression ?? ''}
            onChange={(e) => onChange({ expression: e.target.value } as Partial<WorkflowStep>)}
            style={{ width: '100%', padding: 6, fontSize: 12, fontFamily: 'monospace' }}
          />
        </>
      )}
      {'sla' in step && (
        <>
          <label style={{ fontSize: 11, color: '#64748b', marginTop: 8, display: 'block' }}>SLA (ISO 8601 duration)</label>
          <input
            value={(step as any).sla ?? ''}
            onChange={(e) => onChange({ sla: e.target.value } as Partial<WorkflowStep>)}
            placeholder="PT24H"
            style={{ width: '100%', padding: 6, fontSize: 12 }}
          />
        </>
      )}
    </div>
  );
}

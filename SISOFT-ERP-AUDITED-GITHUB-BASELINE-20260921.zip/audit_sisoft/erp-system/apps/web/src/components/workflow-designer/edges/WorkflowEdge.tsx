import React from 'react';

export function WorkflowEdge({ x1, y1, x2, y2, label }: { x1: number; y1: number; x2: number; y2: number; label?: string }) {
  const midX = (x1 + x2) / 2;
  const midY = (y1 + y2) / 2;
  return (
    <g>
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#94a3b8" strokeWidth={2} markerEnd="url(#arrow)" />
      {label && (
        <text x={midX} y={midY - 4} textAnchor="middle" fontSize={9} fill="#64748b">{label}</text>
      )}
    </g>
  );
}

import React from 'react';
import type { DesignerGraph } from '../utils/graph-to-bpmn';

export function WorkflowPropertiesPanel({ graph, onChange }: { graph: DesignerGraph; onChange: (patch: Partial<DesignerGraph>) => void }) {
  return (
    <div style={{ padding: 12, width: 260, borderLeft: '1px solid #e2e8f0' }}>
      <label style={{ fontSize: 11, color: '#64748b' }}>Name</label>
      <input
        value={graph.name}
        onChange={(e) => onChange({ name: e.target.value })}
        style={{ width: '100%', marginBottom: 12, padding: 6, fontSize: 13 }}
      />
      <label style={{ fontSize: 11, color: '#64748b' }}>Trigger event</label>
      <input
        value={graph.trigger?.event ?? ''}
        onChange={(e) => onChange({ trigger: { type: 'event', event: e.target.value } })}
        placeholder="e.g. purchase.order.created"
        style={{ width: '100%', padding: 6, fontSize: 13 }}
      />
    </div>
  );
}

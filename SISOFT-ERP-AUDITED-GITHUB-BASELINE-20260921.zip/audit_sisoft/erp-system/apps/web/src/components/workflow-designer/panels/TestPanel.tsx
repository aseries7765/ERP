import React, { useState } from 'react';
import type { DesignerGraph } from '../utils/graph-to-bpmn';

/** Calls POST /v1/workflows/:id/test (workflow-test.controller.ts) and renders the dry-run trace. */
export function TestPanel({ graph }: { graph: DesignerGraph }) {
  const [input, setInput] = useState('{}');
  const [result, setResult] = useState<unknown>(null);
  const [error, setError] = useState<string | null>(null);

  async function run() {
    setError(null);
    try {
      const parsed = JSON.parse(input);
      const res = await fetch(`/v1/workflows/${graph.id}/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: parsed }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setResult(await res.json());
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  return (
    <div style={{ padding: 12 }}>
      <label style={{ fontSize: 11, color: '#64748b' }}>Sample input (JSON)</label>
      <textarea value={input} onChange={(e) => setInput(e.target.value)} rows={4} style={{ width: '100%', fontFamily: 'monospace', fontSize: 12 }} />
      <button onClick={run} style={{ marginTop: 8, padding: '6px 12px' }}>Run dry-run</button>
      {error && <div style={{ color: '#dc2626', fontSize: 12, marginTop: 8 }}>{error}</div>}
      {result != null && <pre style={{ fontSize: 11, marginTop: 8, background: '#f8fafc', padding: 8 }}>{JSON.stringify(result, null, 2)}</pre>}
    </div>
  );
}

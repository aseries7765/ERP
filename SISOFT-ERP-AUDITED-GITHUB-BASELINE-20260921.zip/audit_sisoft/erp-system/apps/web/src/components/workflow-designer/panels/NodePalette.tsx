import React from 'react';
import type { StepType } from '@erp/workflow-engine';

const PALETTE: Array<{ type: StepType; label: string; color: string }> = [
  { type: 'condition', label: 'Condition', color: '#6366f1' },
  { type: 'approval', label: 'Approval', color: '#eab308' },
  { type: 'action', label: 'Action', color: '#0ea5e9' },
  { type: 'wait', label: 'Wait', color: '#94a3b8' },
  { type: 'parallel', label: 'Parallel', color: '#a855f7' },
  { type: 'sub-workflow', label: 'Sub-workflow', color: '#f97316' },
  { type: 'end', label: 'End', color: '#0f172a' },
];

export function NodePalette({ onAdd }: { onAdd: (type: StepType) => void }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: 12, width: 160, borderRight: '1px solid #e2e8f0' }}>
      {PALETTE.map((item) => (
        <button
          key={item.type}
          onClick={() => onAdd(item.type)}
          style={{ background: item.color, color: 'white', border: 'none', borderRadius: 6, padding: '8px 10px', cursor: 'pointer', fontSize: 12 }}
        >
          + {item.label}
        </button>
      ))}
    </div>
  );
}

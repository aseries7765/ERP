import React from 'react';
import type { WorkflowStep } from '@erp/workflow-engine';

type Step = Extract<WorkflowStep, { type: 'approval' }>;

export function ApprovalNode({ step, x, y, selected, onClick }: { step: Step; x: number; y: number; selected?: boolean; onClick?: () => void }) {
  const label = step.assignees.map((a) => a.role ?? a.userId).join(', ');
  return (
    <g transform={`translate(${x},${y})`} onClick={onClick} style={{ cursor: 'pointer' }}>
      <rect x={-70} y={-28} width={140} height={56} rx={10} fill="#eab308" stroke={selected ? '#0f172a' : 'none'} strokeWidth={2} />
      <text textAnchor="middle" y={-4} fontSize={11} fontWeight={600}>Approval</text>
      <text textAnchor="middle" y={14} fontSize={10}>{label}{step.sla ? ` · SLA ${step.sla}` : ''}</text>
    </g>
  );
}

// Requires @testing-library/react + jsdom + a bundler-compatible test
// runner — unavailable offline. See test/workflow/README.md for the
// project-wide honesty note; the same applies here.
describe.skip('WorkflowDesigner (needs React testing toolchain)', () => {
  it('renders all seeded step types without crashing', () => {});
});

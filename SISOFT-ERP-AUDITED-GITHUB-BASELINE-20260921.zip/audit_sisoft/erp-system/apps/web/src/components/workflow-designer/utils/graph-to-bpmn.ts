import type { WorkflowDefinition, WorkflowStep } from '@erp/workflow-engine';

/** Visual-editor node: same fields as WorkflowStep plus x/y canvas position (not part of the BPMN-JSON contract). */
export interface DesignerNode {
  step: WorkflowStep;
  x: number;
  y: number;
}

export interface DesignerGraph {
  id: string;
  name: string;
  trigger?: WorkflowDefinition['trigger'];
  nodes: DesignerNode[];
}

/** Strips canvas positions, producing the exact JSON the API/engine consumes. Round-trips with graphToDesigner. */
export function designerToGraph(graph: DesignerGraph, version = 0, status: WorkflowDefinition['status'] = 'draft'): WorkflowDefinition {
  return {
    id: graph.id,
    name: graph.name,
    version,
    status,
    trigger: graph.trigger,
    steps: graph.nodes.map((n) => n.step),
  };
}

/** Inflates a stored WorkflowDefinition into designer nodes with a simple auto-layout (vertical lanes by BFS depth) — real designers would persist x/y separately; this is the fallback for graphs authored via the API directly. */
export function graphToDesigner(def: WorkflowDefinition): DesignerGraph {
  const byId = new Map(def.steps.map((s) => [s.id, s]));
  const depth = new Map<string, number>();
  const start = def.steps.find((s) => s.type === 'start');
  if (start) {
    const queue: Array<[string, number]> = [[start.id, 0]];
    while (queue.length) {
      const [id, d] = queue.shift()!;
      if (depth.has(id)) continue;
      depth.set(id, d);
      const step = byId.get(id);
      if (!step) continue;
      for (const next of outgoingIds(step)) queue.push([next, d + 1]);
    }
  }
  const laneCounts = new Map<number, number>();
  const nodes: DesignerNode[] = def.steps.map((step) => {
    const d = depth.get(step.id) ?? 0;
    const lane = laneCounts.get(d) ?? 0;
    laneCounts.set(d, lane + 1);
    return { step, x: lane * 220 + 40, y: d * 140 + 40 };
  });
  return { id: def.id, name: def.name, trigger: def.trigger, nodes };
}

function outgoingIds(step: WorkflowStep): string[] {
  switch (step.type) {
    case 'start': return [step.next];
    case 'condition': return [step.onTrue, step.onFalse];
    case 'approval': return [step.onApprove, step.onReject];
    case 'action': return [step.next];
    case 'wait': return [step.next];
    case 'parallel': return [...step.branches, step.join];
    case 'sub-workflow': return [step.next];
    case 'end': return [];
  }
}

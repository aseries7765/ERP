import React from 'react';
import type { WorkflowStep } from '@erp/workflow-engine';

type Step = Extract<WorkflowStep, { type: 'parallel' }>;

export function ParallelNode({ step, x, y, selected, onClick }: { step: Step; x: number; y: number; selected?: boolean; onClick?: () => void }) {
  return (
    <g transform={`translate(${x},${y})`} onClick={onClick} style={{ cursor: 'pointer' }}>
      <rect x={-60} y={-24} width={120} height={48} fill="#a855f7" stroke={selected ? '#0f172a' : 'none'} strokeWidth={2} />
      <line x1={-60} y1={-24} x2={60} y2={24} stroke="white" />
      <line x1={-60} y1={24} x2={60} y2={-24} stroke="white" />
      <text textAnchor="middle" dy={5} fill="white" fontSize={10}>{step.branches.length} branches</text>
    </g>
  );
}

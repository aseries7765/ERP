import React, { useState } from 'react';
import type { StepType, WorkflowStep } from '@erp/workflow-engine';
import { useWorkflowGraph } from './hooks/useWorkflowGraph';
import { useWorkflowValidation } from './hooks/useWorkflowValidation';
import type { DesignerGraph } from './utils/graph-to-bpmn';
import { NodePalette } from './panels/NodePalette';
import { NodeConfigPanel } from './panels/NodeConfigPanel';
import { WorkflowPropertiesPanel } from './panels/WorkflowPropertiesPanel';
import { TestPanel } from './panels/TestPanel';
import { StartNode } from './nodes/StartNode';
import { EndNode } from './nodes/EndNode';
import { ApprovalNode } from './nodes/ApprovalNode';
import { ConditionNode } from './nodes/ConditionNode';
import { ActionNode } from './nodes/ActionNode';
import { WaitNode } from './nodes/WaitNode';
import { ParallelNode } from './nodes/ParallelNode';
import { SubWorkflowNode } from './nodes/SubWorkflowNode';
import { WorkflowEdge } from './edges/WorkflowEdge';

let idCounter = 0;
function newStepId(type: string) { return `${type}-${++idCounter}-${Date.now().toString(36)}`; }

function defaultStepFor(type: StepType, id: string): WorkflowStep {
  switch (type) {
    case 'start': return { id, type, next: '' };
    case 'condition': return { id, type, expression: 'true', onTrue: '', onFalse: '' };
    case 'approval': return { id, type, assignees: [{ role: 'manager' }], onApprove: '', onReject: '' };
    case 'action': return { id, type, action: 'notification', config: {}, next: '' };
    case 'wait': return { id, type, next: '' };
    case 'parallel': return { id, type, branches: [], join: '' };
    case 'sub-workflow': return { id, type, workflowId: '', next: '' };
    case 'end': return { id, type, outcome: 'done' };
  }
}

/**
 * Main visual BPMN-subset editor canvas. HONESTY NOTE: this uses plain
 * SVG + inline styles rather than a graph library (e.g. React Flow)
 * because installing one requires network access the build sandbox
 * didn't have (see MANIFEST.md / apps/web/workflow.dependencies.json,
 * which lists `reactflow` as the intended real dependency — swapping it
 * in means replacing the <svg> canvas below with a <ReactFlow> and
 * mapping DesignerNode -> Node, which is a bounded, mechanical change
 * given the node/edge components are already split out per type).
 * This file has NOT been run through a bundler/TSX compiler in this
 * sandbox (no React toolchain available offline) — reviewed by hand for
 * type consistency with @erp/workflow-engine's types (which ARE
 * compiler-verified), not executed.
 */
export function WorkflowDesigner({ initialGraph }: { initialGraph: DesignerGraph }) {
  const { graph, moveNode, updateStep, addNode, setGraph } = useWorkflowGraph(initialGraph);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showTest, setShowTest] = useState(false);
  const validation = useWorkflowValidation(graph);

  const selected = graph.nodes.find((n) => n.step.id === selectedId)?.step ?? null;

  function handleAdd(type: StepType) {
    const id = newStepId(type);
    addNode({ step: defaultStepFor(type, id), x: 300, y: 300 });
    setSelectedId(id);
  }

  const edges: Array<{ x1: number; y1: number; x2: number; y2: number; label?: string }> = [];
  const byId = new Map(graph.nodes.map((n) => [n.step.id, n]));
  for (const n of graph.nodes) {
    const targets: Array<[string, string?]> =
      n.step.type === 'start' ? [[n.step.next]]
      : n.step.type === 'condition' ? [[n.step.onTrue, 'true'], [n.step.onFalse, 'false']]
      : n.step.type === 'approval' ? [[n.step.onApprove, 'approve'], [n.step.onReject, 'reject']]
      : n.step.type === 'action' || n.step.type === 'wait' || n.step.type === 'sub-workflow' ? [[n.step.next]]
      : n.step.type === 'parallel' ? [...n.step.branches.map((b): [string, string?] => [b]), [n.step.join, 'join']]
      : [];
    for (const [targetId, label] of targets) {
      const target = targetId && byId.get(targetId);
      if (target) edges.push({ x1: n.x, y1: n.y, x2: target.x, y2: target.y, label });
    }
  }

  return (
    <div style={{ display: 'flex', height: '100%', fontFamily: 'system-ui, sans-serif' }}>
      <NodePalette onAdd={handleAdd} />
      <div style={{ flex: 1, position: 'relative', overflow: 'auto', background: '#f1f5f9' }}>
        <div style={{ position: 'absolute', top: 8, left: 8, right: 8, display: 'flex', justifyContent: 'space-between', zIndex: 1 }}>
          <span style={{ fontSize: 12, color: validation.valid ? '#16a34a' : '#dc2626' }}>
            {validation.valid ? '✓ Graph is valid' : `${validation.issues.filter((i) => i.severity === 'error').length} error(s)`}
          </span>
          <button onClick={() => setShowTest((v) => !v)} style={{ fontSize: 12 }}>{showTest ? 'Hide' : 'Show'} test panel</button>
        </div>
        <svg width="100%" height="100%" style={{ minHeight: 600 }}>
          <defs>
            <marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
              <path d="M0,0 L8,4 L0,8 z" fill="#94a3b8" />
            </marker>
          </defs>
          {edges.map((e, i) => <WorkflowEdge key={i} {...e} />)}
          {graph.nodes.map((n) => {
            const common = { x: n.x, y: n.y, selected: n.step.id === selectedId, onClick: () => setSelectedId(n.step.id) };
            switch (n.step.type) {
              case 'start': return <StartNode key={n.step.id} {...common} />;
              case 'end': return <EndNode key={n.step.id} {...common} outcome={n.step.outcome} />;
              case 'approval': return <ApprovalNode key={n.step.id} {...common} step={n.step} />;
              case 'condition': return <ConditionNode key={n.step.id} {...common} step={n.step} />;
              case 'action': return <ActionNode key={n.step.id} {...common} step={n.step} />;
              case 'wait': return <WaitNode key={n.step.id} {...common} step={n.step} />;
              case 'parallel': return <ParallelNode key={n.step.id} {...common} step={n.step} />;
              case 'sub-workflow': return <SubWorkflowNode key={n.step.id} {...common} step={n.step} />;
            }
          })}
        </svg>
        {showTest && (
          <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'white', borderTop: '1px solid #e2e8f0' }}>
            <TestPanel graph={graph} />
          </div>
        )}
      </div>
      {selected
        ? <NodeConfigPanel step={selected} onChange={(patch) => updateStep(selected.id, patch)} />
        : <WorkflowPropertiesPanel graph={graph} onChange={(patch) => setGraph((g) => ({ ...g, ...patch }))} />}
    </div>
  );
}

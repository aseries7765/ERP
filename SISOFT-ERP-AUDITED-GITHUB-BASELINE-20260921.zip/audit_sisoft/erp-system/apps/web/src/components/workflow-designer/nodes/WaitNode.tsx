import React from 'react';
import type { WorkflowStep } from '@erp/workflow-engine';

type Step = Extract<WorkflowStep, { type: 'wait' }>;

export function WaitNode({ step, x, y, selected, onClick }: { step: Step; x: number; y: number; selected?: boolean; onClick?: () => void }) {
  return (
    <g transform={`translate(${x},${y})`} onClick={onClick} style={{ cursor: 'pointer' }}>
      <rect x={-50} y={-24} width={100} height={48} rx={24} fill="#94a3b8" stroke={selected ? '#0f172a' : 'none'} strokeWidth={2} />
      <text textAnchor="middle" dy={5} fontSize={10}>Wait {step.until ?? step.signal ?? ''}</text>
    </g>
  );
}

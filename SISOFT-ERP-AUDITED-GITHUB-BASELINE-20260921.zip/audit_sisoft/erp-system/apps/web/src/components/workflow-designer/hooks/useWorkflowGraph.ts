import { useCallback, useState } from 'react';
import type { WorkflowStep } from '@erp/workflow-engine';
import type { DesignerGraph, DesignerNode } from '../utils/graph-to-bpmn';

export function useWorkflowGraph(initial: DesignerGraph) {
  const [graph, setGraph] = useState<DesignerGraph>(initial);

  const moveNode = useCallback((stepId: string, x: number, y: number) => {
    setGraph((g) => ({ ...g, nodes: g.nodes.map((n) => (n.step.id === stepId ? { ...n, x, y } : n)) }));
  }, []);

  const updateStep = useCallback((stepId: string, patch: Partial<WorkflowStep>) => {
    setGraph((g) => ({
      ...g,
      nodes: g.nodes.map((n) => (n.step.id === stepId ? { ...n, step: { ...n.step, ...patch } as WorkflowStep } : n)),
    }));
  }, []);

  const addNode = useCallback((node: DesignerNode) => {
    setGraph((g) => ({ ...g, nodes: [...g.nodes, node] }));
  }, []);

  const removeNode = useCallback((stepId: string) => {
    setGraph((g) => ({ ...g, nodes: g.nodes.filter((n) => n.step.id !== stepId) }));
  }, []);

  return { graph, setGraph, moveNode, updateStep, addNode, removeNode };
}

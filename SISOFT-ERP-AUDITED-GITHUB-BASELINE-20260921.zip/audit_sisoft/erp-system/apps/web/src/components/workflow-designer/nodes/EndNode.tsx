import React from 'react';

export function EndNode({ x, y, outcome, selected, onClick }: { x: number; y: number; outcome: string; selected?: boolean; onClick?: () => void }) {
  const color = outcome === 'rejected' ? '#dc2626' : '#0f172a';
  return (
    <g transform={`translate(${x},${y})`} onClick={onClick} style={{ cursor: 'pointer' }}>
      <circle r={24} fill={color} stroke={selected ? '#f59e0b' : 'none'} strokeWidth={2} />
      <text textAnchor="middle" dy={5} fill="white" fontSize={10}>{outcome}</text>
    </g>
  );
}

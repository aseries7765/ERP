import React from 'react';
import type { WorkflowStep } from '@erp/workflow-engine';

type Step = Extract<WorkflowStep, { type: 'action' }>;

export function ActionNode({ step, x, y, selected, onClick }: { step: Step; x: number; y: number; selected?: boolean; onClick?: () => void }) {
  return (
    <g transform={`translate(${x},${y})`} onClick={onClick} style={{ cursor: 'pointer' }}>
      <rect x={-60} y={-24} width={120} height={48} rx={8} fill="#0ea5e9" stroke={selected ? '#0f172a' : 'none'} strokeWidth={2} />
      <text textAnchor="middle" dy={5} fill="white" fontSize={11}>{step.action}</text>
    </g>
  );
}

// This one CAN run standalone (no React, pure functions) — see the
// manual verification captured in MANIFEST.md ("designer round-trip
// check"). Written as a real Jest-style spec for when
// pnpm --filter @erp/web test can run it; not itself executed under
// Jest here (Jest unavailable offline).
import { graphToDesigner, designerToGraph } from '../utils/graph-to-bpmn';
import type { WorkflowDefinition } from '@erp/workflow-engine';

const def: WorkflowDefinition = {
  id: 'leave-approval', name: 'Leave Approval', version: 1, status: 'published',
  steps: [
    { id: 'start', type: 'start', next: 'approve' },
    { id: 'approve', type: 'approval', assignees: [{ role: 'manager' }], onApprove: 'ok', onReject: 'rejected' },
    { id: 'ok', type: 'end', outcome: 'approved' },
    { id: 'rejected', type: 'end', outcome: 'rejected' },
  ],
};

describe('graph-to-bpmn round trip', () => {
  it('preserves steps through designer <-> graph conversion', () => {
    const designer = graphToDesigner(def);
    const back = designerToGraph(designer, def.version, def.status);
    expect(back.steps).toEqual(def.steps);
  });
});

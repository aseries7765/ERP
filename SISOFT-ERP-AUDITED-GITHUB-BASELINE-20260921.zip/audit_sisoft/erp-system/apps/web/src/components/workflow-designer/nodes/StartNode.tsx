import React from 'react';

export function StartNode({ x, y, selected, onClick }: { x: number; y: number; selected?: boolean; onClick?: () => void }) {
  return (
    <g transform={`translate(${x},${y})`} onClick={onClick} style={{ cursor: 'pointer' }}>
      <circle r={24} fill="#16a34a" stroke={selected ? '#0f172a' : 'none'} strokeWidth={2} />
      <text textAnchor="middle" dy={5} fill="white" fontSize={11}>Start</text>
    </g>
  );
}

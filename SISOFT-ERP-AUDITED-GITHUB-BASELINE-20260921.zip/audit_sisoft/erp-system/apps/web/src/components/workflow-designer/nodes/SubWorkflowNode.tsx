import React from 'react';
import type { WorkflowStep } from '@erp/workflow-engine';

type Step = Extract<WorkflowStep, { type: 'sub-workflow' }>;

export function SubWorkflowNode({ step, x, y, selected, onClick }: { step: Step; x: number; y: number; selected?: boolean; onClick?: () => void }) {
  return (
    <g transform={`translate(${x},${y})`} onClick={onClick} style={{ cursor: 'pointer' }}>
      <rect x={-65} y={-26} width={130} height={52} rx={4} fill="#f97316" stroke={selected ? '#0f172a' : 'none'} strokeWidth={2} />
      <rect x={-58} y={-19} width={116} height={38} rx={2} fill="none" stroke="white" strokeWidth={1.5} />
      <text textAnchor="middle" dy={5} fill="white" fontSize={10}>{step.workflowId}</text>
    </g>
  );
}

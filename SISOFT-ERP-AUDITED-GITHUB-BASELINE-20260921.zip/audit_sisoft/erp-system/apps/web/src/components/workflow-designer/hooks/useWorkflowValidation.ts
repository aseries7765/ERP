import { useMemo } from 'react';
import { validateDefinition } from '@erp/workflow-engine';
import type { DesignerGraph } from '../utils/graph-to-bpmn';
import { designerToGraph } from '../utils/graph-to-bpmn';

/** Live validation as the user edits the canvas — same validateDefinition used server-side at publish time, so the designer never shows "looks fine" for a graph the API will reject. */
export function useWorkflowValidation(graph: DesignerGraph) {
  return useMemo(() => validateDefinition(designerToGraph(graph)), [graph]);
}

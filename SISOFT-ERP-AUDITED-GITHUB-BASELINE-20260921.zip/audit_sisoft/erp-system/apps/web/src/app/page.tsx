'use client';

import { useEffect, useState } from 'react';

type Status = 'loading' | 'ok' | 'error';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:3001';

export default function HomePage(): JSX.Element {
  const [status, setStatus] = useState<Status>('loading');

  useEffect(() => {
    let cancelled = false;

    fetch(`${API_URL}/health/live`)
      .then((res) => {
        if (!cancelled) setStatus(res.ok ? 'ok' : 'error');
      })
      .catch(() => {
        if (!cancelled) setStatus('error');
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-950 p-8 text-slate-100">
      <h1 className="text-2xl font-semibold">ERP System — M1 scaffold</h1>
      <p className="text-slate-400">
        Monorepo, Docker Compose, and CI are wired up. Business modules start
        landing in M2.
      </p>

      {status === 'loading' && (
        <p role="status" className="text-sm text-slate-400">
          Checking API connection…
        </p>
      )}
      {status === 'ok' && (
        <p role="status" className="text-sm text-emerald-400">
          API is reachable at {API_URL}
        </p>
      )}
      {status === 'error' && (
        <p role="alert" className="text-sm text-red-400">
          Could not reach the API at {API_URL}. Is `docker compose up` running?
        </p>
      )}
    </main>
  );
}

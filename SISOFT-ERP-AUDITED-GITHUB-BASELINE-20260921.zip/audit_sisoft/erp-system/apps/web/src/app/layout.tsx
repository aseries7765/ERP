import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ERP System',
  description: 'Universal multi-tenant, AI-native ERP — M1 scaffold',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}): JSX.Element {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

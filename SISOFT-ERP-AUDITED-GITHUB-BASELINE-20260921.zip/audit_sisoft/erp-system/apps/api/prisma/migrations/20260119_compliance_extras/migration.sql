-- M13 Compliance Center — migration 20260119_compliance_extras
--
-- NOT GENERATED FROM A REAL PRISMA MIGRATE RUN. There is no live
-- database or real M2 base schema in this delivery's environment
-- (see MANIFEST.md). This file documents the intended DDL for the
-- models in ../compliance-models.prisma; the merge captain should
-- run `prisma migrate dev` against the real merged schema to generate
-- the actual migration rather than applying this file verbatim.

CREATE TABLE IF NOT EXISTS "BreachNotification" (
  "id" TEXT PRIMARY KEY,
  "tenantId" TEXT NOT NULL,
  "incidentId" TEXT NOT NULL,
  "awareAt" TIMESTAMP NOT NULL,
  "dpaNotifiedAt" TIMESTAMP,
  "individualsNotifiedAt" TIMESTAMP,
  "lastAlertLevel" TEXT,
  "status" TEXT NOT NULL DEFAULT 'open',
  "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
  "updatedAt" TIMESTAMP NOT NULL
);
CREATE INDEX IF NOT EXISTS "BreachNotification_tenantId_status_idx" ON "BreachNotification" ("tenantId", "status");

CREATE TABLE IF NOT EXISTS "LegalHold" (
  "id" TEXT PRIMARY KEY,
  "tenantId" TEXT NOT NULL,
  "reason" TEXT NOT NULL,
  "scope" JSONB NOT NULL,
  "appliedBy" TEXT NOT NULL,
  "appliedAt" TIMESTAMP NOT NULL DEFAULT now(),
  "releasedAt" TIMESTAMP,
  "releasedBy" TEXT
);
CREATE INDEX IF NOT EXISTS "LegalHold_tenantId_releasedAt_idx" ON "LegalHold" ("tenantId", "releasedAt");

CREATE TABLE IF NOT EXISTS "DataResidency" (
  "tenantId" TEXT PRIMARY KEY,
  "primaryRegion" TEXT NOT NULL,
  "allowedRegions" TEXT[] NOT NULL,
  "crossBorderAllowed" BOOLEAN NOT NULL DEFAULT false,
  "approvedExceptions" TEXT[] NOT NULL DEFAULT '{}',
  "updatedAt" TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS "ConsentRecord" (
  "id" TEXT PRIMARY KEY,
  "subjectId" TEXT NOT NULL,
  "purpose" TEXT NOT NULL,
  "action" TEXT NOT NULL,
  "consentVersion" TEXT NOT NULL,
  "ip" TEXT NOT NULL,
  "userAgent" TEXT NOT NULL,
  "timestamp" TIMESTAMP NOT NULL,
  "previousHash" TEXT,
  "hash" TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS "ConsentRecord_subject_purpose_ts_idx" ON "ConsentRecord" ("subjectId", "purpose", "timestamp");
-- G20: revoke UPDATE/DELETE on this table for the application role in
-- production to make immutability DB-enforced, not just app-enforced.

CREATE TABLE IF NOT EXISTS "DataSubjectRequest" (
  "id" TEXT PRIMARY KEY,
  "tenantId" TEXT NOT NULL,
  "subjectId" TEXT NOT NULL,
  "requestType" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'received',
  "receivedAt" TIMESTAMP NOT NULL DEFAULT now(),
  "isComplex" BOOLEAN NOT NULL DEFAULT false,
  "overdueNotifiedAt" TIMESTAMP,
  "completedAt" TIMESTAMP
);
CREATE INDEX IF NOT EXISTS "DataSubjectRequest_tenantId_status_idx" ON "DataSubjectRequest" ("tenantId", "status");

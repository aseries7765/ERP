-- Stage 18: reconcile RBAC persistence with the domain repository contract.
-- Role/role-permission and SoD rules may be platform-wide (NULL tenantId).
ALTER TABLE "roles" ALTER COLUMN "tenantId" DROP NOT NULL;
ALTER TABLE "role_permissions" ALTER COLUMN "tenantId" DROP NOT NULL;
ALTER TABLE "separation_of_duty_rules" ALTER COLUMN "tenantId" DROP NOT NULL;

ALTER TABLE "policies" ADD COLUMN IF NOT EXISTS "description" TEXT NOT NULL DEFAULT '';
ALTER TABLE "separation_of_duty_rules" ADD COLUMN IF NOT EXISTS "description" TEXT NOT NULL DEFAULT '';
ALTER TABLE "separation_of_duty_rules" ADD COLUMN IF NOT EXISTS "severity" TEXT NOT NULL DEFAULT 'block';

ALTER TABLE "access_reviews" ALTER COLUMN "userId" DROP NOT NULL;
ALTER TABLE "access_reviews" ALTER COLUMN "roleId" DROP NOT NULL;
ALTER TABLE "access_reviews" ALTER COLUMN "dueAt" DROP NOT NULL;
ALTER TABLE "access_reviews" ADD COLUMN IF NOT EXISTS "title" TEXT NOT NULL DEFAULT '';
ALTER TABLE "access_reviews" ADD COLUMN IF NOT EXISTS "periodStart" TIMESTAMP(3);
ALTER TABLE "access_reviews" ADD COLUMN IF NOT EXISTS "periodEnd" TIMESTAMP(3);
ALTER TABLE "access_reviews" ADD COLUMN IF NOT EXISTS "status" TEXT NOT NULL DEFAULT 'draft';

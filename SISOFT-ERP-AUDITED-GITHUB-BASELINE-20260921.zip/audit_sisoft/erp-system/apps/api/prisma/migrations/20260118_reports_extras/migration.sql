-- M12 reports_extras migration
-- Additive only. Does not touch any table owned by other modules.
-- Merge captain: run after the M2 baseline schema is applied.

CREATE TABLE IF NOT EXISTS "KpiAlertCooldown" (
  "id" TEXT PRIMARY KEY,
  "tenantId" TEXT NOT NULL,
  "kpiId" TEXT NOT NULL,
  "lastSentAt" TIMESTAMP NOT NULL,
  "breachLevel" TEXT NOT NULL,
  UNIQUE ("tenantId", "kpiId")
);
CREATE INDEX IF NOT EXISTS "KpiAlertCooldown_tenantId_idx" ON "KpiAlertCooldown" ("tenantId");

CREATE TABLE IF NOT EXISTS "TenantAnalyticsOptIn" (
  "tenantId" TEXT PRIMARY KEY,
  "optedIn" BOOLEAN NOT NULL DEFAULT false,
  "updatedAt" TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS "ReportResultCacheEntry" (
  "id" TEXT PRIMARY KEY,
  "tenantId" TEXT NOT NULL,
  "reportId" TEXT NOT NULL,
  "paramsHash" TEXT NOT NULL,
  "columns" JSONB NOT NULL,
  "rows" JSONB NOT NULL,
  "cachedAt" TIMESTAMP NOT NULL DEFAULT now(),
  "expiresAt" TIMESTAMP NOT NULL,
  UNIQUE ("tenantId", "reportId", "paramsHash")
);
CREATE INDEX IF NOT EXISTS "ReportResultCacheEntry_tenant_report_idx" ON "ReportResultCacheEntry" ("tenantId", "reportId");
CREATE INDEX IF NOT EXISTS "ReportResultCacheEntry_expiresAt_idx" ON "ReportResultCacheEntry" ("expiresAt");

CREATE TABLE IF NOT EXISTS "ReportExportJob" (
  "id" TEXT PRIMARY KEY,
  "tenantId" TEXT NOT NULL,
  "reportId" TEXT NOT NULL,
  "format" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "rowCount" INTEGER,
  "signedUrl" TEXT,
  "error" TEXT,
  "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
  "completedAt" TIMESTAMP
);
CREATE INDEX IF NOT EXISTS "ReportExportJob_tenant_status_idx" ON "ReportExportJob" ("tenantId", "status");

-- NOT included in this migration (would be owned by M2, not M12):
-- Row-Level Security policies on Report/Dashboard/Kpi tables. This
-- delivery assumes M2 already enforces tenant_id RLS at the session
-- level, per the spec's step 6 ("Apply RLS (defense in depth)") —
-- M12's query-builder tenant scoping is an additional layer on top
-- of that, not a replacement for it. See MANIFEST.md.

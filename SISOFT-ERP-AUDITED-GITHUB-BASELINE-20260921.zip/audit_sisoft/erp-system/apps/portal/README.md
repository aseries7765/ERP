# @erp/portal

Customer-facing portal (S6 Advanced Customer Portal).

## Current Status

This is a **minimal stub** created during the integration pass.

The original S6 delivery contained only core services (handoff token, MFA, permission matrix). A full Next.js portal application was not delivered.

## Future work

- Authentication handoff from control plane
- Customer self-service (invoices, users, support)
- Branding engine integration

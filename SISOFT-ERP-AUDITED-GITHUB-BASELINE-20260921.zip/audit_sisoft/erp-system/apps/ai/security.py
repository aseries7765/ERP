"""
M15 security additions to the AI module (apps/ai).

STATUS: partial implementation. Prompt injection detection is M10's
responsibility (already noted as existing in the M15 prompt context)
and is NOT reimplemented here. This file adds the pieces explicitly
scoped to M15: output sanitization and basic PII-leak prevention as a
defense-in-depth layer on model output, before it's returned to the
API layer or shown to a user.

NOT implemented in this slice (documented honestly rather than
stubbed to look complete):
- Model access control (which service accounts/roles can call which
  models) — this is an authorization concern that should reuse M3.3's
  RBAC rather than a parallel system; not wired in here.
- Full PII-leak prevention would ideally use a proper PII-detection
  model/NER pipeline; the regex-based approach below catches common
  patterns (emails, SSNs, card-like numbers) but will miss more
  subtle leaks (e.g., a name + address combination that's only
  sensitive in combination). Treat this as a coarse safety net, not a
  guarantee.
"""

import re
from dataclasses import dataclass, field

_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
_SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_CARD_RE = re.compile(r"\b(?:\d[ -]*?){13,16}\b")


@dataclass
class SanitizationResult:
    text: str
    redactions: list = field(default_factory=list)


def sanitize_model_output(text: str) -> SanitizationResult:
    """
    Redacts common PII patterns from model output before it's returned
    to a caller. This is a coarse, regex-based safety net -- see the
    module docstring for its limitations. Real deployments handling
    regulated PHI/PII at scale should pair this with a proper
    NER-based PII detector.
    """
    redactions = []
    result = text

    for pattern, label in ((_EMAIL_RE, "EMAIL"), (_SSN_RE, "SSN"), (_CARD_RE, "CARD")):
        matches = pattern.findall(result)
        if matches:
            redactions.append({"type": label, "count": len(matches)})
            result = pattern.sub(f"[REDACTED_{label}]", result)

    return SanitizationResult(text=result, redactions=redactions)


def contains_likely_pii(text: str) -> bool:
    """Quick check without performing redaction, for logging/anomaly purposes."""
    return bool(_EMAIL_RE.search(text) or _SSN_RE.search(text) or _CARD_RE.search(text))


# Prompt injection detection: NOT reimplemented here. Per the M15
# prompt's context, this already exists as part of M10. If this file
# is merged into a codebase where that isn't true, add a call to
# M10's detector before sending user input to the model, not after --
# output sanitization here is a last line of defense, not a
# substitute for input-side prompt injection detection.

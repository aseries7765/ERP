# Stage 62 Runtime Gate

The runtime gate intentionally fails closed. It requires real endpoints for metrics, tracing and log aggregation plus executable checks proving correlation propagation, alert delivery and incident-evidence capture.

Required environment variables:
- `STAGE62_METRICS_URL`
- `STAGE62_TRACING_URL`
- `STAGE62_LOGS_URL`
- `STAGE62_ALERT_TEST_COMMAND`
- `STAGE62_CORRELATION_TEST_COMMAND`
- `STAGE62_INCIDENT_EVIDENCE_COMMAND`

A runtime PASS is only emitted after all real probes and evidence commands succeed.

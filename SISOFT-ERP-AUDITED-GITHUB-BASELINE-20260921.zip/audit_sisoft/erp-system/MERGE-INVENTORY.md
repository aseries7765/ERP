# MERGE-INVENTORY.md
Generated: 2026-09-19 (initial pass)

## Legend
- Layout: standard = `apps/docs/packages/prisma/scripts` at zip root
- Layout: nested = real repo root is one level down inside a wrapper folder (naming inconsistent across stages — deficiency, see below)

| Archive | Stage | True root path | Layout | Files | Size | Notes |
|---|---|---|---|---|---|---|
| ERP-MERGED-AUDITED-20260917.zip | pre-40 (parallel lineage) | `/` | standard | 2494 | 14M | 30 packages, 5 apps, infra/, tools/. Broadest scope of any archive. |
| ERP-STAGE40-FOUNDATION-BASELINE-RECONSTRUCTION-20260917.zip | 40 | `/` | standard | 1125 | 6.5M | Baseline reset: only 6 packages retained (dsr-engine, payroll-country-plugins, query-builder, security, shared-types, workflow-engine) |
| ERP-STAGE41-PRISMA-RUNTIME-GATE-20260917.zip | 41 | `/` | standard | 1127 | 6.5M | |
| ERP-STAGE42-FOUNDATION-MIGRATION-DEPENDENCY-ORDER-20260917.zip | 42 | `/` | standard | 1131 | 6.5M | |
| ERP-STAGE43-MIGRATION-BASELINE-CANDIDATE-REVIEW-20260917.zip | 43 | `/` | standard | 1135 | 6.6M | |
| ERP-STAGE44-EXECUTABLE-FOUNDATION-BASELINE-DESIGN-20260917.zip | 44 | `/` | standard | 1139 | 6.7M | |
| ERP-STAGE45-DATABASE-FEATURE-RECONCILIATION-20260917.zip | 45 | `/` | standard | 1141 | 6.7M | |
| ERP-STAGE46-AUTHORITATIVE-DATABASE-INFRASTRUCTURE-20260918.zip | 46 | `/` | standard | 1144 | 6.7M | |
| ERP-STAGE47-PRISMA-BASELINE-GENERATION-GATE-20260918.zip | 47 | `/` | standard | 1147 | 6.7M | |
| ERP-STAGE48-PRISMA-RUNTIME-GATE-20260918.zip | 48 | `/erp_work48/` | **nested** | 1150 | 6.7M | DEFICIENCY: non-standard wrapper folder |
| ERP-STAGE49-DATABASE-CONSISTENCY-GATE-20260918.zip | 49 | `/` | standard | 1157 | 7.9M | |
| ERP-STAGE50-POSTGRESQL-RUNTIME-CATALOG-GATE-20260918.zip | 50 | `/erp_work50/` | **nested** | 1161 | 6.8M | DEFICIENCY: non-standard wrapper folder |
| ERP-STAGE51-CLEAN-DATABASE-MIGRATION-REHEARSAL-20260918.zip | 51 | `/` | standard | 1167 | 8.0M | |
| ERP-STAGE53-POST-RUNTIME-SCHEMA-POLICY-SMOKE-20260918.zip | 53 | `/` | standard | 1176 | 8.0M | Stage 52 was never supplied as its own archive — referenced only inside stage55's bundled docs (docs-STAGE52-*.md) |
| ERP-STAGE54-RUNTIME-EVIDENCE-CONSOLIDATION-20260918.zip | 54 | `/` | standard | 1182 | 11M | |
| ERP-STAGE55-END-TO-END-APPLICATION-INTEGRATION-GATE-20260918.zip | 55 | `/erp_work55/` | **nested** | 1190 | 16M | DEFICIENCY: nested; also contains raw copies of STAGE50/53/54 zips + .sha256 files INSIDE it (redundant payload bloat) |
| ERP-STAGE56-RUNTIME-API-MUTATION-ROLLBACK-20260918.zip | 56 | `/` | standard | 1193 | 6.9M | |
| ERP-STAGE57-RUNTIME-EVIDENCE-RECONCILIATION-20260918.zip | 57 | `/` | standard | 1194 | 6.9M | |
| ERP-STAGE58-RELEASE-READINESS-PRODUCTION-CONFIG-20260918.zip | 58 | `/erp_work55-stage58/` | **nested** | 1198 | 6.9M | DEFICIENCY: wrapper name conflates stage55+58 |
| ERP-STAGE59-OPERATIONAL-RUNTIME-READINESS-20260918.zip | 59 | `/stage58/` | **nested** | 1204 | 6.9M | DEFICIENCY: wrapper folder literally named "stage58" despite being stage 59 content |
| ERP-STAGE60-PRODUCTION-DEPLOYMENT-DRIFT-20260918.zip | 60 | `/` | standard | 1212 | 7.0M | Adds top-level `deployment/` dir |
| ERP-STAGE61-PRODUCTION-RECOVERY-20260918.zip | 61 | `/stage58/` | **nested** | 1216 | 7.0M | DEFICIENCY: wrapper folder still named "stage58". Latest cumulative snapshot — most complete in this lineage. |
| his-1-patient-core-slice-VERIFIED-20260917200119.zip | HIS-1 | `/` | standard | 36 | 252K | Separate product line: Hospital Info System. packages/his-core, apps/api only. |
| his-2-ancillary-clinical-20260918-040401.zip | HIS-2 | `/` | standard | 78 | 456K | Adds pharmacy/lab/blood-bank/radiology engines. **DEFICIENCY**: contains a corrupt literal directory named `{pharmacy-engine,lab-engine,blood-bank-engine,radiology-engine}` (unexpanded shell brace — packaging bug), sitting alongside the real per-engine folders. Needs manual reconciliation of which copy is authoritative. |

## Critical structural finding (see MERGE-DECISIONS.md #1)
Two divergent lineages exist under the same package identity (`erp-system@1.0.0-merged`):
- **Lineage A ("wide")**: ERP-MERGED-AUDITED-20260917 — 30 packages, 5 apps, infra/, tools/ (security pentest/chaos tooling).
- **Lineage B ("narrow/verified")**: STAGE40→STAGE61 — only 6 packages ever present, but each stage adds runtime-verification evidence (Prisma gates, Postgres catalog checks, migration rehearsals, API mutation/rollback tests, deployment drift, production recovery).

Stage 40 is named "FOUNDATION BASELINE RECONSTRUCTION" — consistent with it being a deliberate narrowing/reset away from Lineage A to re-verify a minimal foundation before re-adding breadth. Lineage A's 24 extra packages (billing, GL, MRP, sales-pipeline, gantt, quality, compliance, barcode, branding, canary, cloud-provider(+Oracle), control-plane-client, deployment-engine, form-builder, provisioning-engine, sync-crdt, terminology, uom-engine, version-engine, ai-client, ai-prompts, backup-engine) never reappear in any Stage 40–61 archive.

Also missing from every supplied archive: **Stage 52** (referenced in docs but its own zip was never uploaded).

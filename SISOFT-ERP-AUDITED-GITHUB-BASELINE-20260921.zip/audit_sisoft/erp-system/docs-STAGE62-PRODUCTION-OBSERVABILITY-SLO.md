# Stage 62 — Production Observability, SLO and Incident-Evidence Gate

## Objective
Establish a fail-closed observability contract for Sisoft covering structured logs, correlation, metrics, tracing, SLI/SLO definitions, alert routing, incident evidence, audit/event evidence and retention.

## Required telemetry
- Structured JSON logs with timestamp, severity, service, environment, correlation/request ID and outcome.
- Tenant identifiers only where policy permits; secrets, tokens, passwords and sensitive payloads must never be logged.
- HTTP request duration, status, route class and error counters.
- Database latency/error metrics and connection saturation.
- Redis latency/errors and cache health.
- Queue depth, job latency, retries and dead-letter counts.
- Authentication failures, authorization denials and rate-limit events.
- Audit/outbox processing lag and failure counts.
- Liveness/readiness remain separate from observability health.

## Correlation contract
A request correlation ID must be accepted from a trusted inbound header or generated server-side, validated for safe length/characters, propagated through logs and asynchronous jobs, and returned in responses. Correlation IDs are diagnostic identifiers, not authorization credentials.

## SLI/SLO baseline
Initial SLI definitions:
- Availability: successful eligible API requests / total eligible API requests.
- Latency: percentage of eligible requests below endpoint-class latency threshold.
- Error rate: 5xx and classified dependency failures / eligible requests.
- Queue freshness: percentage of jobs completed within their service-class target.
- Recovery evidence: successful restore/recovery exercises within the documented RTO/RPO target.

SLO targets must be configured per service class and measured from real telemetry. No target is considered achieved merely because it is documented.

## Alerting
Alerts must be actionable, deduplicated and routed by severity. At minimum define:
- sustained availability breach;
- sustained latency breach;
- dependency outage;
- queue backlog/dead-letter growth;
- authentication/security anomaly;
- audit/outbox processing failure;
- backup/recovery evidence failure.

Alert rules must identify the service, environment, severity, SLO/SLI, runbook reference and incident correlation key.

## Incident evidence
An incident record should preserve:
1. incident ID;
2. start/end timestamps;
3. affected service/region/tenant scope where safe;
4. alert fingerprints;
5. correlation IDs;
6. relevant log/metric/trace references;
7. timeline of material events;
8. mitigation and recovery actions;
9. deployment/configuration version;
10. post-incident verification;
11. retention/expiry metadata.

Evidence must be append-oriented and access-controlled. Secrets and raw sensitive payloads must be excluded or redacted.

## Runtime rule
Static observability contracts may PASS after inspection. Runtime observability PASS requires actual telemetry collection, query access, alert delivery and evidence capture against a real target environment. Missing telemetry infrastructure is BLOCKED, never PASS.

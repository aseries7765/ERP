#!/usr/bin/env python3
"""Static Stage 63 distributed rate-limit/backpressure/capacity contract verifier."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent

contracts = {
    "docs-STAGE63-DISTRIBUTED-RATE-LIMITING-BACKPRESSURE.md": [
        "Distributed rate limiting", "Redis", "Atomic", "429", "Backpressure",
        "Tenant fairness", "Resource exhaustion", "Capacity evidence", "100M+", "Runtime rule"
    ],
    "docs-STAGE63-EXCEPTIONS.md": [
        "Runtime infrastructure unavailable", "BLOCKED", "No fabricated scale result"
    ],
}
for name, needles in contracts.items():
    p = ROOT / name
    if not p.is_file():
        print(f"MISSING: {name}")
        sys.exit(1)
    text = p.read_text(encoding="utf-8")
    for needle in needles:
        if needle not in text:
            print(f"MISSING CONTRACT: {name}: {needle}")
            sys.exit(1)

roadmap = (ROOT / "ROADMAP.md").read_text(encoding="utf-8") if (ROOT / "ROADMAP.md").exists() else ""
next_steps = (ROOT / "NEXT-STEPS.md").read_text(encoding="utf-8") if (ROOT / "NEXT-STEPS.md").exists() else ""
if "Stage 63" not in roadmap:
    print("MISSING ROADMAP STAGE 63 ENTRY")
    sys.exit(1)
if "Stage 64" not in next_steps:
    print("MISSING NEXT-STEPS STAGE 64")
    sys.exit(1)

# Reject accidental numeric capacity claims in the canonical contract unless explicitly marked as examples/targets.
for name in contracts:
    text = (ROOT / name).read_text(encoding="utf-8")
    forbidden = re.findall(r"\b\d+(?:\.\d+)?\s*(?:RPS|requests/sec|req/s|concurrent users)\b", text, re.I)
    if forbidden:
        print(f"UNVERIFIED CAPACITY CLAIM: {name}: {forbidden[0]}")
        sys.exit(1)

print("STAGE63 STATIC PASS")
print("Capacity matrix: distributed rate limiting, backpressure, concurrency, tenant fairness, resource protection, load evidence")
print("Runtime verdict: BLOCKED until real multi-instance Redis/queue/database/load infrastructure and evidence are supplied")

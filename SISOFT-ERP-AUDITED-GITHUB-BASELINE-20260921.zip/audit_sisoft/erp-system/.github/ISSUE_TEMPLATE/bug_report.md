---
name: Bug report
author: aseries7765
about: Report a reproducible Sisoft ERP defect
---

## Summary

## Reproduction steps

## Expected behavior

## Actual behavior

## Environment

## Logs / evidence

Do not include secrets, credentials, tokens, or customer data.

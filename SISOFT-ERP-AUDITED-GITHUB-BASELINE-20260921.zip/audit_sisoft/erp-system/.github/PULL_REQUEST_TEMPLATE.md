## Change summary

## Scope
- [ ] Code
- [ ] Database/schema
- [ ] Security
- [ ] Documentation
- [ ] Infrastructure

## Validation
- [ ] Tests run
- [ ] Typecheck/build run
- [ ] Static gates run where applicable
- [ ] Runtime verification status is stated honestly

## Tenant/security review
- [ ] Tenant isolation considered
- [ ] Authorization considered
- [ ] No secrets added
- [ ] API compatibility reviewed

## Documentation
- [ ] Canonical documentation updated if behavior/architecture changed

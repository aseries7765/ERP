# Sisoft ERP — Development Rules

1. Read `PROJECT-CONTEXT.md`, `ARCHITECTURE.md`, `MODULE-MAP.md`, `ROADMAP.md`, and the relevant module/security docs before changing architecture.
2. Search existing code before creating a new service, package, schema model, event, endpoint, or utility.
3. Preserve existing APIs unless a breaking change is necessary and documented.
4. Do not create duplicate implementations when an existing implementation can be extended safely.
5. Tenant boundaries must be explicit at API, service, query, cache, event, and database layers.
6. Never commit secrets, credentials, private keys, production `.env` files, or customer credentials.
7. Do not mark runtime behavior PASS from static inspection alone.
8. New functionality requires tests at the appropriate layer.
9. Database changes require schema, migration, RLS/trigger/privilege review, and runtime validation where applicable.
10. Update canonical documentation when architecture or implementation status changes.
11. Keep control-plane and data-plane responsibilities explicit.
12. Provider-specific code must remain behind provider abstractions.
13. Do not split modules into repositories/services without a concrete operational reason.
14. Do not rewrite Git history merely to make it look cleaner.
15. Commit messages must describe real changes.
16. Prefer small reviewable changes for future work; the initial import of this previously-unversioned baseline is necessarily a single current-state import commit because historical Git history is unavailable.

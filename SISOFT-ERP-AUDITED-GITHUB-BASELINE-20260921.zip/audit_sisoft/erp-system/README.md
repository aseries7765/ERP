# Sisoft Universal ERP

**Repository:** `aseries7765/erp`  
**Architecture:** Modular monorepo (pnpm + Turbo)  
**Current audited source baseline:** Canonical merged baseline + Stage 72 trust/service-identity reconciliation  
**Status:** Active development; runtime/production verification is incomplete

Sisoft is a universal multi-industry ERP codebase containing a NestJS API, Next.js web application, background-worker foundation, ERP modules, shared engines, database schema/migrations, infrastructure contracts, and security tooling.

## Repository facts

- 193 Prisma models
- 22 Prisma enums
- 17 migration directories
- 36 API module directories
- 35 shared packages
- 4 application packages (`api`, `web`, `worker`, `portal`)
- 213 documentation files under `docs/`
- CI and security workflows under `.github/workflows/`

## Important status distinction
Static implementation and architecture contracts are present across many areas, but runtime infrastructure verification remains incomplete. Do not interpret architecture documents, static gates, or tests that have not been executed in the current environment as production certification.

`apps/portal` is explicitly a stub. `apps/worker` is a structural worker foundation. The Oracle provider abstraction exists, but production OCI SDK provisioning is not proven. A separately deployed control-plane service is not present in the supplied source.

## Quick start

```bash
cp .env.example .env
pnpm install
pnpm db:validate
pnpm dev
```

A `pnpm-lock.yaml` was not supplied in the audited baseline, so reproducible frozen-lockfile installation is currently blocked until a legitimate lockfile is generated from the actual dependency graph.

## Canonical documentation

- `PROJECT-CONTEXT.md` — product/source-of-truth context
- `ARCHITECTURE.md` — current architecture and scale boundaries
- `MODULE-MAP.md` — factual module status
- `IMPLEMENTATION-STATUS.md` — implementation/runtime status
- `TENANT-ARCHITECTURE.md` — tenant/control-plane/customer-environment model
- `SECURITY-ARCHITECTURE.md` — security architecture and source-control findings
- `DEVELOPMENT-RULES.md` — rules for future development and AI-assisted work
- `ROADMAP.md` — staged development roadmap
- `SOURCE-CONTROL-SETUP.md` — Git/GitHub operating model

## Security
Never commit production secrets or customer credentials. Use `.env.example` only for non-secret development contracts. Review `.github/workflows/security.yml` and `SECURITY.md` before opening the repository to broader contributors.

# Stage 72 — Global Certificate, Trust Chain & Service Identity Lifecycle Integrity Gate

## Objective
Define a provider-neutral trust fabric for Sisoft control-plane and data-plane services. Certificates and workload identities are lifecycle-managed assets, not static deployment secrets.

## CA and trust hierarchy
Use an offline/provider-managed root, purpose/environment-separated intermediates, and short-lived leaf certificates. Root and intermediate changes are versioned and audited. Application workloads never receive root private keys.

## Service identity
Every workload identity has a stable service identifier plus environment, region, purpose and key/certificate version. Tenant-scoped identities additionally carry an authoritative tenant binding. Identity claims cannot override placement or authorization policy.

## mTLS
Sensitive control-plane and internal service communication uses mutual TLS. Peers validate certificate chain, validity window, revocation status, identity, intended audience/purpose and tenant boundary. Unknown, expired, revoked or mismatched identities fail closed.

## Issuance and renewal
Certificate issuance is authorized, scoped and auditable. Renewal happens before expiry. New and old certificates overlap only for an explicitly bounded period. Activation is atomic so a partial rotation cannot leave a service without a valid identity.

## Zero-downtime rotation
Rotation follows: issue → validate → distribute → activate → verify new identity → drain old identity → revoke/retire old identity. Both identities must never be simultaneously accepted outside their defined overlap window.

## Trust-bundle distribution
Trust bundles are immutable, signed/versioned artifacts. Distribution is atomic and version-aware. Security-critical stale or unverifiable bundles fail closed. Rollback is limited to a known-good verified bundle.

## Regional recovery
Regional recovery must preserve service identity purpose and authorization boundaries. A region may not silently substitute an unrelated CA, certificate, or service identity. Cross-region trust requires explicit policy.

## Tenant isolation
Tenant service identities are distinct from global control-plane identities. Certificate possession alone does not grant tenant access; authorization still requires authoritative tenant context and policy.

## Runtime evidence
Runtime PASS requires real CA/identity infrastructure and evidence for issuance, mTLS handshake, identity binding, zero-downtime rotation, expiry/revocation rejection, trust-bundle rollback and regional recovery. Static policy validation is not runtime proof.

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts-verify-stage62.py"

required=(STAGE62_METRICS_URL STAGE62_TRACING_URL STAGE62_LOGS_URL STAGE62_ALERT_TEST_COMMAND STAGE62_CORRELATION_TEST_COMMAND STAGE62_INCIDENT_EVIDENCE_COMMAND)
missing=()
for v in "${required[@]}"; do
  [[ -n "${!v:-}" ]] || missing+=("$v")
done
if ((${#missing[@]})); then
  echo "STAGE62 RUNTIME BLOCKED: missing ${missing[*]}" >&2
  exit 2
fi

command -v curl >/dev/null || { echo "STAGE62 RUNTIME BLOCKED: curl unavailable" >&2; exit 2; }

for url_var in STAGE62_METRICS_URL STAGE62_TRACING_URL STAGE62_LOGS_URL; do
  url="${!url_var}"
  curl --fail --silent --show-error --max-time 10 "$url" >/dev/null || {
    echo "STAGE62 RUNTIME BLOCKED: $url_var probe failed" >&2
    exit 2
  }
done

bash -lc "$STAGE62_CORRELATION_TEST_COMMAND"
bash -lc "$STAGE62_ALERT_TEST_COMMAND"
bash -lc "$STAGE62_INCIDENT_EVIDENCE_COMMAND"

echo "STAGE62 RUNTIME PASS"

# Stage 36 — Prisma / Schema / Migration Integration Gate

Date: 2026-09-17

## Result

This stage performs a static reconciliation of `prisma/schema.prisma` against the tracked migration history. It deliberately does **not** fabricate a Prisma migration when PostgreSQL/Prisma tooling is unavailable.

### Static findings

- Prisma schema models: **192**
- Prisma enums: **21**
- Tracked migration `CREATE TABLE` coverage: **74 tables**
- Schema tables with no tracked `CREATE TABLE`: **118**
- Duplicate model/field structural check: **PASS**
- Migration baseline coverage: **BLOCKED**

The 118-table gap is not treated as evidence that those tables do not exist in a user's real database; it means the repository's tracked migration history does not contain their creation. A production deployment must not assume that `prisma migrate deploy` from this repository can create a fresh database matching the current schema.

## Why no migration was generated here

The available environment does not provide a Prisma CLI installation or a reachable PostgreSQL instance. Generating a hand-written `init_foundation` migration would create an unverified migration history and could produce destructive or incompatible SQL. The correct production action is to generate/verify the baseline against a disposable PostgreSQL database using the project's pinned Prisma version.

## Required external/runtime gate

On a machine/CI runner with PostgreSQL and dependencies available:

1. `pnpm install --frozen-lockfile`
2. `pnpm db:generate`
3. `pnpm db:validate`
4. Create an empty PostgreSQL 16 database with required extensions.
5. Generate a real baseline migration from the current schema.
6. Apply/fold the required raw SQL for UUID/RLS/triggers/app-role grants.
7. Apply every tracked module migration in order against a disposable database.
8. Run `prisma migrate status` and `prisma validate`.
9. Run schema/RLS database tests using the non-superuser application role.
10. Only after those checks pass, designate the resulting migration chain as the production baseline.

## Important safety rule

Do **not** delete or rewrite the existing module migrations merely to make the migration count match the schema. First determine which historical baseline those migrations were intended to extend. The 118-table gap requires reconciliation of the original foundation schema with the later module migrations.

## Verification command

```bash
./scripts/verify-stage36-prisma-gate.sh
```

The command is expected to report the migration-baseline gate as BLOCKED in this environment. That is an intentional truthful result, not a test failure disguised as PASS.

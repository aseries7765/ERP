-- Runs once, on first container start (docker-entrypoint-initdb.d).
-- Extensions needed by later milestones are enabled now so M2's migrations
-- don't need superuser privileges.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";   -- UUID generation helpers
CREATE EXTENSION IF NOT EXISTS "pgcrypto";    -- gen_random_uuid(), crypto fns
CREATE EXTENSION IF NOT EXISTS "pg_trgm";     -- fuzzy/full-text search support
-- pgvector is added in M10 (AI service) via a versioned migration, not here,
-- since it requires the pgvector-enabled Postgres image.

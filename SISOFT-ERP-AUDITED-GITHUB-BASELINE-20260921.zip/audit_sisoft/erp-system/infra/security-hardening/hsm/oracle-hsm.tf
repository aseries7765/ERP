terraform {
  required_providers {
    oci = {
      source  = "oracle/oci"
      version = "~> 5.0"
    }
  }
}

# Included for parity with the multi-cloud key-management options
# referenced in the M15 spec. Only provision this if a customer's
# environment specifically targets OCI (per the amendment's
# customer-environment independence — this would be per-customer,
# not shared control-plane infra).

resource "oci_kms_vault" "customer_env" {
  compartment_id = var.compartment_id
  display_name   = "erp-customer-vault"
  vault_type     = "VIRTUAL_PRIVATE" # HSM-backed
}

variable "compartment_id" {
  type = string
}

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
  }
}

resource "azurerm_key_vault_managed_hardware_security_module" "control_plane" {
  name                       = "erp-cp-hsm"
  resource_group_name        = var.resource_group_name
  location                   = var.location
  sku_name                   = "Standard_B1"
  tenant_id                  = var.azure_tenant_id
  admin_object_ids           = var.hsm_admin_object_ids
  purge_protection_enabled   = true
  soft_delete_retention_days = 90
}

variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "azure_tenant_id" { type = string }
variable "hsm_admin_object_ids" {
  description = "AAD object IDs authorized to administer the HSM — keep this list minimal (break-glass principle)"
  type        = list(string)
}

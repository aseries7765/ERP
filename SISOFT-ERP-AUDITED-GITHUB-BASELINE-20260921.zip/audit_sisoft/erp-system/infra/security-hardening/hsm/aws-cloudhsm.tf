terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

# Control-plane only, per the amendment: highest-security tier gets HSM
# key storage; customer environments use Vault-managed keys (see
# ../vault/) unless a specific enterprise customer contracts for
# dedicated HSM (out of scope for the shared control plane).

resource "aws_cloudhsm_v2_cluster" "control_plane" {
  hsm_type   = "hsm1.medium"
  subnet_ids = var.private_subnet_ids
  tags = {
    Environment = "control-plane"
    ManagedBy   = "m15-security-hardening"
  }
}

resource "aws_cloudhsm_v2_hsm" "primary" {
  cluster_id = aws_cloudhsm_v2_cluster.control_plane.cluster_id
  subnet_id  = var.private_subnet_ids[0]
}

variable "private_subnet_ids" {
  description = "Private subnet IDs in the control-plane VPC, one per AZ for HA"
  type        = list(string)
}

# NOTE: CloudHSM clusters take ~30 min to initialize and require manual
# cluster initialization (activate with a signed CSR) that Terraform
# cannot automate — see AWS docs for the post-apply activation steps.
# Not applied to real infrastructure in this delivery.

terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

resource "aws_shield_protection" "api_alb" {
  name         = "erp-api-alb-shield"
  resource_arn = var.alb_arn
}

resource "aws_shield_protection" "cloudfront" {
  count        = var.cloudfront_distribution_arn != "" ? 1 : 0
  name         = "erp-cloudfront-shield"
  resource_arn = var.cloudfront_distribution_arn
}

# Shield Advanced (paid tier) required for these — Shield Standard is
# automatic and free but has no configurable resources.
variable "alb_arn" {
  description = "ARN of the API load balancer to protect"
  type        = string
}

variable "cloudfront_distribution_arn" {
  description = "ARN of the CloudFront distribution, if used"
  type        = string
  default     = ""
}

# Worker (background jobs: key rotation, cert monitoring, scans) policy.
# Broader than the API policy because rotation jobs need write access
# to rotate credentials — still scoped to erp-api's own secret space.

path "secret/data/erp-api/*" {
  capabilities = ["read", "update"]
}

path "database/creds/erp-api-role" {
  capabilities = ["read"]
}

path "database/roles/erp-api-role" {
  capabilities = ["read", "update"] # needed to rotate the role's TTL/creds
}

path "pki/issue/erp-internal" {
  capabilities = ["update"] # cert rotation
}

path "transit/keys/erp-api" {
  capabilities = ["read", "update"] # key rotation (transit key versioning)
}

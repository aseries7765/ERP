# API service Vault policy — read-only access to its own secrets,
# scoped by path. Least-privilege: no access to other services'
# secrets, no access to control-plane HSM-backed keys.

path "secret/data/erp-api/*" {
  capabilities = ["read"]
}

path "database/creds/erp-api-role" {
  capabilities = ["read"]
}

path "transit/encrypt/erp-api" {
  capabilities = ["update"]
}

path "transit/decrypt/erp-api" {
  capabilities = ["update"]
}

# Explicitly deny access to admin/control-plane paths.
path "secret/data/control-plane/*" {
  capabilities = ["deny"]
}

# Break-glass admin policy. NOT attached to any standing role/token by
# default — issued only via a time-limited, MFA-gated break-glass
# procedure (see docs/security/INCIDENT_RESPONSE.md). Any use of this
# policy should itself trigger a security.policy.violation-adjacent
# alert for review, since legitimate day-to-day operations should never
# need it.

path "secret/data/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}

path "sys/policies/acl/*" {
  capabilities = ["read", "list"]
}

path "transit/keys/*" {
  capabilities = ["read", "update"]
}

# Explicitly excludes root token generation and Shamir unseal key
# access — those require the separate, offline break-glass procedure
# documented in docs/security/SECRETS_MANAGEMENT.md, not a Vault policy.

# Sisoft ERP — Source-Control Setup

## Repository
`aseries7765/erp`

## Current GitHub state at audit time
- Public repository.
- Default branch: `main`.
- Repository size: 0 KB.
- No branch/commit history was available because GitHub reports the repository as empty.
- Supplied local source also contains no `.git` directory.

## Initial import policy
Do not fabricate historical commits. Import the audited current source as a single clearly named baseline commit. Future work should use feature/fix branches and pull requests rather than direct experimental pushes to `main`.

## Recommended branch model
- `main` — protected release/default branch.
- `feature/*` — new functionality.
- `fix/*` — defects.
- `release/*` — release stabilization only when needed.

Avoid maintaining a permanent `develop` branch unless the team later demonstrates a real need for it.

## Recommended GitHub controls
Protect `main`, require CI checks and pull-request review when collaboration begins, disable force pushes/deletions, and use CODEOWNERS for sensitive areas. GitHub supports protected-branch requirements including reviews, status checks, signed commits and force-push/deletion restrictions. citeturn0search2turn0search3

CODEOWNERS should live in `.github/CODEOWNERS`; GitHub recognizes that location and can require code-owner review when branch protection is configured accordingly. citeturn0search1

## Repository security
Enable/verify secret scanning, push protection, dependency alerts and code scanning. Add `SECURITY.md`. GitHub recommends these controls for repository security, especially for public repositories. citeturn0search0turn0search4

#!/usr/bin/env python3
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
policy=ROOT/'STAGE72-TRUST-IDENTITY-POLICY.json'
doc=ROOT/'docs-STAGE72-GLOBAL-CERTIFICATE-TRUST-SERVICE-IDENTITY.md'
exc=ROOT/'docs-STAGE72-EXCEPTIONS.md'
for p in (policy,doc,exc):
    if not p.exists(): raise SystemExit(f'MISSING: {p}')
data=json.loads(policy.read_text())
for k in ('certificate_authority','service_identity','mtls','lifecycle','trust_bundle','runtime_evidence_required'):
    if k not in data: raise SystemExit(f'MISSING POLICY SECTION: {k}')
if data.get('stage')!=72 or data['mtls'].get('fail_closed') is not True or data['lifecycle'].get('zero_downtime_rotation') is not True: raise SystemExit('INVALID SAFETY CONTRACT')
text=doc.read_text().lower()
for phrase in ('CA and trust hierarchy','Service identity','mTLS','Issuance and renewal','Zero-downtime rotation','Trust-bundle distribution','Regional recovery','Tenant isolation','Runtime evidence'):
    if phrase.lower() not in text: raise SystemExit(f'MISSING DOC CONCEPT: {phrase}')
for p in (policy,doc,exc):
    if re.search(r'(?i)(measured|benchmark|throughput|latency)\s*[:=]\s*\d',p.read_text()): raise SystemExit(f'UNVERIFIED MEASUREMENT FOUND: {p}')
print('STAGE72 STATIC PASS')
print('Trust matrix: CA hierarchy, service identity, mTLS, rotation, revocation, trust-bundle distribution, regional recovery')
print('Runtime verdict: BLOCKED until real certificate/identity infrastructure and evidence are supplied')

# Stage 69 Exceptions

- Runtime PASS is not claimed from static inspection alone.
- No fabricated global policy convergence, authorization latency, throughput, or 100M+ capacity figures are permitted.
- A stale security-critical policy must fail closed rather than silently continue with unknown authorization state.
- Client-provided policy versions cannot override the authoritative control plane.
- Conflicting tenant overrides must block activation; precedence must be deterministic and documented.
- Missing distribution acknowledgements mean global convergence is unproven.
- Simulation evidence must never be represented as live authorization evidence.
- Control-plane failover requires real fencing/reconciliation evidence before runtime PASS.

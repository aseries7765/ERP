# Stage 49 — Explicit Database Consistency Exceptions

## Transitive unique constraints

The following tenant-scoped tables intentionally use uniqueness through a globally unique parent identifier rather than repeating `tenantId` in the unique key:

1. `terminology_packs`: `terminologyPackId + key + locale`
2. `access_reviews`: `accessReviewId + userId + roleKey`
3. `event_deliveries`: `outboxId + target`

These are not treated as cross-tenant security boundaries. Their parent identifiers are UUID/cuid identifiers that identify the owning object globally. Tenant isolation remains enforced by the `tenantId` RLS policy on the child table.

## Tenant access paths

`TenantAnalyticsOptIn` and `DataResidency` use `tenantId` as their primary key. `FinancePostingProfile` uses a unique `tenantId`. These provide tenant-leading access paths without a separate `@@index([tenantId])`.

## Nullable tenant reference

`Vulnerability.tenantId` is nullable. Stage 49 adds `@@index([tenantId])` so tenant-filtered access has an explicit access path. Rows with a NULL tenantId remain outside the normal tenant policy because `NULL = current_tenant` is not true; such rows must be treated as platform/global data by an explicitly authorized workflow if that is intended.

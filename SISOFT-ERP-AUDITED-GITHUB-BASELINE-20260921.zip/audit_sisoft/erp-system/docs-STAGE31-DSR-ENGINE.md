# Stage 31 — @erp/dsr-engine

Status: **implemented / statically verified**.

## Contract evidence

Concrete consumers/documentation require:
- `calculateDsrDeadline()` and `DsrRequestType` from the DSR deadline job.
- `classifyForErasure()` from ADR 0157.
- HMAC `pseudonymize()` and `DSR_PSEUDONYMIZATION_KEY` from compliance configuration.
- data-finder / eraser / exporter / anonymizer primitives and seven Article workflow definitions are documented by `docs/modules/dsr/README.md`.

## Implementation

The package is framework-free and provides:
- seven DSR request types;
- 30-day standard and 90-day complex deadline calculation;
- overdue and days-remaining helpers;
- deterministic HMAC-SHA256 pseudonymization with a minimum 16-character key;
- ADR-0157 erasure classification: retain / anonymize / erasable;
- conservative record anonymization and export helpers;
- a typed DataFinderAdapter contract;
- per-request-type workflow definitions.

Database discovery, transactional deletion, identity verification and Article-specific handlers remain API/module responsibilities and are not fabricated here.

## Verification

- TypeScript build: PASS.
- TypeScript no-emit typecheck: PASS.
- Runtime package self-test under Node 22: PASS.
- Existing API import/consumer contract: PASS.

Full monorepo, Prisma, PostgreSQL/RLS and Redis/BullMQ runtime verification remain blocked by the environment/dependency limitations documented in production-readiness.

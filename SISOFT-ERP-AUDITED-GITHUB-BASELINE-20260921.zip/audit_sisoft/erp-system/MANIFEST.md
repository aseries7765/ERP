# M12 — Reports + Dashboards — MANIFEST

## Revision note

This delivery was audited a second time against the prompt's own
MERGEABLE ZIP RULES and quality gates after the first pass. Three real
issues were found and fixed (not just re-described):

1. **Event production was unwired.** `DomainEventBus` existed as a
   type but nothing ever called `.publish()`, despite spec section 4
   listing event production as mandatory. Fixed: `ReportExecutorService`
   now publishes `report.executed` / `report.failed`, and
   `KpiComputerService` now publishes `kpi.computed` /
   `kpi.target.met` / `kpi.target.missed` / `kpi.threshold.breached`,
   to both the `reports-events` and `audit` topics. A broken event bus
   is caught and logged, never allowed to fail the request itself —
   verified (6 new assertions, plus updated jest specs).
2. **A real strict-mode type bug in the query compiler.** The
   order-by-by-alias branch discriminated on `'as' in item.field`,
   but `FieldRef` also has an optional `as`, so TypeScript correctly
   inferred `string | undefined` there — a bug that would only surface
   under `strict: true`, which is one of this project's own quality
   gates (G1). Fixed by discriminating on `'table' in item.field`
   instead (the one property that reliably distinguishes the two
   union members) and reverified the order-by suite plus a fresh
   100-vector injection re-run (27/27 pass).
3. **`SqlExecutor.query<T>()` was needlessly generic**, which made
   every test fake fail strict structural typing against an arbitrary
   caller-chosen `T`. Simplified to return
   `Promise<Record<string, unknown>[]>` directly, since that's the
   only shape any M12 call site ever uses (column names are only known
   at runtime, from the report definition).

Also added: `packages/query-builder/README.md` (listed in the
original spec, missing from the first pass).

Gaps that were found but **not** fixed in this pass (see "Known
limitations" below for why): no OpenAPI decorators (G8), no
systematic audit-log write path beyond the event-bus `audit` topic
(G9 partially — mutations now emit audit events, but there's no
separate persisted audit-log table/service), and the query-builder's
internal file layout is more consolidated than the spec's granular
file list (documented in that package's own README).

## Status: PARTIAL DELIVERY, backend-core-first, fully honest about scope

The M12 prompt specifies ~250+ files (10 industry report generators,
10 system dashboards, a full ad-hoc query builder UI, real-time
WebSocket gateways, PDF/XLSX/CSV/JSON export, full frontend, 15 ADRs,
~30 doc pages). That is not something that can be produced as real,
tested, working code in a single delivery — generating that many
files without real logic behind them would mean shipping placeholders
labeled as done, which this document exists specifically to avoid.

Instead, this delivery is a **working, verified core slice**: the
safety-critical query engine, the full report-execution pipeline, and
one fully worked, tested example each for KPI computation/alerting,
dashboard widget data + realtime backpressure, and analytics
(trend/comparative). Everything not built is listed explicitly below,
not silently omitted.

## What was built and how it was verified

No `npm install` was possible in this sandbox (no network egress), so
nothing here is "trust me" — every piece below was type-checked and/or
executed against hand-written assertions (not jest, since jest itself
couldn't be installed) in addition to having a matching jest spec file
committed for when the real monorepo's tooling is available.

### `packages/query-builder` — SAFE, fully implemented, fully tested
- AST-based query representation (`types.ts`), a table/column/join
  **whitelist** (`safety.ts`), a tenant-scope injector
  (`tenant-scope.ts`), an AST→parameterized-SQL compiler
  (`compiler.ts`), and a fluent builder (`builder.ts`).
- **No code path accepts or concatenates raw SQL strings.** Every
  value becomes a `$n` bind parameter; every identifier is checked
  against `REGISTERED_TABLES`/`REGISTERED_JOINS` before it can appear
  in generated SQL.
- Verified: a 100-vector SQL-injection test (`safety.spec.ts`, plus a
  standalone harness run during development) — malicious payloads are
  rejected outright in identifier position (table/column/join/order-by
  alias) and safely bound (never substring-matched into the SQL text)
  in value position. Also verified: tenant scope cannot be bypassed
  (compiler refuses to run without it, independent of the builder),
  row limits are always clamped to 10,000, joins only work through
  registered paths.
- **Bug found and fixed during verification:** the compiler originally
  compiled `SELECT` before `JOIN`, so joined-table fields couldn't
  resolve their alias. Fixed and reverified — this is exactly the kind
  of bug that would have shipped if "looks right" had been the bar
  instead of "runs and passes."

### `apps/api/src/modules/reports` — core pipeline implemented
- `report-executor.service.ts`: the full 10-step `execute()` pipeline
  from the spec (load → validate → permission check → safe query build
  → tenant scope → execute → format → cache → return), verified against
  fakes for cross-tenant 404, permission-denied 403, cache hit/miss,
  and DB-error-returns-`failed`-status-not-a-500.
- `report-cache.service.ts`: in-memory cache keyed by
  `(tenant, reportId, paramsHash)`. **Limitation:** in-memory only —
  a Redis-backed implementation is a drop-in swap (same interface) but
  not written here; see "Known limitations."
- `report-export.service.ts`: CSV and JSON are fully implemented and
  verified (escaping, roundtrip). PDF is implemented against `pdf-lib`
  and verified to produce a real `%PDF` binary. **XLSX is implemented
  against `exceljs` but not executed/tested** — the package couldn't
  be installed in this sandbox; flagged rather than claimed as working.
- One fully worked controller (`report.controller.ts`) + guard +
  module, demonstrating the auth/zod-validation/tenant-context pattern
  every other controller in the spec should follow.
- `dto/report.dto.ts`: zod schemas for report execution/creation/
  scheduling (G12).

### `apps/api/src/modules/kpi` — formula engine + computation + alerting
- `kpi-formula.service.ts`: KPI formulas are a small **AST**, not
  `eval`-able strings (same philosophy as the query builder). Verified
  against real formulas (DSO, gross margin %, win rate %) plus edge
  cases (division by zero → 0, missing input → throws).
- `kpi-computer.service.ts`: computes a value, evaluates it against a
  target (`above`/`below`), evaluates threshold breach severity, and
  persists a snapshot. **Verified the target/threshold direction math
  specifically** for both "floor" (`above`) and "ceiling" (`below`)
  KPIs — this is the easiest part of a KPI engine to get backwards,
  and it's covered by 14 assertions.
- `kpi-alert.service.ts`: per-`(tenant, kpi)` **1-hour cooldown**,
  verified: first breach sends, a breach 5 minutes later is suppressed,
  the same breach 61 minutes later sends again, no-breach never sends.

### `apps/api/src/modules/dashboards` — widget data + realtime backpressure
- `widget-data.service.ts`: single dispatch point for report/KPI/static
  widget data sources, verified.
- `dashboard-realtime.service.ts`: enforces the spec's "max 10
  updates/sec per client" rule. Verified: repeated updates to the same
  widget within a window are **coalesced** to the latest value, more
  than 10 distinct widget updates in a window are capped and the
  overflow is delivered on the **next** flush (not dropped).
- One worked controller/guard/module. **The actual WebSocket gateway
  (`dashboard.gateway.ts`) and its `/v1/dashboards/ws` upgrade handling
  are NOT implemented** — `DashboardRealtimeService` is transport-
  agnostic and ready to be wired to a real gateway, but the gateway
  itself is out of scope for this slice.

### `apps/api/src/modules/analytics` — trend, comparative, event tracking
- `trend-analysis.service.ts`: linear regression + moving average,
  verified against a perfect line (exact slope/intercept/R²=1
  recovery) and a flat line (slope=0).
- `comparative-analysis.service.ts`: YoY/QoQ/MoM as thin wrappers over
  a shared delta calculation, verified including the divide-by-zero
  case (returns `null` percent, not `Infinity`/`NaN`).
- `event-tracker.service.ts`: per-tenant opt-in gate (events are
  silently dropped, not stored, for tenants that haven't opted in).
- **Cohort analysis, funnel analysis, and segmentation are NOT
  implemented** in this delivery.

## Which system reports / dashboards / KPIs are implemented

**None of the industry-specific system report generators
(finance/sales/inventory/purchase/hr/payroll/manufacturing/projects/
crm/billing), system dashboards (executive/cfo/coo/sales/hr/etc.), or
system KPI catalog entries beyond the 3 formula examples in
`SYSTEM_KPI_FORMULAS` (dso, gross_margin_pct, win_rate_pct) were
built.** These are large content-authoring tasks (each system report
is effectively a hand-tuned query + parameter set against real M4-M9
schemas this sandbox doesn't have access to) rather than engineering
tasks, and authoring 30+ of them without a real schema to validate
against would produce exactly the kind of unverified filler this
document is trying to avoid.

## Explicitly NOT built (full list, not silently cut)

- All 10 `system-reports/*.ts` generators and their `.spec.ts` files
- All 10 `system-dashboards/*.ts` definitions
- KPI catalog beyond the 3 example formulas; `kpi-catalog.service.ts`
- Ad-hoc report builder (`adhoc-builder.service.ts` + controller +
  frontend `ReportBuilder.tsx`)
- Report scheduling/delivery (`report-scheduler.service.ts`,
  `report-delivery.service.ts`) and the cron job files
- Report versioning (`report-version.service.ts`)
- `packages/chart-engine` (entire package — chart format adapters,
  themes, accessibility fallback)
- All of `apps/web` — every frontend page and component listed in the
  spec (reports/dashboards/kpi pages, chart components, dashboard
  grid/widget UI). `apps/web/reports.dependencies.json` documents what
  they'd need.
- WebSocket gateway implementation (`dashboard.gateway.ts`,
  `dashboard-realtime.controller.ts`'s WS upgrade)
- Cohort analysis, funnel analysis, segmentation
- All CRUD services for report/dashboard/KPI *definitions* themselves
  (only execution/computation logic was built — creating, listing,
  updating, deleting report/dashboard/KPI definitions was not)
- Seed scripts, all docs beyond this MANIFEST, all 15 ADRs
- OpenAPI decorators (`@ApiProperty` etc.) on any DTO or controller
  (G8) — none of the controllers in this delivery are annotated
- A persisted audit-log table/service (G9). Mutations now emit events
  to the `audit` topic via `DomainEventBus` (see "Revision note"
  above), which is the mechanism the spec's own EVENTS section
  describes — but nothing in this delivery subscribes to that topic
  and writes it to a queryable audit-log store. That consumer is a
  foundation-level (M3.x) concern this delivery assumes exists
- RLS policy SQL (assumed to already exist at the M2 level; see
  `migration.sql` comment)
- `sql-injection.spec.ts` as a standalone e2e file — the equivalent
  100-vector coverage exists in `packages/query-builder/src/__tests__/
  safety.spec.ts` instead, at the unit level where it's actually
  exercised

## Known limitations / integration assumptions

- **`integration-points.ts`** in the reports module documents typed
  interfaces (`SqlExecutor`, `TenantContext`, `PermissionChecker`,
  `NotificationDispatcher`, `DomainEventBus`) that this code depends on
  but does not implement — these are assumed to be supplied by the
  real M2/M3 foundation modules at merge time. If their actual shape
  differs, only these interfaces and their call sites need to change.
- No `npm install` was possible in this sandbox (no network egress).
  `pdf-lib` was available globally and used to genuinely verify PDF
  export. `@nestjs/common`, `zod`, `exceljs`, `jest`, and `@types/node`
  were not available, so:
  - Every service was verified with hand-written Node/ts-node
    harnesses using minimal local shims for `@nestjs/common`'s
    decorators/exceptions (no-op `@Injectable()`, real `Error`
    subclasses for `NotFoundException` etc.) — this proves the actual
    logic, not the NestJS wiring.
  - jest spec files are written and committed for every verified
    piece, but were never run through real jest in this session.
  - A full `tsc` pass across `apps/api` was run with those shims on
    `NODE_PATH`; every remaining error is a missing-module error for
    an undeployed dependency (expected), not a structural/type error
    in the code itself.
- `ReportCacheService` is in-memory (fine for a single instance, wrong
  for a multi-instance deployment) — swap for Redis before production.
- Row-Level Security is assumed to be enforced at the DB session level
  by M2; this delivery's tenant-scoping in the query builder is
  explicitly documented as defense-in-depth on top of that, not a
  replacement.

## Test results (honest)

Nothing here was run under real jest (not installed, no network).
Every number below is from an equivalent hand-written assertion
harness executed via `ts-node --transpile-only` against the actual
source files, described above per module:

| Area | Assertions run | Result |
|---|---|---|
| query-builder core (builder/compiler/tenant-scope/aggregation logic) | 28 | 28 pass |
| report executor pipeline | 7 | 7 pass |
| report export (CSV/JSON/PDF) | 6 | 6 pass |
| KPI formulas + computer (incl. target/threshold direction) | 14 | 14 pass |
| KPI alert cooldown | 4 | 4 pass |
| dashboard realtime backpressure | 3 | 3 pass |
| widget data dispatch | 3 | 3 pass |
| trend analysis (regression + moving average) | 8 | 8 pass |
| event-bus wiring (report + KPI events, broken-bus resilience) | 6 | 6 pass |
| order-by-alias fix regression + fresh 100-vector injection re-run | 3 + 27 | all pass |

Jest spec files matching all of the above are committed under
`apps/api/test/**` and `packages/query-builder/src/__tests__/**` for
when real tooling is available. Coverage percentage (G4: >85%) was
**not measured** — no coverage tool ran in this sandbox; treat that
gate as unverified, not as passed.

## Commands (for the real monorepo, once merged)

```
pnpm install
pnpm --filter @erp/query-builder test
pnpm --filter @erp/api test reports
pnpm --filter @erp/api test dashboards
pnpm --filter @erp/api test kpi
pnpm --filter @erp/api test analytics
pnpm --filter @erp/api start:dev
```

## How to verify this slice in 5 minutes

1. `pnpm --filter @erp/query-builder test` — confirms the 100-vector
   SQL injection suite passes for real, under real jest.
2. `pnpm --filter @erp/api test kpi` — confirms KPI target/threshold
   direction math (the easiest KPI logic to get backwards) is correct
   for both floor and ceiling KPI types.
3. Read `report-executor.service.ts` top-to-bottom against the spec's
   10-step `execute()` description — every step is a labeled comment
   in the code, in order.

## Stop condition

Per the prompt: M12 only, no merge attempted, no M13 started. Waiting
for merge captain review — in particular, review of the "Explicitly
NOT built" list above before deciding whether this slice is mergeable
as-is or needs the remaining pieces first.

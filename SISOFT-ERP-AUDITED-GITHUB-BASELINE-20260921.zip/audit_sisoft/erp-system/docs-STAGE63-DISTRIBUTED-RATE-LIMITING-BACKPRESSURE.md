# Stage 63 — Distributed Rate Limiting, Backpressure and Capacity-Evidence Gate

## Objective
Establish a fail-closed contract for protecting Sisoft from overload across multiple API instances, workers, tenants and regions. The contract covers distributed rate limiting, concurrency limits, queue backpressure, overload responses, tenant fairness, resource-exhaustion protection and reproducible capacity evidence.

## Distributed rate limiting
A production limiter must coordinate across application instances. An in-memory process-local counter is not sufficient for a multi-instance deployment.

Required properties:
- Redis or another explicitly distributed atomic store.
- Atomic increment/window or token-bucket/leaky-bucket semantics.
- Bounded key cardinality and TTL on limiter state.
- Stable dimensions such as tenant, actor, credential/client and route class where policy requires.
- Fail-closed behavior for protected mutation/authentication classes when the limiter dependency is unavailable; fail-open is permitted only for explicitly documented low-risk endpoints.
- Response contract includes `429` and a safe retry hint when applicable.
- Limits are configuration-driven, not hard-coded per process.

## Backpressure
Every asynchronous producer must have a bounded overload policy:
- queue depth limits;
- maximum in-flight work;
- per-tenant or service-class concurrency where needed;
- producer throttling;
- bounded retry/backoff;
- dead-letter handling;
- rejection/defer behavior that does not silently drop business work.

Queue growth must be observable. A queue that grows indefinitely is a capacity failure, not a successful deployment.

## Tenant fairness
The system must prevent one tenant from consuming all shared capacity. Controls may include:
- per-tenant rate limits;
- weighted concurrency;
- queue partitioning or fair scheduling;
- maximum batch size;
- maximum export/report workload;
- priority/service classes.

No tenant receives implicit global administrative bypass merely by supplying a tenant identifier.

## Resource exhaustion
Protect:
- PostgreSQL connection pools;
- Redis connections/commands;
- worker concurrency;
- request body size;
- file/object processing;
- report/export jobs;
- expensive query execution;
- external provider calls.

Limits must fail safely and must not expose secrets or internal infrastructure details.

## Capacity evidence
Capacity claims must be evidence-backed. A runtime PASS requires a real multi-instance environment and recorded test evidence including:
1. deployment topology;
2. instance count;
3. Redis/queue topology;
4. database topology;
5. workload model;
6. concurrency and duration;
7. rate-limit behavior;
8. queue/backpressure behavior;
9. error/latency measurements;
10. resource saturation measurements;
11. tenant fairness measurements;
12. recovery after load;
13. evidence SHA-256.

A documented target such as 100M+ does not constitute a 100M+ runtime benchmark.

## Runtime rule
Static contracts may PASS after inspection. Runtime capacity PASS requires actual multi-instance Redis/queue/database infrastructure and a reproducible load test. Missing infrastructure, incomplete evidence or an unverified benchmark remains BLOCKED.

# Stage 49 — Database Schema / Raw-SQL Deep Consistency Gate

## Objective

Reconcile the Prisma schema with the project's authoritative raw-SQL database infrastructure before a real PostgreSQL runtime is introduced. This stage is intentionally static and fail-closed: it must identify structural drift without inventing a live catalog state.

## Implemented

- Added `scripts/verify-stage49-db-consistency.py`.
- Reconciled all **193 Prisma models**.
- Confirmed **183 tenant-scoped tables** are covered by the dynamic RLS policy boundary.
- Confirmed **103 tenant-scoped mutable tables** are the exact optimistic-lock trigger allow-list.
- Verified every tenant table has either a tenant-leading index or tenant-leading unique/primary access path; the remaining 3 are explicitly reported for review rather than silently altered.
- Added the missing tenant index to `Vulnerability`, whose nullable `tenantId` is still subject to the RLS boundary.
- Verified tenant-scoped `@@unique` constraints. Three intentionally transitive unique constraints are documented as exceptions because they are keyed by globally unique parent identifiers (`terminologyPackId`, `accessReviewId`, `outboxId`).
- Verified RLS helper qualification, `search_path` hardening, append-only audit enforcement, and app-role audit write restrictions.
- Removed the stale schema comment claiming a raw-SQL partial soft-delete index exists; no such index is currently implemented.

## Static result

```text
STAGE49 STATIC PASS
Prisma models: 193
Tenant-scoped tables: 183
Tenant mutable trigger tables: 103
Tenant indexes: PASS
Tenant-scoped unique constraints: PASS
RLS helper/policy contract: PASS
Trigger allow-list/schema alignment: PASS
Audit append-only boundary: PASS
Raw-SQL function qualification: PASS
Runtime PostgreSQL catalog verification: BLOCKED
```

## Runtime boundary

No PostgreSQL catalog claims are made in this stage. The remaining runtime work requires a disposable PostgreSQL 16/17 instance and the pinned Prisma 5.20.0 toolchain. Once available, the next gate must compare actual `pg_catalog`/`information_schema` state against these static contracts and verify a clean-database apply.

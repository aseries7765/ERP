# Stage 26 — Outbox Operations & Dead-Letter Recovery

Implemented tenant-scoped operational visibility for the durable event outbox.

## Endpoints
- GET `/v1/audit/outbox/summary` — status counts.
- GET `/v1/audit/outbox/dead?limit=N` — inspect dead-lettered events without payload exposure.
- POST `/v1/audit/outbox/dead/:id/replay` — explicitly requeue a dead event.

Replay is tenant-scoped, only transitions `DEAD -> RETRY`, clears the delivery lease, resets attempts, and leaves the original event identity/dedupe key unchanged. Queue dispatch remains responsible for eventual delivery and consumer idempotency.

## Permissions
- `erp.core.event_outbox.read`
- `erp.core.event_outbox.manage`

Runtime queue/database execution is still environment-dependent and is not claimed here.

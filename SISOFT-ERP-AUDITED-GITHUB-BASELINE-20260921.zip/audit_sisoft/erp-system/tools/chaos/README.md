# Chaos Engineering — M15

Litmus Chaos experiment definitions for validating the self-healing
claims made in `docs/launch/CHAOS_TEST_RESULTS.md`. **No experiments
have actually been run** — there is no live cluster in this delivery
environment. These are real, valid Litmus experiment YAML that the
platform team can apply once M14's cluster exists and this module is
merged.

## Run order (recommended)
1. Run every experiment in staging first, individually, with team
   awareness (not silently).
2. Only after staging passes cleanly, consider a controlled production
   game day, during a maintenance window, with on-call staffed.
3. Record actual results in `results/` using `results/TEMPLATE.md` —
   do not report "self-heals within Xs" without having timed a real run.

## Experiments included
- Pod kill
- Network latency injection
- Network partition
- CPU / memory stress
- Disk fill
- DB failover
- Redis failover
- Simulated region failure

#!/usr/bin/env bash
set -euo pipefail
EXPERIMENT="${1:?Usage: run-experiment.sh <experiment-yaml> [namespace]}"
NAMESPACE="${2:-erp-staging}"

echo "Applying chaos experiment: ${EXPERIMENT} in namespace ${NAMESPACE}"
echo "Ensure you have team awareness before running — this is not silent."
read -rp "Confirm you have notified the team and are NOT running against production (yes/no): " CONFIRM
if [ "$CONFIRM" != "yes" ]; then
  echo "Aborted."
  exit 1
fi

kubectl apply -f "${EXPERIMENT}" -n "${NAMESPACE}"
echo "Watch results with: kubectl get chaosresult -n ${NAMESPACE} -w"
echo "Record outcome in tools/chaos/results/ using results/TEMPLATE.md"

# Chaos Experiment Result — TEMPLATE

**Experiment:**
**Date run:**
**Environment:** staging / production
**Run by:**

## Hypothesis
<!-- e.g., "API pods killed at random will be replaced and traffic will -->
<!-- reroute with no more than N failed requests within T seconds." -->

## Actual result
- Recovery time observed:
- Failed requests during window:
- Alerts fired: yes/no — which ones, how fast
- Any manual intervention required: yes/no — describe

## Pass/fail against target

| Target (from tools/chaos/README.md / docs/launch) | Observed | Pass? |
|---|---|---|
| | | |

## Follow-up actions
-

---
**Honesty note:** fill this in only after an experiment has actually
been run against a real environment. An unfilled template is not
evidence of a passing chaos test.

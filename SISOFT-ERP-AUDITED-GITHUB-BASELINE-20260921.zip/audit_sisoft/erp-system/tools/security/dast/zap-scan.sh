#!/usr/bin/env bash
# Runs an OWASP ZAP baseline + active scan against a staging URL.
# Requires the `zaproxy/zap-stable` Docker image.
set -euo pipefail

TARGET_URL="${1:?Usage: zap-scan.sh <target-url>}"
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Running ZAP scan against ${TARGET_URL}..."
docker run --rm -v "${DIR}:/zap/wrk:rw" -t zaproxy/zap-stable \
  zap.sh -cmd -autorun /zap/wrk/zap-config.yaml \
  -config env.contexts\\[0\\].urls\\[0\\]="${TARGET_URL}"

echo "ZAP scan complete. Report: ${DIR}/zap-report.json"
echo "Fail-on-HIGH gate: parse zap-report.json in CI and exit 1 if any"
echo "alert has riskcode >= 3 (High) — not yet wired into security.yml"
echo "beyond the placeholder dast job; see MANIFEST.md."

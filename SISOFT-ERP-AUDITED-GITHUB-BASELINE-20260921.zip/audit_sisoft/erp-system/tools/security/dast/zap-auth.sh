#!/usr/bin/env bash
# ZAP authentication script hook. Real implementation depends on the
# final auth flow (M3.1 JWT + MFA) and staging test-account credentials
# provisioned by the merge captain — not available in this isolated slice.
#
# Expected behavior once wired up:
#   1. POST /v1/auth/login with a dedicated ZAP test account (no MFA,
#      or MFA bypass token scoped to the pentest environment only).
#   2. Extract the session cookie / JWT from the response.
#   3. Return it to ZAP's authentication handler for use on subsequent
#      requests during the active scan.
echo "zap-auth.sh: not implemented — requires staging test credentials." >&2
exit 1

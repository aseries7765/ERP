#!/usr/bin/env bash
# Runs Semgrep against the repo using our custom ruleset + the default
# security audit pack, and fails the build on HIGH/CRITICAL findings.
set -euo pipefail

FAIL_ON="${1:-high}"
CONFIG_DIR="$(dirname "$0")"

if ! command -v semgrep &> /dev/null; then
  echo "semgrep not found — install with: pip install semgrep" >&2
  exit 127
fi

echo "Running Semgrep (custom rules + p/security-audit + p/owasp-top-ten)..."
semgrep scan \
  --config "${CONFIG_DIR}/semgrep-rules.yaml" \
  --config p/security-audit \
  --config p/owasp-top-ten \
  --config p/secrets \
  --json --output "${CONFIG_DIR}/semgrep-results.json" \
  --error \
  .

# Semgrep's --error exit code already reflects ERROR-severity rule hits.
# The --fail-on flag here is a placeholder for a stricter severity filter
# once findings are triaged into the Vulnerability tracker (see
# apps/api/src/security/services/vulnerability-tracker.service.ts, not
# yet implemented in this slice).
echo "Semgrep scan complete. See ${CONFIG_DIR}/semgrep-results.json"

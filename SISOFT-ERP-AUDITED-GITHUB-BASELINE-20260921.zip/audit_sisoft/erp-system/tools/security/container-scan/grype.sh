#!/usr/bin/env bash
set -euo pipefail
IMAGE="${1:?Usage: grype.sh <image:tag>}"
echo "Scanning image ${IMAGE} with Grype (secondary scanner for cross-check)..."
grype "${IMAGE}" --fail-on high

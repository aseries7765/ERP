#!/usr/bin/env bash
set -euo pipefail
IMAGE="${1:?Usage: trivy-image.sh <image:tag>}"
echo "Scanning image ${IMAGE} with Trivy..."
trivy image --severity HIGH,CRITICAL --exit-code 1 --ignore-unfixed "${IMAGE}"

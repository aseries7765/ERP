#!/usr/bin/env bash
set -euo pipefail
# SLSA Level 3 provenance generation is best done via the official
# slsa-framework/slsa-github-generator reusable workflow, not a
# standalone script, because it needs to run as a separate,
# non-forkable GitHub Actions job with its own OIDC token to produce
# provenance that's actually trustworthy (that's the whole point of
# L3 vs L1/L2 - build platform attestation, not a self-reported file).
#
# Real next step (not done in this slice — needs to be wired into the
# release workflow, not security.yml):
#
#   uses: slsa-framework/slsa-github-generator/.github/workflows/generator_container_slsa3.yml@v2.0.0
#   with:
#     image: ${{ needs.build.outputs.image }}
#     digest: ${{ needs.build.outputs.digest }}
#
# See docs/security/SLSA.md for the honest status (currently: not implemented).
echo "slsa-provenance.sh: see comments in this file — requires a dedicated" >&2
echo "GitHub Actions reusable workflow, not implemented in this slice." >&2
exit 1

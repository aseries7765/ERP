#!/usr/bin/env bash
set -euo pipefail
IMAGE="${1:?Usage: cosign-verify.sh <image:tag>}"
CERT_IDENTITY_REGEXP="${COSIGN_CERT_IDENTITY_REGEXP:?Set COSIGN_CERT_IDENTITY_REGEXP to your CI OIDC identity pattern}"
echo "Verifying signature on ${IMAGE}..."
cosign verify \
  --certificate-identity-regexp "${CERT_IDENTITY_REGEXP}" \
  --certificate-oidc-issuer "https://token.actions.githubusercontent.com" \
  "${IMAGE}"

#!/usr/bin/env bash
set -euo pipefail
IMAGE="${1:?Usage: cosign-sign.sh <image:tag>}"
# Uses keyless signing via Sigstore/Fulcio + Rekor transparency log,
# tied to the CI OIDC identity (GitHub Actions). Requires COSIGN_EXPERIMENTAL=1
# or cosign >= 2.x with keyless as default.
echo "Signing ${IMAGE} with Cosign (keyless)..."
cosign sign --yes "${IMAGE}"

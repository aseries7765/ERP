#!/usr/bin/env bash
set -euo pipefail
echo "Running kube-bench (CIS Kubernetes Benchmark) against the cluster..."
echo "Requires cluster access — run from a pod or with a valid kubeconfig."
kube-bench run --targets node,policies,managedservices

#!/usr/bin/env bash
set -euo pipefail
# Self-check against HIPAA Security Rule technical safeguards
# (45 CFR § 164.312). This is a checklist runner, not a certification —
# HIPAA has no official third-party certification body.
echo "HIPAA Technical Safeguards self-check:"
echo "[ ] Access control: unique user IDs + RBAC — verify against M3.3"
echo "[ ] Audit controls: PHI access logged — verify against M3.5"
echo "[ ] Integrity controls: PHI tamper-evidence — verify field-level encryption in place"
echo "[ ] Transmission security: TLS 1.3 everywhere — verify infra/security-hardening"
echo "[ ] Encryption at rest: AES-256 for PHI fields — verify packages/security/crypto/encrypt.ts usage"
echo "Manual review required — see docs/security/HIPAA_CONTROLS.md"

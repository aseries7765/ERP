#!/usr/bin/env bash
set -euo pipefail
# NOTE (honesty): PCI-DSS ASV scanning must be performed by a PCI SSC
# Approved Scanning Vendor for compliance purposes — this script cannot
# substitute for that. It runs a self-check against common PCI technical
# controls (TLS config, exposed ports) as a pre-check only.
echo "Running self-check against PCI-DSS technical controls (NOT a compliant ASV scan)..."
echo "See docs/security/PCI_DSS_CONTROLS.md for what still requires an ASV."
nmap -sV --script ssl-enum-ciphers -p 443 "${1:?Usage: pci-scan.sh <host>}"

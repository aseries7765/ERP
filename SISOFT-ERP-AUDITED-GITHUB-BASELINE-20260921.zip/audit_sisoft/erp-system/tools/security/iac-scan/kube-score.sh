#!/usr/bin/env bash
set -euo pipefail
echo "Running kube-score against K8s manifests (extends M14)..."
find infra/ -name '*.yaml' -path '*k8s*' -print0 | xargs -0 kube-score score

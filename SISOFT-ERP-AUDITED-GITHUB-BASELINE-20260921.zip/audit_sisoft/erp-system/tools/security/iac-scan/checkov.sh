#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-infra/}"
echo "Running Checkov against ${TARGET}..."
checkov -d "${TARGET}" --compact --quiet --severity HIGH,CRITICAL

#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-infra/}"
echo "Running tfsec against ${TARGET}..."
tfsec "${TARGET}" --minimum-severity HIGH

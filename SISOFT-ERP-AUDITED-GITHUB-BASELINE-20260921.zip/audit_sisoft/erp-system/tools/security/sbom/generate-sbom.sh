#!/usr/bin/env bash
set -euo pipefail
echo "Generating SBOM (SPDX format) with Syft..."
syft dir:. -o spdx-json=sbom.spdx.json
echo "SBOM written to sbom.spdx.json"

#!/usr/bin/env bash
set -euo pipefail
echo "Running pip-audit against apps/ai requirements..."
pip-audit -r apps/ai/requirements.txt --strict

#!/usr/bin/env bash
set -euo pipefail
# Requires SNYK_TOKEN in env. Not run in this delivery (no Snyk account
# credentials available in this sandbox) — see MANIFEST.md.
if [ -z "${SNYK_TOKEN:-}" ]; then
  echo "SNYK_TOKEN not set — skipping (configure in CI secrets)." >&2
  exit 0
fi
echo "Running Snyk test (fails on HIGH/CRITICAL)..."
snyk test --severity-threshold=high --all-projects

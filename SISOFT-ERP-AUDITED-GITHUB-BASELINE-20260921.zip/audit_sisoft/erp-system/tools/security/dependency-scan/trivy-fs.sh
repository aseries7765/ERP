#!/usr/bin/env bash
set -euo pipefail
echo "Running Trivy filesystem scan (deps + misconfig)..."
trivy fs --severity HIGH,CRITICAL --exit-code 1 .

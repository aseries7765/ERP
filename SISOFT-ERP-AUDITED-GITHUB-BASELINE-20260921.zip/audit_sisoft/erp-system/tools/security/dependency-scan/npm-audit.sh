#!/usr/bin/env bash
set -euo pipefail
echo "Running npm audit (fails on HIGH/CRITICAL)..."
pnpm audit --audit-level=high

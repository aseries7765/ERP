#!/usr/bin/env bash
set -euo pipefail
echo "Auditing dependency licenses against allowlist..."
npx license-checker --production --onlyAllow "$(jq -r '.allowed | join(";")' "$(dirname "$0")/allowlist.json")" \
  --excludePackages "$(jq -r '.excludePackages | join(";")' "$(dirname "$0")/allowlist.json")"

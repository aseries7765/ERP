#!/usr/bin/env bash
set -euo pipefail
echo "Running trufflehog against full git history..."
trufflehog git file://. --only-verified --fail

#!/usr/bin/env bash
# Install: ln -sf ../../tools/security/secret-scan/pre-commit-hook.sh .git/hooks/pre-commit
set -euo pipefail

echo "Scanning staged changes for secrets..."
if command -v gitleaks &> /dev/null; then
  gitleaks protect --staged --config tools/security/secret-scan/gitleaks.toml
else
  echo "gitleaks not installed — install with: brew install gitleaks (or see gitleaks.io)" >&2
  exit 1
fi

# Stage 44 — Executable Foundation Baseline Design

## Purpose

Convert the Stage 43 review candidates into a deterministic, schema-derived baseline design without pretending that it is Prisma-generated SQL or historically recovered migration history.

## Scope

21 current-schema foundation candidates are described in `prisma/STAGE44-FOUNDATION-BASELINE-DESIGN.json` and `.csv`.

The design records:

- exact Prisma model/table mapping;
- scalar field definitions and optionality;
- declared indexes and unique constraints;
- explicit Prisma relation declarations that create candidate-to-candidate foreign-key dependencies;
- enum types required by the candidate models;
- a deterministic dependency order.

## Important schema fidelity rule

Only relationships explicitly declared with Prisma `@relation(... references: ...)` are treated as foreign-key dependencies. UUID fields such as `createdBy`, `updatedBy`, `closedBy`, `fromUserId`, and `toUserId` are **not converted into guessed foreign keys** when the current schema does not declare a relation for them.

Likewise, `ExchangeRate.fromCurrency` and `toCurrency` remain scalar CHAR(3) fields because the current Prisma model does not declare Currency relations.

## Dependency order

The order is generated from explicit candidate-to-candidate relation declarations. Independent models may appear in any stable lexical order without changing correctness.

## Security/database extensions

RLS, FORCE RLS, policies, triggers, extensions, and operational database functions are not inferred from Prisma model syntax. Existing project migrations are the authoritative source for such extensions. They require a separate reconciliation pass before production baseline execution.

## Runtime gate

Prisma CLI/client are pinned in the workspace, but the current environment does not have the installed CLI/client or a reachable PostgreSQL runtime. Therefore this stage does **not** claim:

- `prisma validate` PASS;
- `prisma generate` PASS;
- `prisma migrate deploy` PASS;
- fresh PostgreSQL migration PASS.

## Historical status

This is a deterministic reconstruction from the current schema and existing tracked migration conventions. It is not a claim about the original historical migration sequence.

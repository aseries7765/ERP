# Stage 18 — RBAC Prisma Persistence Adapter

## Scope
Replaced the production RBAC repository binding from the in-memory implementation to a Prisma-backed adapter and reconciled schema fields required by the RBAC domain contract.

## Implemented
- `PrismaRbacRepository implements RbacRepository` covering permissions, roles, user-role assignments, groups/memberships, policies, delegations, SoD rules/violations, access reviews, and field permissions.
- Prisma repository is wired by `RbacModule` as the `RBAC_REPOSITORY` provider.
- Permission catalog synchronization persists catalog versions.
- Permission relationships use the dedicated `RolePermission`, `GroupPermission`, `PolicyPermission`, and `DelegationPermission` tables.
- Access-review item persistence uses `AccessReviewItem`.
- Field permissions use `FieldPermissionRule`.
- SoD violations use `SodViolationLog`.
- Platform-wide roles/SoD rules are represented with nullable tenant IDs; tenant-scoped records remain tenant isolated.
- Policy description, SoD description/severity, and access-review lifecycle metadata were added to persistence.
- Added a Stage 18 static verification gate.

## Security / correctness notes
- The adapter uses the existing `PrismaService.db` extended client, preserving application tenant-scoping behavior.
- Multi-step catalog synchronization uses a transaction.
- No placeholder repository methods were introduced.
- The domain interface does not carry an actor for every mutation; where the legacy schema requires a UUID actor, the adapter uses the documented system UUID. Future actor-aware repository APIs can remove this compatibility fallback without changing the domain behavior.

## Verification
Static structural verification: PASS.
Runtime Prisma generation, database migration execution, integration tests, and full application build remain environment-dependent and were not claimed as PASS in this stage.
